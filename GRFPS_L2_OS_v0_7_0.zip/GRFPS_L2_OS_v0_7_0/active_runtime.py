"""One owner, one asynchronous sensor worker, local HTTP compositor."""
import argparse,copy,json,queue,subprocess,sys,threading,time,webbrowser
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from grfps_l2 import canon,loads,require
from adapters import MonotonicClock
from live import server_for
from active_atlas import ActiveJournal,config,replay
from run_map_demo import world

class ActiveService:
    def __init__(self,engine,clock=None,runner=None):
        self.engine=engine;self.clock=clock or MonotonicClock(engine.machine.mapper.at)
        self.lock=threading.Lock();self.current=engine.machine.snapshot();self.error=None
        self.commands=queue.Queue(16);self.command_results=deque(maxlen=16)
        self.pool=ThreadPoolExecutor(max_workers=1);self.future=None;self.stop_reason=None;self.runner=runner or self.measure
    def now(self):return max(self.clock.now(),self.engine.machine.mapper.at)
    def measure(self,r):
        try:
            timeout=max(.001,(r['deadline']-self.now())/1000)
            p=subprocess.run([sys.executable,str(Path(__file__).with_name('active_worker.py')),self.engine.machine.config['world']],
                input=canon(dict(request=r,start_ns=self.clock.start_ns,offset=self.clock.offset)),capture_output=True,timeout=timeout)
            require(p.returncode==0 and len(p.stdout)<=262144,'worker_protocol');patch=loads(p.stdout)
            return dict(kind='patch',at=self.now(),exposure_ref=r['exposure_ref'],patch=patch)
        except subprocess.TimeoutExpired:
            return dict(kind='fail',at=max(self.now(),r['deadline']+1),request=r['id'],reason='TIMEOUT')
        except (OSError,ValueError):return dict(kind='fail',at=self.now(),request=r['id'],reason='ERROR')
    def commit(self,e):
        self.engine.commit(e)
        with self.lock:self.current=self.engine.machine.snapshot()
    def updates(self,cursor=None,state_digest=None):
        with self.lock:
            return dict(kind='reset',snapshot=copy.deepcopy(self.current),error=self.error)
    def enqueue(self,c):
        require(type(c) is dict and c.get('kind') in ['pause','frame','stop'],'control')
        require(set(c)==({'kind','paused'} if c['kind']=='pause' else {'kind'}),'control_fields')
        if c['kind']=='pause':require(type(c['paused']) is bool,'pause_type')
        require(self.current['phase']=='RUNNING' and not self.error,'stopped');self.commands.put_nowait(copy.deepcopy(c))
    def cycle(self):
        m=self.engine.machine
        if m.phase=='STOPPED':return False
        if m.seq>=m.config['max_events']-4:self.stop_reason='capacity'
        if not self.stop_reason:
            for _ in range(16):
                if self.engine.machine.seq>=m.config['max_events']-4:self.stop_reason='capacity';break
                try:c=self.commands.get_nowait()
                except queue.Empty:break
                try:
                    if c['kind']=='stop':self.stop_reason='user'
                    else:self.commit(dict(c,at=self.now()))
                    self.command_results.append(dict(command=c,status='COMMITTED' if c['kind']!='stop' else 'DRAINING'))
                finally:self.commands.task_done()
                if self.stop_reason:break
        if self.future:
            if self.future.done():
                e=self.future.result();e['at']=max(e['at'],self.now(),self.engine.machine.mapper.at)
                try:self.commit(e)
                except ValueError:
                    r=self.engine.machine.mapper.pending
                    self.commit(dict(kind='fail',at=self.now(),request=r['id'],reason='ERROR'))
                self.future=None
            else:
                # Ticks remain active during a blocked sensor so evidence can expire.
                if not self.stop_reason:self.commit(dict(kind='tick',at=self.now()))
                return True
        if self.stop_reason:
            self.commit(dict(kind='stop',at=max(self.now(),self.engine.machine.mapper.at),reason=self.stop_reason));return False
        self.commit(dict(kind='tick',at=self.now()))
        p=self.engine.machine.plan()
        if p:
            self.commit(dict(kind='dispatch',at=self.engine.machine.mapper.at,proposal=p))
            self.future=self.pool.submit(self.runner,copy.deepcopy(self.engine.machine.mapper.pending))
        return True
    def close(self):self.pool.shutdown(wait=True);self.engine.close()


def html(data):
    return Path(__file__).with_name('active_viewer.html').read_text().replace('__MAP_DATA__',json.dumps(data,ensure_ascii=True).replace('<','\\u003c'))
def export(path,target):
    r=replay(path);Path(target).write_text(html(dict(mode='replay',views=r['views'],events=r['events'],head=r['head'])))
    return dict(transitions=r['machine'].seq,spent=r['machine'].mapper.spent,head=r['head'],state_digest=r['machine'].snapshot()['state_digest'])
def fixture():
    w=world();w['windows']['bridge']=dict(landmarks=['C','D','E','F'],pose=[3,3,7],boundary=['C','D','E','F']);return w

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='active_run');p.add_argument('--resume',action='store_true');p.add_argument('--duration',type=float,default=15);p.add_argument('--open',action='store_true');a=p.parse_args()
    require(0<a.duration<=3600,'duration')
    d=Path(a.out).resolve()
    if a.resume:
        e=ActiveJournal.reopen(d/'active.jsonl');offset=e.machine.mapper.at+e.machine.mapper.config['ttl']+1;e.commit(dict(kind='resume',at=offset));clock=MonotonicClock(offset)
    else:
        d.mkdir(parents=True,exist_ok=False);f=d/'world.json';f.write_text(json.dumps(fixture(),indent=2));e=ActiveJournal(d/'active.jsonl',config(f));clock=MonotonicClock()
    service=ActiveService(e,clock);server=server_for(service,html_factory=lambda _:html(dict(mode='live',views=[service.current],events=[])))
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();url=f'http://127.0.0.1:{server.server_port}/';print(url,flush=True)
    if a.open:webbrowser.open(url)
    end=time.monotonic()+a.duration
    try:
        while True:
            if time.monotonic()>=end:service.stop_reason='duration'
            if not service.cycle():break
            time.sleep(.04)
    except KeyboardInterrupt:
        service.stop_reason='user'
        while service.cycle():time.sleep(.04)
    finally:server.shutdown();server.server_close();thread.join();service.close()
    print(json.dumps(export(d/'active.jsonl',d/'replay.html'),indent=2))
if __name__=='__main__':main()
