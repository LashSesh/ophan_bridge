"""Fixed model-scope adapter: field length must match registration range."""
import json,sys,time
from pathlib import Path
from grfps_l2 import loads,fields,require
from field_world import measure,world_ref
try:
    request=loads(sys.stdin.buffer.readline(8193));fields(request,'path sectors query sector exposure')
    with Path(request['path']).open('rb') as f:raw=f.read(65537)
    require(len(raw)<=65536,'bytes');w=loads(raw)
    require(w['sectors']==request['sectors'] and w['depth']==int(sys.argv[1]),'model_scope')
    r=measure(w,request['query'],request['sector']);r.update(sampled_ns=time.monotonic_ns(),sample_ref=world_ref(w),exposure=request['exposure'],detail='registered_model_scope')
except Exception:r=dict(outcome='ERROR',value=None,sampled_ns=None,sample_ref=None,exposure=None,detail='scope_or_input_error')
sys.stdout.write(json.dumps(r)+'\n')
