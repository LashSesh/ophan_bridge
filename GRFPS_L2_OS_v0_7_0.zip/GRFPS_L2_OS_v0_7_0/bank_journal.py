"""Streaming semantic replay; retired payloads remain in sealed transition outputs."""
import json
from pathlib import Path
from grfps_l2 import canon,loads,require
from map_runtime import MapJournal,MAX_LINE
from organ_bank import OrganBank,PROFILE,seal

def header(c):return dict(profile=PROFILE,config=c,initial=OrganBank(c).snapshot()['state_digest'])
def record(m,e,parent):
    n,out=m.reduce(e);r=dict(profile=PROFILE,sequence=m.seq,parent=parent,event=e,pre=m.snapshot()['state_digest'],post=n.snapshot()['state_digest'],output=out)
    return n,dict(r,digest=seal('Transition',r))
def replay(path,collect=False,resolve=None):
    found=[];views=[];events=[]
    with Path(path).open('rb') as f:
        def line():
            b=f.readline(MAX_LINE+1);require(len(b)<=MAX_LINE and (not b or b.endswith(b'\n')),'journal_line');return loads(b) if b else None
        h=line();require(type(h) is dict and 'config' in h and canon(h)==canon(header(h['config'])),'header_semantics')
        m=OrganBank(h['config']);head=seal('Header',h)
        if collect:views.append(m.snapshot())
        while (r:=line()) is not None:
            n,expected=record(m,r['event'],head);require(canon(r)==canon(expected),'record_semantics');m=n;head=r['digest']
            if collect:views.append(m.snapshot());events.append(r['event'])
            if resolve:
                found.extend(x for x in r['output'].get('archived',[]) if x['ref']==resolve)
    return dict(machine=m,head=head,views=views,events=events,resolved=found)

class BankJournal(MapJournal):
    def __init__(self,path,c):
        self.path=Path(path);self.machine=OrganBank(c);self.failed=False;h=header(c);self.head=seal('Header',h);self.stream=self.path.open('xb')
        try:self._write(h)
        except BaseException:self.stream.close();raise
    def commit(self,e):
        require(not self.failed,'writer_failed');n,r=record(self.machine,e,self.head)
        try:self._write(r)
        except BaseException:self.failed=True;raise
        self.machine=n;self.head=r['digest'];return n.snapshot()
    @classmethod
    def reopen(cls,path):
        r=replay(path);j=cls.__new__(cls);j.path=Path(path);j.machine=r['machine'];j.head=r['head'];j.failed=False;j.stream=j.path.open('ab');return j
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('journal');p.add_argument('--resolve');a=p.parse_args();r=replay(a.journal,resolve=a.resolve)
    print(json.dumps(dict(head=r['head'],archive=r['machine'].archive,resolved=r['resolved']),indent=2))
