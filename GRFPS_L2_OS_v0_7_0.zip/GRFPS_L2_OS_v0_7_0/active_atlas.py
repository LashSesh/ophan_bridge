"""Active atlas organ: evidence-driven aperture selection and bounded lifecycle."""
import copy
from pathlib import Path
from grfps_l2 import canon, fields, ident, require, uint, loads
from mapping import MapMachine, config_default, hashof
from map_runtime import MapJournal, MAX_LINE

PROFILE='grfps-active-atlas/0.5.0'

def config(world):
    c=config_default();c.update(ttl=1500,timeout=600,budget=16,max_events=4096)
    return dict(profile=PROFILE,world=str(Path(world).resolve()),atlas=c,refresh=700,max_events=1024,
                routes=[dict(window='left',anchors=[]),dict(window='right',anchors=['B','C']),
                        dict(window='bridge',anchors=['C','D']),dict(window='island',anchors=['E','F'])])

def seal(kind,x):return hashof(kind,dict(profile=PROFILE,value=x))

class ActiveAtlas:
    def __init__(self,c):
        fields(c,'profile world atlas refresh max_events routes');canon(c)
        require(c['profile']==PROFILE and type(c['world']) is str and 0<len(c['world'])<=1024,'profile_world')
        require(uint(c['refresh']) and 0<c['refresh']<c['atlas']['ttl'],'refresh')
        require(uint(c['max_events']) and 8<=c['max_events']<=2000 and c['atlas']['max_events']>=2*c['max_events'],'event_limits')
        require(type(c['routes']) is list and 1<=len(c['routes'])<=16,'routes')
        seen=set()
        for r in c['routes']:
            fields(r,'window anchors');require(ident(r['window']) and r['window'] not in seen,'window')
            require(type(r['anchors']) is list and all(ident(k) for k in r['anchors']) and len(set(r['anchors']))==len(r['anchors']) and len(r['anchors'])<=32,'anchors')
            require(not r['anchors'] or len(r['anchors'])>=2,'anchors_minimum');seen.add(r['window'])
        require(sum(not r['anchors'] for r in c['routes'])==1,'single_bootstrap')
        self.config=copy.deepcopy(c);self.mapper=MapMachine(c['atlas']);self.seq=0;self.phase='RUNNING';self.paused=False
        self.attempts={};self.last=None;self.reason=None
    def plan(self):
        m=self.mapper
        if self.phase!='RUNNING' or self.paused or m.pending or m.spent>=m.config['budget'] or len(m.patches)>=m.config['max_patches']:return None
        state=m.snapshot();points={k for p in state['patches'] for k in p['points']};boundary={k for p in state['patches'] for k in p['boundary']}
        eligible=[]
        for r in self.config['routes']:
            old=self.attempts.get(r['window']);anchors=set(r['anchors'])
            valid=not anchors or (anchors<=points and bool(anchors&boundary))
            if valid and (old is None or m.at-old['at']>=self.config['refresh']):
                eligible.append((0 if old is None else 1,-1 if old is None else old['at'],r['window'],r))
        if not eligible:return None
        r=min(eligible)[3];refs=[hashof('Patch',p) for p in state['patches'] if set(r['anchors'])&set(p['points'])]
        return dict(window=r['window'],reason='bootstrap' if not r['anchors'] else 'boundary_probe',anchors=r['anchors'],evidence=refs,frame=m.frame)
    def snapshot(self):
        s=self.mapper.snapshot();s.update(profile=PROFILE,sequence=self.seq,phase=self.phase,paused=self.paused,
            organ=dict(id='atlas_window',state='STOPPED' if self.phase=='STOPPED' else 'QUIESCENT' if self.paused else 'WAITING' if self.mapper.pending else 'READY'),
            plan=self.plan(),attempts=copy.deepcopy(self.attempts),control_result=self.last,stop_reason=self.reason,
            config_ref=seal('Config',self.config))
        s['state_digest']=seal('State',{k:v for k,v in s.items() if k!='state_digest'});return s
    def reduce(self,e):
        canon(e);require(self.seq<self.config['max_events'],'outer_capacity')
        n=copy.deepcopy(self);n._apply(e);n.seq+=1;canon(n.snapshot());return n,copy.deepcopy(n.last)
    def _inner(self,e):self.mapper=self.mapper.reduce(e)[0]
    def _apply(self,e):
        require(type(e) is dict and uint(e.get('at')) and e['at']>=self.mapper.at,'time')
        k=e.get('kind');require(self.phase=='RUNNING' or k=='resume','stopped');self.last=dict(kind=k)
        if k=='dispatch':
            fields(e,'kind at proposal');self._inner(dict(kind='tick',at=e['at']))
            require(canon(e['proposal'])==canon(self.plan()) and self.plan() is not None,'proposal_binding')
            p=self.plan();self._inner(dict(kind='request',at=e['at'],window=p['window'],source='atlas_window'))
            self.attempts[p['window']]=dict(at=e['at'],request=self.mapper.pending['id']);self.last=dict(kind=k,proposal=p)
        elif k in ['patch','fail','tick','retract']:
            if k=='patch' and self.paused:
                # Pause invalidates the frame on entry; receipts are therefore superseded.
                require(self.mapper.pending is not None,'pending')
            self._inner(e);self.last=self.mapper.last
        elif k=='pause':
            fields(e,'kind at paused');require(type(e['paused']) is bool,'pause_type')
            self._inner(dict(kind='frame' if e['paused'] and not self.paused else 'tick',at=e['at']));self.paused=e['paused']
        elif k=='frame':fields(e,'kind at');self._inner(e)
        elif k=='stop':
            fields(e,'kind at reason');require(e['reason'] in ['duration','user','capacity'],'stop_reason');require(self.mapper.pending is None,'drain_before_stop')
            self._inner(dict(kind='tick',at=e['at']));self.phase='STOPPED';self.reason=e['reason']
        elif k=='resume':
            fields(e,'kind at');require(e['at']>self.mapper.at,'resume_time')
            if self.mapper.pending:self._inner(dict(kind='fail',at=e['at'],request=self.mapper.pending['id'],reason='ERROR'))
            self._inner(dict(kind='frame',at=e['at']));self.phase='RUNNING';self.paused=False;self.reason=None
        else:raise ValueError('event_kind')

def header(c):return dict(profile=PROFILE,config=c,initial=ActiveAtlas(c).snapshot()['state_digest'])
def record(m,e,parent):
    n,out=m.reduce(e);r=dict(profile=PROFILE,sequence=m.seq,parent=parent,event=e,pre=m.snapshot()['state_digest'],post=n.snapshot()['state_digest'],output=out)
    return n,dict(r,digest=seal('Transition',r))

def replay(path):
    with Path(path).open('rb') as f:
        def line():
            b=f.readline(MAX_LINE+1);require(len(b)<=MAX_LINE and (not b or b.endswith(b'\n')),'journal_line');return loads(b) if b else None
        h=line();require(type(h) is dict and 'config' in h,'header');require(canon(h)==canon(header(h['config'])),'header_semantics')
        m=ActiveAtlas(h['config']);head=seal('Header',h);views=[m.snapshot()];events=[]
        while (r:=line()) is not None:
            n,expected=record(m,r['event'],head);require(canon(r)==canon(expected),'record_semantics')
            m=n;head=r['digest'];views.append(m.snapshot());events.append(r['event'])
    return dict(machine=m,head=head,views=views,events=events)

class ActiveJournal(MapJournal):
    def __init__(self,path,c):
        self.path=Path(path);self.machine=ActiveAtlas(c);self.failed=False;h=header(c);self.head=seal('Header',h)
        self.stream=self.path.open('xb')
        try:self._write(h)
        except BaseException:self.stream.close();raise
    def commit(self,event):
        require(not self.failed,'writer_failed');candidate,r=record(self.machine,event,self.head)
        try:self._write(r)
        except BaseException:self.failed=True;raise
        self.machine=candidate;self.head=r['digest'];return candidate.snapshot()
    @classmethod
    def reopen(cls,path):
        r=replay(path);j=cls.__new__(cls);j.path=Path(path);j.machine=r['machine'];j.head=r['head'];j.failed=False
        j.stream=j.path.open('ab');return j
