import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from active_atlas import ActiveAtlas,ActiveJournal,config,replay,seal
from active_runtime import ActiveService,fixture
from map_worker import sample
from adapters import MonotonicClock

class ActiveTests(unittest.TestCase):
    def machine(self):return ActiveAtlas(config('/tmp/fixture.json'))
    def dispatch(self,m):return m.reduce(dict(kind='dispatch',at=m.mapper.at,proposal=m.plan()))[0]
    def receive(self,m):
        r=m.mapper.pending;p=sample(fixture(),r,m.mapper.at+1)
        return m.reduce(dict(kind='patch',at=m.mapper.at+1,exposure_ref=r['exposure_ref'],patch=p))[0]
    def test_bootstrap_then_evidence_route(self):
        m=self.machine();self.assertEqual(m.plan()['window'],'left')
        m=self.receive(self.dispatch(m));p=m.plan();self.assertEqual(p['window'],'right');self.assertTrue(p['evidence'])
    def test_four_windows_join(self):
        m=self.machine()
        for _ in range(4):m=self.receive(self.dispatch(m))
        self.assertEqual(set(m.attempts),{'left','right','bridge','island'})
        self.assertEqual(len(m.snapshot()['atlas']['components']),1)
    def test_unmeasured_route_cannot_dispatch(self):
        m=self.machine();p=m.plan();p['window']='bridge'
        with self.assertRaises(ValueError):m.reduce(dict(kind='dispatch',at=0,proposal=p))
    def test_expired_proposal_rejected(self):
        m=self.receive(self.dispatch(self.machine()));p=m.plan()
        with self.assertRaises(ValueError):m.reduce(dict(kind='dispatch',at=2000,proposal=p))
    def test_pause_gates_receipt_and_cost(self):
        m=self.dispatch(self.machine());m=m.reduce(dict(kind='pause',at=1,paused=True))[0];m=self.receive(m)
        self.assertEqual(m.last['status'],'SUPERSEDED');self.assertEqual(m.mapper.spent,1);self.assertIsNone(m.plan());self.assertFalse(m.snapshot()['patches'])
    def test_noop_pause_does_not_invalidate_twice(self):
        m=self.machine();m=m.reduce(dict(kind='pause',at=0,paused=True))[0];epoch=m.mapper.frame
        m=m.reduce(dict(kind='pause',at=1,paused=True))[0];self.assertEqual(m.mapper.frame,epoch)
    def test_retry_cooldown(self):
        m=self.dispatch(self.machine());m=m.reduce(dict(kind='fail',at=1,request='request1',reason='ERROR'))[0]
        self.assertIsNone(m.plan());m=m.reduce(dict(kind='tick',at=700))[0];self.assertEqual(m.plan()['window'],'left')
    def test_budget_never_refunded(self):
        c=config('/tmp/world');c['atlas']['budget']=1;m=ActiveAtlas(c);m=self.dispatch(m)
        m=m.reduce(dict(kind='fail',at=1,request='request1',reason='ERROR'))[0];m=m.reduce(dict(kind='tick',at=700))[0];self.assertIsNone(m.plan())
    def test_stop_requires_drain(self):
        m=self.dispatch(self.machine())
        with self.assertRaises(ValueError):m.reduce(dict(kind='stop',at=1,reason='user'))
    def test_restart_abandons_pending_preserves_ids(self):
        m=self.dispatch(self.machine());m=m.reduce(dict(kind='resume',at=2000))[0]
        self.assertIsNone(m.mapper.pending);self.assertEqual(m.mapper.spent,1)
        m=self.dispatch(m);self.assertEqual(m.mapper.pending['id'],'request2')
    def test_stop_then_resume(self):
        m=self.receive(self.dispatch(self.machine()));m=m.reduce(dict(kind='stop',at=2,reason='user'))[0]
        with self.assertRaises(ValueError):m.reduce(dict(kind='tick',at=3))
        m=m.reduce(dict(kind='resume',at=2000))[0];self.assertFalse(m.snapshot()['patches']);self.assertEqual(m.mapper.spent,1)
    def test_journal_reopen_semantic_tamper(self):
        with tempfile.TemporaryDirectory() as t:
            f=Path(t)/'j';j=ActiveJournal(f,config('/tmp/world'));j.commit(dict(kind='tick',at=1));j.close()
            j=ActiveJournal.reopen(f);j.commit(dict(kind='resume',at=2));j.close();self.assertEqual(replay(f)['machine'].seq,2)
            rows=f.read_text().splitlines();r=json.loads(rows[-1]);r['post']='bad';r['digest']=seal('Transition',{k:v for k,v in r.items() if k!='digest'});rows[-1]=json.dumps(r);f.write_text('\n'.join(rows)+'\n')
            with self.assertRaises(ValueError):replay(f)
    def test_write_failure_no_publication(self):
        with tempfile.TemporaryDirectory() as t:
            j=ActiveJournal(Path(t)/'j',config('/tmp/world'));before=j.machine.snapshot()
            try:
                with patch('map_runtime.os.fsync',side_effect=OSError('disk')):
                    with self.assertRaises(OSError):j.commit(dict(kind='tick',at=1))
                self.assertEqual(before,j.machine.snapshot());self.assertTrue(j.failed)
            finally:j.close()
    def test_catalog_validation(self):
        c=config('/tmp/world');c['routes'][1]['anchors']=['B']
        with self.assertRaises(ValueError):ActiveAtlas(c)
    def test_http_control_shape_queue(self):
        with tempfile.TemporaryDirectory() as t:
            j=ActiveJournal(Path(t)/'j',config('/tmp/world'));s=ActiveService(j)
            try:
                with self.assertRaises(ValueError):s.enqueue(dict(kind='pause',paused=1))
                for _ in range(16):s.enqueue(dict(kind='frame'))
                import queue
                with self.assertRaises(queue.Full):s.enqueue(dict(kind='frame'))
            finally:s.close()
    def test_capacity_clean_stop(self):
        with tempfile.TemporaryDirectory() as t:
            c=config('/tmp/world');c['max_events']=8;j=ActiveJournal(Path(t)/'j',c)
            for i in range(4):j.commit(dict(kind='tick',at=i))
            s=ActiveService(j,MonotonicClock(4))
            try:self.assertFalse(s.cycle());self.assertEqual(s.current['stop_reason'],'capacity')
            finally:s.close()
    def test_counterevidence_holds_join(self):
        m=self.receive(self.dispatch(self.machine()));m=self.dispatch(m)
        w=fixture();w['relations'][2][2]=False;r=m.mapper.pending;p=sample(w,r,2)
        m=m.reduce(dict(kind='patch',at=2,exposure_ref=r['exposure_ref'],patch=p))[0]
        self.assertEqual(m.snapshot()['atlas']['pairs'][0]['status'],'CONFLICT')
    def test_actual_process_timeout(self):
        import subprocess,sys
        real_run=subprocess.run
        with tempfile.TemporaryDirectory() as t:
            c=config('/tmp/world');c['atlas']['timeout']=40
            j=ActiveJournal(Path(t)/'j',c);s=ActiveService(j)
            try:
                j.commit(dict(kind='dispatch',at=0,proposal=j.machine.plan()))
                def blocked(*args,**kw):return real_run([sys.executable,'-c','import time; time.sleep(2)'],**kw)
                with patch('active_runtime.subprocess.run',side_effect=blocked):e=s.measure(j.machine.mapper.pending)
                self.assertEqual(e['reason'],'TIMEOUT');j.commit(e);self.assertIsNone(j.machine.mapper.pending)
            finally:s.close()
    def test_pause_while_sensor_pending(self):
        import threading,time
        gate=threading.Event()
        with tempfile.TemporaryDirectory() as t:
            j=ActiveJournal(Path(t)/'j',config('/tmp/world'))
            def blocked(r):
                gate.wait(1);return dict(kind='fail',at=1,request=r['id'],reason='ERROR')
            s=ActiveService(j,runner=blocked)
            try:
                s.cycle();self.assertIsNotNone(s.future)
                s.enqueue(dict(kind='pause',paused=True));s.cycle()
                self.assertTrue(s.current['paused']);self.assertEqual(s.current['spent'],1)
                gate.set()
                for _ in range(100):
                    if s.future.done():break
                    time.sleep(.001)
                s.cycle();self.assertIsNone(s.future);self.assertEqual(s.current['spent'],1)
            finally:gate.set();s.close()
if __name__=='__main__':unittest.main()
