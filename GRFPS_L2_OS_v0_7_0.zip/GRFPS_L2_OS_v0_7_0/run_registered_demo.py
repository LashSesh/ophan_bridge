"""Actual registered workers/HTTP plus a >2000-event continuity proof."""
import json,tempfile,shutil,threading,time
from pathlib import Path
from urllib.request import urlopen,Request
from registered_runtime import RegisteredService,fixture,export,html
from domain_bridge import config
from registered_segments import SegmentJournal,replay
from field_world import generate_world,world_ref
from mapping import hashof
from adapters import MonotonicClock
from live import server_for

def write(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2));tmp.replace(path)
def setup(d):
    d.mkdir();(d/'samples').mkdir();w=fixture();f=generate_world(0,sectors=4,depth=2)
    for ray in f['cells']:
        for cell in ray:cell.update(solid=False,beacon=False)
    def save():
        write(d/'world.json',w);write(d/'field.json',f)
        write(d/'samples'/(hashof('SampleWorld',w)+'.json'),w);write(d/'samples'/(world_ref(f)+'.json'),f)
    save();return w,f,save

def live_run(d):
    w,f,save=setup(d);c=config(d/'world.json',d/'field.json');c['segment_records']=16;c['bank']['budget']=256
    c['bank']['atlas']['atlas']['ttl']=4000;c['bank']['atlas']['refresh']=120;c['bank'].update(ttl=4000,refresh=120)
    j=SegmentJournal(d/'journal',c);s=RegisteredService(j);server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])))
    t=threading.Thread(target=server.serve_forever,daemon=True);t.start();base=f'http://127.0.0.1:{server.server_port}';checks=0;stages=[];scope_errors=[]
    base_commit=s.commit
    def observed_commit(e):
        value=base_commit(e)
        if e['kind']=='scoped_boolean' and e['event']['outcome']=='ERROR':scope_errors.append(e)
        return value
    s.commit=observed_commit
    def bridge():return s.current['bridges'][0]
    def drive(predicate,limit=12):
        nonlocal checks
        end=time.monotonic()+limit
        while not predicate():
            assert time.monotonic()<end,'stage timeout';assert s.cycle()
            with urlopen(base+'/api/updates') as r:assert json.load(r)['snapshot']==s.current
            checks+=1;time.sleep(.01)
    def stage(name):stages.append(dict(name=name,sequence=s.current['sequence'],spent=s.current['spent'],epoch=s.current['epoch'],bridge=bridge()))
    def command(c):
        with urlopen(Request(base+'/api/control',data=json.dumps(c).encode(),headers={'Content-Type':'application/json'})) as r:assert r.status==202
    try:
        with urlopen(base) as r:assert 'Domänenanschlüsse'.encode() in r.read()
        drive(lambda:bridge()['epistemic']=='Known' and bridge()['value'] is True);stage('registered_true')
        f['cells'][0][0]['solid']=True;save()
        drive(lambda:bridge()['epistemic']=='Known' and bridge()['value'] is False);stage('registered_false')
        w['points']['B']=[0,2];save()
        drive(lambda:bridge()['reason']=='geometry_counterevidence');stage('counterevidence_holds')
        f['depth']=3
        for ray in f['cells']:ray.append(dict(solid=False,beacon=False))
        save()
        drive(lambda:bool(scope_errors));stage('scope_error')
        w['points']['B']=[2,0];f['depth']=2
        for ray in f['cells']:
            del ray[2:]
            for cell in ray:cell.update(solid=False,beacon=False)
        save();command(dict(kind='frame'))
        drive(lambda:bridge()['epistemic']=='Known' and bridge()['value'] is True);stage('new_frame_restored')
        command(dict(kind='pause',paused=True));drive(lambda:s.current['paused']);stage('pause_revokes')
        s.stop_reason='user'
        while s.cycle():time.sleep(.01)
        stage('stopped')
    finally:server.shutdown();server.server_close();t.join();s.close()
    proof=export(d/'journal',d/'replay.html');proof.update(http_checks=checks,stages=stages,visual_browser_review=False)
    (d/'report.json').write_text(json.dumps(proof,indent=2));return proof

def continuity_run(d):
    setup(d);c=config(d/'world.json',d/'field.json');c['segment_records']=32
    j=SegmentJournal(d/'journal',c);s=RegisteredService(j)
    try:
        for _ in range(3):
            s.commit(dict(kind='tick',at=s.now()));s.commit(dict(kind='dispatch',at=s.engine.machine.mapper.at,proposal=s.engine.machine.plan()));s.commit(s.measure(s.engine.machine.pending))
        cost=s.engine.machine.spent
        for _ in range(2050):
            m=s.engine.machine;s.commit(dict(kind='tick',at=m.mapper.at+1));items=s.engine.machine.compactable()
            if items:s.commit(dict(kind='compact',at=s.engine.machine.mapper.at,items=items))
        s.commit(dict(kind='stop',at=s.engine.machine.mapper.at,reason='user'));before=s.engine.machine.seq;archive=s.engine.machine.archive.copy()
    finally:s.close()
    j=SegmentJournal.reopen(d/'journal');at=j.machine.mapper.at+1501;j.commit(dict(kind='resume',at=at));assert j.machine.spent==cost and j.machine.archive==archive
    j.commit(dict(kind='stop',at=at,reason='user'));j.close();r=replay(d/'journal');assert r['machine'].seq>2000
    report=dict(transitions=r['machine'].seq,segments=r['index']+1,spent=r['machine'].spent,archive=r['machine'].archive,
        head=r['head'],state_digest=r['machine'].snapshot()['state_digest'],before_restart=before,preserved_spent=cost,
        clock='2050 explicit one-millisecond ticks after three real sensor processes; not a latency benchmark')
    (d/'report.json').write_text(json.dumps(report,indent=2));return report

def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',default='new_registered_run');a=p.parse_args();target=Path(a.out);assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps_registered_') as tmp:
        d=Path(tmp)/'verified';d.mkdir();l=live_run(d/'live');c=continuity_run(d/'continuity');report=dict(live=l,continuity=c);(d/'report.json').write_text(json.dumps(report,indent=2));shutil.copytree(d,target)
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
