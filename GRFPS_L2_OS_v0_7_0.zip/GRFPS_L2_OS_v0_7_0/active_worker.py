import sys,time
from pathlib import Path
from grfps_l2 import loads,canon,require
from map_worker import sample
try:
    raw=Path(sys.argv[1]).read_bytes();require(len(raw)<=1048576,'world_size')
    q=loads(sys.stdin.buffer.read(8193));w=loads(raw)
    at=q['offset']+(time.monotonic_ns()-q['start_ns'])//1000000
    sys.stdout.buffer.write(canon(sample(w,q['request'],at)))
except Exception:sys.exit(2)
