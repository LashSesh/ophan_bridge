"""Exact model registration, typed relevance gates and explicit segment epochs."""
import copy
from grfps_l2 import canon,fields,ident,uint,require
from organ_bank import OrganBank,config as bank_config,seal as bank_seal
from mapping import hashof

PROFILE='grfps-registered-bank/0.7.0'
def seal(kind,x):return hashof(kind,dict(profile=PROFILE,value=x))
def config(world,field):
    return dict(profile=PROFILE,bank=bank_config(world,field),segment_records=32,max_segments=128,scope_cells=2,
        registrations=[dict(id='AB_ray',window='left',a='A',b='B',vector=[2,0],query='ray_clear',sector=0)])
def scope_ref(c):return seal('Scope',dict(sectors=c['bank']['sectors'],cells=c['scope_cells'],units='model_grid_step',sampling='one_cell_per_step',contract='finite_radial_model@1'))

class RegisteredBank(OrganBank):
    def __init__(self,c):
        fields(c,'profile bank segment_records max_segments scope_cells registrations');canon(c)
        require(c['profile']==PROFILE and uint(c['segment_records']) and 16<=c['segment_records']<=256 and uint(c['max_segments']) and 2<=c['max_segments']<=128,'segment_contract')
        require(uint(c['scope_cells']) and 1<=c['scope_cells']<=32 and c['bank']['sectors']==4,'scope_contract')
        require(type(c['registrations']) is list and 1<=len(c['registrations'])<=16,'registration_limit')
        ids=set();windows={r['window'] for r in c['bank']['atlas']['routes']}
        for r in c['registrations']:
            fields(r,'id window a b vector query sector');require(ident(r['id']) and r['id'] not in ids and r['window'] in windows,'registration_id')
            require(ident(r['a']) and ident(r['b']) and r['a']!=r['b'] and r['query'] in ['ray_clear','beacon_present'] and uint(r['sector']) and r['sector']<4,'registration_type')
            directions=[[c['scope_cells'],0],[0,c['scope_cells']],[-c['scope_cells'],0],[0,-c['scope_cells']]]
            require(canon(r['vector'])==canon(directions[r['sector']]),'registration_scope_vector');ids.add(r['id'])
        super().__init__(c['bank']);self.contract=copy.deepcopy(c);self.epoch=0;self.bindings={};self.patch_windows={}
    def registration(self,key):
        return next((r for r in self.contract['registrations'] if r['id']==key),None)
    def geometry(self,r,p):
        return r['a'] in p['points'] and r['b'] in p['points'] and [p['points'][r['b']][i]-p['points'][r['a']][i] for i in range(2)]==r['vector']
    def bind_proposal(self):
        live=self.mapper.snapshot()['patches']
        for r in self.contract['registrations']:
            bound=self.bindings.get(r['id']);refs={hashof('Patch',p) for p in live}
            if bound and bound['frame']==self.mapper.frame and bound['patch_ref'] in refs:continue
            for p in sorted(live,key=lambda p:(-p['sampled_at'],p['id'])):
                if self.patch_windows.get(p['id'])==r['window'] and self.geometry(r,p):
                    return dict(registration=r['id'],patch=p['id'],patch_ref=hashof('Patch',p),scope_ref=scope_ref(self.contract),frame=self.mapper.frame)
        return None
    def projections(self):
        state=self.mapper.snapshot();live=state['patches'];out=[]
        for r in self.contract['registrations']:
            w=self.bindings.get(r['id']);reason='unbound';conflicts=[];p=None
            if w:
                p=next((p for p in live if hashof('Patch',p)==w['patch_ref']),None)
                reason='old_frame' if w['frame']!=self.mapper.frame else 'patch_expired_or_retired' if p is None else 'valid'
                if reason=='valid':
                    conflicts=[hashof('Patch',q) for q in live if self.patch_windows.get(q['id'])==r['window'] and r['a'] in q['points'] and r['b'] in q['points'] and not self.geometry(r,q)]
                    quarantined=any(c['quarantined'] and p['id'] in c['patches'] for c in state['atlas']['components'])
                    if conflicts or quarantined:reason='geometry_counterevidence'
            e=self.boolean.get(self.bool_key(r['query'],r['sector']));fresh=e is not None and self.bool_active(e)
            relevant=reason=='valid';known=relevant and fresh and e['outcome']=='OK'
            out.append(dict(id=r['id'],a=r['a'],b=r['b'],predicate=r['query'],gate='ADMITTED' if relevant else 'HOLD',reason=reason,
                epistemic='Known' if known else 'Unknown',value=e['value'] if known else None,
                field_ref=bank_seal('Boolean',e) if fresh else None,witness_ref=seal('RegistrationWitness',w) if w else None,
                patch_ref=w['patch_ref'] if w else None,scope_ref=scope_ref(self.contract),counterevidence=conflicts))
        return out
    def snapshot(self):
        s=super().snapshot();s.update(profile=PROFILE,epoch=self.epoch,bridges=self.projections(),
            bindings=copy.deepcopy(self.bindings),window_lineage=copy.deepcopy(self.patch_windows),contract_ref=seal('Contract',self.contract))
        s['state_digest']=seal('State',{k:v for k,v in s.items() if k!='state_digest'});return s
    def reduce(self,e):
        canon(e);require(type(e) is dict and uint(e.get('at')) and e['at']>=self.mapper.at,'time')
        require(self.seq<self.contract['segment_records']*self.contract['max_segments'],'total_capacity')
        n=copy.deepcopy(self);n._registered(e);n.seq+=1;canon(n.snapshot());return n,copy.deepcopy(n.last)
    def _registered(self,e):
        k=e.get('kind')
        if k=='rollover':
            fields(e,'kind at epoch');require(type(e['epoch']) is int and e['epoch']==self.epoch+1 and self.seq>0 and self.seq%self.contract['segment_records']==0 and e['epoch']==self.seq//self.contract['segment_records'],'rollover_boundary')
            require(e['at']==self.mapper.at,'rollover_time');self.epoch=e['epoch'];self.active.seq=0;self.mapper.seq=0;self.last=dict(kind=k,epoch=self.epoch)
        elif k=='bind':
            fields(e,'kind at witness');require(self.phase=='RUNNING','stopped');self._active(dict(kind='tick',at=e['at']))
            proposal=self.bind_proposal();require(proposal is not None and canon(e['witness'])==canon(proposal),'binding_witness')
            self.bindings[proposal['registration']]=copy.deepcopy(proposal);self.last=dict(kind=k,witness=proposal)
        elif k=='scoped_boolean':
            fields(e,'kind at scope_ref event');require(e['scope_ref']==scope_ref(self.contract),'scope_binding')
            require(type(e['event']) is dict and e['event'].get('kind')=='boolean_result' and e['event'].get('at')==e['at'],'scoped_type')
            super()._apply(e['event']);self.last=dict(self.last,kind=k,scope_ref=e['scope_ref'])
        elif k=='boolean_result':raise ValueError('unscoped_boolean_forbidden')
        else:
            r=copy.deepcopy(self.pending);super()._apply(e)
            if k=='window_result' and e['event']['kind']=='patch' and self.last['result'].get('status')=='INTEGRATED':
                self.patch_windows[e['event']['patch']['id']]=r['inner']['window']
            if k=='compact':self.patch_windows={k:v for k,v in self.patch_windows.items() if k in self.mapper.patches}

def checkpoint(m):
    return dict(bank={k:copy.deepcopy(v) for k,v in m.__dict__.items() if k!='active'},
        active={k:copy.deepcopy(v) for k,v in m.active.__dict__.items() if k!='mapper'},mapper=copy.deepcopy(m.mapper.__dict__))
