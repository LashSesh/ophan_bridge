import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from domain_bridge import RegisteredBank,config,scope_ref,seal
from registered_segments import SegmentJournal,replay,header
from registered_runtime import RegisteredService,fixture
from map_worker import sample
from field_world import generate_world,measure,world_ref

def field():
    w=generate_world(0,sectors=4,depth=2)
    for ray in w['cells']:
        for cell in ray:cell.update(solid=False,beacon=False)
    return w

def answer(m,world=None):
    r=m.pending;at=m.mapper.at+1
    if r['organ']=='window':
        p=sample(world or fixture(),r['inner'],at)
        return dict(kind='window_result',at=at,request=r['id'],exposure=r['exposure'],event=dict(kind='patch',at=at,exposure_ref=r['inner']['exposure_ref'],patch=p))
    w=world or field();v=measure(w,r['organ'],r['payload']['sector']);e=dict(kind='boolean_result',at=at,request=r['id'],exposure=r['exposure'],outcome=v['outcome'],value=v['value'],sampled_at=at,sample_ref=world_ref(w))
    return dict(kind='scoped_boolean',at=at,scope_ref=scope_ref(m.contract),event=e)

class RegisteredTests(unittest.TestCase):
    def machine(self):return RegisteredBank(config('/tmp/w','/tmp/f'))
    def dispatch(self,m):return m.reduce(dict(kind='dispatch',at=m.mapper.at,proposal=m.plan()))[0]
    def measured(self):
        m=self.machine()
        for _ in range(3):m=self.dispatch(m);m=m.reduce(answer(m))[0]
        return m
    def bound(self):
        m=self.measured();return m.reduce(dict(kind='bind',at=m.mapper.at,witness=m.bind_proposal()))[0]
    def test_positive_registration(self):
        p=self.bound().projections()[0];self.assertEqual(p['gate'],'ADMITTED');self.assertEqual(p['epistemic'],'Known');self.assertIs(p['value'],True)
    def test_raw_field_without_witness_not_projected(self):
        m=self.measured();self.assertEqual(m.projections()[0]['reason'],'unbound');self.assertIsNone(m.projections()[0]['value'])
    def test_vector_scope_reject(self):
        c=config('/tmp/w','/tmp/f');c['registrations'][0]['vector']=[4,0]
        with self.assertRaises(ValueError):RegisteredBank(c)
    def test_integer_boolean_vector_reject(self):
        c=config('/tmp/w','/tmp/f');c['scope_cells']=1;c['registrations'][0]['vector']=[True,0]
        with self.assertRaises(ValueError):RegisteredBank(c)
    def test_unscoped_input_reject(self):
        m=self.dispatch(self.machine());e=answer(m)
        with self.assertRaises(ValueError):m.reduce(e['event'])
    def test_wrong_scope_ref_reject(self):
        m=self.dispatch(self.machine());e=answer(m);e['scope_ref']='0'*64
        with self.assertRaises(ValueError):m.reduce(e)
    def test_patch_witness_ref_reject(self):
        m=self.measured();w=m.bind_proposal();w['patch_ref']='0'*64
        with self.assertRaises(ValueError):m.reduce(dict(kind='bind',at=m.mapper.at,witness=w))
    def test_wrong_window_frame_not_bound(self):
        m=self.measured();m.patch_windows['patch1']='right';self.assertIsNone(m.bind_proposal())
    def test_pause_revokes_registration(self):
        m=self.bound();m=m.reduce(dict(kind='pause',at=10,paused=True))[0];self.assertEqual(m.projections()[0]['reason'],'old_frame')
    def test_expiry_revokes_registration(self):
        m=self.bound();m=m.reduce(dict(kind='tick',at=2000))[0];self.assertEqual(m.projections()[0]['reason'],'patch_expired_or_retired')
    def test_geometry_counterevidence(self):
        m=self.bound()
        for _ in range(9):m=self.dispatch(m);m=m.reduce(answer(m))[0]
        m=m.reduce(dict(kind='tick',at=800))[0]
        while m.plan()['organ']!='window':m=self.dispatch(m);m=m.reduce(answer(m))[0]
        m=self.dispatch(m);w=fixture();w['points']['B']=[0,2];m=m.reduce(answer(m,w))[0]
        self.assertEqual(m.projections()[0]['reason'],'geometry_counterevidence');self.assertIsNone(m.projections()[0]['value'])
    def test_registered_false_stays_false(self):
        m=self.bound();e=m.boolean['ray_clear.s0'];e['value']=False
        self.assertIs(m.projections()[0]['value'],False);self.assertEqual(m.projections()[0]['epistemic'],'Known')
    def test_real_scope_mismatch_worker(self):
        with tempfile.TemporaryDirectory() as t:
            d=Path(t);f=d/'f';f.write_text(json.dumps(generate_world(0,sectors=4,depth=3)))
            j=SegmentJournal(d/'j',config(d/'w',f));s=RegisteredService(j)
            try:
                j.commit(dict(kind='dispatch',at=0,proposal=j.machine.plan()));e=s.measure(j.machine.pending);self.assertEqual(e['event']['outcome'],'ERROR');j.commit(e);self.assertFalse(j.machine.boolean)
            finally:s.close()
    def test_rollover_preserves_pending_and_cost(self):
        with tempfile.TemporaryDirectory() as t:
            c=config('/tmp/w','/tmp/f');c['segment_records']=16;j=SegmentJournal(Path(t)/'j',c)
            for i in range(15):j.commit(dict(kind='tick',at=i))
            j.commit(dict(kind='dispatch',at=15,proposal=j.machine.plan()));r=copy.deepcopy(j.machine.pending);cost=j.machine.spent
            j.commit(answer(j.machine));self.assertEqual(j.index,1);self.assertEqual(j.machine.epoch,1);self.assertEqual(j.machine.spent,cost);self.assertEqual(j.machine.request_count,1);j.close()
            self.assertEqual(replay(Path(t)/'j')['machine'].seq,18)
    def test_segment_gap_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            c=config('/tmp/w','/tmp/f');c['segment_records']=16;j=SegmentJournal(Path(t)/'j',c)
            for i in range(34):j.commit(dict(kind='tick',at=i))
            j.close();(Path(t)/'j/segment-000001.jsonl').unlink()
            with self.assertRaises(ValueError):replay(Path(t)/'j')
    def test_rehashed_checkpoint_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            c=config('/tmp/w','/tmp/f');c['segment_records']=16;j=SegmentJournal(Path(t)/'j',c)
            for i in range(17):j.commit(dict(kind='tick',at=i))
            j.close();p=Path(t)/'j/segment-000001.jsonl';lines=p.read_text().splitlines();h=json.loads(lines[0]);h['checkpoint']['bank']['spent']=1;h['digest']=seal('SegmentHeader',{k:v for k,v in h.items() if k!='digest'});lines[0]=json.dumps(h);p.write_text('\n'.join(lines)+'\n')
            with self.assertRaises(ValueError):replay(Path(t)/'j')
    def test_bool_integer_checkpoint_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            j=SegmentJournal(Path(t)/'j',config('/tmp/w','/tmp/f'));j.close();p=Path(t)/'j/segment-000000.jsonl';h=json.loads(p.read_text());h['checkpoint']['active']['paused']=0;h['digest']=seal('SegmentHeader',{k:v for k,v in h.items() if k!='digest'});p.write_text(json.dumps(h)+'\n')
            with self.assertRaises(ValueError):replay(Path(t)/'j')
    def test_torn_tail_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            j=SegmentJournal(Path(t)/'j',config('/tmp/w','/tmp/f'));j.commit(dict(kind='tick',at=1));j.close();p=Path(t)/'j/segment-000000.jsonl';p.write_bytes(p.read_bytes()[:-1])
            with self.assertRaises(ValueError):replay(Path(t)/'j')
    def test_reopen_header_only_boundary(self):
        with tempfile.TemporaryDirectory() as t:
            c=config('/tmp/w','/tmp/f');c['segment_records']=16;j=SegmentJournal(Path(t)/'j',c)
            for i in range(16):j.commit(dict(kind='tick',at=i))
            j.stream.close();j.index=1;j._open_segment();j.close();j=SegmentJournal.reopen(Path(t)/'j');j.commit(dict(kind='tick',at=16));self.assertEqual(j.machine.epoch,1);j.close();self.assertEqual(replay(Path(t)/'j')['machine'].seq,18)
    def test_rollover_not_client_event(self):
        with tempfile.TemporaryDirectory() as t:
            j=SegmentJournal(Path(t)/'j',config('/tmp/w','/tmp/f'))
            try:
                with self.assertRaises(ValueError):j.commit(dict(kind='rollover',at=0,epoch=1))
            finally:j.close()
    def test_write_failure_no_publication(self):
        with tempfile.TemporaryDirectory() as t:
            j=SegmentJournal(Path(t)/'j',config('/tmp/w','/tmp/f'))
            try:
                with patch('registered_segments.os.fsync',side_effect=OSError('disk')):
                    with self.assertRaises(OSError):j.commit(dict(kind='tick',at=1))
                self.assertEqual(j.machine.seq,0);self.assertTrue(j.failed)
            finally:j.close()
    def test_total_segment_limit(self):
        with tempfile.TemporaryDirectory() as t:
            c=config('/tmp/w','/tmp/f');c.update(segment_records=16,max_segments=2);j=SegmentJournal(Path(t)/'j',c)
            try:
                for i in range(31):j.commit(dict(kind='tick',at=i))
                self.assertEqual(j.machine.seq,32)
                with self.assertRaises(ValueError):j.commit(dict(kind='tick',at=31))
            finally:j.close()
if __name__=='__main__':unittest.main()
