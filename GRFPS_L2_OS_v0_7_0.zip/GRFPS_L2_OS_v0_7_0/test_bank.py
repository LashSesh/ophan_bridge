import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from organ_bank import OrganBank,config,seal
from bank_journal import BankJournal,replay
from bank_runtime import fixture,BankService
from map_worker import sample
from field_world import generate_world,measure,world_ref
from mapping import hashof

def result(m,outcome=None):
    r=m.pending;at=m.mapper.at+1
    if r['organ']=='window':
        p=sample(fixture(),r['inner'],at)
        return dict(kind='window_result',at=at,request=r['id'],exposure=r['exposure'],event=dict(kind='patch',at=at,exposure_ref=r['inner']['exposure_ref'],patch=p))
    w=generate_world(23,sectors=4);v=measure(w,r['organ'],r['payload']['sector'])
    return dict(kind='boolean_result',at=at,request=r['id'],exposure=r['exposure'],outcome=outcome or v['outcome'],value=v['value'],sampled_at=at,sample_ref=world_ref(w))

class BankTests(unittest.TestCase):
    def machine(self):return OrganBank(config('/tmp/w','/tmp/f'))
    def dispatch(self,m):return m.reduce(dict(kind='dispatch',at=m.mapper.at,proposal=m.plan()))[0]
    def cycle(self,m):m=self.dispatch(m);return m.reduce(result(m))[0]
    def four(self):
        m=self.machine()
        for _ in range(12):m=self.cycle(m)
        return m
    def test_three_typed_organs_share_cost(self):
        m=self.machine();chosen=[]
        for _ in range(3):chosen.append(m.plan()['organ']);m=self.cycle(m)
        self.assertEqual(set(chosen),{'window','ray_clear','beacon_present'});self.assertEqual(m.spent,4);self.assertEqual(m.request_count,3)
    def test_unequal_cost_admission(self):
        c=config('/tmp/w','/tmp/f');c['budget']=3;m=OrganBank(c)
        for _ in range(2):m=self.cycle(m)
        self.assertEqual(m.spent,2);self.assertNotEqual(m.plan()['organ'],'window');m=self.cycle(m);self.assertIsNone(m.plan());self.assertEqual(m.spent,3)
    def test_cost_not_client_selected(self):
        m=self.machine();p=m.plan();p['cost']=0
        with self.assertRaises(ValueError):m.reduce(dict(kind='dispatch',at=0,proposal=p))
    def test_wrong_response_type(self):
        m=self.dispatch(self.machine());e=result(m);e['kind']='window_result'
        with self.assertRaises(ValueError):m.reduce(e)
    def test_boolean_not_integer(self):
        m=self.dispatch(self.machine());e=result(m);e.update(outcome='OK',value=1)
        with self.assertRaises(ValueError):m.reduce(e)
    def test_exposure_binding(self):
        m=self.dispatch(self.machine());e=result(m);e['exposure']='0'*64
        with self.assertRaises(ValueError):m.reduce(e)
    def test_duplicate_receipt(self):
        m=self.dispatch(self.machine());e=result(m);m=m.reduce(e)[0]
        with self.assertRaises(ValueError):m.reduce(e)
    def test_pause_supersedes_boolean(self):
        m=self.dispatch(self.machine());m=m.reduce(dict(kind='pause',at=1,paused=True))[0];m=m.reduce(result(m))[0]
        self.assertEqual(m.last['status'],'SUPERSEDED');self.assertEqual(m.spent,1);self.assertFalse(m.boolean)
    def test_failure_does_not_refund(self):
        m=self.dispatch(self.machine());r=m.pending
        m=m.reduce(dict(kind='boolean_result',at=1,request=r['id'],exposure=r['exposure'],outcome='ERROR',value=None,sampled_at=None,sample_ref=None))[0]
        self.assertEqual(m.spent,1);self.assertFalse(m.boolean)
    def test_no_cross_type_map_edges(self):
        m=self.cycle(self.machine());self.assertFalse(m.snapshot()['atlas']['relations']);self.assertTrue(m.boolean)
    def test_four_windows_with_field_organs(self):
        m=self.four();self.assertEqual(m.mapper.spent,4);self.assertEqual(m.spent,16);self.assertEqual(len(m.snapshot()['atlas']['components']),1)
    def test_live_patch_cannot_retire(self):
        m=self.four();p=next(iter(m.mapper.patches.values()));items=[dict(type='patch',id=p['id'],ref=hashof('Patch',p))]
        with self.assertRaises(ValueError):m.reduce(dict(kind='compact',at=m.mapper.at,items=items))
    def test_exact_retirement_archive_root(self):
        m=self.four();m=m.reduce(dict(kind='tick',at=2000))[0];items=m.compactable();old=m.archive['head']
        m=m.reduce(dict(kind='compact',at=2000,items=items))[0]
        self.assertEqual(m.archive['count'],12);self.assertNotEqual(old,m.archive['head']);self.assertEqual(len(m.mapper.patches),0);self.assertEqual(len(m.boolean),0)
        self.assertEqual(m.mapper.spent,4);self.assertEqual(m.spent,16)
    def test_retirement_tamper_rejected(self):
        m=self.four();m=m.reduce(dict(kind='tick',at=2000))[0];items=m.compactable();items[0]['ref']='f'*64
        with self.assertRaises(ValueError):m.reduce(dict(kind='compact',at=2000,items=items))
    def test_patch_generation_after_retirement(self):
        m=self.four();m=m.reduce(dict(kind='tick',at=2000))[0];m=m.reduce(dict(kind='compact',at=2000,items=m.compactable()))[0]
        while m.plan()['organ']!='window':m=self.cycle(m)
        m=self.dispatch(m);e=result(m);self.assertEqual(e['event']['patch']['id'],'patch5');e['event']['patch']['id']='patch1'
        with self.assertRaises(ValueError):m.reduce(e)
    def test_resume_keeps_global_cost(self):
        m=self.dispatch(self.machine());m=m.reduce(dict(kind='resume',at=2000))[0];self.assertEqual(m.spent,1);self.assertEqual(m.request_count,1);self.assertIsNone(m.pending)
    def test_streaming_replay_and_resolve(self):
        with tempfile.TemporaryDirectory() as t:
            f=Path(t)/'j';j=BankJournal(f,config('/tmp/w','/tmp/f'))
            for _ in range(3):
                j.commit(dict(kind='dispatch',at=j.machine.mapper.at,proposal=j.machine.plan()));j.commit(result(j.machine))
            ref=hashof('Patch',next(iter(j.machine.mapper.patches.values())))
            j.commit(dict(kind='tick',at=2000));j.commit(dict(kind='compact',at=2000,items=j.machine.compactable()));j.close()
            r=replay(f,resolve=ref);self.assertFalse(r['views']);self.assertEqual(len(r['resolved']),1);self.assertEqual(r['resolved'][0]['ref'],ref)
    def test_rehashed_retired_payload_tamper(self):
        with tempfile.TemporaryDirectory() as t:
            f=Path(t)/'j';j=BankJournal(f,config('/tmp/w','/tmp/f'));j.commit(dict(kind='dispatch',at=0,proposal=j.machine.plan()));j.commit(result(j.machine));j.commit(dict(kind='tick',at=2000));j.commit(dict(kind='compact',at=2000,items=j.machine.compactable()));j.close()
            lines=f.read_text().splitlines();r=json.loads(lines[-1]);r['output']['archived'][0]['value']['value']=True;r['output']['archived'][0]['value']['request']='forged';r['digest']=seal('Transition',{k:v for k,v in r.items() if k!='digest'});lines[-1]=json.dumps(r);f.write_text('\n'.join(lines)+'\n')
            with self.assertRaises(ValueError):replay(f)
    def test_fsync_failure_no_global_cost_publication(self):
        with tempfile.TemporaryDirectory() as t:
            j=BankJournal(Path(t)/'j',config('/tmp/w','/tmp/f'))
            try:
                with patch('map_runtime.os.fsync',side_effect=OSError('disk')):
                    with self.assertRaises(OSError):j.commit(dict(kind='dispatch',at=0,proposal=j.machine.plan()))
                self.assertEqual(j.machine.spent,0);self.assertTrue(j.failed)
            finally:j.close()
    def test_boolean_expiry_is_unknown(self):
        m=self.cycle(self.machine());m=m.reduce(dict(kind='tick',at=2000))[0];self.assertTrue(all(e['status']=='Unknown' for e in m.snapshot()['boolean']))
    def test_window_response_cannot_enter_boolean(self):
        m=self.machine()
        for _ in range(2):m=self.cycle(m)
        m=self.dispatch(m);r=m.pending
        with self.assertRaises(ValueError):m.reduce(dict(kind='boolean_result',at=3,request=r['id'],exposure=r['exposure'],outcome='OK',value=True,sampled_at=3,sample_ref='a'*64))
    def test_resume_journal(self):
        with tempfile.TemporaryDirectory() as t:
            f=Path(t)/'j';j=BankJournal(f,config('/tmp/w','/tmp/f'));j.commit(dict(kind='dispatch',at=0,proposal=j.machine.plan()));j.close();j=BankJournal.reopen(f);j.commit(dict(kind='resume',at=2000));self.assertEqual(j.machine.spent,1);j.close();self.assertEqual(replay(f)['machine'].request_count,1)
if __name__=='__main__':unittest.main()
