"""Typed window/ray/beacon bank, global admission budget, verified retirement."""
import copy
from pathlib import Path
from grfps_l2 import canon,fields,require,uint
from mapping import hashof
from active_atlas import ActiveAtlas,config as atlas_config

PROFILE='grfps-organ-bank/0.6.0'

def seal(kind,x):return hashof(kind,dict(profile=PROFILE,value=x))
def config(window_world,field_world):
    a=atlas_config(window_world);a['atlas'].update(budget=512,max_patches=32);a['max_events']=2000;a['atlas']['max_events']=10000
    return dict(profile=PROFILE,atlas=a,field_world=str(Path(field_world).resolve()),sectors=4,
                budget=128,costs=dict(window=2,ray_clear=1,beacon_present=1),refresh=500,ttl=1500,timeout=600,max_events=2000)

class OrganBank:
    def __init__(self,c):
        fields(c,'profile atlas field_world sectors budget costs refresh ttl timeout max_events');canon(c)
        require(c['profile']==PROFILE and type(c['field_world']) is str and 0<len(c['field_world'])<=1024,'profile_path')
        for k in ['sectors','budget','refresh','ttl','timeout','max_events']:require(uint(c[k]) and c[k]>0,'uint')
        require(2<=c['sectors']<=16 and 8<=c['max_events']<=2000 and c['atlas']['max_events']>=c['max_events'],'capacity')
        require(c['budget']<=512 and c['refresh']<c['ttl']<=1000000 and c['timeout']<=1000000,'limits')
        fields(c['costs'],'window ray_clear beacon_present');require(all(uint(v) and 1<=v<=16 for v in c['costs'].values()),'cost')
        require(c['atlas']['atlas']['budget']>=c['budget'],'inner_budget')
        self.config=copy.deepcopy(c);self.active=ActiveAtlas(c['atlas']);self.seq=0;self.spent=0;self.request_count=0;self.pending=None
        self.last_dispatch=dict(window=-1,ray_clear=-1,beacon_present=-1);self.attempts={};self.boolean={};self.last=None
        self.archive=dict(count=0,head=seal('ArchiveGenesis',c),patches=0,boolean=0)
    @property
    def mapper(self):return self.active.mapper
    @property
    def phase(self):return self.active.phase
    def bool_key(self,q,s):return q+'.s'+str(s)
    def bool_active(self,e):return e['frame']==self.mapper.frame and self.mapper.at<e['sampled_at']+self.config['ttl']
    def candidates(self):
        if self.phase!='RUNNING' or self.active.paused or self.pending:return []
        out=[];p=self.active.plan()
        if p:out.append(dict(organ='window',payload=p))
        for q in ['ray_clear','beacon_present']:
            choices=[s for s in range(self.config['sectors']) if self.bool_key(q,s) not in self.attempts or self.mapper.at-self.attempts[self.bool_key(q,s)]>=self.config['refresh']]
            if choices:
                s=min(choices,key=lambda s:(self.attempts.get(self.bool_key(q,s),-1),s));out.append(dict(organ=q,payload=dict(query=q,sector=s)))
        return [dict(p,cost=self.config['costs'][p['organ']],frame=self.mapper.frame) for p in out if self.spent+self.config['costs'][p['organ']]<=self.config['budget']]
    def plan(self):
        choices=self.candidates();return min(choices,key=lambda p:(self.last_dispatch[p['organ']],p['organ'])) if choices else None
    def compactable(self):
        inactive=self.mapper.snapshot()['inactive']
        items=[dict(type='patch',id=k,ref=hashof('Patch',self.mapper.patches[k])) for k in sorted(inactive)]
        items += [dict(type='boolean',id=k,ref=seal('Boolean',e)) for k,e in sorted(self.boolean.items()) if not self.bool_active(e)]
        return items
    def snapshot(self):
        s=self.active.snapshot();boolean=[]
        for q in ['ray_clear','beacon_present']:
            for sector in range(self.config['sectors']):
                k=self.bool_key(q,sector);e=self.boolean.get(k);valid=e is not None and self.bool_active(e)
                status='Unknown' if not valid or e['outcome']=='OCCLUDED' else 'Known'
                boolean.append(dict(id=k,status=status,value=e['value'] if status=='Known' else None,
                    visibility='occluded' if valid and e['outcome']=='OCCLUDED' else 'observed' if valid else 'not_observed',evidence=seal('Boolean',e) if valid else None))
        s.update(profile=PROFILE,sequence=self.seq,spent=self.spent,budget=self.config['budget'],pending=copy.deepcopy(self.pending),
            request_count=self.request_count,plan=self.plan(),control_result=copy.deepcopy(self.last),boolean=boolean,
            archive=copy.deepcopy(self.archive),resident=dict(patches=len(self.mapper.patches),boolean=len(self.boolean)),
            bank=[dict(id=q,type='Patch' if q=='window' else 'BooleanEvidence',cost=self.config['costs'][q],last_dispatch=self.last_dispatch[q]) for q in ['window','ray_clear','beacon_present']],
            memory_ref=seal('Memory',dict(boolean=self.boolean,attempts=self.attempts,last_dispatch=self.last_dispatch)),config_ref=seal('Config',self.config))
        s['state_digest']=seal('State',{k:v for k,v in s.items() if k!='state_digest'});return s
    def _active(self,e):self.active=self.active.reduce(e)[0]
    def reduce(self,e):
        canon(e);require(type(e) is dict and uint(e.get('at')) and e['at']>=self.mapper.at,'time');require(self.seq<self.config['max_events'],'capacity')
        n=copy.deepcopy(self);n._apply(e);n.seq+=1;canon(n.snapshot());return n,copy.deepcopy(n.last)
    def _archive(self,kind,key,value):
        ref=hashof('Patch',value) if kind=='patch' else seal('Boolean',value)
        entry=dict(type=kind,id=key,ref=ref,value=copy.deepcopy(value),previous=self.archive['head'],index=self.archive['count'])
        entry['digest']=seal('ArchiveEntry',entry);self.archive['head']=entry['digest'];self.archive['count']+=1
        self.archive['patches' if kind=='patch' else 'boolean']+=1;return entry
    def _apply(self,e):
        k=e.get('kind');require(self.phase=='RUNNING' or k=='resume','stopped');self.last=dict(kind=k)
        if k=='dispatch':
            fields(e,'kind at proposal');self._active(dict(kind='tick',at=e['at']));p=self.plan()
            require(p is not None and canon(p)==canon(e['proposal']),'proposal_binding')
            self.spent+=p['cost'];self.request_count+=1;organ=p['organ'];self.last_dispatch[organ]=self.request_count
            r=dict(id='bank'+str(self.request_count),organ=organ,cost=p['cost'],frame=self.mapper.frame,issued_at=e['at'],deadline=e['at']+self.config['timeout'],payload=p['payload'])
            if organ=='window':
                self._active(dict(kind='dispatch',at=e['at'],proposal=p['payload']));r['inner']=copy.deepcopy(self.mapper.pending)
                r['deadline']=self.mapper.pending['deadline']
            else:self.attempts[self.bool_key(organ,p['payload']['sector'])]=e['at']
            r['exposure']=seal('Exposure',r);self.pending=r;self.last=dict(kind=k,request=r)
        elif k=='window_result':
            fields(e,'kind at request exposure event');r=self.pending
            require(r is not None and r['organ']=='window' and e['request']==r['id'] and e['exposure']==r['exposure'],'window_binding')
            inner=e['event'];require(type(inner) is dict and inner.get('kind') in ['patch','fail'] and inner.get('at')==e['at'],'window_type')
            # A patch id is generated by the monotonically retained inner request count.
            if inner['kind']=='patch':require(inner['patch']['id']=='patch'+str(self.mapper.spent),'patch_generation')
            self._active(inner);self.last=dict(kind=k,result=self.active.last);self.pending=None
        elif k=='boolean_result':
            fields(e,'kind at request exposure outcome value sampled_at sample_ref');r=self.pending
            require(r is not None and r['organ'] in ['ray_clear','beacon_present'] and e['request']==r['id'] and e['exposure']==r['exposure'],'boolean_binding')
            require(e['outcome'] in ['OK','OCCLUDED','ERROR','TIMEOUT'],'boolean_outcome')
            require(e['outcome']!='OCCLUDED' or r['organ']=='beacon_present','query_occlusion')
            require(e['outcome']!='TIMEOUT' or e['at']>=r['deadline'],'early_timeout')
            if e['outcome'] in ['OK','OCCLUDED']:
                require(type(e['value']) is bool if e['outcome']=='OK' else e['value'] is None,'boolean_value')
                require(uint(e['sampled_at']) and r['issued_at']<=e['sampled_at']<=e['at'],'sample_time')
                require(type(e['sample_ref']) is str and len(e['sample_ref'])==64 and all(c in '0123456789abcdef' for c in e['sample_ref']),'sample_ref')
            else:require(e['value'] is None and e['sampled_at'] is None and e['sample_ref'] is None,'failure_payload')
            self._active(dict(kind='tick',at=e['at']));status='SUPERSEDED' if r['frame']!=self.mapper.frame else 'TIMEOUT' if e['at']>r['deadline'] else e['outcome'];retired=[]
            if status in ['OK','OCCLUDED']:
                key=self.bool_key(r['organ'],r['payload']['sector'])
                if key in self.boolean:retired.append(self._archive('boolean',key,self.boolean[key]))
                self.boolean[key]=dict(request=r['id'],query=r['organ'],sector=r['payload']['sector'],frame=r['frame'],sampled_at=e['sampled_at'],outcome=status,value=e['value'],sample_ref=e['sample_ref'])
            self.pending=None;self.last=dict(kind=k,status=status,archived=retired)
        elif k=='compact':
            fields(e,'kind at items');self._active(dict(kind='tick',at=e['at']));items=self.compactable()
            require(items and canon(items)==canon(e['items']),'retirement_binding');entries=[]
            for item in items:
                if item['type']=='patch':
                    value=self.mapper.patches.pop(item['id']);self.mapper.retracted=[x for x in self.mapper.retracted if x!=item['id']]
                else:value=self.boolean.pop(item['id'])
                entries.append(self._archive(item['type'],item['id'],value))
            self.last=dict(kind=k,archived=entries)
        elif k in ['pause','frame','tick','stop','resume']:
            if k=='stop':require(self.pending is None,'drain_before_stop')
            if k=='resume':self.pending=None
            self._active(e);self.last=dict(kind=k,result=self.active.last)
        else:raise ValueError('event_kind')
