"""Real worker and HTTP proofs; archive stress uses explicitly advanced clock offsets."""
import json,shutil,tempfile,threading,time
from pathlib import Path
from urllib.request import urlopen,Request
from organ_bank import config
from bank_journal import BankJournal,replay
from bank_runtime import BankService,fixture,export,html
from field_world import generate_world
from adapters import MonotonicClock
from live import server_for

def setup(d,budget=160):
    d.mkdir();w=d/'world.json';w.write_text(json.dumps(fixture(),indent=2));f=d/'field.json';f.write_text(json.dumps(generate_world(23,sectors=4),indent=2))
    c=config(w,f);c['budget']=budget;return c

def live_run(d):
    c=setup(d,32);j=BankJournal(d/'bank.jsonl',c);s=BankService(j);server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])))
    t=threading.Thread(target=server.serve_forever,daemon=True);t.start();base=f'http://127.0.0.1:{server.server_port}';checks=0
    try:
        with urlopen(base) as r:assert 'Organbank'.encode() in r.read()
        end=time.monotonic()+10
        while len(s.current['patches'])<4:
            assert time.monotonic()<end;s.cycle()
            with urlopen(base+'/api/updates') as r:assert json.load(r)['snapshot']==s.current
            checks+=1;time.sleep(.02)
        with urlopen(Request(base+'/api/control',data=b'{"kind":"pause","paused":true}',headers={'Content-Type':'application/json'})) as r:assert r.status==202
        s.cycle();assert s.current['paused'];spent=s.current['spent']
        s.stop_reason='user'
        while s.cycle():time.sleep(.02)
        assert s.current['spent']==spent
    finally:server.shutdown();server.server_close();t.join();s.close()
    result=export(d/'bank.jsonl',d/'replay.html');result.update(http_checks=checks,paused_spent=spent)
    (d/'report.json').write_text(json.dumps(result,indent=2));return result

def archive_run(d):
    c=setup(d);c['atlas']['atlas'].update(ttl=10000,max_patches=4);c['atlas']['refresh']=100
    c.update(ttl=10000,refresh=100)
    (d/'protocol.json').write_text(json.dumps(dict(rounds=10,windows_per_round=4,budget=160,resident_patch_limit=4,clock='Actual process clocks with explicit forward offsets between rounds; no latency benchmark'),indent=2))
    j=BankJournal(d/'bank.jsonl',c);s=BankService(j);rounds=[];peak=0;first_ref=None
    try:
        for round_no in range(10):
            if round_no:
                offset=s.engine.machine.mapper.at+10001;s.clock=MonotonicClock(offset)
                s.commit(dict(kind='tick',at=offset));items=s.engine.machine.compactable()
                if items:s.commit(dict(kind='compact',at=offset,items=items))
            target=4*(round_no+1)
            end=time.monotonic()+20
            while s.engine.machine.mapper.spent<target:
                assert time.monotonic()<end
                s.commit(dict(kind='tick',at=s.now()));p=s.engine.machine.plan()
                if not p:time.sleep(.01);continue
                s.commit(dict(kind='dispatch',at=s.engine.machine.mapper.at,proposal=p));r=s.measure(s.engine.machine.pending)
                assert r['kind']!='boolean_result' or r['outcome'] in ['OK','OCCLUDED']
                assert r['kind']!='window_result' or r['event']['kind']=='patch'
                s.commit(r);peak=max(peak,len(s.engine.machine.mapper.patches));assert peak<=4
            state=s.current;rounds.append(dict(round=round_no+1,spent=state['spent'],archive=state['archive']['count'],patches=state['resident']['patches']))
            if round_no==0:
                from mapping import hashof
                first_ref=hashof('Patch',state['patches'][0])
            if round_no==4:
                cost=s.engine.machine.spent;s.commit(dict(kind='stop',at=s.now(),reason='user'));s.close()
                j=BankJournal.reopen(d/'bank.jsonl');at=j.machine.mapper.at+1;j.commit(dict(kind='resume',at=at));assert j.machine.spent==cost
                s=BankService(j,MonotonicClock(at))
        assert s.engine.machine.spent==160 and s.engine.machine.mapper.spent==40
        s.commit(dict(kind='stop',at=s.now(),reason='duration'))
    finally:s.close()
    result=export(d/'bank.jsonl',d/'replay.html');resolved=replay(d/'bank.jsonl',resolve=first_ref)['resolved'];assert len(resolved)==1
    result.update(rounds=rounds,peak_resident_patches=peak,window_measurements=40,resolve_ref=first_ref,resolved_exact=True,real_processes=120)
    (d/'report.json').write_text(json.dumps(result,indent=2));return result

def main():
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--out',default='new_bank_run');args=parser.parse_args()
    target=Path(args.out);assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps_bank_') as tmp:
        d=Path(tmp)/'verified';d.mkdir();live=live_run(d/'live');archive=archive_run(d/'archive')
        (d/'report.json').write_text(json.dumps(dict(live=live,archive=archive),indent=2));shutil.copytree(d,target)
    print(json.dumps(dict(live=live,archive=archive),indent=2))
if __name__=='__main__':main()
