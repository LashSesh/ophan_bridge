"""Actual asynchronous workers + HTTP, pause/expiry/restart; isolated journal IO."""
import json,shutil,tempfile,threading,time
from pathlib import Path
from urllib.request import urlopen,Request
from active_atlas import ActiveJournal,config,replay
from active_runtime import ActiveService,fixture,export,html
from live import server_for
from adapters import MonotonicClock

def run(d):
    d=Path(d);d.mkdir();w=d/'world.json';w.write_text(json.dumps(fixture(),indent=2))
    c=config(w);c['atlas']['budget']=12
    j=ActiveJournal(d/'active.jsonl',c);s=ActiveService(j);server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])))
    t=threading.Thread(target=server.serve_forever,daemon=True);t.start();base=f'http://127.0.0.1:{server.server_port}';checks=0;stages=[]
    def check():
        nonlocal checks
        with urlopen(base+'/api/updates') as r:state=json.load(r)['snapshot']
        assert state==s.current;checks+=1
    def drive(predicate,limit=5):
        end=time.monotonic()+limit
        while not predicate():
            assert time.monotonic()<end,'stage timeout';assert s.cycle();check();time.sleep(.02)
    def stage(name):
        stages.append(dict(name=name,sequence=s.current['sequence'],spent=s.current['spent'],glued=sum(p['status']=='GLUED' for p in s.current['atlas']['pairs']),patches=len(s.current['patches'])))
    def command(c):
        with urlopen(Request(base+'/api/control',data=json.dumps(c).encode(),headers={'Content-Type':'application/json'})) as r:assert r.status==202
    try:
        drive(lambda:len(s.current['attempts'])==4 and s.future is None);stage('boundary_expansion')
        assert sum(p['status']=='GLUED' for p in s.current['atlas']['pairs'])>=3
        command(dict(kind='pause',paused=True));drive(lambda:s.current['paused']);stage('paused')
        spent=s.current['spent'];until=s.clock.now()+1600
        drive(lambda:s.clock.now()>=until);assert s.current['spent']==spent and not s.current['patches'];stage('paused_expired')
        command(dict(kind='pause',paused=False));drive(lambda:s.current['spent']>=spent+4 and s.future is None);stage('reacquired')
        s.stop_reason='duration'
        while s.cycle():time.sleep(.02)
        check();stage('stopped')
    finally:server.shutdown();server.server_close();t.join();s.close()
    before=replay(d/'active.jsonl');cost=before['machine'].mapper.spent
    j=ActiveJournal.reopen(d/'active.jsonl');at=j.machine.mapper.at+1501;j.commit(dict(kind='resume',at=at));assert j.machine.mapper.spent==cost
    s=ActiveService(j,MonotonicClock(at))
    try:
        end=time.monotonic()+5
        while s.current['spent']<cost+2 or s.future:
            assert time.monotonic()<end;s.cycle();time.sleep(.02)
        s.stop_reason='duration'
        while s.cycle():time.sleep(.02)
    finally:s.close()
    report=dict(**export(d/'active.jsonl',d/'replay.html'),http_checks=checks,stages=stages,restart_preserved_spent=cost,real_async_processes=True,visual_browser_review=False)
    (d/'report.json').write_text(json.dumps(report,indent=2));return report
if __name__=='__main__':
    target=Path('active_evidence_run');assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps_active_') as tmp:
        d=Path(tmp)/'run';r=run(d);replay(d/'active.jsonl');shutil.copytree(d,target)
    print(json.dumps(r,indent=2))
