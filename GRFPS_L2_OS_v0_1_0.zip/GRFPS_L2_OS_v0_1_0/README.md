# GRFPS — 2nd-Layer Synthetic Perception OS

**Ausführbares Referenzprofil 0.1.0 auf Basis von GRFPS v3.0.0.**

Das Paket entwickelt die vorhandene Perceptual-OS-Architektur zu einem
prüfbaren Betriebsvertrag weiter. Ein Python-Kern erzeugt aus Beobachtungen
zeitgebundene Modellzustände, eine operative Graphregion, Sondenvorschläge
und eine Herkunft tragende Ansicht. Jeder gespeicherte Lauf lässt sich
vollständig neu ausführen und vergleichen.

## Sofort ansehen

**GRFPS_Second_Layer_Demo.html** im Browser öffnen.

- Mit **Abspielen** oder dem Zeitschieber durch 20 Pulse navigieren.
- Einen Knoten auswählen, um Aussage, Supportgruppen, Zeit und Quellen zu sehen.
- Puls 7 zeigt einen Widerspruch, Puls 11 dessen Auflösung.
- Puls 13 zeigt Frameverlust. Puls 16 zeigt Evidenzablauf und die leere Region.
- Puls 20 zeigt die erfolgreiche Wiedererfassung.
- **Run öffnen** lädt weitere vom Kern erzeugte JSON-Bundles. Im Browser
  importierte Daten werden als ungeprüfte Ansicht gekennzeichnet.

Die Servicewelt verwendet konstruierte Testdaten. Das Diagramm zeigt
Modellbeziehungen. Seine Bildschirmkoordinaten sind keine Raumkoordinaten.

## Ausführen

Python 3.10 oder neuer. Der Kern benötigt ausschließlich die Standardbibliothek.
Die Befehle im entpackten Paketordner ausführen:

~~~sh
python -m unittest -v
python build_demo.py
python grfps_l2.py replay demo_run.json
~~~

Eigene Beobachtungen im dokumentierten JSONL-Format verarbeiten:

~~~sh
python grfps_l2.py run --genome genome.json --events demo_events.jsonl --out my_run.json --view my_view.html
~~~

Reale Dateizustände erfassen:

~~~sh
python capture_files.py --out files.json --view files.html grfps_l2.py genome.json absent-example.txt
~~~

Dieser Adapter liest Dateimetadaten, keine Inhalte. Er meldet, ob ein Pfad
zum Aufnahmezeitpunkt eine reguläre Datei ist. Ein gemeinsamer Verzeichnisanker
wird gesondert erfasst. Known / false ist hier ein gültiges negatives
Abfrageergebnis. Zugriffsfehler werden Invalid. Das Ein-Quellen-Profil
bezieht sich auf das Ergebnis dieser lokalen Abfrage; es behauptet keine
unabhängige Sensorfusion. ASCII-Pfade und höchstens 32 Eingabepfade werden
unterstützt. Der gespeicherte Zustand ist eine Aufnahme, keine Liveanzeige.

## Was bereits funktioniert

| Bereich | Implementierung |
|---|---|
| Genome | Normalform, IDs, Signaturen, Abhängigkeiten, deterministischer Plan |
| Kernel | Transaktionen, Eingabevalidierung, Budgets, Epochen |
| Evidenz | Neueste Kanalspitze, gleichzeitiger Konflikt, TTL, Rücknahme |
| Klassen | Known, Ambiguous, Unknown, OutOfScope, Invalid |
| Quellen | Deklarierte Abhängigkeitsgruppen; Kopien erhöhen das Quorum nicht |
| Karte | Aktuelle positive Zusammenhangskomponente im vorgegebenen Graphen |
| Navigation | Zielgebundener Pfad oder budgetierte Sondenvorschläge |
| Ansicht | Knoteninspektion, Herkunft, zeitgebundene Zustände, Replayauswahl |
| Replay | Neukompilation und Neuinterpretation der kompletten Ereignisfolge |
| Reale Quelle | Dateisystemabfrage mit aufgezeichneter Zeit |

## Präzise Reichweite

- Dies ist ein boolesches Ausführungsprofil, keine vollständige
  GRFPS-v3-Konformitätserklärung. Das Ziel ist ein Perception OS auf einem
  Hostbetriebssystem; ein hardwareverwaltender Kernel ist nicht enthalten.
- Known bedeutet erfüllter Profilvertrag. Deklarierte Quellengruppen
  beweisen weder statistische Unabhängigkeit noch Außenweltwahrheit.
- Der Graph ist im Genome angegeben. Unbekannte Topologie wird nicht
  rekonstruiert; Patchgluing und Nervenkomplexe sind noch nicht implementiert.
- Die Sondenheuristik gibt Vorschläge aus. Der Demonstrationslauf folgt
  einem Skript und ist kein geschlossener adaptiver Messzyklus.
- Die Registry bindet drei feste Operatoren. Rotorfaser, echte Ophanzyklen,
  Quaternionenlift, Gyrosphäre und verlustbewusste Skalenoperatoren bleiben
  spezifizierte Erweiterungen.
- ADVANCE ist Modellnavigation. Externe Aktionen, Berechtigungsverwaltung
  und ein ausführender Effect Port sind nicht enthalten.
- Hashes und Replay prüfen Konsistenz; sie authentifizieren keine Quelle.
- Der Kern arbeitet mit endlichen Runs und vollständigen Snapshots.
  Ein kontinuierlicher Dienst, inkrementelle Persistenz, automatische
  Sedimentation und reale XR-Registrierung sind weitere Implementierungsstufen.
- Python dient als ausführbare Semantikreferenz für eine spätere Rust-Portierung.

## Eingabe- und Zeitvertrag

Alle Ereignisse tragen id, kind, at, label.
Zusätzliche Felder sind abhängig von der Familie:

| kind | Zusätzliche Pflichtfelder |
|---|---|
| observe | time, fact, source, value, quality, visibility |
| retract | ref |
| target | fact |
| tracking | valid |
| tick | keine |

at ist der monotone Aufnahmetakt; time ist die Ereigniszeit.
time <= at ist Pflicht. Eine aktuelle Beobachtung ist gültig, solange
clock - time < ttl. Die neuesten Beobachtungen einer Quelle und Frage
ersetzen frühere. Gleiche Zeitpunkte mit verschiedenen Werten bleiben
widersprüchlich. Rücknahmen reaktivieren keine älteren Werte.

L2-CANON-1 verwendet ASCII-JSON und ganze Zahlen im exakten
JavaScript-Zahlenbereich. Fließkommazahlen und doppelte JSON-Schlüssel
werden abgewiesen. Ein aktiver Dienst müsste die zum Evidenzablauf
notwendigen Tick-Ereignisse selbst erzeugen.

## Nachweise

**validation.json** und **test_results.txt** dokumentieren die ausgeführten
Vertragstests sowie Replays der synthetischen Welt und der Dateiaufnahme.
Das ist ein Implementierungsnachweis, kein empirischer Blindbenchmark.
Die HTML-Logik wird durch **test_viewer.cjs** gegen echte Run-Snapshots
in einer minimalen DOM-Testumgebung geprüft. Visuelle Browserprüfung und
DOM-Verhalten sind im Bericht getrennt ausgewiesen.

Der SHA-256-Hash der bereitgestellten 104-seitigen Ausgangs-PDF ist:

~~~text
bfefe77119e3a17048bb7f26fdb9df5ac3fe9744a085ce759d6e79f4e5824252
~~~

## Dokumentation

**GRFPS_2nd_Layer_OS.pdf** enthält Systemvertrag, formale Ableitungen,
Realisierungsmatrix und den nächsten konkreten Implementierungszug.
**GRFPS_2nd_Layer_OS.tex** ist eigenständig kompilierbar, auch in Overleaf.
Keine externen Bilder und kein BibTeX erforderlich:

~~~sh
pdflatex GRFPS_2nd_Layer_OS.tex
pdflatex GRFPS_2nd_Layer_OS.tex
~~~
