"""Reproduce kernel tests, demo replay, and a real file capture."""
import io
import json
import platform
import unittest
from pathlib import Path
from grfps_l2 import Kernel, loads, replay
from capture_files import capture
import test_kernel

root=Path(__file__).parent
stream=io.StringIO()
suite=unittest.defaultTestLoader.loadTestsFromModule(test_kernel)
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
(root/"test_results.txt").write_text(stream.getvalue())
demo=replay(loads((root/"demo_run.json").read_text()))
captured=capture([root/"grfps_l2.py",root/"genome.json",root/"absent-example.txt"])
(root/"file_capture_run.json").write_text(json.dumps(captured,indent=2))
report={"profile":"grfps-l2-boolean/0.1.0","python":platform.python_version(),
        "tests_run":result.testsRun,"failures":len(result.failures),
        "errors":len(result.errors),"success":result.wasSuccessful(),
        "randomized_test_events":120,"demo_replay":demo,
        "real_file_capture_replay":replay(captured),
        "benchmark_type":"contract tests and scripted integration; no blind benchmark",
        "source_pdf_pages":104,
        "source_pdf_sha256":"bfefe77119e3a17048bb7f26fdb9df5ac3fe9744a085ce759d6e79f4e5824252"}
(root/"validation.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
if not result.wasSuccessful():raise SystemExit(1)
