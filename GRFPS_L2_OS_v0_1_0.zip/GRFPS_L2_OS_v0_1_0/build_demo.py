"""Create a deterministic scripted reference-world run, not a blind benchmark."""
import json
from pathlib import Path
from grfps_l2 import Kernel, loads, render, replay

ROOT = Path(__file__).parent
events=[]


def observe(fact,source,value,at,label,visibility="observed",quality="valid",time=None):
    events.append({"id":"obs"+str(len(events)+1),"kind":"observe","at":at,
                   "time":at if time is None else time,"fact":fact,"source":source,
                   "value":value,"quality":quality,"visibility":visibility,"label":label})


def event(kind,at,label,**kw):
    events.append(dict(id="event"+str(len(events)+1),kind=kind,at=at,label=label,**kw))


observe("gateway","sensor_a",True,1,"Gateway: first source; support incomplete")
observe("gateway","sensor_a_copy",True,1,"Copied source adds no independent support group")
observe("gateway","sensor_b",True,2,"Gateway: declared second source group agrees")
observe("api","sensor_a",True,3,"API: first source")
observe("api","sensor_b",True,4,"API: current region expands")
observe("database","sensor_a",True,5,"Database: first source")
observe("database","sensor_b",False,6,"Database conflict: retain both observations")
observe("cache","sensor_a",True,7,"Cache: first source")
observe("cache","sensor_b",True,8,"Cache: current region expands")
observe("worker","sensor_a",None,9,"Worker is occluded; absence is not inferred",visibility="occluded")
observe("database","sensor_b",True,10,"New database observation resolves active conflict")
event("target",11,"Target changes; evidence identity remains",fact="cache")
event("tracking",12,"Carrier test: registration lost",valid=False)
event("tracking",13,"Carrier test: new frame epoch",valid=True)
observe("database","sensor_a",False,14,"Late old observation retained, not made current",time=2)
event("tick",42,"Evidence expires; certified region contracts")
observe("gateway","sensor_a",True,43,"Reacquisition: gateway first source")
observe("gateway","sensor_b",True,44,"Reacquisition: gateway known again")
observe("cache","sensor_a",True,45,"Reacquisition: cache first source")
observe("cache","sensor_b",True,46,"Reacquisition: path restored")


if __name__=="__main__":
    k=Kernel(loads((ROOT/"genome.json").read_text()))
    for e in events:k.step(e)
    b=k.bundle()
    (ROOT/"demo_events.jsonl").write_text("\n".join(json.dumps(e) for e in events)+"\n")
    (ROOT/"demo_run.json").write_text(json.dumps(b,indent=2))
    render(b,ROOT/"GRFPS_Second_Layer_Demo.html")
    print(json.dumps(replay(b),indent=2))
