"""GRFPS organ profile 0.3: finite angular exposure and explicit lifecycle.

This is a discrete instrument model, not physical rotation or a spinor model.
All external measurements and clock readings enter through typed events.
"""
from __future__ import annotations
import copy
import json
from pathlib import Path
from grfps_l2 import canon, digest, fields, ident, require, uint, compile_genome
from session import IncrementalKernel

ORGAN_PROFILE = "grfps-organ-session/0.3.0"
WORLD_PROFILE = "grfps-radial-field/0.3.0"
STATES = ("UNBOUND", "READY", "EXPOSING", "WAITING", "INTEGRATING",
          "COOLDOWN", "FAULT", "STOPPED")
ACTIVE = ("EXPOSING", "WAITING", "INTEGRATING")
LIFECYCLE = ("TEMPLATE", "INSTANTIATED", "CALIBRATED", "ACTIVE", "QUIESCENT", "RETIRED")


def calibration_contract(config):
    return {"operator":"ideal_ray@1","world_contract":config["world_contract"],
            "sectors":config["sectors"],"aperture_sectors":1,"frame":"radial_index",
            "time_unit":"millisecond","calibration_kind":"model_contract"}


def field_config(path, *, policy="coverage", sectors=8, budget=32,
                 ttl_ms=2000, timeout_ms=500, cooldown_ms=50,
                 segment_records=64, max_transitions=10000):
    return normalize_config({
        "profile": ORGAN_PROFILE, "name": "radial-instrument-bank",
        "world_path": str(Path(path).absolute()), "world_contract": WORLD_PROFILE,
        "sectors": sectors, "policy": policy, "policy_seed": 17,
        "ttl_ms": ttl_ms, "timeout_ms": timeout_ms, "cooldown_ms": cooldown_ms,
        "tick_ms": 40, "budget": budget, "probe_cost": 1,
        "max_transitions": max_transitions, "segment_records": segment_records,
        "max_segments": 1024,
        "organs": [{"id": "clearance", "query": "ray_clear", "source": "field_clearance"},
                   {"id": "beacon", "query": "beacon_present", "source": "field_beacon"}]})


def normalize_config(raw):
    c = copy.deepcopy(raw)
    canon(c)
    fields(c, "profile name world_path world_contract sectors policy policy_seed "
              "ttl_ms timeout_ms cooldown_ms tick_ms budget probe_cost "
              "max_transitions segment_records max_segments organs")
    require(c["profile"] == ORGAN_PROFILE and ident(c["name"]), "organ_profile")
    require(c["world_contract"] == WORLD_PROFILE, "world_contract")
    require(type(c["world_path"]) is str and 0 < len(c["world_path"]) <= 1024,
            "world_path")
    require(uint(c["sectors"]) and 2 <= c["sectors"] <= 16, "sector_count")
    require(c["policy"] in ["coverage", "fixed", "uniform"], "exposure_policy")
    require(uint(c["policy_seed"]) and c["policy_seed"] < 2**31, "policy_seed")
    for k in ["ttl_ms", "timeout_ms", "tick_ms", "probe_cost", "max_transitions",
              "segment_records", "max_segments"]:
        require(uint(c[k]) and 0 < c[k] <= 1000000, "positive_limit:" + k)
    require(uint(c["budget"]) and c["budget"] <= 1000000, "budget")
    require(uint(c["cooldown_ms"]) and c["cooldown_ms"] <= 1000000, "cooldown")
    require(c["max_transitions"] >= 20, "transition_capacity")
    require(type(c["organs"]) is list and len(c["organs"]) == 2, "organ_bank")
    ids, queries, sources = set(), set(), set()
    for o in c["organs"]:
        fields(o, "id query source")
        require(ident(o["id"]) and o["id"] not in ids, "organ_id")
        require(ident(o["source"]) and o["source"] not in sources, "organ_source")
        require(o["query"] in ["ray_clear", "beacon_present"] and o["query"] not in queries,
                "organ_query")
        ids.add(o["id"]); queries.add(o["query"]); sources.add(o["source"])
    c["organs"].sort(key=lambda o: o["id"])
    return c


def fact_id(organ, sector):
    return organ + ".s" + str(sector)


def genome_for(config):
    g = json.loads(Path(__file__).with_name("genome.json").read_text())
    n = config["sectors"]
    g.update(name="radial-field", ttl=config["ttl_ms"], min_groups=1,
             max_events=2*config["max_transitions"]+2,
             sources={o["source"]: "single_simulator" for o in config["organs"]},
             facts=[{"id": fact_id(o["id"], s),
                     "label": o["query"] + " / sector " + str(s), "scope": True}
                    for o in config["organs"] for s in range(n)],
             edges=[[fact_id(o["id"], s), fact_id(o["id"], (s+1) % n)]
                    for o in config["organs"] for s in range(n)])
    anchor = next(o["id"] for o in config["organs"] if o["query"] == "ray_clear")
    target = next(o["id"] for o in config["organs"] if o["query"] == "beacon_present")
    g.update(center=fact_id(anchor, 0), target=fact_id(target, 0))
    g["edges"] += [[fact_id(anchor, s), fact_id(target, s)] for s in range(n)]
    return compile_genome(g)[0]


class OrganKernel(IncrementalKernel):
    """The outer segment journal owns replay snapshots.

    Keep inner event accounting and trace digests, but do not duplicate every
    historical rendered state inside every transaction candidate.
    """
    def step(self, event):
        result = super().step(event)
        self.snapshots.clear()
        return result

    def bundle(self):
        raise ValueError("organ_kernel_use_segment_replay")


class OrganMachine:
    def __init__(self, config):
        self.config = normalize_config(config)
        self.config_digest = digest(ORGAN_PROFILE, self.config)
        self.kernel = OrganKernel(genome_for(self.config))
        self.seq, self.phase, self.paused = 0, "RUNNING", False
        self.limit, self.spent, self.budget_epoch = self.config["budget"], 0, 0
        self.request_count = 0
        self.rng = self.config["policy_seed"]
        self.attempts, self.completed, self.abandoned = {}, {}, []
        self.organs = {o["id"]: {
            "state": "UNBOUND", "lifecycle": "TEMPLATE", "calibration": None,
            "sector": 0, "unwrapped_step": 0,
            "exposure": None, "request": None, "receipt": None,
            "last_result": None, "ready_at": 0, "last_dispatch": -1,
            "bindings": 0} for o in self.config["organs"]}

    @property
    def clock(self):
        return self.kernel.s["clock"]

    def descriptor(self, organ):
        return next(o for o in self.config["organs"] if o["id"] == organ)

    def plan(self):
        if (self.phase != "RUNNING" or self.paused or not self.kernel.s["tracking"]
                or any(o["state"] in ACTIVE for o in self.organs.values())
                or self.spent+self.config["probe_cost"] > self.limit):
            return []
        choices = []
        for oid, o in self.organs.items():
            if o["state"] != "READY" or o["lifecycle"] != "ACTIVE":
                continue
            if self.config["policy"] == "fixed":
                sector = 0
            elif self.config["policy"] == "uniform":
                sector = ((1103515245*self.rng+12345) % 2**31) >> 16
                sector %= self.config["sectors"]
            else:
                sector = min(range(self.config["sectors"]),
                             key=lambda s: (self.attempts.get(fact_id(oid, s), -1), s))
            choices.append({"organ": oid, "sector": sector,
                            "fact": fact_id(oid, sector), "query": self.descriptor(oid)["query"],
                            "cost": self.config["probe_cost"], "last_dispatch": o["last_dispatch"]})
        return sorted(choices, key=lambda p: (p["last_dispatch"], p["organ"]))

    def snapshot(self):
        k = self.kernel.snapshot()
        active = {ref for p in k["percepts"].values() for ref in p["active_refs"]}
        s = {"profile": ORGAN_PROFILE, "config_digest": self.config_digest,
             "sequence": self.seq, "phase": self.phase, "paused": self.paused,
             "kernel": k, "organs": copy.deepcopy(self.organs), "plan": self.plan(),
             "budget": {"limit": self.limit, "spent": self.spent, "epoch": self.budget_epoch},
             "request_count": self.request_count, "attempts": dict(self.attempts),
             "rng": self.rng, "completed": dict(self.completed), "abandoned": list(self.abandoned),
             "active_evidence": {ref: copy.deepcopy(self.kernel.s["observations"][ref])
                                 for ref in sorted(active)}}
        s["state_digest"] = digest("OrganState", s)
        return s

    def reduce(self, event):
        candidate = copy.deepcopy(self)
        result = candidate._apply(event)
        return candidate, result

    def _kernel_event(self, kind, **kw):
        e = dict(id="organ"+str(self.seq)+":"+kind, kind=kind, at=self.clock,
                 label="Organ " + kind, **kw)
        self.kernel.step(e)
        require(self.kernel.records[-1]["outcome"] == "COMMITTED", "inner_rejection")
        return e["id"]

    def _advance(self, at):
        if at > self.clock:
            self.kernel.step({"id":"organ"+str(self.seq)+":tick","kind":"tick",
                              "at":at,"label":"Organ clock"})
            require(self.kernel.records[-1]["outcome"] == "COMMITTED", "inner_clock")

    def _binding_current(self, x):
        return (x["target_epoch"] == self.kernel.s["epoch"]
                and x["frame_epoch"] == self.kernel.s["frame_epoch"]
                and not self.paused and self.kernel.s["tracking"])

    def _apply(self, e):
        canon(e)
        schema = {
            "tick":"kind at", "instantiate":"kind at organ",
            "calibrate":"kind at organ contract", "bind":"kind at organ", "expose":"kind at organ sector",
            "dispatch":"kind at organ", "receipt":"kind at organ request exposure outcome value sampled_at sample_ref detail",
            "integrate":"kind at organ", "release":"kind at organ", "recover":"kind at organ",
            "cancel":"kind at organ", "pause":"kind at paused", "target":"kind at fact",
            "tracking":"kind at valid", "budget":"kind at limit", "stop":"kind at reason",
            "resume":"kind at"}
        require(type(e) is dict and type(e.get("kind")) is str and e["kind"] in schema,
                "organ_event")
        fields(e, schema[e["kind"]])
        require(uint(e["at"]) and e["at"] >= self.clock, "organ_clock")
        require(self.seq < self.config["max_transitions"], "organ_capacity")
        kind = e["kind"]
        require(self.phase == "RUNNING" or kind == "resume", "organ_stopped")
        if "organ" in e:
            require(type(e["organ"]) is str and e["organ"] in self.organs, "organ_binding")
        if kind in ["pause", "tracking"]:
            require(type(e["paused" if kind == "pause" else "valid"]) is bool, "control_type")
        if kind == "target":
            require(e["fact"] in self.kernel.fact_ids, "target_binding")
        if kind == "budget":
            require(uint(e["limit"]) and self.spent <= e["limit"] <= 1000000, "budget_reservation")
        self._advance(e["at"])
        out = {"kind": kind}
        o = self.organs[e["organ"]] if "organ" in e else None
        old = o["state"] if o else None
        old_lifecycle = o["lifecycle"] if o else None
        if kind == "instantiate":
            require(old_lifecycle == "TEMPLATE", "instantiate_state")
            o["lifecycle"] = "INSTANTIATED"
        elif kind == "calibrate":
            require(old_lifecycle == "INSTANTIATED" and old == "UNBOUND", "calibrate_state")
            require(canon(e["contract"]) == canon(calibration_contract(self.config)), "calibration_contract")
            o["calibration"] = {"contract":copy.deepcopy(e["contract"]),"at":self.clock,
                                "ref":digest("Calibration",e)}
            o["lifecycle"] = "CALIBRATED"
        elif kind == "bind":
            require(old == "UNBOUND" and old_lifecycle == "CALIBRATED", "bind_state")
            o["bindings"] += 1
            o["state"] = "READY"
            o["lifecycle"] = "ACTIVE" if not self.paused and self.kernel.s["tracking"] else "QUIESCENT"
        elif kind == "expose":
            plan = self.plan()
            require(plan and e["organ"] == plan[0]["organ"] and
                    type(e["sector"]) is int and e["sector"] == plan[0]["sector"], "exposure_plan")
            require(old == "READY", "expose_state")
            n = self.config["sectors"]
            o["unwrapped_step"] += (e["sector"]-o["sector"]) % n
            o["sector"] = e["sector"]
            x = {"organ":e["organ"], "sector":e["sector"], "sectors":n,
                 "unwrapped_step":o["unwrapped_step"], "at":self.clock,
                 "query":self.descriptor(e["organ"])["query"],
                 "fact":fact_id(e["organ"],e["sector"]),
                 "target_epoch":self.kernel.s["epoch"], "frame_epoch":self.kernel.s["frame_epoch"],
                 "state_ref":self.kernel.snapshot()["state_digest"]}
            x["id"] = digest("Exposure", x)
            o["exposure"], o["state"] = x, "EXPOSING"
            if self.config["policy"] == "uniform":
                self.rng = (1103515245*self.rng+12345) % 2**31
            out["exposure"] = copy.deepcopy(x)
        elif kind == "dispatch":
            require(old == "EXPOSING" and self._binding_current(o["exposure"]), "dispatch_binding")
            cost = self.config["probe_cost"]
            require(self.spent+cost <= self.limit, "budget_exhausted")
            self.request_count += 1
            self.spent += cost
            x = o["exposure"]
            req = {"id":"measure"+str(self.request_count), "organ":e["organ"], "exposure":x["id"],
                   "sector":x["sector"], "query":x["query"], "fact":x["fact"],
                   "source":self.descriptor(e["organ"])["source"],
                   "issued_at":self.clock,"deadline":self.clock+self.config["timeout_ms"],
                   "target_epoch":x["target_epoch"],"frame_epoch":x["frame_epoch"],
                   "budget_epoch":self.budget_epoch,"cost":cost,"effect":"READ_SIMULATED_FIELD"}
            require(uint(req["deadline"]), "deadline_range")
            o["request"], o["state"], o["last_dispatch"] = req, "WAITING", self.seq
            self.attempts[req["fact"]] = self.seq
            out["request"] = copy.deepcopy(req)
        elif kind == "receipt":
            require(old == "WAITING", "receipt_state")
            req = o["request"]
            require(e["request"] == req["id"] and e["exposure"] == req["exposure"], "receipt_binding")
            require(e["outcome"] in ["OK","OCCLUDED","TIMEOUT","ERROR"], "receipt_outcome")
            require(type(e["detail"]) is str and len(e["detail"]) <= 256, "receipt_detail")
            if e["outcome"] in ["OK","OCCLUDED"]:
                require(uint(e["sampled_at"]) and req["issued_at"] <= e["sampled_at"] <= self.clock,
                        "sample_time")
                require(type(e["sample_ref"]) is str and len(e["sample_ref"]) == 64
                        and all(c in "0123456789abcdef" for c in e["sample_ref"]), "sample_ref")
                require(type(e["value"]) is bool if e["outcome"] == "OK" else e["value"] is None,
                        "sample_value")
            else:
                require(e["value"] is None and e["sampled_at"] is None and e["sample_ref"] is None,
                        "failed_sample")
            o["receipt"], o["state"] = copy.deepcopy(e), "INTEGRATING"
            out["receipt_ref"] = digest("OrganReceipt", e)
        elif kind == "integrate":
            require(old == "INTEGRATING", "integrate_state")
            receipt, req = o["receipt"], o["request"]
            status = receipt["outcome"]
            if receipt["at"] > req["deadline"]:
                status = "TIMEOUT"
            if not self._binding_current(req):
                status = "SUPERSEDED"
            ref = None
            if status != "SUPERSEDED":
                measured = status in ["OK","OCCLUDED"]
                ref = self._kernel_event("observe", fact=req["fact"],source=req["source"],
                    time=receipt["sampled_at"] if measured else self.clock,
                    value=receipt["value"] if status == "OK" else None,
                    quality="invalid" if status == "ERROR" else "valid",
                    visibility="observed" if status == "OK" else
                               "occluded" if status == "OCCLUDED" else "not_observed")
            result = {"request":req["id"],"exposure":req["exposure"],"fact":req["fact"],
                      "outcome":status,"observation_ref":ref,"sample_ref":receipt["sample_ref"],
                      "receipt_ref":digest("OrganReceipt",receipt),"at":self.clock}
            self.completed[req["id"]] = copy.deepcopy(result)
            o["last_result"] = result
            o["request"], o["receipt"] = None, None
            o["state"] = "FAULT" if status in ["ERROR","TIMEOUT"] else "COOLDOWN"
            o["ready_at"] = self.clock+self.config["cooldown_ms"]
            out["result"] = copy.deepcopy(result)
        elif kind in ["release","recover"]:
            require(old == ("FAULT" if kind == "recover" else "COOLDOWN"), "rearm_state")
            require(self.clock >= o["ready_at"], "rearm_cooldown")
            o["state"], o["exposure"] = "READY", None
        elif kind == "cancel":
            require(old == "EXPOSING", "cancel_state")
            out["cancelled_exposure"] = o["exposure"]["id"]
            o["state"], o["exposure"] = "READY", None
        elif kind == "pause":
            self.paused = e["paused"]
            self._sync_activity()
        elif kind == "target":
            self._kernel_event("target", fact=e["fact"])
        elif kind == "tracking":
            self._kernel_event("tracking", valid=e["valid"])
            self._sync_activity()
        elif kind == "budget":
            self.limit = e["limit"]
            self.budget_epoch += 1
        elif kind == "stop":
            require(ident(e["reason"]), "stop_reason")
            require(not any(x["state"] in ACTIVE for x in self.organs.values()), "stop_active")
            self.phase = "STOPPED"
            for x in self.organs.values():
                x["state"] = "STOPPED"
                x["lifecycle"] = "RETIRED"
            out["reason"] = e["reason"]
        elif kind == "resume":
            require(not any(p["active_refs"] for p in self.kernel.snapshot()["percepts"].values()),
                    "resume_requires_expiry")
            for oid, x in self.organs.items():
                if x["request"]:
                    self.abandoned.append(x["request"]["id"])
                x.update(state="UNBOUND", lifecycle="INSTANTIATED", calibration=None,
                         exposure=None, request=None, receipt=None, ready_at=0)
            self.phase, self.paused = "RUNNING", False
            out["abandoned"] = list(self.abandoned)
        self.seq += 1
        if o:
            out["transition"] = {"organ":e["organ"],"from":old,"to":o["state"]}
            out["lifecycle"] = {"from":old_lifecycle,"to":o["lifecycle"]}
        return out

    def _sync_activity(self):
        for o in self.organs.values():
            if o["lifecycle"] in ["ACTIVE","QUIESCENT"]:
                o["lifecycle"] = "ACTIVE" if not self.paused and self.kernel.s["tracking"] else "QUIESCENT"


def organ_view(state, config):
    k = state["kernel"]
    return {"profile":ORGAN_PROFILE,"sequence":state["sequence"],"state_digest":state["state_digest"],
            "phase":state["phase"],"paused":state["paused"],"clock":k["clock"],
            "tracking":k["tracking"],"target_epoch":k["epoch"],"frame_epoch":k["frame_epoch"],
            "target":k["navigation"]["target"],"navigation":k["navigation"],
            "organs":state["organs"],"descriptors":config["organs"],"sectors":config["sectors"],
            "policy":config["policy"],"budget":state["budget"],"request_count":state["request_count"],
            "attempts":state["attempts"],
            "plan":state["plan"],"evidence":state["active_evidence"],
            "completed":state["completed"],
            "objects":{v["fact"]:{"view":v,"percept":k["percepts"][v["fact"]]} for v in k["view"]},
            "region":k["region"],"edges":k["edges"]}
