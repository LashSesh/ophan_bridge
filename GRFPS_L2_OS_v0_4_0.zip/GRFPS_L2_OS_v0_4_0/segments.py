"""Hash-linked journal segments with continuous reducer state and full replay.

Rotation bounds individual files, not total in-memory history or replay cost.
One process owns a run directory; no concurrent-writer protocol is claimed.
"""
import os
from pathlib import Path
from grfps_l2 import canon, loads, require, digest
from journal import sealed, verify_seal, record_for, MAX_LINE
from organs import ORGAN_PROFILE, OrganMachine


def segment_header(machine, index, previous):
    return sealed("OrganSegment", {"type":"segment","profile":ORGAN_PROFILE,
        "index":index,"previous":previous,"start_sequence":machine.seq,
        "initial_state":machine.snapshot()["state_digest"],"config":machine.config})


def recover_segments(directory, *, allow_torn_tail=False, collect_views=False):
    directory = Path(directory)
    paths = sorted(directory.glob("segment-*.jsonl"))
    require(paths, "missing_segments")
    machine, head = None, None
    records, views, lengths = [], [], []
    tail, active_index, active_count = None, -1, 0
    for index, path in enumerate(paths):
        require(path.name == f"segment-{index:06d}.jsonl", "segment_gap")
        last = index == len(paths)-1
        with path.open("rb") as stream:
            line = stream.readline(MAX_LINE+1)
            require(len(line) <= MAX_LINE, "segment_header_bytes")
            if not line.endswith(b"\n"):
                require(last and allow_torn_tail and machine is not None, "torn_segment_header")
                tail = {"path":str(path),"offset":0}
                break
            h = loads(line)
            verify_seal("OrganSegment", h)
            if machine is None:
                machine = OrganMachine(h["config"])
            require(index < machine.config["max_segments"], "segment_limit")
            require(h == segment_header(machine, index, head), "segment_link_or_state")
            head = h["digest"]
            pos, count = len(line), 0
            while True:
                line = stream.readline(MAX_LINE+1)
                if not line:
                    break
                require(len(line) <= MAX_LINE, "segment_line_bytes")
                if not line.endswith(b"\n"):
                    require(last and allow_torn_tail, "torn_segment_record")
                    tail = {"path":str(path),"offset":pos}
                    break
                rec = loads(line)
                verify_seal("SessionTransition", rec)
                candidate, expected = record_for(machine, rec["event"], head)
                require(rec == expected, "segment_record_semantics")
                machine, head = candidate, rec["digest"]
                records.append(rec)
                if collect_views:
                    views.append(machine.snapshot())
                pos += len(line); count += 1
                require(count <= machine.config["segment_records"], "segment_record_limit")
            require(last or count == machine.config["segment_records"], "premature_segment_rotation")
            lengths.append(pos)
            active_index, active_count = index, count
    return {"machine":machine,"head":head,"records":records,"views":views,
            "segment_index":active_index,"segment_count":active_index+1,"record_count":active_count,
            "verified_lengths":lengths,"tail":tail}


class SegmentEngine:
    def __init__(self, directory, machine):
        self.directory, self.machine = Path(directory), machine
        self.index, self.count, self.head, self.stream = -1, 0, None, None

    def _check_writer(self):
        path = self.directory/f"segment-{self.index:06d}.jsonl"
        opened, named = os.fstat(self.stream.fileno()), path.stat()
        require((opened.st_dev, opened.st_ino) == (named.st_dev, named.st_ino),
                "segment_writer_file_replaced")
        require(self.stream.tell() == opened.st_size, "segment_writer_position")

    @classmethod
    def create(cls, directory, config):
        engine = cls(directory, OrganMachine(config))
        engine.directory.mkdir(parents=True, exist_ok=False)
        engine._rotate()
        return engine

    def _rotate(self):
        require(self.index+1 < self.machine.config["max_segments"], "segment_limit")
        if self.stream:
            self.stream.close()
        index = self.index+1
        header = segment_header(self.machine, index, self.head)
        stream = (self.directory/f"segment-{index:06d}.jsonl").open("xb")
        try:
            stream.write(canon(header)+b"\n"); stream.flush(); os.fsync(stream.fileno())
        except BaseException:
            stream.close()
            raise
        self.index, self.count, self.head, self.stream = index, 0, header["digest"], stream

    def commit(self, event):
        # Reject invalid input before creating a new segment.
        candidate, record = record_for(self.machine, event, self.head)
        if self.count >= self.machine.config["segment_records"]:
            self._rotate()
            candidate, record = record_for(self.machine, event, self.head)
        line = canon(record)+b"\n"
        require(len(line) <= MAX_LINE, "segment_record_bytes")
        try:
            self._check_writer()
            self.stream.write(line); self.stream.flush(); os.fsync(self.stream.fileno())
            self._check_writer()
        except BaseException:
            self.stream.close()
            raise
        self.machine, self.head = candidate, record["digest"]
        self.count += 1
        return record

    @classmethod
    def reopen(cls, directory):
        restored = recover_segments(directory, allow_torn_tail=True)
        if restored["tail"]:
            tail = restored["tail"]
            path, offset = Path(tail["path"]), tail["offset"]
            data = path.read_bytes()[offset:]
            with path.with_name(path.name+".torn").open("xb") as out:
                out.write(data); out.flush(); os.fsync(out.fileno())
            if offset == 0:
                path.unlink()  # Exact incomplete header bytes were saved above.
            else:
                with path.open("r+b") as out:
                    out.truncate(offset); out.flush(); os.fsync(out.fileno())
        engine = cls(directory, restored["machine"])
        engine.index, engine.count, engine.head = (restored["segment_index"],
            restored["record_count"], restored["head"])
        engine.stream = (engine.directory/f"segment-{engine.index:06d}.jsonl").open("ab")
        return engine

    def checkpoint(self):
        cp = sealed("OrganCheckpoint", {"profile":ORGAN_PROFILE,"segment_index":self.index,
            "record_count":self.count,"byte_position":self.stream.tell(),
            "head":self.head,"state":self.machine.snapshot()})
        target = self.directory/"checkpoint.json"
        temp = self.directory/"checkpoint.tmp"
        with temp.open("wb") as out:
            out.write(canon(cp)); out.flush(); os.fsync(out.fileno())
        os.replace(temp, target)
        return target

    def close(self):
        if self.stream:
            self.stream.close()


def verify_segment_checkpoint(directory):
    r = recover_segments(directory)
    cp = loads((Path(directory)/"checkpoint.json").read_bytes())
    verify_seal("OrganCheckpoint", cp)
    require(cp["profile"] == ORGAN_PROFILE and cp["segment_index"] == r["segment_index"]
            and cp["record_count"] == r["record_count"] and cp["head"] == r["head"]
            and cp["byte_position"] == r["verified_lengths"][-1]
            and canon(cp["state"]) == canon(r["machine"].snapshot()), "segment_checkpoint_mismatch")
    return True
