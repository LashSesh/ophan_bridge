"""Select files and open a bounded local perception session in the browser."""
import argparse
import datetime
import threading
import uuid
import webbrowser
from pathlib import Path
from adapters import file_config,MonotonicClock
from journal import JournalEngine
from live import LiveService,server_for


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("paths",nargs="*")
    p.add_argument("--duration",type=float,default=60)
    args=p.parse_args()
    paths=args.paths
    if not paths:
        try:
            import tkinter as tk
            from tkinter import filedialog
        except ImportError:
            p.error("No graphical file selector available. Supply file paths as arguments.")
        try:
            window=tk.Tk();window.withdraw()
            paths=list(filedialog.askopenfilenames(title="GRFPS: Dateien beobachten"))
            window.destroy()
        except tk.TclError:
            p.error("No graphical file selector available. Supply file paths as arguments.")
    if not paths:return
    if not 0<args.duration<=86400:p.error("Duration must be positive and at most 86400 seconds.")
    output=Path(__file__).parent/"runs";output.mkdir(exist_ok=True)
    stamp=datetime.datetime.now().strftime("%Y%m%d-%H%M%S")+"-"+uuid.uuid4().hex[:8]
    journal=output/(stamp+".jsonl")
    engine=JournalEngine.create(journal,file_config(paths))
    service=LiveService(engine,MonotonicClock())
    server=server_for(service)
    network=threading.Thread(target=server.serve_forever,daemon=True);network.start()
    worker=threading.Thread(target=service.run,args=(args.duration,),daemon=True);worker.start()
    url="http://127.0.0.1:"+str(server.server_port)
    print("GRFPS:",url,"\nJournal:",journal,flush=True)
    webbrowser.open(url)
    try:
        while worker.is_alive():worker.join(.5)
    except KeyboardInterrupt:
        service.stopping.set();worker.join()
    finally:
        server.shutdown();server.server_close();network.join();engine.close()
    if service.error:raise RuntimeError(service.error)
    print("Session closed. Replay:",journal)


if __name__=="__main__":main()
