/* Executes the actual viewer script against a minimal DOM and real run frames.
 * This is a logic test, not a rendered browser or accessibility test.
 */
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'closed_loop_demo.html'),'utf8');
const dataText=html.match(/<script id="sessionData" type="application\/json">([\s\S]*?)<\/script>/)[1];
const data=JSON.parse(dataText);
const code=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].at(-1)[1];
class Element{
  constructor(){this.children=[];this.style={};this.attrs={};this._text='';}
  set textContent(x){this._text=String(x);this.children=[];}
  get textContent(){return this._text+this.children.map(x=>x.textContent).join('');}
  append(...xs){this.children.push(...xs);}
  replaceChildren(...xs){this._text='';this.children=xs;}
  setAttribute(k,v){this.attrs[k]=v;}
  click(){if(this.onclick)this.onclick();}
}
const nodes=new Map(),get=id=>{if(!nodes.has(id))nodes.set(id,new Element());return nodes.get(id)};
get('sessionData').textContent=dataText;
let interval=null;
const context=vm.createContext({document:{getElementById:get,createElement:()=>new Element(),createElementNS:()=>new Element()},
  console,clearInterval:()=>{interval=null},setInterval:fn=>{interval=fn;return 1},setTimeout:()=>{},Date,
  fetch:()=>{throw Error('Unexpected network request in replay')}});
vm.runInContext(code,context,{filename:'live-viewer-script.js'});
const results=[];
function check(name,fn){fn();results.push({name,passed:true});}
const at=i=>get('timeline').oninput({target:{value:i}});
check('recorded_mode_has_no_network_dependency',()=>assert.equal(get('connection').textContent,'AUFZEICHNUNG'));
check('all_frames_render_from_machine_objects',()=>{
  for(let i=0;i<data.frames.length;i++){
    at(i);const s=data.frames[i];
    assert.equal(get('facts').children.length,Object.keys(s.objects).length);
    assert.equal(Number(get('region').textContent),s.region.length);
    assert.equal(Number(get('requests').textContent),s.request_count);
  }
});
check('real_removal_displays_known_false',()=>{
  const i=data.frames.findIndex(s=>s.objects.file0.percept.value===false);
  assert(i>=0);at(i);
  get('facts').children.find(b=>b.textContent.startsWith('alpha.txt')).click();
  assert(get('detail').textContent.includes('Known / false'));
  assert(get('evidence').textContent.includes('Wert false'));
});
check('paused_expiry_is_unknown',()=>{
  const i=data.frames.findIndex(s=>s.paused&&s.region.length===0&&Object.values(s.objects).every(o=>o.percept.epistemic==='Unknown'));
  assert(i>=0);at(i);
  assert(get('detail').textContent.includes('Unknown'));
});
check('request_deadline_is_visible',()=>{
  const i=data.frames.findIndex(s=>s.inflight);at(i);
  assert(get('process').textContent.includes('Frist'));
});
check('stopped_session_is_explicit',()=>{
  at(data.frames.length-1);
  assert(get('process').textContent.includes('abgeschlossen'));
});
check('navigation_controls_select_adjacent_transactions',()=>{
  at(2);get('previous').click();assert(get('stepLabel').textContent.startsWith('2 /'));
  get('next').click();assert(get('stepLabel').textContent.startsWith('3 /'));
});
check('delta_gap_is_rejected_by_actual_client_function',()=>{
  assert.throws(()=>vm.runInContext('applyDelta({sequence:1,state_digest:"a"},{from:2,pre:"a"})',context),/view_gap/);
});
console.log(JSON.stringify({checks:results,rendered_browser_review:false},null,2));
