"""One fixed read-only simulated field measurement per subprocess."""
import json
import sys
import time
from pathlib import Path
from grfps_l2 import loads, fields, require
from field_world import measure, world_ref


def main():
    raw = sys.stdin.buffer.readline(8193)
    try:
        require(len(raw) <= 8192, "request_bytes")
        request = loads(raw)
        fields(request, "path sectors query sector exposure")
        with Path(request["path"]).open("rb") as stream:
            content = stream.read(65537)
        require(len(content) <= 65536, "world_bytes")
        world = loads(content)
        require(world["sectors"] == request["sectors"], "world_sector_binding")
        result = measure(world, request["query"], request["sector"])
        result.update(sampled_ns=time.monotonic_ns(), sample_ref=world_ref(world),
                      exposure=request["exposure"], detail="finite_ray_query")
    except (OSError, ValueError, TypeError, KeyError):
        result = {"outcome":"ERROR","value":None,"sampled_ns":None,
                  "sample_ref":None,"exposure":None,"detail":"field_read_or_protocol"}
    sys.stdout.write(json.dumps(result)+"\n")


if __name__ == "__main__":
    main()
