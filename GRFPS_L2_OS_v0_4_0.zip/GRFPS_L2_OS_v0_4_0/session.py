"""Deterministic closed-loop session semantics and selective revalidation."""
from __future__ import annotations
import copy
from grfps_l2 import Kernel, canon, digest, fields, ident, require, uint, compile_genome

SESSION = "grfps-l2-session/0.2.0"


class IncrementalKernel(Kernel):
    """Same public state as the reference interpreter; cached local percepts."""
    def __init__(self, genome):
        self.cache, self.expires, self.dirty = {}, {}, set()
        self.revalidations = 0
        super().__init__(genome)

    def _percept(self, f):
        key = f["id"]
        if key not in self.cache or key in self.dirty:
            p = super()._percept(f)
            self.cache[key] = p
            self.expires[key] = min(
                (self.s["observations"][ref]["time"] + self.g["ttl"]
                 for ref in p["active_refs"]), default=None)
            self.dirty.discard(key)
            self.revalidations += 1
        return copy.deepcopy(self.cache[key])

    def _mutate(self, state, event):
        result = super()._mutate(state, event)
        self.dirty.update(k for k,t in self.expires.items()
                          if t is not None and t <= state["clock"])
        if event["kind"] == "observe":
            self.dirty.add(event["fact"])
        elif event["kind"] == "retract":
            self.dirty.add(state["observations"][event["ref"]]["fact"])
        return result


def config_normal_form(raw):
    c = copy.deepcopy(raw)
    canon(c)
    fields(c, "profile name genome endpoints timeout_ms refresh_ms retry_ms "
              "tick_ms queue_limit delta_limit checkpoint_every max_transitions")
    require(c["profile"] == SESSION and ident(c["name"]), "session_profile")
    for key in ["timeout_ms", "refresh_ms", "retry_ms", "tick_ms", "queue_limit",
                "delta_limit", "checkpoint_every", "max_transitions"]:
        require(uint(c[key]) and 0 < c[key] <= 1000000, "config_budget:" + key)
    c["genome"], manifest = compile_genome(c["genome"])
    require(c["genome"]["max_events"] >= 2*c["max_transitions"]+2, "kernel_capacity")
    require(c["refresh_ms"] < c["genome"]["ttl"], "refresh_before_expiry")
    require(c["genome"]["probe_budget"] >= manifest["probe_cost"], "probe_unaffordable")
    require(type(c["endpoints"]) is list and 0 < len(c["endpoints"]) <= 64, "endpoints")
    ids, channels = set(), set()
    scope = {f["id"] for f in c["genome"]["facts"] if f["scope"]}
    for e in c["endpoints"]:
        fields(e, "id fact source path query")
        require(ident(e["id"]) and e["id"] not in ids, "endpoint_id")
        require(e["fact"] in scope and e["source"] in c["genome"]["sources"], "endpoint_binding")
        require(type(e["path"]) is str and 0 < len(e["path"]) <= 1024, "endpoint_path")
        require(e["query"] in ["is_file", "is_dir"], "endpoint_query")
        pair = (e["fact"], e["source"])
        require(pair not in channels, "duplicate_channel")
        ids.add(e["id"])
        channels.add(pair)
    require({e["fact"] for e in c["endpoints"]} == scope, "unbound_scoped_fact")
    c["endpoints"].sort(key=lambda e:e["id"])
    return c


class SessionMachine:
    """All non-determinism enters as explicit events (including receipt times)."""
    def __init__(self, config):
        self.config = config_normal_form(config)
        self.config_digest = digest(SESSION, self.config)
        self.kernel = IncrementalKernel(self.config["genome"])
        self.seq = 0
        self.phase = "RUNNING"
        self.paused = False
        self.inflight = None
        self.last_attempt = {}
        self.next_due = {}
        self.last_receipt = {}
        self.completed = {}
        self.request_count = 0
        self.abandoned = []

    @property
    def clock(self):
        return self.kernel.s["clock"]

    def plan(self):
        if (self.phase != "RUNNING" or self.paused or
                not self.kernel.s["tracking"] or self.inflight):
            return []
        snap = self.kernel.snapshot()
        priorities = {(x["fact"], x["source"]): x["score"]
                      for x in snap["navigation"]["probes"]}
        candidates = []
        for e in self.config["endpoints"]:
            if self.clock < self.next_due.get(e["id"], 0):
                continue
            p = snap["percepts"][e["fact"]]
            reason = {"Known":"REFRESH", "Ambiguous":"RESOLVE",
                      "Invalid":"RECOVER"}.get(p["epistemic"], "DISCOVER")
            candidates.append({"endpoint":e["id"], "fact":e["fact"], "source":e["source"],
                               "reason":reason, "cost":self.kernel.manifest["probe_cost"],
                               "last_attempt":self.last_attempt.get(e["id"],-1),
                               "priority":priorities.get((e["fact"],e["source"]),0)})
        # Oldest eligible channel first prevents an uncertain channel starving others.
        return sorted(candidates, key=lambda p:(p["last_attempt"],-p["priority"],p["endpoint"]))

    def snapshot(self):
        k = self.kernel.snapshot()
        state = {"profile":SESSION,"config_digest":self.config_digest,
                 "sequence":self.seq,"phase":self.phase,"paused":self.paused,
                 "kernel":k,"inflight":copy.deepcopy(self.inflight),
                 "last_attempt":copy.deepcopy(self.last_attempt),
                 "next_due":copy.deepcopy(self.next_due),
                 "last_receipt":copy.deepcopy(self.last_receipt),
                 "completed":copy.deepcopy(self.completed),
                 "request_count":self.request_count,"abandoned":list(self.abandoned),
                 "plan":self.plan()}
        active = {ref for p in k["percepts"].values() for ref in p["active_refs"]}
        state["active_evidence"] = {ref:copy.deepcopy(self.kernel.s["observations"][ref])
                                    for ref in sorted(active)}
        state["state_digest"] = digest("SessionState",state)
        return state

    def reduce(self, event):
        candidate = copy.deepcopy(self)
        output = candidate._apply(event)
        return candidate, output

    def _kernel_event(self, kind, at, **kw):
        event = {"id":"live"+str(self.seq)+":"+kind,"kind":kind,"at":at,
                 "label":"Session "+kind}
        event.update(kw)
        self.kernel.step(event)
        require(self.kernel.records[-1]["outcome"] == "COMMITTED", "kernel_rejected")

    def _apply(self, event):
        canon(event)
        require(type(event) is dict and uint(event.get("at")) and
                event["at"] >= self.clock, "session_clock")
        require(self.seq < self.config["max_transitions"], "session_capacity")
        kind = event.get("kind")
        schema = {
            "tick":"kind at", "dispatch":"kind at endpoint",
            "receipt":"kind at request outcome value sampled_at detail",
            "target":"kind at fact", "tracking":"kind at valid",
            "pause":"kind at paused", "stop":"kind at reason", "resume":"kind at"}
        require(type(kind) is str and kind in schema, "session_event_kind")
        fields(event,schema[kind])
        if self.phase != "RUNNING":
            require(kind == "resume", "session_stopped")
        if kind == "pause":
            require(type(event["paused"]) is bool, "pause_type")
        if kind == "tracking":
            require(type(event["valid"]) is bool, "tracking_type")
        if kind == "target":
            require(event["fact"] in self.kernel.fact_ids, "target_binding")
        if kind == "stop":
            require(ident(event["reason"]), "stop_reason")
        if kind == "receipt":
            require(self.inflight is not None and event["request"] == self.inflight["id"],
                    "unmatched_receipt")
            require(event["outcome"] in ["OK","TIMEOUT","ERROR"], "receipt_outcome")
            require(type(event["detail"]) is str and len(event["detail"]) <= 256, "receipt_detail")
            if event["outcome"] == "OK":
                require(type(event["value"]) is bool and uint(event["sampled_at"]), "receipt_value")
                require(self.inflight["issued_at"] <= event["sampled_at"] <= event["at"],
                        "receipt_time")
            else:
                require(event["value"] is None and event["sampled_at"] is None, "failure_payload")
        if event["at"] > self.clock:
            self._kernel_event("tick",event["at"])
        result = {"kind":kind}
        if kind == "dispatch":
            plan = self.plan()
            require(plan and plan[0]["endpoint"] == event["endpoint"], "dispatch_plan_mismatch")
            selected = plan[0]
            req = {"id":"probe"+str(self.request_count+1),
                   "endpoint":selected["endpoint"],"fact":selected["fact"],"source":selected["source"],
                   "issued_at":self.clock,"deadline":self.clock+self.config["timeout_ms"],
                   "target_epoch":self.kernel.s["epoch"],"frame_epoch":self.kernel.s["frame_epoch"],
                   "state_ref":self.kernel.snapshot()["state_digest"],
                   "reason":selected["reason"],"cost":selected["cost"],"effect":"READ_METADATA"}
            require(uint(req["deadline"]), "deadline_range")
            self.request_count += 1
            self.inflight = req
            self.last_attempt[selected["endpoint"]] = self.clock
            result["request"] = copy.deepcopy(req)
        elif kind == "receipt":
            req = self.inflight
            status = event["outcome"]
            if self.clock > req["deadline"]:
                status = "TIMEOUT"
            obsolete = (req["target_epoch"] != self.kernel.s["epoch"] or
                        req["frame_epoch"] != self.kernel.s["frame_epoch"] or
                        self.paused or not self.kernel.s["tracking"])
            if obsolete:
                status = "SUPERSEDED"
            observation_ref = None
            if not obsolete:
                self._kernel_event("observe", self.clock, fact=req["fact"],source=req["source"],
                    time=event["sampled_at"] if status=="OK" else self.clock,
                    value=event["value"] if status=="OK" else None,
                    quality="invalid" if status=="ERROR" else "valid",
                    visibility="observed" if status=="OK" else "not_observed")
                observation_ref = self.kernel.records[-1]["input"]["id"]
            summary = {"request":req["id"],"outcome":status,"at":self.clock,
                       "observation_ref":observation_ref,"detail":event["detail"]}
            self.last_receipt[req["endpoint"]] = summary
            self.completed[req["id"]] = digest("Receipt",event)
            self.next_due[req["endpoint"]] = self.clock + (
                self.config["refresh_ms"] if status=="OK" else self.config["retry_ms"])
            self.inflight = None
            result["receipt"] = summary
        elif kind == "target":
            self._kernel_event("target",self.clock,fact=event["fact"])
        elif kind == "tracking":
            self._kernel_event("tracking",self.clock,valid=event["valid"])
        elif kind == "pause":
            self.paused = event["paused"]
        elif kind == "stop":
            require(self.inflight is None, "stop_with_pending_probe")
            self.phase = "STOPPED"
            result["reason"] = event["reason"]
        elif kind == "resume":
            require(event["at"] >= self.clock, "resume_time")
            # Revoke old evidence explicitly; a restart never silently keeps it live.
            # One tick beyond the TTL is sufficient, without resurrecting old evidence.
            require(not any(p["active_refs"] for p in self.kernel.snapshot()["percepts"].values()),
                    "resume_requires_expired_evidence")
            if self.inflight:
                self.abandoned.append(self.inflight["id"])
            self.inflight = None
            self.phase, self.paused = "RUNNING",False
            self.next_due = {}
        self.seq += 1
        return result


def view_snapshot(state, config):
    """Compact projection; current source metadata remains inspectable."""
    k = state["kernel"]
    objects = {}
    for v in k["view"]:
        p = k["percepts"][v["fact"]]
        objects[v["fact"]] = {"view":v,"percept":p}
    payload = {"profile":SESSION,"sequence":state["sequence"],
               "state_digest":state["state_digest"],"clock":k["clock"],
               "phase":state["phase"],"paused":state["paused"],"tracking":k["tracking"],
               "frame_epoch":k["frame_epoch"],"target_epoch":k["epoch"],
               "target":k["navigation"]["target"],"center":config["genome"]["center"],
               "objects":objects,"edges":k["edges"],"region":k["region"],
               "frontier":k["frontier"],"navigation":k["navigation"],
               "plan":state["plan"],"inflight":state["inflight"],
               "last_receipt":state["last_receipt"],"request_count":state["request_count"]}
    payload["evidence"] = state["active_evidence"]
    return payload


def view_delta(before, after):
    changes = {key:value for key,value in after["objects"].items()
               if before["objects"].get(key) != value}
    return {"kind":"delta","from":before["sequence"],"to":after["sequence"],
            "pre":before["state_digest"],"post":after["state_digest"],
            "frame_epoch":after["frame_epoch"],
            "changed":changes,"removed":sorted(set(before["objects"])-set(after["objects"])),
            "meta":{k:v for k,v in after.items() if k!="objects"}}


def apply_view_delta(before, delta):
    require(before["sequence"] == delta["from"] and
            before["state_digest"] == delta["pre"], "view_gap")
    after = copy.deepcopy(delta["meta"])
    after["objects"] = copy.deepcopy(before["objects"])
    for key in delta["removed"]:
        after["objects"].pop(key,None)
    after["objects"].update(copy.deepcopy(delta["changed"]))
    require(after["sequence"] == delta["to"] and after["state_digest"] == delta["post"],
            "view_delta_binding")
    return after
