"""Predeclared finite exposure comparison; no wall-clock performance claims."""
from pathlib import Path
import argparse
import json
from grfps_l2 import digest
from organs import field_config, calibration_contract, fact_id
from field_world import generate_world, measure, truth, world_ref
from segments import SegmentEngine, recover_segments

PROTOCOL = {
    "version":"0.3.0","sectors":8,"depth":4,"world_seeds":list(range(12)),
    "policies":["fixed","uniform","coverage"],"measurements_per_run":16,
    "measurement_cost":1,"ttl_ms":100000,"cooldown_ms":0,
    "uniform_policy_seed_rule":"2027 + world_seed",
    "primary_metric":"distinct_requested_questions_of_16",
    "secondary_metrics":["known_questions","false_known_count","unknown_questions"],
    "truth_access":"Only measurement/evaluator functions read world values; planner receives receipts.",
    "clock":"Logical milliseconds; no runtime or latency comparison.",
    "scope":"Static finite ideal-ray model. Fixed is an exposure ablation; uniform is an elementary baseline.",
    "limits":"No held-out real-world accuracy or superiority over advanced active perception policies."
}


def run_case(out, world_seed, policy):
    world = generate_world(world_seed,PROTOCOL["sectors"],PROTOCOL["depth"])
    field = out/f"world-{world_seed:02d}.json"
    field.write_text(json.dumps(world,indent=2))
    c = field_config(field, policy=policy, budget=16, ttl_ms=100000, cooldown_ms=0,
                     segment_records=48)
    c["policy_seed"] = 2027+world_seed
    engine = SegmentEngine.create(out/f"{world_seed:02d}-{policy}", c)
    try:
        def event(kind, **kw):
            return engine.commit({"kind":kind,"at":engine.machine.clock,**kw})
        for oid in engine.machine.organs:
            event("instantiate",organ=oid)
            event("calibrate",organ=oid,contract=calibration_contract(c))
            event("bind",organ=oid)
        for _ in range(PROTOCOL["measurements_per_run"]):
            p = engine.machine.plan()[0]
            event("expose",organ=p["organ"],sector=p["sector"])
            req = event("dispatch",organ=p["organ"])["output"]["request"]
            at = engine.machine.clock+1
            reply = measure(world,req["query"],req["sector"])
            engine.commit({"kind":"receipt","at":at,"organ":req["organ"],"request":req["id"],
                "exposure":req["exposure"],**reply,"sampled_at":at,
                "sample_ref":world_ref(world),"detail":"benchmark_model"})
            event("integrate",organ=req["organ"])
            event("release",organ=req["organ"])
        event("stop",reason="benchmark_budget")
        engine.checkpoint()
        state = engine.machine.snapshot()
    finally:
        engine.close()
    recovered = recover_segments(engine.directory)
    assert recovered["machine"].snapshot() == state
    known, wrong = 0, 0
    for o in c["organs"]:
        for s in range(c["sectors"]):
            p=state["kernel"]["percepts"][fact_id(o["id"],s)]
            if p["epistemic"]=="Known":
                known+=1
                wrong += p["value"] != truth(world,o["query"],s)
    return {"world_seed":world_seed,"policy":policy,"measurements":state["request_count"],
            "spent":state["budget"]["spent"],"distinct_questions":len(state["attempts"]),
            "known_questions":known,"false_known_count":wrong,"unknown_questions":16-known,
            "replay_identity":True,"state_digest":state["state_digest"],"head":recovered["head"]}


def run_benchmark(output):
    out=Path(output);out.mkdir(parents=True,exist_ok=False)
    # Protocol is persisted before generating cases or evaluating outcomes.
    (out/"protocol.json").write_text(json.dumps(PROTOCOL,indent=2))
    rows=[]
    for seed in PROTOCOL["world_seeds"]:
        for policy in PROTOCOL["policies"]:
            rows.append(run_case(out,seed,policy))
    aggregate={}
    for policy in PROTOCOL["policies"]:
        cases=[r for r in rows if r["policy"]==policy]
        aggregate[policy]={"runs":len(cases),"measurements_per_run":16,
            "mean_distinct_questions":sum(r["distinct_questions"] for r in cases)/len(cases),
            "mean_known_questions":sum(r["known_questions"] for r in cases)/len(cases),
            "known_total":sum(r["known_questions"] for r in cases),
            "false_known_total":sum(r["false_known_count"] for r in cases),
            "replay_identity_runs":sum(r["replay_identity"] for r in cases)}
    report={"protocol_digest":digest("BenchmarkProtocol",PROTOCOL),"protocol":PROTOCOL,
            "runs":len(rows),"measurements":sum(r["measurements"] for r in rows),
            "aggregate":aggregate,"cases":rows}
    (out/"benchmark_report.json").write_text(json.dumps(report,indent=2))
    return report


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--out",required=True)
    result=run_benchmark(p.parse_args().out)
    print(json.dumps({k:v for k,v in result.items() if k not in ["cases","protocol"]},indent=2))
