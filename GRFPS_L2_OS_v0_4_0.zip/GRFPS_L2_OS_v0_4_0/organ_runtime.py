"""Local organ runtime, finite field adapter, continuous segment lineage."""
from __future__ import annotations
import argparse
import copy
import json
import queue
import threading
import time
from collections import deque
from pathlib import Path
from grfps_l2 import require, uint, loads
from adapters import MonotonicClock
from field_adapter import FieldRunner
from organs import OrganMachine, field_config, organ_view, ACTIVE, calibration_contract
from segments import SegmentEngine, recover_segments, verify_segment_checkpoint
from session import view_delta
from live import LiveService, server_for


def viewer_html(data):
    text = Path(__file__).with_name("organ_viewer.html").read_text(encoding="utf-8")
    return text.replace("__ORGAN_DATA__", json.dumps(data, ensure_ascii=True).replace("<","\\u003c"))


class OrganService(LiveService):
    def __init__(self, engine, clock=None, runner=None):
        self.engine, self.config = engine, engine.machine.config
        self.clock = clock or MonotonicClock(engine.machine.clock)
        self.runner = runner or FieldRunner(self.clock, self.config)
        self.commands = queue.Queue(maxsize=16)
        self.command_results = deque(maxlen=16)
        self.lock, self.deltas = threading.Lock(), deque(maxlen=64)
        self.current = organ_view(engine.machine.snapshot(), self.config)
        self.stopping = threading.Event()
        self.stop_requested, self.error = False, None

    def commit(self, event):
        before = self.current
        record = self.engine.commit(event)
        after = organ_view(self.engine.machine.snapshot(), self.config)
        delta = view_delta(before, after)
        with self.lock:
            self.current = after
            self.deltas.append(delta)
        if self.engine.machine.seq % 64 == 0:
            self.engine.checkpoint()
        return record

    def enqueue(self, command):
        if type(command) is dict and command.get("kind") == "budget":
            require(set(command) == {"kind","limit"} and uint(command["limit"])
                    and command["limit"] <= 1000000, "budget_control")
            require(self.current["phase"] == "RUNNING" and not self.error, "service_stopped")
            self.commands.put_nowait(copy.deepcopy(command))
        else:
            super().enqueue(command)

    def _event(self, kind, **kw):
        return self.commit({"kind":kind,"at":self.clock.now(),**kw})

    def cycle(self):
        m = self.engine.machine
        if m.phase != "RUNNING":
            return False
        cap = min(self.config["max_transitions"],
                  self.config["max_segments"]*self.config["segment_records"])
        if m.seq >= cap-12:
            self.stop_requested = True
        for _ in range(16):
            if self.engine.machine.seq >= cap-12:
                self.stop_requested = True
            if self.stop_requested:
                break
            try:
                command = self.commands.get_nowait()
            except queue.Empty:
                break
            try:
                if command["kind"] == "stop":
                    self.stop_requested = True
                    result = "STOP_REQUESTED"
                else:
                    self._event(**command)
                    result = "COMMITTED"
                with self.lock:
                    self.command_results.append({"command":command,"status":result})
            except ValueError as err:
                with self.lock:
                    self.command_results.append({"command":command,"status":"REJECTED","error":str(err)})
            finally:
                self.commands.task_done()
        # Drain accepted work before stop. A receipt and integration remain explicit.
        m = self.engine.machine
        for oid, o in m.organs.items():
            if o["state"] == "WAITING":
                receipt = self.runner.run(o["request"])
                self.commit(receipt)
                return True
            if o["state"] == "INTEGRATING":
                self._event("integrate", organ=oid)
                return True
            if o["state"] == "EXPOSING":
                if (self.stop_requested or not m._binding_current(o["exposure"])
                        or m.spent+self.config["probe_cost"] > m.limit):
                    self._event("cancel", organ=oid)
                else:
                    self._event("dispatch", organ=oid)
                return True
        if self.stop_requested:
            self._event("stop", reason="runtime_stop")
            return False
        self._event("tick")
        m = self.engine.machine
        for oid, o in m.organs.items():
            if o["lifecycle"] == "TEMPLATE":
                self._event("instantiate", organ=oid)
                return True
            if o["lifecycle"] == "INSTANTIATED":
                self._event("calibrate", organ=oid, contract=calibration_contract(self.config))
                return True
            if o["state"] == "UNBOUND":
                self._event("bind", organ=oid)
                return True
            if o["state"] in ["COOLDOWN","FAULT"] and m.clock >= o["ready_at"]:
                self._event("recover" if o["state"] == "FAULT" else "release", organ=oid)
                return True
        plan = m.plan()
        if plan:
            self._event("expose", organ=plan[0]["organ"], sector=plan[0]["sector"])
        return True

    def run(self, duration_s):
        start = time.monotonic()
        try:
            while self.engine.machine.phase == "RUNNING":
                if self.stopping.is_set() or time.monotonic()-start >= duration_s:
                    self.stop_requested = True
                if not self.cycle():
                    break
                if not self.stop_requested:
                    self.stopping.wait(self.config["tick_ms"]/1000)
            self.engine.checkpoint()
        except BaseException as err:
            with self.lock:
                self.error = type(err).__name__+": "+str(err)
        finally:
            self.stopping.set()


def export_replay(directory, html_path):
    r = recover_segments(directory, collect_views=True)
    c = r["machine"].config
    frames = [organ_view(s,c) for s in r["views"]]
    data = {"mode":"replay","frames":frames,
            "events":[{"kind":x["event"]["kind"],"output":x["output"]} for x in r["records"]],
            "head":r["head"],"verified":True,"segments":r["segment_count"]}
    Path(html_path).write_text(viewer_html(data), encoding="utf-8")
    return {"transitions":r["machine"].seq,"requests":r["machine"].request_count,
            "segments":r["segment_count"],"state_digest":r["machine"].snapshot()["state_digest"],
            "head":r["head"]}


def serve(engine, duration=30, port=0, open_browser=False, clock=None):
    service = OrganService(engine, clock)
    server = server_for(service, port, viewer_html)
    network = threading.Thread(target=server.serve_forever, daemon=True)
    worker = threading.Thread(target=service.run, args=(duration,), daemon=True)
    network.start(); worker.start()
    url = f"http://127.0.0.1:{server.server_port}"
    print("GRFPS organ runtime:", url, flush=True)
    print("Journal:",engine.directory, flush=True)
    if open_browser:
        import webbrowser
        webbrowser.open(url)
    try:
        while worker.is_alive():
            worker.join(.25)
    except KeyboardInterrupt:
        service.stopping.set(); worker.join()
    finally:
        server.shutdown(); server.server_close(); network.join(); engine.close()
    if service.error:
        raise RuntimeError(service.error)
    print(json.dumps({"phase":service.current["phase"],"sequence":service.current["sequence"]}))
    return service


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="cmd", required=True)
    w = sub.add_parser("watch")
    w.add_argument("--out", required=True)
    w.add_argument("--world")
    w.add_argument("--config")
    w.add_argument("--resume", action="store_true")
    w.add_argument("--budget", type=int)
    w.add_argument("--duration", type=float, default=30)
    w.add_argument("--port", type=int, default=0)
    w.add_argument("--open", action="store_true")
    r = sub.add_parser("replay")
    r.add_argument("directory")
    r.add_argument("--html")
    args = p.parse_args()
    if args.cmd == "replay":
        if args.html:
            print(json.dumps(export_replay(args.directory,args.html),indent=2))
        else:
            result = recover_segments(args.directory)
            print(json.dumps({"verified":True,"segments":result["segment_count"],
                "transitions":result["machine"].seq,"head":result["head"],
                "state_digest":result["machine"].snapshot()["state_digest"]},indent=2))
        return
    require(0 < args.duration <= 86400, "duration")
    if args.resume:
        require(not args.world and not args.config, "resume_bound_configuration")
        engine = SegmentEngine.reopen(args.out)
        offset = engine.machine.clock+engine.machine.config["ttl_ms"]+1
        engine.commit({"kind":"resume","at":offset})
        if args.budget is not None:
            engine.commit({"kind":"budget","at":offset,"limit":args.budget})
        clock = MonotonicClock(offset)
    else:
        require(bool(args.world) != bool(args.config), "choose_world_or_config")
        config = loads(Path(args.config).read_bytes()) if args.config else field_config(args.world)
        if args.budget is not None:
            config["budget"] = args.budget
        engine = SegmentEngine.create(args.out, config)
        clock = MonotonicClock()
    serve(engine, args.duration, args.port, args.open, clock)


if __name__ == "__main__":
    main()
