"""Actual subprocess supervision for the fixed finite-field instrument."""
import json
import subprocess
import sys
from pathlib import Path
from grfps_l2 import loads, fields, require


class FieldRunner:
    def __init__(self, clock, config, command=None):
        self.clock, self.config = clock, config
        # Override is a Python test-harness hook, never an HTTP/config capability.
        self.command = command or [sys.executable, str(Path(__file__).with_name("field_worker.py"))]
        self.child = None

    def failed(self, request, outcome, detail):
        return {"kind":"receipt","at":self.clock.now(),"organ":request["organ"],
                "request":request["id"],"exposure":request["exposure"],
                "outcome":outcome,"value":None,"sampled_at":None,"sample_ref":None,"detail":detail}

    def run(self, request):
        remaining = request["deadline"]-self.clock.now()
        if remaining <= 0:
            return self.failed(request, "TIMEOUT", "deadline_before_start")
        payload = {"path":self.config["world_path"],"sectors":self.config["sectors"],
                   "query":request["query"],"sector":request["sector"],"exposure":request["exposure"]}
        try:
            process = subprocess.Popen(self.command, stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False)
        except OSError:
            return self.failed(request, "ERROR", "worker_spawn")
        self.child = process
        try:
            stdout, _ = process.communicate(json.dumps(payload).encode()+b"\n", timeout=remaining/1000)
            require(process.returncode == 0 and len(stdout) <= 8192, "worker_output")
            reply = loads(stdout)
            fields(reply, "outcome value sampled_ns sample_ref exposure detail")
            require(type(reply["detail"]) is str and len(reply["detail"]) <= 256, "worker_detail")
            if reply["outcome"] == "ERROR":
                return self.failed(request, "ERROR", reply["detail"])
            require(reply["outcome"] in ["OK","OCCLUDED"], "worker_outcome")
            require(reply["exposure"] == request["exposure"], "worker_exposure")
            require(type(reply["sampled_ns"]) is int, "worker_sample_clock")
            sampled, at = self.clock.convert(reply["sampled_ns"]), self.clock.now()
            require(request["issued_at"] <= sampled <= at, "worker_time")
            require(type(reply["value"]) is bool if reply["outcome"] == "OK" else reply["value"] is None,
                    "worker_value")
            require(type(reply["sample_ref"]) is str and len(reply["sample_ref"]) == 64
                    and all(c in "0123456789abcdef" for c in reply["sample_ref"]), "worker_ref")
            return {"kind":"receipt","at":at,"organ":request["organ"],"request":request["id"],
                    "exposure":request["exposure"],"outcome":reply["outcome"],
                    "value":reply["value"],"sampled_at":sampled,
                    "sample_ref":reply["sample_ref"],"detail":reply["detail"]}
        except subprocess.TimeoutExpired:
            process.kill(); process.communicate()
            return self.failed(request, "TIMEOUT", "worker_deadline")
        except (ValueError, TypeError, KeyError):
            return self.failed(request, "ERROR", "worker_protocol")
        except BaseException:
            if process.poll() is None:
                process.kill(); process.communicate()
            raise
        finally:
            self.child = None
