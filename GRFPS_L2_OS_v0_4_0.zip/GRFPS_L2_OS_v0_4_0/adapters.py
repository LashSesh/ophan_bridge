"""Bounded subprocess supervision for explicit filesystem capabilities."""
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from grfps_l2 import require
from session import SESSION, config_normal_form


def file_config(paths, *, ttl_ms=2000,refresh_ms=500,timeout_ms=500,
                max_transitions=600):
    paths=[Path(p).absolute() for p in paths]
    require(1<=len(paths)<=32,"path_count")
    require(all(str(p).isascii() for p in paths),"ascii_path_profile")
    root=Path(os.path.commonpath([str(p.parent) for p in paths]))
    targets=[("workspace",root,"is_dir")]+[
        ("file"+str(i),p,"is_file") for i,p in enumerate(paths)]
    genome=json.loads(Path(__file__).with_name("genome.json").read_text())
    genome.update(name="live-file-state",min_groups=1,ttl=ttl_ms,max_events=2*max_transitions+2,
        sources={"filesystem_stat":"local_filesystem"},center="workspace",target="file0",
        facts=[{"id":key,"label":p.name or str(p),"scope":True} for key,p,q in targets],
        edges=[["workspace",key] for key,p,q in targets[1:]])
    return config_normal_form({"profile":SESSION,"name":"filesystem-watch",
        "genome":genome,"endpoints":[{"id":"read:"+key,"fact":key,"source":"filesystem_stat",
                                    "path":str(p),"query":q} for key,p,q in targets],
        "timeout_ms":timeout_ms,"refresh_ms":refresh_ms,"retry_ms":refresh_ms,
        "tick_ms":50,"queue_limit":16,"delta_limit":64,"checkpoint_every":25,
        "max_transitions":max_transitions})


class MonotonicClock:
    def __init__(self,offset=0):
        self.start_ns=time.monotonic_ns()
        self.offset=offset

    def now(self):
        return self.offset+(time.monotonic_ns()-self.start_ns)//1000000

    def convert(self,ns):
        return self.offset+(ns-self.start_ns)//1000000


class FileRunner:
    def __init__(self,clock,command=None):
        self.clock=clock
        self.command=command or [sys.executable,str(Path(__file__).with_name("adapter_worker.py"))]
        self.child=None

    def run(self,request,endpoint):
        payload=json.dumps(endpoint).encode()+b"\n"
        remaining=max(0,request["deadline"]-self.clock.now())
        if not remaining:
            return self._failure(request,"TIMEOUT","deadline_before_dispatch")
        try:
            process=subprocess.Popen(self.command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE,shell=False)
        except OSError:
            return self._failure(request,"ERROR","worker_spawn")
        self.child=process
        try:
            stdout,stderr=process.communicate(payload,timeout=remaining/1000)
            if process.returncode!=0:
                return self._failure(request,"ERROR","worker_exit")
            if len(stdout)>8192:
                return self._failure(request,"ERROR","worker_output_budget")
            reply=json.loads(stdout)
            require(set(reply)=={"outcome","value","sampled_ns","detail"},"worker_shape")
            require(reply["outcome"] in ["OK","ERROR"],"worker_status")
            require(type(reply["sampled_ns"]) is int,"worker_clock")
            require(type(reply["detail"]) is str and reply["detail"].isascii()
                    and len(reply["detail"])<=256,"worker_detail")
            if reply["outcome"]=="OK":
                require(type(reply["value"]) is bool,"worker_value")
                sampled=self.clock.convert(reply["sampled_ns"])
                at=self.clock.now()
                require(request["issued_at"]<=sampled<=at,"worker_time")
                return {"kind":"receipt","at":at,"request":request["id"],
                        "outcome":"OK","value":reply["value"],"sampled_at":sampled,
                        "detail":reply["detail"]}
            return self._failure(request,"ERROR",reply["detail"])
        except subprocess.TimeoutExpired:
            process.kill()
            process.communicate()
            return self._failure(request,"TIMEOUT","worker_deadline")
        except (ValueError,TypeError,KeyError):
            return self._failure(request,"ERROR","worker_protocol")
        except BaseException:
            if process.poll() is None:
                process.kill()
                process.communicate()
            raise
        finally:
            self.child=None

    def _failure(self,request,status,detail):
        return {"kind":"receipt","at":self.clock.now(),"request":request["id"],
                "outcome":status,"value":None,"sampled_at":None,"detail":detail}
