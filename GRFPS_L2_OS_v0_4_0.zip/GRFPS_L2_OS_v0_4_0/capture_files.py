"""Read-only file existence adapter. No file contents are read.

Usage: python capture_files.py --out file-run.json --view file-view.html PATH ...
Every Known value means only: the local filesystem query returned this value
at the recorded instant. This is a one-source observation profile, not sensor fusion.
"""
import argparse
import json
import os
import stat
import time
from pathlib import Path
from grfps_l2 import Kernel, render, replay


def capture(paths):
    paths = [Path(p).absolute() for p in paths]
    if not 1 <= len(paths) <= 32:
        raise ValueError("Provide 1..32 paths")
    if not all(str(p).isascii() for p in paths):
        raise ValueError("This reference adapter requires ASCII paths")
    g = json.loads(Path(__file__).with_name("genome.json").read_text())
    root = Path(os.path.commonpath([str(p.parent) for p in paths]))
    targets = [("workspace",root)] + [("file"+str(i),p) for i,p in enumerate(paths)]
    g.update(name="local-file-state", min_groups=1, sources={"filesystem_stat":"local_filesystem"},
             facts=[{"id":k,"label":str(p),"scope":True} for k,p in targets],
             edges=[["workspace",k] for k,p in targets[1:]], center="workspace",target=targets[1][0])
    k = Kernel(g)
    clock = int(time.time())
    for i,(key,p) in enumerate(targets):
        quality = "valid"
        try:
            info = p.stat()
            value = stat.S_ISDIR(info.st_mode) if key=="workspace" else stat.S_ISREG(info.st_mode)
        except (FileNotFoundError, NotADirectoryError):
            value = False
        except OSError:
            value,quality = False,"invalid"
        k.step({"id":"stat"+str(i),"kind":"observe","at":clock,"time":clock,
                "fact":key,"source":"filesystem_stat","value":value,"quality":quality,
                "visibility":"observed","label":"Filesystem query: "+str(p)})
    return k.bundle()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out",required=True)
    p.add_argument("--view")
    p.add_argument("paths",nargs="+")
    args=p.parse_args()
    bundle=capture(args.paths)
    Path(args.out).write_text(json.dumps(bundle,indent=2))
    if args.view: render(bundle,args.view)
    print(json.dumps(replay(bundle),indent=2))


if __name__=="__main__": main()
