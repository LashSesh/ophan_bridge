import copy
import json
import queue
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from grfps_l2 import canon, loads
from organs import (OrganMachine, field_config, calibration_contract, fact_id, organ_view)
from field_world import generate_world, measure, truth, world_ref
from field_adapter import FieldRunner
from adapters import MonotonicClock
from segments import SegmentEngine, recover_segments, verify_segment_checkpoint
from journal import sealed
from organ_runtime import OrganService, server_for, viewer_html
from session import apply_view_delta


class FakeClock:
    def __init__(self, at=0): self.at=at
    def now(self): return self.at
    def advance(self, ms=1): self.at+=ms


class ModelRunner:
    def __init__(self, clock, world):
        self.clock, self.world = clock, world
    def run(self, req):
        self.clock.advance()
        return {"kind":"receipt","at":self.clock.now(),"organ":req["organ"],
                "request":req["id"],"exposure":req["exposure"],
                **measure(self.world,req["query"],req["sector"]),
                "sampled_at":self.clock.now(),"sample_ref":world_ref(self.world),"detail":"model"}


class OrganTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="organ_test_")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.world = generate_world(23)
        self.path = self.root/"world.json"
        self.path.write_text(json.dumps(self.world))
        self.config = field_config(self.path, cooldown_ms=0, ttl_ms=100, segment_records=12)
        self.m = OrganMachine(self.config)

    def step(self, kind, **kw):
        at = kw.pop("at", self.m.clock)
        self.m, out = self.m.reduce({"kind":kind,"at":at,**kw})
        return out

    def bind(self):
        for oid in self.m.organs:
            if self.m.organs[oid]["lifecycle"] == "TEMPLATE":
                self.step("instantiate",organ=oid)
            self.step("calibrate",organ=oid,contract=calibration_contract(self.config))
            self.step("bind",organ=oid)

    def dispatch(self):
        p = self.m.plan()[0]
        self.step("expose",organ=p["organ"],sector=p["sector"])
        return self.step("dispatch",organ=p["organ"])["request"]

    def reply(self, r, outcome=None, **kw):
        data = measure(self.world,r["query"],r["sector"])
        if outcome:
            data = {"outcome":outcome,"value":True if outcome=="OK" else None}
        measured = data["outcome"] in ["OK","OCCLUDED"]
        e = {"kind":"receipt","at":self.m.clock+1,"organ":r["organ"],
             "request":r["id"],"exposure":r["exposure"],**data,
             "sampled_at":self.m.clock+1 if measured else None,
             "sample_ref":world_ref(self.world) if measured else None,"detail":"test"}
        e.update(kw)
        self.m, out = self.m.reduce(e)
        return out

    def finish(self, r):
        return self.step("integrate",organ=r["organ"])["result"]

    def assert_rejected(self, event):
        before = self.m.snapshot()
        with self.assertRaises(ValueError):
            self.m.reduce(event)
        self.assertEqual(before,self.m.snapshot())

    def test_calibration_and_binding_require_lifecycle_order(self):
        self.assert_rejected({"kind":"bind","at":0,"organ":"beacon"})
        self.step("instantiate",organ="beacon")
        contract=calibration_contract(self.config);contract["aperture_sectors"]=2
        self.assert_rejected({"kind":"calibrate","at":0,"organ":"beacon","contract":contract})
        contract["aperture_sectors"]=True
        self.assert_rejected({"kind":"calibrate","at":0,"organ":"beacon","contract":contract})
        self.step("calibrate",organ="beacon",contract=calibration_contract(self.config))
        self.step("bind",organ="beacon")
        self.assertEqual(self.m.organs["beacon"]["lifecycle"],"ACTIVE")

    def test_compact_kernel_matches_full_interpreter_without_snapshot_archive(self):
        from grfps_l2 import Kernel
        from organs import OrganKernel,genome_for
        g=genome_for(self.config);full=Kernel(g);compact=OrganKernel(g)
        for i in range(120):
            e={"id":"equivalence"+str(i),"kind":"tick","at":i*3,"label":"Equivalence"}
            if i%3==0:
                e.update(kind="observe",time=i*3,fact="beacon.s"+str(i%8),
                         source="field_beacon",value=i%2==0,quality="valid",visibility="observed")
            elif i%7==0:e.update(kind="target",fact="clearance.s"+str(i%8))
            self.assertEqual(full.step(e),compact.step(e))
            self.assertEqual(full.records[-1],compact.records[-1])
        self.assertEqual(len(compact.snapshots),0)
        self.assertEqual(len(full.snapshots),120)
        self.assertEqual(len(compact.records),120)
        with self.assertRaises(ValueError):compact.bundle()

    def test_pause_and_stop_preserve_separate_lifecycle_semantics(self):
        self.bind();self.step("pause",paused=True)
        self.assertTrue(all(o["lifecycle"]=="QUIESCENT" for o in self.m.organs.values()))
        self.assertEqual(self.m.plan(),[])
        self.step("pause",paused=False)
        self.step("stop",reason="test")
        self.assertTrue(all(o["lifecycle"]=="RETIRED" for o in self.m.organs.values()))

    def test_unknown_query_is_rejected(self):
        c=copy.deepcopy(self.config);c["organs"][0]["query"]="execute_shell"
        with self.assertRaises(ValueError):OrganMachine(c)

    def test_exposure_changes_executed_question(self):
        w=generate_world(0)
        for ray in w["cells"]:
            for c in ray:c.update(solid=False,beacon=False)
        w["cells"][1][0]["solid"]=True
        self.assertEqual(measure(w,"ray_clear",0)["value"],True)
        self.assertEqual(measure(w,"ray_clear",1)["value"],False)
        self.assertEqual(truth(w,"ray_clear",1),False)

    def test_occlusion_is_not_negative_beacon_evidence(self):
        w=generate_world(0)
        w["cells"][0]=[{"solid":True,"beacon":False}]+[{"solid":False,"beacon":True}]*3
        self.assertEqual(measure(w,"beacon_present",0),{"outcome":"OCCLUDED","value":None})
        self.assertTrue(truth(w,"beacon_present",0))
        w["cells"][0][0]["beacon"]=True
        self.assertEqual(measure(w,"beacon_present",0),{"outcome":"OK","value":True})

    def test_exposure_plan_cannot_be_substituted(self):
        self.bind();p=self.m.plan()[0]
        self.assert_rejected({"kind":"expose","at":0,"organ":p["organ"],"sector":1})

    def test_receipt_requires_request_and_exposure_witness(self):
        self.bind();r=self.dispatch();before=self.m.snapshot()
        with self.assertRaises(ValueError):self.reply(r,exposure="0"*64)
        self.assertEqual(before,self.m.snapshot())

    def test_receipt_needs_explicit_integration(self):
        self.bind();r=self.dispatch();self.reply(r,"OK")
        self.assertEqual(self.m.kernel.snapshot()["percepts"][r["fact"]]["epistemic"],"Unknown")
        self.finish(r)
        self.assertEqual(self.m.kernel.snapshot()["percepts"][r["fact"]]["epistemic"],"Known")

    def test_duplicate_receipt_and_integration_do_not_charge_twice(self):
        self.bind();r=self.dispatch();self.reply(r,"OK")
        with self.assertRaises(ValueError):self.reply(r,"OK")
        self.finish(r)
        with self.assertRaises(ValueError):self.finish(r)
        self.assertEqual(self.m.spent,1)

    def test_target_change_between_receipt_and_integration_obsoletes_result(self):
        self.bind();r=self.dispatch();self.reply(r,"OK")
        self.step("target",fact="clearance.s1")
        result=self.finish(r)
        self.assertEqual(result["outcome"],"SUPERSEDED")
        self.assertIsNone(result["observation_ref"])

    def test_tracking_loss_and_reacquisition_does_not_rebind_old_request(self):
        self.bind();r=self.dispatch()
        self.step("tracking",valid=False);self.step("tracking",valid=True)
        self.reply(r,"OK");self.assertEqual(self.finish(r)["outcome"],"SUPERSEDED")

    def test_pause_obsoletes_pending_result(self):
        self.bind();r=self.dispatch();self.step("pause",paused=True)
        self.reply(r,"OK");self.assertEqual(self.finish(r)["outcome"],"SUPERSEDED")

    def test_future_sample_rejected_transactionally(self):
        self.bind();r=self.dispatch();before=self.m.snapshot()
        with self.assertRaises(ValueError):self.reply(r,"OK",sampled_at=100)
        self.assertEqual(before,self.m.snapshot())

    def test_late_success_is_timeout_and_fault(self):
        self.bind();r=self.dispatch()
        self.reply(r,"OK",at=r["deadline"]+1,sampled_at=r["deadline"])
        self.assertEqual(self.finish(r)["outcome"],"TIMEOUT")
        self.assertEqual(self.m.organs[r["organ"]]["state"],"FAULT")
        self.assertEqual(self.m.kernel.snapshot()["percepts"][r["fact"]]["epistemic"],"Unknown")

    def test_error_is_invalid_and_explicit_recovery_is_required(self):
        self.bind();r=self.dispatch();self.reply(r,"ERROR");self.finish(r)
        self.assertEqual(self.m.kernel.snapshot()["percepts"][r["fact"]]["epistemic"],"Invalid")
        with self.assertRaises(ValueError):self.step("release",organ=r["organ"])
        self.step("recover",organ=r["organ"])
        self.assertEqual(self.m.organs[r["organ"]]["state"],"READY")

    def test_occluded_receipt_retains_visibility_axis(self):
        self.bind();r=self.dispatch();self.reply(r,"OCCLUDED");self.finish(r)
        p=self.m.kernel.snapshot()["percepts"][r["fact"]]
        self.assertEqual(p["epistemic"],"Unknown");self.assertIn("occluded",p["visibility"])

    def test_cooldown_cannot_be_skipped(self):
        self.config["cooldown_ms"]=10;self.m=OrganMachine(self.config)
        self.bind();r=self.dispatch();self.reply(r,"OK");self.finish(r)
        with self.assertRaises(ValueError):self.step("release",organ=r["organ"])
        self.step("release",organ=r["organ"],at=self.m.clock+10)

    def test_committed_budget_reservation_survives_budget_change(self):
        self.bind();r=self.dispatch()
        self.step("budget",limit=1)
        self.reply(r,"OK");self.assertEqual(self.finish(r)["outcome"],"OK")
        self.assertEqual(self.m.plan(),[])
        self.assert_rejected({"kind":"budget","at":self.m.clock,"limit":0})
        self.step("release",organ=r["organ"])
        self.step("budget",limit=3)
        self.assertTrue(self.m.plan())

    def test_budget_reduction_before_dispatch_blocks_exposure(self):
        self.bind();p=self.m.plan()[0];self.step("expose",organ=p["organ"],sector=p["sector"])
        self.step("budget",limit=0)
        with self.assertRaises(ValueError):self.step("dispatch",organ=p["organ"])
        self.step("cancel",organ=p["organ"])
        self.assertEqual(self.m.spent,0)

    def test_bank_covers_all_questions_with_sixteen_measurements(self):
        self.bind()
        for _ in range(16):
            r=self.dispatch();self.reply(r);self.finish(r)
            self.step("release",organ=r["organ"])
        self.assertEqual(len(self.m.attempts),16)
        self.assertEqual(self.m.spent,16)
        self.assertTrue(all(o["sector"]==7 for o in self.m.organs.values()))
        r=self.dispatch()
        self.assertEqual(self.m.organs[r["organ"]]["unwrapped_step"],8)

    def test_fixed_exposure_repeatedly_samples_only_two_questions(self):
        self.config["policy"]="fixed";self.m=OrganMachine(self.config);self.bind()
        for _ in range(16):
            r=self.dispatch();self.reply(r);self.finish(r);self.step("release",organ=r["organ"])
        self.assertEqual(set(self.m.attempts),{"beacon.s0","clearance.s0"})

    def test_expiry_preserves_unknown_vs_false(self):
        self.bind();r=self.dispatch();self.reply(r,"OK",value=False);self.finish(r)
        self.assertFalse(self.m.kernel.snapshot()["percepts"][r["fact"]]["value"])
        self.step("tick",at=self.m.clock+100)
        self.assertEqual(self.m.kernel.snapshot()["percepts"][r["fact"]]["epistemic"],"Unknown")

    def test_resume_expires_evidence_abandons_pending_and_retains_spent(self):
        self.bind();r=self.dispatch();self.reply(r,"OK");self.finish(r);self.step("release",organ=r["organ"])
        pending=self.dispatch()
        self.step("resume",at=self.m.clock+101)
        self.assertIn(pending["id"],self.m.abandoned)
        self.assertEqual(self.m.spent,2)
        self.assertTrue(all(o["lifecycle"]=="INSTANTIATED" for o in self.m.organs.values()))
        self.assertTrue(all(p["epistemic"]=="Unknown" for p in self.m.kernel.snapshot()["percepts"].values()))

    def engine(self):
        e=SegmentEngine.create(self.root/"journal",self.config)
        self.addCleanup(e.close)
        return e

    def test_segments_preserve_state_and_budget_at_boundary(self):
        e=self.engine()
        for i in range(29):e.commit({"kind":"tick","at":i})
        e.checkpoint();r=recover_segments(e.directory)
        self.assertEqual(r["segment_count"],3)
        self.assertEqual(r["machine"].snapshot(),e.machine.snapshot())
        self.assertTrue(verify_segment_checkpoint(e.directory))
        cp_path=e.directory/"checkpoint.json";cp=loads(cp_path.read_bytes())
        cp["state"]["kernel"]["tracking"]=1
        cp.pop("digest");cp_path.write_bytes(canon(sealed("OrganCheckpoint",cp)))
        with self.assertRaises(ValueError):verify_segment_checkpoint(e.directory)

    def test_segment_gap_rejected(self):
        e=self.engine()
        for i in range(25):e.commit({"kind":"tick","at":i})
        (e.directory/"segment-000001.jsonl").unlink()
        with self.assertRaisesRegex(ValueError,"segment_gap"):recover_segments(e.directory)

    def test_rehashed_semantic_tampering_detected(self):
        e=self.engine();e.commit({"kind":"tick","at":1});e.close()
        p=e.directory/"segment-000000.jsonl";lines=p.read_bytes().splitlines()
        rec=loads(lines[-1]);rec["post"]="0"*64;rec.pop("digest")
        lines[-1]=canon(sealed("SessionTransition",rec));p.write_bytes(b"\n".join(lines)+b"\n")
        with self.assertRaisesRegex(ValueError,"semantics"):recover_segments(e.directory)

    def test_torn_record_saved_before_resume(self):
        e=self.engine();e.commit({"kind":"tick","at":1});e.close()
        p=e.directory/"segment-000000.jsonl"
        with p.open("ab") as f:f.write(b'{"partial":')
        with self.assertRaises(ValueError):recover_segments(e.directory)
        reopened=SegmentEngine.reopen(e.directory);self.addCleanup(reopened.close)
        self.assertEqual(p.with_name(p.name+".torn").read_bytes(),b'{"partial":')
        self.assertEqual(reopened.machine.seq,1)

    def test_torn_new_segment_header_preserves_verified_prefix(self):
        e=self.engine()
        for i in range(12):e.commit({"kind":"tick","at":i})
        e.close();p=e.directory/"segment-000001.jsonl";p.write_bytes(b'{"incomplete')
        reopened=SegmentEngine.reopen(e.directory);self.addCleanup(reopened.close)
        self.assertFalse(p.exists());self.assertTrue(p.with_name(p.name+".torn").exists())
        reopened.commit({"kind":"tick","at":20})
        self.assertEqual(recover_segments(e.directory)["machine"].seq,13)

    def test_storage_failure_does_not_publish_candidate(self):
        e=self.engine();before=e.machine.snapshot()
        with patch("segments.os.fsync",side_effect=OSError("disk")):
            with self.assertRaises(OSError):e.commit({"kind":"tick","at":2})
        self.assertEqual(e.machine.snapshot(),before)

    def test_real_subprocess_obeys_exposure(self):
        self.bind();r=self.dispatch();clock=MonotonicClock()
        runner=FieldRunner(clock,self.config);receipt=runner.run(r)
        self.assertEqual(receipt["exposure"],r["exposure"])
        expected=measure(self.world,r["query"],r["sector"])
        self.assertEqual(receipt["value"],expected["value"])
        self.assertEqual(receipt["outcome"],expected["outcome"])
        self.assertIsNone(runner.child)

    def test_real_blocked_process_times_out(self):
        self.config["timeout_ms"]=50;self.m=OrganMachine(self.config)
        self.bind();r=self.dispatch();clock=MonotonicClock()
        runner=FieldRunner(clock,self.config,[sys.executable,"-c","import time;time.sleep(3)"])
        receipt=runner.run(r)
        self.assertEqual(receipt["outcome"],"TIMEOUT")
        self.assertIsNone(runner.child)

    def test_wrong_worker_exposure_is_not_promoted(self):
        self.bind();r=self.dispatch();clock=MonotonicClock()
        script="import json,time;print(json.dumps(dict(outcome='OK',value=True,sampled_ns=time.monotonic_ns(),sample_ref='a'*64,exposure='wrong',detail='bad')))"
        runner=FieldRunner(clock,self.config,[sys.executable,"-c",script])
        self.assertEqual(runner.run(r)["outcome"],"ERROR")

    def test_real_http_budget_and_delta_protocol(self):
        e=self.engine();clock=FakeClock();s=OrganService(e,clock,ModelRunner(clock,self.world))
        server=server_for(s,0,viewer_html);t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
        self.addCleanup(lambda:(server.shutdown(),server.server_close(),t.join()))
        base=f"http://127.0.0.1:{server.server_port}"
        with urlopen(base+"/api/updates",timeout=2) as response:first=json.load(response)["snapshot"]
        request=Request(base+"/api/control",data=b'{"kind":"budget","limit":4}',
                        headers={"Content-Type":"application/json","Origin":base},method="POST")
        with urlopen(request,timeout=2) as response:self.assertEqual(response.status,202)
        s.cycle()
        with urlopen(base+f"/api/updates?cursor={first['sequence']}&digest={first['state_digest']}",timeout=2) as response:
            updates=json.load(response)
        for delta in updates["deltas"]:first=apply_view_delta(first,delta)
        self.assertEqual(first,s.current);self.assertEqual(first["budget"]["limit"],4)
        with urlopen(base,timeout=2) as response:self.assertIn("Organbank",response.read().decode())

    def test_control_queue_overflow_explicit(self):
        e=self.engine();s=OrganService(e,FakeClock())
        for _ in range(16):s.enqueue({"kind":"pause","paused":True})
        with self.assertRaises(queue.Full):s.enqueue({"kind":"pause","paused":False})

    def test_capacity_stop_drains_without_exceeding_limit(self):
        self.config["max_transitions"]=40;self.config["segment_records"]=10
        e=self.engine();clock=FakeClock();s=OrganService(e,clock,ModelRunner(clock,self.world))
        for _ in range(80):
            clock.advance()
            if not s.cycle():break
        self.assertEqual(e.machine.phase,"STOPPED")
        self.assertLessEqual(e.machine.seq,40)


if __name__ == "__main__":
    unittest.main()
