"""Contract and integration tests for the 0.2 closed-loop session."""
import copy
import io
import json
import os
import queue
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from grfps_l2 import Kernel,canon,digest
from test_kernel import genome,obs
from session import SessionMachine,IncrementalKernel,view_snapshot,view_delta,apply_view_delta
from adapters import file_config,MonotonicClock,FileRunner
from journal import JournalEngine,recover,verify_checkpoint
from live import LiveService,server_for,export_replay


class FakeClock:
    def __init__(self):self.t=0
    def now(self):return self.t
    def advance(self,dt):self.t+=dt


class LocalRunner:
    """Deterministic test carrier with actual file queries and explicit fake time."""
    def __init__(self,clock,outcome="OK"):
        self.clock,self.outcome=clock,outcome
    def run(self,request,endpoint):
        p=Path(endpoint["path"])
        value=p.is_dir() if endpoint["query"]=="is_dir" else p.is_file()
        return {"kind":"receipt","at":self.clock.now(),"request":request["id"],
                "outcome":self.outcome,"value":value if self.outcome=="OK" else None,
                "sampled_at":self.clock.now() if self.outcome=="OK" else None,"detail":"test"}


class SessionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        self.file=self.root/"sample.txt"
        self.file.write_text("fixture")
        self.config=file_config([self.file],ttl_ms=300,refresh_ms=100,timeout_ms=100)
        self.machine=SessionMachine(self.config)
    def tearDown(self):self.temp.cleanup()
    def step(self,event):
        self.machine,out=self.machine.reduce(event)
        return out
    def dispatch(self,at=0):
        self.step({"kind":"tick","at":at})
        endpoint=self.machine.plan()[0]["endpoint"]
        return self.step({"kind":"dispatch","at":at,"endpoint":endpoint})["request"]
    def answer(self,req,value=True,at=1,outcome="OK"):
        return self.step({"kind":"receipt","at":at,"request":req["id"],"outcome":outcome,
                         "value":value if outcome=="OK" else None,
                         "sampled_at":at if outcome=="OK" else None,"detail":"test"})
    def service(self):
        e=JournalEngine.create(self.root/"session.jsonl",self.config)
        self.addCleanup(e.close)
        clock=FakeClock()
        return LiveService(e,clock,LocalRunner(clock))

    def test_incremental_matches_reference_including_expiry_retraction(self):
        baseline=Kernel(genome());incremental=IncrementalKernel(genome())
        events=[obs(1),obs(2,source="sensor_b"),obs(3,at=2,value=False),
                {"id":"r","kind":"retract","at":3,"ref":"e3","label":"test"},
                {"id":"t","kind":"target","at":5,"fact":"cache","label":"test"},
                {"id":"end","kind":"tick","at":40,"label":"expire"}]
        for event in events:
            self.assertEqual(baseline.step(event),incremental.step(event))
        self.assertEqual(baseline.bundle(),incremental.bundle())

    def test_only_affected_fact_is_revalidated(self):
        k=IncrementalKernel(genome())
        count=k.revalidations
        k.step(obs(1))
        self.assertEqual(k.revalidations-count,1)
        count=k.revalidations
        k.step({"id":"tick","kind":"tick","at":1,"label":"before expiry"})
        self.assertEqual(k.revalidations,count)
        k.step({"id":"expiry","kind":"tick","at":30,"label":"expiry"})
        self.assertEqual(k.revalidations-count,1)

    def test_dispatch_executes_the_planned_endpoint(self):
        req=self.dispatch()
        self.assertEqual(req["effect"],"READ_METADATA")
        self.assertEqual(req["deadline"],100)
        self.assertEqual(self.machine.plan(),[])

    def test_unmatched_receipt_cannot_mutate_state(self):
        before=self.machine.snapshot()
        with self.assertRaises(ValueError):
            self.answer({"id":"fake"})
        self.assertEqual(before,self.machine.snapshot())

    def test_duplicate_receipt_is_rejected(self):
        req=self.dispatch()
        self.answer(req)
        before=self.machine.snapshot()
        with self.assertRaises(ValueError):self.answer(req)
        self.assertEqual(before,self.machine.snapshot())

    def test_future_sample_is_rejected(self):
        req=self.dispatch()
        with self.assertRaises(ValueError):
            self.step({"kind":"receipt","at":2,"request":req["id"],"outcome":"OK",
                       "value":True,"sampled_at":3,"detail":"test"})

    def test_late_success_becomes_timeout_not_false(self):
        req=self.dispatch()
        result=self.answer(req,at=101)
        self.assertEqual(result["receipt"]["outcome"],"TIMEOUT")
        p=self.machine.kernel.snapshot()["percepts"][req["fact"]]
        self.assertEqual(p["epistemic"],"Unknown")
        self.assertIsNone(p["value"])

    def test_error_becomes_invalid(self):
        req=self.dispatch()
        self.answer(req,outcome="ERROR")
        self.assertEqual(self.machine.kernel.snapshot()["percepts"][req["fact"]]["epistemic"],"Invalid")

    def test_target_epoch_obsoletes_pending_request(self):
        req=self.dispatch()
        self.step({"kind":"target","at":1,"fact":"workspace"})
        result=self.answer(req,at=2)
        self.assertEqual(result["receipt"]["outcome"],"SUPERSEDED")
        self.assertIsNone(result["receipt"]["observation_ref"])

    def test_tracking_epoch_obsoletes_pending_request(self):
        req=self.dispatch()
        self.step({"kind":"tracking","at":1,"valid":False})
        self.assertEqual(self.answer(req,at=2)["receipt"]["outcome"],"SUPERSEDED")
        self.assertEqual(self.machine.plan(),[])

    def test_pause_keeps_clock_and_expiry_running(self):
        req=self.dispatch()
        self.answer(req)
        self.step({"kind":"pause","at":2,"paused":True})
        self.step({"kind":"tick","at":302})
        self.assertEqual(self.machine.plan(),[])
        p=self.machine.kernel.snapshot()["percepts"][req["fact"]]
        self.assertEqual(p["epistemic"],"Unknown")

    def test_known_facts_are_refreshed_fairly(self):
        seen=[]
        for at in [0,10,120,130]:
            req=self.dispatch(at)
            seen.append(req["endpoint"])
            self.answer(req,at=at+1)
        self.assertEqual(seen[0],seen[2])
        self.assertEqual(seen[1],seen[3])
        self.assertEqual(len(set(seen)),2)

    def test_file_disappears_and_returns_in_closed_loop(self):
        service=self.service()
        for _ in range(2):service.cycle();service.clock.advance(10)
        self.assertIs(service.current["objects"]["file0"]["percept"]["value"],True)
        self.file.unlink()
        service.clock.advance(150)
        for _ in range(2):service.cycle();service.clock.advance(10)
        self.assertIs(service.current["objects"]["file0"]["percept"]["value"],False)
        self.assertNotIn("file0",service.current["region"])
        self.file.write_text("returned")
        service.clock.advance(150)
        for _ in range(2):service.cycle();service.clock.advance(10)
        self.assertIs(service.current["objects"]["file0"]["percept"]["value"],True)
        self.assertIn("file0",service.current["region"])
        self.assertEqual(recover(service.engine.path)["machine"].snapshot(),
                         service.engine.machine.snapshot())

    def test_pause_queue_blocks_new_dispatch(self):
        service=self.service()
        service.enqueue({"kind":"pause","paused":True})
        service.cycle()
        self.assertTrue(service.current["paused"])
        self.assertEqual(service.current["request_count"],0)

    def test_control_backpressure_is_explicit(self):
        self.config["queue_limit"]=1
        service=self.service()
        service.enqueue({"kind":"pause","paused":True})
        with self.assertRaises(queue.Full):service.enqueue({"kind":"pause","paused":False})

    def test_view_delta_is_exact_projection(self):
        before=view_snapshot(self.machine.snapshot(),self.config)
        req=self.dispatch()
        self.answer(req)
        after=view_snapshot(self.machine.snapshot(),self.config)
        delta=view_delta(before,after)
        self.assertEqual(apply_view_delta(before,delta),after)
        self.assertEqual(set(delta["changed"]),{req["fact"]})

    def test_missing_delta_requires_reset(self):
        service=self.service()
        base=copy.deepcopy(service.current)
        service.cycle()
        update=service.updates(base["sequence"],"wrong_digest")
        self.assertEqual(update["kind"],"reset")
        d=service.deltas[-1]
        with self.assertRaises(ValueError):apply_view_delta(base,d)

    def test_delta_ring_overrun_produces_full_snapshot(self):
        self.config["delta_limit"]=1
        service=self.service()
        base=copy.deepcopy(service.current)
        service.cycle()
        self.assertEqual(service.updates(base["sequence"],base["state_digest"])["kind"],"reset")

    def test_journal_and_checkpoint_reproduce_state(self):
        service=self.service()
        service.cycle()
        cp=service.engine.checkpoint()
        self.assertTrue(verify_checkpoint(service.engine.path,cp))

    def test_fsync_failure_does_not_publish_next_state(self):
        service=self.service()
        engine=service.engine
        before=engine.machine.snapshot()
        original=engine.stream
        class FailedStream:
            def write(self,data):raise OSError("simulated disk error")
            def close(self):original.close()
        engine.stream=FailedStream()
        with self.assertRaises(OSError):service.commit({"kind":"tick","at":10})
        self.assertEqual(engine.machine.snapshot(),before)
        self.assertEqual(service.current["sequence"],0)

    def test_torn_tail_is_preserved_before_reopen(self):
        service=self.service()
        service.cycle()
        path=service.engine.path
        service.engine.close()
        with path.open("ab") as f:f.write(b'{"partial":')
        with self.assertRaises(ValueError):recover(path)
        recovered=recover(path,allow_torn_tail=True)
        self.assertEqual(recovered["torn_tail_bytes"],11)
        engine=JournalEngine.reopen(path)
        try:
            self.assertEqual(path.with_name(path.name+".torn").read_bytes(),b'{"partial":')
            self.assertEqual(engine.machine.snapshot(),recovered["machine"].snapshot())
        finally:engine.close()

    def test_rehashed_false_post_digest_is_detected(self):
        service=self.service()
        service.cycle()
        service.engine.close()
        path=service.engine.path
        lines=path.read_bytes().splitlines()
        record=json.loads(lines[-1])
        record["post"]="0"*64
        record["digest"]=digest("SessionTransition",{k:v for k,v in record.items() if k!="digest"})
        lines[-1]=canon(record)
        path.write_bytes(b"\n".join(lines)+b"\n")
        with self.assertRaises(ValueError):recover(path)

    def test_resume_expires_prior_evidence_and_abandons_pending_probe(self):
        req=self.dispatch()
        self.answer(req)
        pending=self.dispatch(10)
        before_count=self.machine.request_count
        self.step({"kind":"resume","at":400})
        self.assertIn(pending["id"],self.machine.abandoned)
        self.assertEqual(self.machine.request_count,before_count)
        self.assertEqual(self.machine.kernel.snapshot()["region"],[])
        self.assertTrue(self.machine.plan())

    def test_subprocess_reads_real_file(self):
        clock=MonotonicClock()
        runner=FileRunner(clock)
        endpoint=self.config["endpoints"][0]
        req={"id":"real","issued_at":clock.now(),"deadline":clock.now()+1000}
        r=runner.run(req,endpoint)
        self.assertEqual(r["outcome"],"OK")
        self.assertIs(r["value"],True)
        self.assertIsNone(runner.child)

    def test_blocked_subprocess_is_killed_and_reaped(self):
        clock=MonotonicClock()
        runner=FileRunner(clock,[sys.executable,"-c","import time; time.sleep(3)"])
        req={"id":"timeout","issued_at":0,"deadline":100}
        before=time.monotonic()
        r=runner.run(req,self.config["endpoints"][0])
        self.assertEqual(r["outcome"],"TIMEOUT")
        self.assertLess(time.monotonic()-before,2)
        self.assertIsNone(runner.child)

    def test_real_http_protocol_and_queue(self):
        service=self.service()
        server=server_for(service)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        url="http://127.0.0.1:"+str(server.server_port)
        try:
            with urlopen(url+"/api/updates",timeout=2) as r:
                self.assertEqual(json.load(r)["kind"],"reset")
            request=Request(url+"/api/control",data=b'{"kind":"pause","paused":true}',
                            headers={"Content-Type":"application/json"},method="POST")
            with urlopen(request,timeout=2) as r:self.assertEqual(r.status,202)
            service.cycle()
            with urlopen(url+"/api/updates",timeout=2) as r:
                self.assertTrue(json.load(r)["snapshot"]["paused"])
            bad=Request(url+"/api/control",data=b'{"kind":"pause","paused":false}',
                        headers={"Content-Type":"application/json","Origin":"https://example.invalid"},
                        method="POST")
            with self.assertRaises(HTTPError) as err:urlopen(bad,timeout=2)
            self.assertEqual(err.exception.code,403)
        finally:
            server.shutdown();server.server_close();thread.join()

    def test_session_budget_stops_explicitly(self):
        self.config["max_transitions"]=8
        service=self.service()
        while service.cycle():service.clock.advance(1)
        self.assertEqual(service.current["phase"],"STOPPED")
        self.assertLessEqual(service.current["sequence"],8)


if __name__=="__main__":unittest.main()
