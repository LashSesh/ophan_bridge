"""Fixed read-only filesystem worker. One request, one bounded JSON response."""
import json
import stat
import sys
import time
from pathlib import Path


def measure(endpoint):
    try:
        mode=Path(endpoint["path"]).stat().st_mode
        value=stat.S_ISDIR(mode) if endpoint["query"]=="is_dir" else stat.S_ISREG(mode)
        status,detail="OK","stat_result"
    except (FileNotFoundError,NotADirectoryError):
        value,status,detail=False,"OK","path_absent"
    except OSError as err:
        value,status,detail=None,"ERROR",type(err).__name__
    return {"outcome":status,"value":value,"sampled_ns":time.monotonic_ns(),"detail":detail}


if __name__=="__main__":
    data=sys.stdin.buffer.readline(8193)
    if len(data)>8192:
        raise SystemExit(2)
    endpoint=json.loads(data)
    if endpoint.get("query") not in ["is_file","is_dir"]:
        raise SystemExit(2)
    print(json.dumps(measure(endpoint)),flush=True)
