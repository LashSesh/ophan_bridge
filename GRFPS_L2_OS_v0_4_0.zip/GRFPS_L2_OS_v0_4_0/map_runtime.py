"""Typed window sensor, append-first replay and offline atlas export."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
from grfps_l2 import canon, loads, require
from mapping import MapMachine, hashof

MAX_LINE=262144

def header(config):
    m=MapMachine(config);return dict(type='header',config=config,state=m.snapshot()['state_digest'])

def record(m,event,parent):
    n,out=m.reduce(event)
    body=dict(type='transition',sequence=m.seq,event=event,parent=parent,
              pre=m.snapshot()['state_digest'],post=n.snapshot()['state_digest'],output=out)
    return n,dict(body,digest=hashof('Transition',body))

class MapJournal:
    def __init__(self,path,config):
        self.machine=MapMachine(config);self.path=Path(path);self.stream=self.path.open('xb');self.failed=False
        h=header(config);self.head=hashof('Header',h)
        try:self._write(h)
        except BaseException:self.stream.close();raise
    def _write(self,obj):
        data=canon(obj)+b'\n';require(len(data)<=MAX_LINE,'line_budget')
        require(self.stream.tell()==os.fstat(self.stream.fileno()).st_size,'writer_size')
        st=self.path.stat();fd=os.fstat(self.stream.fileno())
        require((st.st_dev,st.st_ino)==(fd.st_dev,fd.st_ino),'writer_identity')
        self.stream.write(data);self.stream.flush();os.fsync(self.stream.fileno())
    def commit(self,event):
        require(not self.failed,'writer_failed')
        candidate,r=record(self.machine,event,self.head)
        try:self._write(r)
        except BaseException:self.failed=True;raise
        self.machine=candidate;self.head=r['digest'];return self.machine.snapshot()
    def close(self):self.stream.close()

def replay(path):
    with Path(path).open('rb') as f:
        def line():
            b=f.readline(MAX_LINE+1)
            require(len(b)<=MAX_LINE and (not b or b.endswith(b'\n')),'journal_line')
            return loads(b) if b else None
        h=line();require(type(h) is dict and 'config' in h,'header')
        require(canon(h)==canon(header(h['config'])),'header_semantics')
        m=MapMachine(h['config']);parent=hashof('Header',h);views=[m.snapshot()];events=[]
        while (r:=line()) is not None:
            require(type(r) is dict and 'event' in r,'transition')
            candidate,expected=record(m,r['event'],parent)
            require(canon(r)==canon(expected),'transition_semantics')
            m=candidate;parent=r['digest'];views.append(m.snapshot());events.append(r['event'])
    return dict(machine=m,head=parent,views=views,events=events)

def measure_process(world,request,at):
    """Fixed subprocess; logical sampled_at supplied by harness, not a latency claim."""
    try:
        run=subprocess.run([sys.executable,str(Path(__file__).with_name('map_worker.py')),str(world)],
            input=canon(dict(request=request,sampled_at=at)),capture_output=True,timeout=2)
        require(run.returncode==0 and len(run.stdout)<=MAX_LINE,'worker_protocol')
        p=loads(run.stdout)
        return dict(kind='patch',at=at,exposure_ref=request['exposure_ref'],patch=p)
    except (ValueError,subprocess.TimeoutExpired,OSError):
        return dict(kind='fail',at=at,request=request['id'],reason='ERROR')

def export(path,html):
    r=replay(path)
    data=dict(profile='grfps-witnessed-atlas/0.4.0',views=r['views'],events=r['events'],head=r['head'])
    template=Path(__file__).with_name('map_viewer.html').read_text()
    Path(html).write_text(template.replace('__MAP_DATA__',json.dumps(data,ensure_ascii=True).replace('<','\\u003c')))
    return dict(transitions=r['machine'].seq,spent=r['machine'].spent,head=r['head'],state_digest=r['machine'].snapshot()['state_digest'])

def main():
    p=argparse.ArgumentParser();p.add_argument('journal');p.add_argument('--html');a=p.parse_args()
    if a.html:print(json.dumps(export(a.journal,a.html),indent=2))
    else:
        r=replay(a.journal);print(json.dumps(dict(head=r['head'],state=r['machine'].snapshot()),indent=2))
if __name__=='__main__':main()
