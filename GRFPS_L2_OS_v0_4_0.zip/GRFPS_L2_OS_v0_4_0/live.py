"""Local closed-loop perception service. Python standard library only."""
from __future__ import annotations
import argparse
import copy
import json
import queue
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from grfps_l2 import canon,loads,require
from session import view_snapshot,view_delta
from journal import JournalEngine,recover,verify_checkpoint
from adapters import file_config,MonotonicClock,FileRunner


class LiveService:
    def __init__(self,engine,clock=None,runner=None):
        self.engine=engine
        self.config=engine.machine.config
        self.clock=clock or MonotonicClock(engine.machine.clock)
        self.runner=runner or FileRunner(self.clock)
        self.commands=queue.Queue(maxsize=self.config["queue_limit"])
        self.lock=threading.Lock()
        self.deltas=deque(maxlen=self.config["delta_limit"])
        self.current=view_snapshot(engine.machine.snapshot(),self.config)
        self.stopping=threading.Event()
        self.error=None
        self.command_results=deque(maxlen=self.config["queue_limit"])

    def commit(self,event):
        before=self.current
        record=self.engine.commit(event)
        after=view_snapshot(self.engine.machine.snapshot(),self.config)
        delta=view_delta(before,after)
        with self.lock:
            self.current=after
            self.deltas.append(delta)
        if self.engine.machine.seq % self.config["checkpoint_every"]==0:
            self.engine.checkpoint()
        return record

    def enqueue(self,command):
        require(type(command) is dict,"control_shape")
        kind=command.get("kind")
        required={"pause":{"kind","paused"},"target":{"kind","fact"},
                  "tracking":{"kind","valid"},"stop":{"kind"}}
        require(type(kind) is str and kind in required and set(command)==required[kind],
                "control_fields")
        if kind=="pause":require(type(command["paused"]) is bool,"pause_type")
        if kind=="tracking":require(type(command["valid"]) is bool,"tracking_type")
        if kind=="target":require(type(command["fact"]) is str and
            command["fact"] in self.engine.machine.kernel.fact_ids,"target_binding")
        require(self.current["phase"]=="RUNNING" and not self.error,"service_stopped")
        self.commands.put_nowait(copy.deepcopy(command))

    def updates(self,cursor=None,state_digest=None):
        with self.lock:
            if cursor==self.current["sequence"] and state_digest==self.current["state_digest"]:
                return {"kind":"deltas","deltas":[],"head":cursor,"error":self.error}
            pending=[d for d in self.deltas if cursor is not None and d["to"]>cursor]
            if (pending and pending[0]["from"]==cursor and pending[0]["pre"]==state_digest):
                return {"kind":"deltas","deltas":copy.deepcopy(pending),
                        "head":self.current["sequence"],"error":self.error}
            return {"kind":"reset","snapshot":copy.deepcopy(self.current),"error":self.error}

    def cycle(self):
        machine=self.engine.machine
        if machine.phase!="RUNNING":
            return False
        # Leave enough room for the final receipt and stop transaction.
        if machine.seq>=self.config["max_transitions"]-5:
            self.commit({"kind":"stop","at":self.clock.now(),"reason":"session_budget"})
            return False
        for _ in range(self.config["queue_limit"]):
            if self.engine.machine.seq>=self.config["max_transitions"]-5:
                break
            try:
                command=self.commands.get_nowait()
            except queue.Empty:
                break
            event=dict(command,at=self.clock.now())
            if event["kind"]=="stop":event["reason"]="user_stop"
            try:
                self.commit(event)
                with self.lock:
                    self.command_results.append({"command":command,"status":"COMMITTED"})
            except ValueError as err:
                with self.lock:
                    self.command_results.append({"command":command,"status":"REJECTED","error":str(err)})
            finally:
                self.commands.task_done()
            if self.engine.machine.phase!="RUNNING":
                return False
        if self.engine.machine.seq>=self.config["max_transitions"]-5:
            self.commit({"kind":"stop","at":self.clock.now(),"reason":"session_budget"})
            return False
        self.commit({"kind":"tick","at":self.clock.now()})
        plan=self.engine.machine.plan()
        if plan:
            record=self.commit({"kind":"dispatch","at":self.engine.machine.clock,"endpoint":plan[0]["endpoint"]})
            req=record["output"]["request"]
            endpoint=next(e for e in self.config["endpoints"] if e["id"]==req["endpoint"])
            receipt=self.runner.run(req,endpoint)
            self.commit(receipt)
        return True

    def run(self,duration_s):
        start=time.monotonic()
        try:
            while not self.stopping.is_set() and time.monotonic()-start<duration_s:
                if not self.cycle():break
                self.stopping.wait(self.config["tick_ms"]/1000)
            if self.engine.machine.phase=="RUNNING":
                self.commit({"kind":"stop","at":self.clock.now(),"reason":"session_end"})
            self.engine.checkpoint()
        except BaseException as err:
            # Never label a storage or interpreter failure as a successful stop.
            with self.lock:self.error=type(err).__name__+": "+str(err)
        finally:
            self.stopping.set()


def viewer_html(data):
    template=Path(__file__).with_name("live_viewer.html").read_text(encoding="utf-8")
    return template.replace("__SESSION_DATA__",json.dumps(data,ensure_ascii=True).replace("<","\\u003c"))


def server_for(service,port=0,html_factory=viewer_html):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass

        def send(self,status,payload,content_type="application/json"):
            raw=payload.encode("utf-8") if isinstance(payload,str) else json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type",content_type+"; charset=utf-8")
            self.send_header("Content-Length",str(len(raw)))
            self.send_header("Cache-Control","no-store")
            self.send_header("X-Content-Type-Options","nosniff")
            self.end_headers()
            self.wfile.write(raw)

        def bound_host(self):
            host=self.headers.get("Host","")
            return host in [f"127.0.0.1:{self.server.server_port}",f"localhost:{self.server.server_port}"]

        def do_GET(self):
            if not self.bound_host():return self.send(403,{"error":"host_binding"})
            u=urlsplit(self.path)
            if u.path=="/":
                return self.send(200,html_factory({"mode":"live","frames":[],
                    "title":"Lokale Dateiwahrnehmung"}),"text/html")
            if u.path=="/api/updates":
                q=parse_qs(u.query)
                try:cursor=int(q["cursor"][0]) if "cursor" in q else None
                except ValueError:return self.send(400,{"error":"cursor"})
                return self.send(200,service.updates(cursor,q.get("digest",[None])[0]))
            if u.path=="/api/status":
                with service.lock:
                    data={"phase":service.current["phase"],"sequence":service.current["sequence"],
                          "error":service.error,"queued":service.commands.qsize(),
                          "commands":list(service.command_results)}
                return self.send(200,data)
            return self.send(404,{"error":"not_found"})

        def do_POST(self):
            if not self.bound_host():return self.send(403,{"error":"host_binding"})
            origin=self.headers.get("Origin")
            if origin and origin not in [f"http://127.0.0.1:{self.server.server_port}",
                                         f"http://localhost:{self.server.server_port}"]:
                return self.send(403,{"error":"origin_binding"})
            if self.path!="/api/control":return self.send(404,{"error":"not_found"})
            if self.headers.get("Content-Type","").split(";")[0]!="application/json":
                return self.send(415,{"error":"json_required"})
            try:
                n=int(self.headers.get("Content-Length","0"))
                require(0<n<=4096,"control_byte_budget")
                command=loads(self.rfile.read(n))
                service.enqueue(command)
                self.send(202,{"status":"QUEUED"})
            except queue.Full:
                self.send(429,{"error":"control_queue_full"})
            except (ValueError,TypeError):
                self.send(400,{"error":"invalid_control"})
    server=ThreadingHTTPServer(("127.0.0.1",port),Handler)
    server.daemon_threads=True
    return server


def export_replay(journal_path,html_path):
    r=recover(journal_path,collect_views=True)
    frames=[view_snapshot(s,r["header"]["config"]) for s in r["views"]]
    data={"mode":"replay","title":"Geschlossener Messzyklus / Aufzeichnung",
          "frames":frames,"journal_head":r["head"],"verified":True,
          "events":[{"kind":x["event"]["kind"],"output":x["output"]} for x in r["records"]]}
    Path(html_path).write_text(viewer_html(data),encoding="utf-8")
    return {"transitions":len(r["records"]),"requests":r["machine"].request_count,
            "state_digest":r["machine"].snapshot()["state_digest"],"head":r["head"]}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    commands=p.add_subparsers(dest="command",required=True)
    watch=commands.add_parser("watch")
    watch.add_argument("paths",nargs="*")
    watch.add_argument("--journal",required=True)
    watch.add_argument("--resume",action="store_true")
    watch.add_argument("--port",type=int,default=8765)
    watch.add_argument("--duration",type=float,default=60)
    watch.add_argument("--config")
    replay=commands.add_parser("replay")
    replay.add_argument("journal")
    replay.add_argument("--html")
    args=p.parse_args()
    if args.command=="replay":
        if args.html:report=export_replay(args.journal,args.html)
        else:
            r=recover(args.journal)
            report={"verified":True,"transitions":len(r["records"]),"head":r["head"],
                    "state_digest":r["machine"].snapshot()["state_digest"]}
        print(json.dumps(report,indent=2))
        return
    require(0<args.duration<=86400,"duration_range")
    if args.resume:
        require(not args.paths and not args.config,"resume_uses_bound_config")
        engine=JournalEngine.reopen(args.journal)
        offset=engine.machine.clock+engine.machine.config["genome"]["ttl"]+1
        engine.commit({"kind":"resume","at":offset})
        clock=MonotonicClock(offset)
    else:
        config=loads(Path(args.config).read_text()) if args.config else file_config(args.paths)
        engine=JournalEngine.create(args.journal,config)
        clock=MonotonicClock()
    service=LiveService(engine,clock)
    server=server_for(service,args.port)
    network=threading.Thread(target=server.serve_forever,daemon=True)
    worker=threading.Thread(target=service.run,args=(args.duration,),daemon=True)
    network.start();worker.start()
    print(f"GRFPS live: http://127.0.0.1:{server.server_port}",flush=True)
    print("Session:",args.journal,flush=True)
    try:
        while worker.is_alive():worker.join(.5)
    except KeyboardInterrupt:
        service.stopping.set()
        worker.join()
    finally:
        server.shutdown();server.server_close();engine.close()
    print(json.dumps({"phase":service.current["phase"],"error":service.error,
                      "sequence":service.current["sequence"]},indent=2))
    if service.error:raise SystemExit(1)


if __name__=="__main__":main()
