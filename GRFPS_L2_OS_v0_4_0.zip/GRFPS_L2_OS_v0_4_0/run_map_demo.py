"""Reproducible real-process mapping experiment; outputs written in /tmp first."""
import argparse
import copy
import json
from pathlib import Path
import shutil
import tempfile
from mapping import config_default, hashof
from map_runtime import MapJournal, export, measure_process, replay

PROTOCOL=dict(profile='grfps-map-experiment/0.4.0',budget=8,ttl=100,
    windows=['left','right','island'],shared_minimum=2,transform_group='C4_integer_translation',
    metrics=['true_positive','false_positive','missed_positive'],
    truth_role='fixture graph withheld from reducer and viewer; synthetic only',
    declared=[['A','B'],['A','D'],['B','C'],['C','D'],['D','E'],['E','F']])

def world():
    return dict(profile='grfps-window-world/0.4.0',points=dict(A=[0,0],B=[2,0],C=[2,2],D=[4,2],E=[8,0],F=[10,0]),
        relations=[['A','B',True],['A','C',False],['B','C',True],['B','D',False],['C','D',True],['E','F',True]],
        windows=dict(left=dict(landmarks=['A','B','C'],pose=[0,0,0],boundary=['B','C']),
                     right=dict(landmarks=['B','C','D'],pose=[1,5,-2],boundary=['B','C','D']),
                     island=dict(landmarks=['E','F'],pose=[2,9,1],boundary=['E','F'])))

def metrics(predicted,truth):
    p={tuple(e) for e in predicted};t={tuple(e) for e in truth}
    return dict(true_positive=len(p&t),false_positive=len(p-t),missed_positive=len(t-p))

def run(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=False)
    (out/'protocol.json').write_text(json.dumps(PROTOCOL,indent=2)) # before sampling
    w=world();(out/'world_initial.json').write_text(json.dumps(w,indent=2))
    path=out/'world.json';path.write_text(json.dumps(w))
    (out/'samples').mkdir()
    c=config_default();c.update(budget=8,ttl=100)
    engine=MapJournal(out/'map.jsonl',c);stages=[]
    def stage(name):
        s=engine.machine.snapshot();stages.append(dict(name=name,sequence=s['seq'],at=s['at'],spent=s['spent'],
          glued=sum(p['status']=='GLUED' for p in s['atlas']['pairs']),
          conflicts=sum(p['status']=='CONFLICT' for p in s['atlas']['pairs']),
          gaps=sum(p['status']=='GAP' for p in s['atlas']['pairs']),state_digest=s['state_digest']))
    def sample(window,at):
        engine.commit(dict(kind='request',at=at,window=window,source='window_sensor'))
        r=engine.machine.pending
        (out/'samples'/(hashof('SampleWorld',w)+'.json')).write_text(json.dumps(w,indent=2))
        result=measure_process(path,r,at+1)
        assert result['kind']=='patch','actual worker failed'
        engine.commit(result)
    try:
        sample('left',0);stage('local_window')
        sample('right',2);stage('witnessed_join')
        sample('island',4);stage('open_gap')
        base=engine.machine.snapshot()
        truth=[e[:2] for e in w['relations'] if e[2]]
        predicted=[[e['a'],e['b']] for e in base['atlas']['relations'] if e['status']=='Known' and e['value']]
        comparison=dict(declared=metrics(PROTOCOL['declared'],truth),measured=metrics(predicted,truth),budget_spent=3)
        # Retract an old sample explicitly; new contradictory sample cannot silently erase evidence.
        engine.commit(dict(kind='retract',at=6,patch='patch2'));stage('join_retracted')
        w['relations'][2][2]=False;path.write_text(json.dumps(w));sample('right',7);stage('counterevidence')
        assert any(p['status']=='CONFLICT' for p in engine.machine.snapshot()['atlas']['pairs'])
        engine.commit(dict(kind='retract',at=9,patch='patch4'))
        w['relations'][2][2]=True;path.write_text(json.dumps(w));sample('right',10);stage('join_restored')
        engine.commit(dict(kind='tick',at=101));stage('witness_expired')
        engine.commit(dict(kind='frame',at=102));stage('frame_invalidated')
        sample('left',103);sample('right',105);stage('new_frame_join')
        engine.commit(dict(kind='request',at=107,window='left',source='window_sensor'))
        request=copy.deepcopy(engine.machine.pending)
        engine.commit(dict(kind='frame',at=108))
        engine.commit(measure_process(path,request,109));stage('late_old_frame_suppressed')
        engine.commit(dict(kind='tick',at=300));stage('all_expired')
    finally:engine.close()
    proof=export(out/'map.jsonl',out/'GRFPS_Second_Layer_Demo.html')
    report=dict(**proof,protocol_digest=hashof('Protocol',PROTOCOL),stages=stages,comparison=comparison,
                actual_worker_calls=8,clock='logical milliseconds; subprocess execution real',visual_browser_review=False)
    (out/'mapping_report.json').write_text(json.dumps(report,indent=2));return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='mapping_run');a=p.parse_args()
    target=Path(a.out);assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps_mapping_') as tmp:
        source=Path(tmp)/'verified';r=run(source);replay(source/'map.jsonl');shutil.copytree(source,target)
    print(json.dumps(r,indent=2))
if __name__=='__main__':main()
