"""GRFPS L2 reference profile 0.1.0. Python >=3.10, standard library only.

Finite Boolean observation model; deterministic reducer and inspectable replay.
No actuation, authentication, statistical calibration, or full GRFPS conformance.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
from collections import deque
from pathlib import Path

PROFILE = "grfps-l2-boolean/0.1.0"
REGISTRY = {"observe_bool@1": ("Observation", "BooleanEvidence"),
            "classify_bool@1": ("BooleanEvidence", "Percept"),
            "project_view@1": ("Percept", "ViewObject")}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def canon(obj):
    """L2-CANON-1: ASCII JSON, integers within JS exact range, no floats."""
    def check(x):
        if x is None or type(x) is bool:
            return
        if type(x) is int:
            require(abs(x) <= 2**53-1, "integer_range")
        elif type(x) is str:
            require(x.isascii(), "ascii_required")
        elif type(x) is list:
            for y in x:
                check(y)
        elif type(x) is dict:
            for k, v in x.items():
                require(type(k) is str, "string_key_required")
                check(k)
                check(v)
        else:
            raise ValueError("unsupported_canonical_type")
    check(obj)
    return json.dumps(obj, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("ascii")


def digest(kind, obj):
    return hashlib.sha256(canon([PROFILE, kind, obj])).hexdigest()


def loads(data):
    def pairs(items):
        out = {}
        for k, v in items:
            require(k not in out, "duplicate_json_key")
            out[k] = v
        return out
    obj = json.loads(data, object_pairs_hook=pairs)
    canon(obj)
    return obj


def fields(obj, names):
    require(type(obj) is dict and set(obj) == set(names.split()), "record_fields")


def uint(x):
    return type(x) is int and 0 <= x <= 2**53-1


def ident(x):
    return type(x) is str and re.fullmatch(r"[A-Za-z][A-Za-z0-9_.:-]{0,95}", x)


def compile_genome(raw):
    g = copy.deepcopy(raw)
    canon(g)
    fields(g, "profile name ttl min_groups max_events max_bytes probe_budget facts sources genes edges center target")
    require(g["profile"] == PROFILE and ident(g["name"]), "profile_or_name")
    for k in ["ttl", "min_groups", "max_events", "max_bytes", "probe_budget"]:
        require(uint(g[k]) and g[k] > 0, "positive_budget:" + k)
    require(type(g["facts"]) is list and 0 < len(g["facts"]) <= 128, "fact_limit")
    require(type(g["sources"]) is dict and 0 < len(g["sources"]) <= 64, "source_limit")
    require(all(ident(k) and ident(v) for k, v in g["sources"].items()), "source_group")
    fact_ids = set()
    for f in g["facts"]:
        fields(f, "id label scope")
        require(ident(f["id"]) and type(f["label"]) is str and type(f["scope"]) is bool, "fact_type")
        require(f["id"] not in fact_ids, "duplicate_fact")
        fact_ids.add(f["id"])
    require(g["center"] in fact_ids and g["target"] in fact_ids, "anchor_missing")
    require(type(g["edges"]) is list and len(g["edges"]) <= 512, "edge_limit")
    edges = set()
    for e in g["edges"]:
        require(type(e) is list and len(e) == 2 and all(x in fact_ids for x in e), "edge_ref")
        require(e[0] != e[1], "self_edge")
        edges.add(tuple(sorted(e)))
    g["edges"] = [list(e) for e in sorted(edges)]
    require(type(g["genes"]) is list and 0 < len(g["genes"]) <= 64, "gene_limit")
    genes = {}
    for gene in g["genes"]:
        fields(gene, "id op input output deps cost")
        require(ident(gene["id"]) and gene["id"] not in genes, "gene_id")
        require(gene["op"] in REGISTRY, "unknown_operator")
        require((gene["input"], gene["output"]) == REGISTRY[gene["op"]], "operator_type")
        require(uint(gene["cost"]) and gene["cost"] > 0, "operator_cost")
        require(type(gene["deps"]) is list and all(ident(d) for d in gene["deps"]), "dependencies")
        gene["deps"] = sorted(set(gene["deps"]))
        genes[gene["id"]] = gene
    for gene in genes.values():
        for d in gene["deps"]:
            require(d in genes, "missing_dependency")
            require(genes[d]["output"] == gene["input"], "dependency_type")
    pending, order = set(genes), []
    while pending:
        ready = sorted(k for k in pending if set(genes[k]["deps"]) <= set(order))
        require(ready, "dependency_cycle")
        order.extend(ready)
        pending.difference_update(ready)
    # This profile links exactly the supported three-stage vertical pipeline.
    require([genes[k]["op"] for k in order] == list(REGISTRY), "unsupported_plan")
    require(genes[order[0]]["deps"] == [] and
            genes[order[1]]["deps"] == [order[0]] and
            genes[order[2]]["deps"] == [order[1]], "pipeline_dependencies")
    g["facts"] = sorted(g["facts"], key=lambda f: f["id"])
    g["genes"] = [genes[k] for k in order]
    manifest = {"genome_digest": digest("Genome", g), "order": order,
                "registry_digest": digest("Registry", {k: list(v) for k,v in REGISTRY.items()}),
                "probe_cost": sum(x["cost"] for x in g["genes"]),
                "canonical_profile": "L2-CANON-1"}
    return g, manifest


class Kernel:
    def __init__(self, genome):
        self.g, self.manifest = compile_genome(genome)
        self.fact_ids = {f["id"] for f in self.g["facts"]}
        self.s = {"clock": 0, "epoch": 0, "target": self.g["target"],
                  "observations": {}, "retracted": [], "tracking": True,
                  "frame_epoch": 0, "label": "Bound; awaiting evidence"}
        self.records, self.snapshots, self.inputs = [], [], {}
        self.initial = self.snapshot()

    def _mutate(self, s, e):
        require(type(e) is dict and ident(e.get("id")), "event_id")
        require(uint(e.get("at")) and e["at"] >= s["clock"], "clock_regression")
        require(type(e.get("label")) is str, "event_label")
        kind = e.get("kind")
        residuals = []
        if kind == "observe":
            fields(e, "id kind at time fact source value quality visibility label")
            require(e["fact"] in self.fact_ids and e["source"] in self.g["sources"], "adapter_binding")
            require(uint(e["time"]) and e["time"] <= e["at"], "observation_time")
            require(e["time"] + self.g["ttl"] <= 2**53-1, "expiry_range")
            require(e["quality"] in ["valid", "invalid"], "quality")
            require(e["visibility"] in ["observed", "occluded", "not_observed"], "visibility")
            require((e["visibility"] == "observed" and type(e["value"]) is bool) or
                    (e["visibility"] != "observed" and e["value"] is None), "observation_value")
            old = [o for o in s["observations"].values()
                   if (o["fact"], o["source"]) == (e["fact"], e["source"])]
            if old and e["time"] < max(o["time"] for o in old):
                residuals.append("LATE_EVIDENCE_RETAINED")
            s["observations"][e["id"]] = copy.deepcopy(e)
        elif kind == "retract":
            fields(e, "id kind at ref label")
            require(e["ref"] in s["observations"], "unknown_retraction")
            s["retracted"] = sorted(set(s["retracted"] + [e["ref"]]))
        elif kind == "target":
            fields(e, "id kind at fact label")
            require(e["fact"] in self.fact_ids, "target_scope")
            s["target"], s["epoch"] = e["fact"], s["epoch"] + 1
        elif kind == "tracking":
            fields(e, "id kind at valid label")
            require(type(e["valid"]) is bool, "tracking_type")
            if s["tracking"] != e["valid"]:
                s["frame_epoch"] += 1
            s["tracking"] = e["valid"]
        elif kind == "tick":
            fields(e, "id kind at label")
        else:
            raise ValueError("unsupported_event")
        s["clock"], s["label"] = e["at"], e["label"]
        return residuals

    def _percept(self, f):
        history = [o for o in self.s["observations"].values() if o["fact"] == f["id"]]
        latest = []
        for source in sorted(self.g["sources"]):
            channel = [o for o in history if o["source"] == source]
            if channel:
                top = max(o["time"] for o in channel)
                # Equal-time conflicting values remain simultaneous constraints.
                latest.extend(o for o in channel if o["time"] == top)
        active = [o for o in latest if o["id"] not in self.s["retracted"] and
                  self.s["clock"] - o["time"] < self.g["ttl"]]
        claims = [o for o in active if o["quality"] == "valid" and o["visibility"] == "observed"]
        values = sorted(set(o["value"] for o in claims))
        groups = sorted(set(self.g["sources"][o["source"]] for o in claims))
        candidates = [] if len(values) > 1 else values if values else [False, True]
        if not f["scope"]:
            status = "OutOfScope"
        elif len(values) > 1:
            status = "Ambiguous"
        elif len(values) == 1 and len(groups) >= self.g["min_groups"]:
            status = "Known"
        elif not claims and any(o["quality"] == "invalid" for o in active):
            status = "Invalid"
        else:
            status = "Unknown"
        visibility = sorted(set(o["visibility"] for o in active))
        return {"id": f["id"], "label": f["label"], "epistemic": status,
                "value": values[0] if status == "Known" else None,
                "candidates": candidates, "facticity": "Derived",
                "visibility": visibility or ["not_observed"],
                "freshness": "fresh" if active else "stale" if history else "none",
                "support_groups": groups, "threshold": self.g["min_groups"],
                "source_refs": sorted(o["id"] for o in claims),
                "active_refs": sorted(o["id"] for o in active),
                "history_refs": sorted(o["id"] for o in history),
                "inactive_reasons": sorted(({"RETRACTED"} if any(o["id"] in self.s["retracted"] for o in latest) else set()) |
                                           ({"EXPIRED"} if any(self.s["clock"]-o["time"] >= self.g["ttl"] for o in latest) else set())),
                "valid_until": min((o["time"]+self.g["ttl"] for o in claims), default=None),
                "contradiction": len(values) > 1}

    def snapshot(self):
        percepts = {f["id"]: self._percept(f) for f in self.g["facts"]}
        scoped = {f["id"] for f in self.g["facts"] if f["scope"]}
        adj = {x: [] for x in percepts}
        for a,b in self.g["edges"]:
            adj[a].append(b)
            adj[b].append(a)
        positive = {k for k,p in percepts.items() if p["epistemic"] == "Known" and p["value"] is True}
        region = set()
        if self.g["center"] in positive:
            q = deque([self.g["center"]])
            while q:
                a = q.popleft()
                if a in region:
                    continue
                region.add(a)
                q.extend(b for b in adj[a] if b in positive and b not in region)
        frontier = sorted({b for a in region for b in adj[a] if b not in region})
        target = self.s["target"]
        distances = {target: 0}
        q = deque([target])
        while q:
            a = q.popleft()
            for b in sorted(adj[a]):
                if b not in distances:
                    distances[b] = distances[a]+1
                    q.append(b)
        choices = []
        for k,p in percepts.items():
            if k not in scoped or p["epistemic"] == "Known":
                continue
            needs = [s for s in sorted(self.g["sources"])
                     if self.g["sources"][s] not in p["support_groups"]]
            if not needs:
                needs = sorted(self.g["sources"])
            for source in needs:
                # Transparent integer heuristic, never advertised as measured IG.
                parts = {"uncertainty": 20, "conflict": 40 if p["contradiction"] else 0,
                         "frontier": 30 if k in frontier else 0,
                         "target": max(0, 25-5*distances.get(k, 128)),
                         "freshness": 10 if p["freshness"] == "stale" else 0}
                choices.append({"fact": k, "source": source, "parts": parts,
                                "score": sum(parts.values()), "cost": self.manifest["probe_cost"]})
        choices.sort(key=lambda x: (-x["score"], x["fact"], x["source"]))
        proposals, selected_facts, spent = [], set(), 0
        for c in choices:
            if c["fact"] not in selected_facts and spent+c["cost"] <= self.g["probe_budget"]:
                proposals.append(c)
                selected_facts.add(c["fact"])
                spent += c["cost"]
        path = []
        if target in region:
            parents, q = {self.g["center"]: None}, deque([self.g["center"]])
            while q:
                a = q.popleft()
                if a == target:
                    break
                for b in sorted(adj[a]):
                    if b in region and b not in parents:
                        parents[b] = a
                        q.append(b)
            x = target
            while x is not None:
                path.append(x)
                x = parents[x]
            path.reverse()
        status = ("REANCHOR" if not self.s["tracking"] else
                  "HOLD" if target not in scoped else
                  "ADVANCE" if path else "PROBE" if proposals else "HOLD")
        nav = {"status": status, "epoch": self.s["epoch"], "target": target,
               "path": path if self.s["tracking"] else [],
               "probes": proposals if self.s["tracking"] and target in scoped else [],
               "budget_used": spent if self.s["tracking"] and target in scoped else 0,
               "meaning": "model_navigation_only"}
        views = []
        for k,p in percepts.items():
            views.append({"id": "view:"+k, "machine_ref": digest("Percept", p),
                          "fact": k, "epistemic": p["epistemic"], "value": p["value"],
                          "facticity": p["facticity"], "source_refs": p["source_refs"],
                          "freshness": p["freshness"], "visibility": p["visibility"],
                          "frame": "machine_graph", "world_registered": False,
                          "frame_epoch": self.s["frame_epoch"],
                          "interaction": ["Inspect", "Replay"],
                          "horizon": "Current" if k in region else "Open",
                          "density_milli": min(1000, len(p["support_groups"])*1000//self.g["min_groups"])
                          if p["epistemic"] == "Known" else 0})
        state = {"profile": PROFILE, "manifest": self.manifest,
                 "clock": self.s["clock"], "epoch": self.s["epoch"],
                 "tracking": self.s["tracking"], "frame_epoch": self.s["frame_epoch"],
                 "percepts": percepts, "region": sorted(region), "frontier": frontier,
                 "edges": self.g["edges"], "navigation": nav, "view": views,
                 "history_digest": digest("ObservationHistory", self.s["observations"]),
                 "retracted": self.s["retracted"]}
        state["state_digest"] = digest("State", state)
        return state

    def step(self, event):
        raw = canon(event)
        require(len(raw) <= self.g["max_bytes"], "event_byte_budget")
        eid = event.get("id") if type(event) is dict else None
        require(ident(eid), "event_id")
        if eid in self.inputs:
            require(self.inputs[eid] == event, "event_id_collision")
            return self.snapshot()  # exact duplicate is transport-idempotent
        require(len(self.records) < self.g["max_events"], "event_count_budget")
        pre = self.snapshot()["state_digest"]
        next_state = copy.deepcopy(self.s)
        try:
            residuals = self._mutate(next_state, event)
            self.s = next_state
            outcome = "COMMITTED"
        except (ValueError, TypeError, KeyError) as err:
            residuals = [str(err) if isinstance(err, ValueError) else "record_type"]
            outcome = "REJECTED"
        snap = self.snapshot()
        record = {"index": len(self.records), "input": copy.deepcopy(event),
                  "pre": pre, "post": snap["state_digest"], "outcome": outcome,
                  "residuals": residuals,
                  "parent": self.records[-1]["digest"] if self.records else digest("Run", self.manifest)}
        record["digest"] = digest("Trace", record)
        self.records.append(record)
        self.snapshots.append(snap)
        self.inputs[eid] = copy.deepcopy(event)
        return snap

    def bundle(self):
        b = {"profile": PROFILE, "genome": self.g, "manifest": self.manifest,
             "initial": self.initial, "records": self.records, "snapshots": self.snapshots}
        b["bundle_digest"] = digest("Bundle", b)
        return copy.deepcopy(b)


def replay(bundle):
    fields(bundle, "profile genome manifest initial records snapshots bundle_digest")
    require(bundle["profile"] == PROFILE, "replay_profile")
    expected = {k:v for k,v in bundle.items() if k != "bundle_digest"}
    require(digest("Bundle", expected) == bundle["bundle_digest"], "bundle_digest_mismatch")
    k = Kernel(bundle["genome"])
    for rec in bundle["records"]:
        k.step(rec["input"])
    require(k.bundle() == bundle, "replay_semantic_mismatch")
    return {"verified": True, "records": len(k.records),
            "bundle_digest": bundle["bundle_digest"],
            "state_digest": k.snapshot()["state_digest"]}


def render(bundle, output):
    replay(bundle)
    template = Path(__file__).with_name("viewer_template.html").read_text(encoding="utf-8")
    # Escape '<' so user labels cannot terminate the embedded JSON script element.
    data = json.dumps(bundle, ensure_ascii=True).replace("<", "\\u003c")
    Path(output).write_text(template.replace("__BUNDLE_DATA__", data), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="cmd", required=True)
    run = sub.add_parser("run")
    run.add_argument("--genome", required=True)
    run.add_argument("--events", required=True)
    run.add_argument("--out", required=True)
    run.add_argument("--view")
    verify = sub.add_parser("replay")
    verify.add_argument("bundle")
    args = parser.parse_args()
    if args.cmd == "replay":
        print(json.dumps(replay(loads(Path(args.bundle).read_text())), indent=2))
        return
    kernel = Kernel(loads(Path(args.genome).read_text()))
    with Path(args.events).open(encoding="utf-8") as events:
        for line in events:
            if line.strip():
                require(len(line.encode("utf-8")) <= kernel.g["max_bytes"], "line_byte_budget")
                kernel.step(loads(line))
    bundle = kernel.bundle()
    Path(args.out).write_text(json.dumps(bundle, indent=2), encoding="utf-8")
    if args.view:
        render(bundle, args.view)
    print(json.dumps(replay(bundle), indent=2))


if __name__ == "__main__":
    main()
