# GRFPS — 2nd-Layer Synthetic Perception OS, 0.4.0

Version 0.4.0 ergänzt bezeugte lokale Kartenstücke. Zwei Messfenster werden nur bei mindestens zwei gemeinsamen Landmarken und einer eindeutigen kompatiblen Transformation verbunden. Rücknahme, Ablauf und Framewechsel entziehen abhängigen Anschlüssen ihre Gültigkeit. Gegenbelege bleiben sichtbar.

## Kartenphase starten

**GRFPS_Second_Layer_Demo.html** direkt öffnen: 23 Zustände eines vollständig geprüften Laufs, ohne Server. Der Zeitschieber zeigt Anschlüsse, Konflikte, getrennte Komponenten und offene Randpunkte.

Für neue echte Messprozesse: Python 3.10+; keine Zusatzpakete. Im entpackten Verzeichnis:

~~~sh
python run_map_demo.py --out mein_kartenlauf
python map_runtime.py mein_kartenlauf/map.jsonl --html mein_atlas.html
python validate.py
~~~

Der Ausgabeordner darf noch nicht existieren. Der Harness verwendet eine eigene synthetische Welt, führt acht feste Sensorprozesse aus und archiviert alle tatsächlich benutzten Weltfassungen. Die Zeitachse ist logisch und kein Latenzbenchmark. Der Mapper selbst erhält lokale Punkte und Beziehungen, keine verborgenen Weltposen.

## Vertrag der Kartenstufe

- Ganzzahlige 2D-Punkte, Vierteldrehungen und Translationen; Landmarken-IDs werden vom Sensor vorgegeben.
- Auftragsgebundene Patches mit Quelle, Frame, Abtastzeit, TTL, Beziehungen und offenen Rändern.
- Mindestens zwei gemeinsame Punkte; alle gemeinsamen Punkte müssen exakt passen. Keine Spiegelung, kein numerisches Fitting.
- Gemeinsame Beziehungen dürfen nicht widersprechen. Konflikte können nicht über andere Patches umgangen werden; inkonsistente Komponenten werden konservativ getrennt.
- Fehlende Beobachtung ist kein false. Gleichzeitige gegensätzliche Aussagen ergeben Ambiguous.
- Ein offener Auftrag; Kosten bei Annahme. Standard: 16 Aufträge, 512 Ereignisse, 32 archivierte Patches; kein unbegrenzter Dauerbetrieb.
- Append-first Journal mit fsync, semantischem Vollreplay und Schreibfehlersperre. Das Atlasprofil repariert keine unvollständigen Journale und unterstützt noch keinen Wiederanlauf.

Der neue Fensteradapter ist ein getrenntes typisiertes Aufnahmeprofil. Er ist noch nicht an den Scheduler der Organruntime angeschlossen. Die Kartenansicht ist ein Offline-Replay; `start.py` startet weiterhin das kompatible Organ-Cockpit.

## Nachweis dieser Phase

22 Übergänge, acht tatsächliche Messprozesse. Zwei kompatible Fenster verbinden sich; ein drittes bleibt getrennt. Rücknahme entfernt den Anschluss, ein Gegenbeleg verhindert ihn, konsistenter Ersatz stellt ihn wieder her. TTL und Framewechsel entfernen ihn erneut. Eine Antwort aus dem alten Frame wird unterdrückt.

Nach drei Messungen: vier richtige positive Beziehungen, keine falsche positive Beziehung, keine fehlende positive Beziehung in der kleinen Fixture. Der absichtlich fehlerhafte deklarierte Kontrollgraph hat zwei zusätzliche falsche Kanten. Dies ist ein Konformitätsbeispiel, kein allgemeiner Mapping-Leistungsvergleich.

Prüfumfang: **119 Python-Tests und 36 JavaScript-Prüfungen**. Dazu vollständige Replays, archivierte Sample-Provenienz, Neuberechnung der Kontrollmetriken und die erhaltenen 36 Organversuche. JavaScript wurde mit minimalem DOM getestet; eine visuelle Browserprüfung war nicht verfügbar.

| Datei | Zweck |
|---|---|
| mapping.py | Patchvertrag, Zustandsmaschine, Overlap, Konsistenz, Atlas |
| map_worker.py | Fester lesender Fenster-Sensorprozess |
| map_runtime.py | Adapter, Journal, Replay und HTML-Export |
| run_map_demo.py | Reproduzierbarer Versuch mit eigenen Fixtures |
| mapping_run/ | Protokoll, Journal, Report, archivierte Samples |
| test_mapping.py / test_map_viewer.cjs | Neue Vertrags- und Ansichtsprüfungen |
| GRFPS_2nd_Layer_OS.tex / .pdf | Vollständiger Monolith einschließlich dieser Phase |

Nächste Phase: Kartenlücken an den Organ-Scheduler binden, budgetierte Folgeaufnahmen auslösen und neue Kartenstände live projizieren. Kontinuierliches SLAM, automatische Landmarkenerkennung, empirische Sensorunsicherheit und XR-Registrierung sind weiterhin offen.

## Erhaltene Organruntime 0.3.0

Voraussetzung: Python 3.10 oder neuer; getestet mit Python 3.12 unter Linux. Keine zusätzlichen Python-Pakete. Für die Live-Ansicht einen aktuellen Browser mit Fetch und AbortSignal.timeout verwenden.

ZIP entpacken, Terminal im entpackten Ordner öffnen:

~~~sh
python start.py
~~~

Das Programm erstellt ein eigenes Testfeld, startet die Organruntime und öffnet das lokale Cockpit. Unter Windows kann „py“ anstelle von „python“ verwendet werden. Falls das automatische Browseröffnen scheitert, die im Terminal ausgegebene Adresse öffnen.

Die Standardlaufzeit beträgt höchstens 30 Sekunden. Danach schließt die lokale Runtime und erzeugt eine Offlineansicht im jeweiligen Unterordner von organ_runs. Ohne automatisches Browseröffnen:

~~~sh
python start.py --duration 30 --no-browser
~~~

**organ_demo.html** lässt sich direkt öffnen. Diese mitgelieferte Aufzeichnung benötigt weder Python noch einen Server. Der Zeitschieber wählt einzelne Übergänge; ein Sektorknoten zeigt Aussage, Gültigkeit, Exposition und Quellenbeleg.

## Was die zwei Organe messen

| Organ | Frage | Beobachtungsgrenze |
|---|---|---|
| Freie Sicht / ray_clear | Enthält der endliche radiale Sektor irgendein Hindernis? | Ein Hindernis belegt false; vollständig freier Sektor belegt true. |
| Signalpräsenz / beacon_present | Existiert ein Beacon irgendwo im endlichen Sektor? | Die Messung reicht bis einschließlich des ersten Hindernisses. Ein verdeckter Rest kann Unknown erzeugen. |

Die Standardwelt besitzt acht Sektoren mit je vier Zellen. Jede Zelle trägt die booleschen Merkmale solid und beacon. Ein Beacon auf einer Hinderniszelle gilt als sichtbar. Ein Beacon dahinter bleibt verborgen. Wenn der sichtbare Präfix keinen Beacon enthält und ein Rest verdeckt ist, wird keine negative Gesamtaussage erfunden.

Jede Kombination aus Organ und Sektor ist ein eigener Fact. Der Richtungswechsel ändert die abgefragte Frage; er benennt keine vorhandene Evidenz um. Der fortlaufende Schrittzähler verfolgt positive zyklische Richtungswechsel. Das ist ein diskretes Instrumentenmodell, keine physische Rotation oder 720-Grad-Spinorimplementierung.

## Lebenszyklus und Messautomat

Der Lebenszyklus entspricht der Rollenfolge aus Anhang H.2 der Ausgangsschrift:

TEMPLATE → INSTANTIATED → CALIBRATED → ACTIVE → QUIESCENT → RETIRED

Die implementierte Kalibrierung prüft den Vertrag des idealen Feldmodells: Operatorversion, Sektorzahl, Apertur, Frame und Zeiteinheit. Sie ersetzt keine empirische Sensorkalibrierung. Pause und Trackingverlust bewahren die Organidentität in QUIESCENT. Geordneter Stop erzeugt RETIRED.

Innerhalb der aktiven Bindung gibt es getrennte Messphasen:

| Übergang | Wirkung |
|---|---|
| READY → EXPOSING | Gewählten Sektor und Expositionswitness binden. |
| EXPOSING → WAITING | Request ausstellen und Kosten genau einmal verbrauchen. |
| WAITING → INTEGRATING | Passende Antwort aufnehmen; noch keine neue operative Evidenz. |
| INTEGRATING → COOLDOWN | Verwertbares oder überholtes Ergebnis verarbeiten. |
| INTEGRATING → FAULT | Fehler oder Timeout explizit verarbeiten. |
| COOLDOWN / FAULT → READY | Nach Wartefrist ausdrücklich freigeben beziehungsweise reaktivieren. |

Ein Receipt bindet Request-ID und Expositionsdigest. Ziel- und Frameepochen werden bei Integration erneut geprüft. Ein inzwischen überholtes Ergebnis bleibt als SUPERSEDED im Journal, erzeugt aber keine neue Beobachtung.

## Laufsteuerung und Budget

~~~sh
python organ_runtime.py watch --world field.json --out run_journal --budget 32 --duration 30 --open
python organ_runtime.py replay run_journal --html replay.html
python organ_runtime.py watch --out run_journal --resume --budget 64 --duration 30
~~~

Das Testfeldformat zeigt organ_evidence_run/field.json. Ein neuer Journalordner darf noch nicht existieren. Die Adresse bindet ausschließlich an 127.0.0.1; mit --port kann ein bestimmter lokaler Port gewählt werden.

**--budget gibt das absolute Gesamtlimit an.** Resume setzt den Verbrauch nicht zurück. Ein Limit unter bereits verbrauchten Kosten wird abgewiesen. Auch Timeout und SUPERSEDED behalten ihre verbrauchten Kosten. Eine bereits angenommene Messung wird durch eine zulässige Budgetänderung nicht nachträglich ungebunden.

Im Cockpit kann das Limit um 16 Einheiten erhöht werden. Eine HTTP-Bestätigung bedeutet zunächst Einreihung; erst der Commit ändert das Budget. Bei ausgeschöpftem Budget laufen Ticks und Evidenzverfall weiter. Das Messbudget enthält abstrakte Einheiten, keine gemessene CPU-Zeit oder physische Energie.

Resume prüft die komplette Segmentfolge, lässt bisherige Evidenz konservativ verfallen, gibt offene Requests auf und kalibriert die bestehenden Organidentitäten erneut. Der ursprünglich gebundene Weltpfad bleibt bestehen; Pfade oder neue Konfigurationen können nicht gleichzeitig ersetzt werden. Für einen unabhängigen neuen Lauf einen neuen Journalordner verwenden.

## Defaults und Grenzen

| Größe | Standard |
|---|---|
| Organe / Sektoren | 2 / 8 |
| Messpolitik | coverage |
| Messkosten / Anfangsbudget | 1 / 32 |
| TTL / Timeout / Cooldown | 2000 / 500 / 50 ms |
| Nominelle Zykluspause | 40 ms, zuzüglich Bearbeitungszeit |
| Aktive Messfolgen | höchstens 1 |
| Steuerqueue / Delta-Ring | 16 / 64 |
| Segmentgröße | 64 Übergänge |
| Obergrenzen | 1024 Segmente und 10000 Sessionübergänge |
| Standardlaufzeit | höchstens 30 Sekunden |

Die zuerst erreichte Laufgrenze löst einen geordneten Stop aus. Ein laufender Messprozess verzögert Steuerung bis zur Antwort oder zum Timeout. Es gibt keine harte Echtzeitgarantie. Der Worker ist zeitlich überwacht, aber nicht durch eine OS-Sandbox isoliert.

Der Dienst führt ausschließlich die zwei fest gebundenen Messoperatoren aus. HTTP kann keine Programme, Weltwerte oder Beobachtungen einschleusen. Host- und Origin-Prüfungen begrenzen fremde Browseraufrufe; der lokale Dienst ist kein authentisierter Mehrbenutzerdienst. Pro Journalordner ist genau ein Writer vorgesehen.

Pfade und Kennungen unterliegen weiterhin dem ASCII-Kanonisierungsprofil. Die Ring- und Querbeziehungen der Modellkarte sind vorgegeben. Kartographische Rekonstruktion, dynamisches Laden weiterer Organe, kontinuierliche Rotorfaser, räumliche Kalibrierung, Multiskaligkeit und XR sind weitere Stufen.

## Segmentiertes Gedächtnis

Jeder neue Segmentheader bindet globale Sequenz, Zustand, Konfiguration und Vorgängerkopf. Rotation erhält Evidenz, Organidentität und Budget. Sie erzeugt keinen semantischen Neustart.

Ein Übergang wird berechnet, geschrieben, geflusht und mit fsync bestätigt, bevor der Kandidat als aktueller Zustand veröffentlicht wird. Replay prüft Header, vollständige Records, Hashverkettung und die erneute Ausführung aller Übergänge. Ein vollständig korrupter Record wird abgewiesen.

Beim expliziten Resume wird ein unvollständiges letztes Fragment unverändert als .torn gesichert. Auch ein abgerissener Header eines neuen Segments kann so vom geprüften Vorgänger aus wiederhergestellt werden. Vorhandene Fragmentdateien werden nicht überschrieben. Normales Replay repariert keine Fragmente.

Der OrganKernel archiviert nicht zusätzlich jeden historischen inneren Renderzustand. Ein Vergleich über 120 Ereignisse bestätigt dieselben Zustände und Tracedigests wie beim vollständigen Interpreter. Beobachtungen und Traces wachsen weiterhin; Rotation erzeugt weder konstanten Speicherverbrauch noch konstante Replaykosten. Checkpoints werden durch vollständiges Replay überprüft und sind noch kein vertrauenswürdiger Schnellstart.

## Vergleich unter gleichem Budget

Vorab festgelegt: zwölf statische Testwelten, drei Politiken, je 16 Messungen zu je einer Einheit; insgesamt 36 Läufe und 576 Messungen.

| Politik | Verschiedene angefragte Fragen, Mittel von 16 | Bestimmte Fragen, Mittel von 16 | Falsche Known / Known gesamt |
|---|---:|---:|---:|
| fixed: stets Sektor 0 | 2,00 | 1,83 | 0 / 22 |
| uniform: gleichverteilte Pseudozufallswahl | 10,00 | 8,67 | 0 / 104 |
| coverage: ältester beziehungsweise unbesuchter Sektor | 16,00 | 13,67 | 0 / 164 |

Alle Läufe sind replaybar. Die Zahlen unterscheiden ausdrücklich zwischen angefragten und bestimmten Fragen: Eine verdeckte Frage bleibt Unknown.

Die feste Richtung ist eine Ablation der Expositionswahl; uniform ist eine einfache Vergleichspolitik. Systematische Abdeckung ist in dieser statischen endlichen Aufgabe erwartbar effizient. Der Versuch belegt diesen konkreten Unterschied, keine allgemeine Überlegenheit gegenüber aktiver Inferenz oder optimierten Sensorsystemen. Messfunktion und Evaluator gehören demselben idealen Modell an. Ein unabhängiger Realweltbenchmark und eine Laufzeitmessung sind nicht enthalten.

Protokoll, alle Welten, Journale und Einzelfallergebnisse liegen in benchmark_run. Einen neuen Versuch erzeugen:

~~~sh
python benchmark_organs.py --out new_benchmark
~~~

## Integrationsnachweis

Der aufgezeichnete Lauf umfasst 55 reale Messprozessaufrufe, 474 Übergänge, 15 Journalabschnitte und 354 über HTTP verglichene Projektionen. Das Umfeld dieser Prozesse bleibt synthetisch.

Er enthält Feldänderung und Wiederherstellung, eine verdeckte Beaconfrage, Pause bis zum Evidenzverfall, Wiedererfassung, Epochenwechsel während eines offenen Requests, einen absichtlich blockierten Prozess, Recovery, Budgetstopp und Budgeterweiterung.

Das Harness verändert ausschließlich sein eigenes Testfeld. Die normale Runtime liest es. Die Zeitwerte des Berichts sind Laufzeitpunkte dieser Ausführung; Mutationszeitpunkte und Publikationslatenzen wurden nicht separat als Latenzbenchmark erfasst.

~~~sh
python run_organ_demo.py --out new_integration
~~~

Beide Versuchsskripte verlangen bisher nicht vorhandene Ausgabeordner. Für aktive Journale einen lokalen Ordner verwenden, dessen Dateien kein zweiter Prozess überschreibt. Die mitgelieferten absoluten Pfade dokumentieren die ursprüngliche Bindung; Replay liest diese Weltpfade nicht erneut. Neue Ausführungen besitzen andere Messzeiten und Digests.

## Verifikation

~~~sh
python validate.py
~~~

Die Releaseprüfung führt 119 Python-Tests aus: 34 Kern-, 27 Dateisession-, 36 Organ- und 22 Kartenprüfungen. Sie prüft die beiden Integrationsjournale, alle 36 Vergleichsläufe samt Messwerten sowie einen tatsächlichen CLI-Start mit Stop, Resume und Replay.

Bei vorhandenem Node.js werden außerdem 36 Prüfungen der vier Ansichtslogiken ausgeführt; andernfalls wird das ausdrücklich als übersprungen ausgewiesen. validation.json und validation.log enthalten die Ergebnisse. Die JavaScript-Prüfungen verwenden eine minimale DOM-Umgebung. Eine visuelle Prüfung in einem echten Browser war hier nicht verfügbar.

## Frühere Dateiwahrnehmung

~~~sh
python start_files.py
python start_files.py "/PFAD/datei_a.txt" "/PFAD/datei_b.txt"
python live.py watch --journal file_run.jsonl --duration 60 "/PFAD/datei.txt"
python live.py replay file_run.jsonl --html file_replay.html
~~~

Dieses Profil fragt reale lokale Dateimetadaten ab. Ohne Pfadargument benötigt start_files.py eine verfügbare Tk-Dateiauswahl. closed_loop_demo.html zeigt seinen aufgezeichneten Integrationslauf. legacy_demo.html enthält die ursprüngliche konstruierte Mehrquellenwelt.

## Erhaltene Quelldateien

| Datei | Rolle |
|---|---|
| organs.py | Organlebenszyklus, Messautomat, Exposition und Budget |
| field_world.py | endliches Weltmodell, Generator, Messung und Evaluator |
| field_worker.py / field_adapter.py | feste Prozessmessung und Überwachung |
| segments.py | segmentierte Lineage, Recovery, Checkpointprüfung |
| organ_runtime.py / organ_viewer.html | Dienst, HTTP, CLI und Second Layer |
| run_organ_demo.py / benchmark_organs.py | Integration und Expositionsvergleich |
| grfps_l2.py / session.py / journal.py / live.py | kompatible frühere Kern- und Dateiprofile |
| test_*.py / test_*.cjs / validate.py | Vertragstests und Releaseprüfung |
| GRFPS_2nd_Layer_OS.pdf / .tex | vollständiger Systemvertrag und eigenständige LaTeX-Quelle |

