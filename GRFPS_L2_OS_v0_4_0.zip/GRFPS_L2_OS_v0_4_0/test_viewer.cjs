/* Integration smoke test in a minimal DOM.
 * This does not replace a real-browser layout or accessibility review.
 * Usage: node test_viewer.cjs
 */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname,'legacy_demo.html'),'utf8');
const data = html.match(/<script id="data" type="application\/json">([\s\S]*?)<\/script>/)[1];
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
const code = scripts.at(-1)[1];
class El {
  constructor(tag='div'){this.tag=tag;this.children=[];this.style={};this.attrs={};this._text='';}
  set textContent(v){this._text=String(v);this.children=[];}
  get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}
  append(...items){this.children.push(...items);}
  replaceChildren(...items){this._text='';this.children=[...items];}
  setAttribute(k,v){this.attrs[k]=String(v);}
  click(){if(this.onclick)this.onclick();}
}
const els = new Map();
const document = {
  getElementById(id){if(!els.has(id))els.set(id,new El());return els.get(id);},
  createElement(tag){return new El(tag);},
  createElementNS(ns,tag){return new El(tag);}
};
document.getElementById('data').textContent=data;
let interval;
const context=vm.createContext({document,console,Blob,URL,setTimeout,
  setInterval(fn){interval=fn;return 1;},clearInterval(){interval=null;}});
vm.runInContext(code,context,{filename:'viewer-script.js'});
const el=id=>document.getElementById(id);
const at=n=>el('timeline').oninput({target:{value:String(n)}});
const result=[];
function check(name,fn){fn();result.push({name,passed:true});}
check('initial_unknown_map',()=>{
  assert.equal(el('known').textContent,'0 / 5');
  assert.equal(el('facts').children.length,6);
});
check('conflict_snapshot',()=>{
  at(7);
  const b=el('facts').children.find(x=>x.textContent.startsWith('Database'));
  b.click();
  assert(el('detail').textContent.includes('Ambiguous'));
  assert(el('sources').textContent.includes('sensor_a'));
  assert(el('sources').textContent.includes('sensor_b'));
});
check('resolved_snapshot',()=>{
  at(11);
  assert.equal(el('navStatus').textContent,'ADVANCE');
  assert(el('detail').textContent.includes('Known'));
});
check('tracking_loss',()=>{
  at(13);
  assert.equal(el('navStatus').textContent,'REANCHOR');
  assert(el('proposals').textContent.includes('Framebindung'));
});
check('expiry_map',()=>{
  at(16);
  assert.equal(el('region').textContent,'0');
  assert.equal(el('known').textContent,'0 / 5');
});
check('reacquired_map',()=>{
  at(20);
  assert.equal(el('navStatus').textContent,'ADVANCE');
  assert.equal(el('region').textContent,'2');
});
check('previous_next_controls',()=>{
  el('prev').click();
  assert(el('stepLabel').textContent.startsWith('Puls 19'));
  el('next').click();
  assert(el('stepLabel').textContent.startsWith('Puls 20'));
});
check('playback_restarts_and_advances',()=>{
  el('play').click();
  assert(interval);
  interval();
  assert(el('stepLabel').textContent.startsWith('Puls 1'));
  el('play').click();
  assert.equal(interval,null);
});
console.log(JSON.stringify({environment:'minimal DOM / Node.js',checks:result,
  real_browser_layout_tested:false},null,2));
