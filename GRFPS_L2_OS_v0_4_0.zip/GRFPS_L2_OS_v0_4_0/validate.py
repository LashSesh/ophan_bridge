"""Reexecute release contracts, recorded experiments, and actual CLI restart."""
from pathlib import Path
import io
import json
import platform
import shutil
import subprocess
import sys
import tempfile
import unittest
from grfps_l2 import digest
from journal import recover,verify_checkpoint
from live import export_replay as export_files
from segments import recover_segments,verify_segment_checkpoint
from organ_runtime import export_replay
from field_world import truth
from organs import fact_id

ROOT=Path(__file__).resolve().parent


def main():
    report={"version":"0.4.0","python":platform.python_version(),"platform":platform.system(),
            "visual_browser_review":False}
    log=[];passed=False
    def run(args):
        r=subprocess.run(args,cwd=ROOT,capture_output=True,text=True,encoding="utf-8",
                         errors="replace",timeout=90)
        log.extend(["COMMAND "+repr(args),r.stdout,r.stderr])
        if r.returncode:raise RuntimeError("Command failed: "+repr(args))
        return r.stdout
    try:
        stream=io.StringIO()
        suite=unittest.defaultTestLoader.discover(str(ROOT),pattern="test_*.py")
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
        log.append(stream.getvalue())
        report["python_tests"]={"run":result.testsRun,"failures":len(result.failures),
            "errors":len(result.errors),"skipped":len(result.skipped)}
        if not result.wasSuccessful():raise RuntimeError("Contract tests failed")
        run([sys.executable,"build_demo.py"])
        filejournal=ROOT/"evidence_run/session.jsonl"
        fileproof=export_files(filejournal,ROOT/"closed_loop_demo.html")
        verify_checkpoint(filejournal,filejournal.with_name(filejournal.name+".checkpoint.json"))
        report["file_profile_replay"]=fileproof
        organjournal=ROOT/"organ_evidence_run/journal"
        proof=export_replay(organjournal,ROOT/"organ_demo.html")
        verify_segment_checkpoint(organjournal)
        original=json.loads((ROOT/"organ_evidence_run/integration_report.json").read_text())
        for k in ["transitions","requests","segments","state_digest","head"]:
            if proof[k]!=original[k]:raise RuntimeError("Organ evidence mismatch: "+k)
        report["organ_integration"]={**proof,"checkpoint_verified":True,
            "original_http_projection_checks":original["http_projection_checks"],
            "note":"Reexecution of recorded inputs; original process/HTTP integration is not repeated."}
        bench=ROOT/"benchmark_run"
        protocol=json.loads((bench/"protocol.json").read_text())
        br=json.loads((bench/"benchmark_report.json").read_text())
        if br["protocol_digest"]!=digest("BenchmarkProtocol",protocol):
            raise RuntimeError("Benchmark protocol mismatch")
        for row in br["cases"]:
            directory=bench/f"{row['world_seed']:02d}-{row['policy']}"
            r=recover_segments(directory);m=r["machine"];state=m.snapshot()
            if state["state_digest"]!=row["state_digest"] or r["head"]!=row["head"]:
                raise RuntimeError("Benchmark replay mismatch")
            world=json.loads((bench/f"world-{row['world_seed']:02d}.json").read_text())
            known=wrong=0
            for o in m.config["organs"]:
                for s in range(m.config["sectors"]):
                    p=state["kernel"]["percepts"][fact_id(o["id"],s)]
                    if p["epistemic"]=="Known":
                        known+=1;wrong+=p["value"]!=truth(world,o["query"],s)
            if (known!=row["known_questions"] or wrong!=row["false_known_count"]
                    or len(m.attempts)!=row["distinct_questions"] or m.spent!=16):
                raise RuntimeError("Benchmark metric mismatch")
        report["benchmark"]={"replayed_runs":len(br["cases"]),"measurements":br["measurements"],
                            "aggregate":br["aggregate"],"protocol_digest":br["protocol_digest"]}
        from map_runtime import export as export_map, replay as replay_map
        from mapping import hashof
        from map_worker import sample as sample_map
        from run_map_demo import metrics
        mapping_dir=ROOT/"mapping_run"
        mp=export_map(mapping_dir/"map.jsonl",ROOT/"GRFPS_Second_Layer_Demo.html")
        mr=json.loads((mapping_dir/"mapping_report.json").read_text())
        for k in ["transitions","spent","head","state_digest"]:
            if mp[k]!=mr[k]:raise RuntimeError("Map replay mismatch")
        rr=replay_map(mapping_dir/"map.jsonl")
        for before,event in zip(rr["views"],rr["events"]):
            if event["kind"]=="patch":
                fixture=json.loads((mapping_dir/"samples"/(event["patch"]["sample_ref"]+".json")).read_text())
                if sample_map(fixture,before["pending"],event["patch"]["sampled_at"])!=event["patch"]:
                    raise RuntimeError("Map sample provenance mismatch")
        protocol=json.loads((mapping_dir/"protocol.json").read_text())
        if hashof("Protocol",protocol)!=mr["protocol_digest"]:raise RuntimeError("Map protocol mismatch")
        baseline=rr["views"][6]
        initial=json.loads((mapping_dir/"world_initial.json").read_text())
        map_truth=[e[:2] for e in initial["relations"] if e[2]]
        predicted=[[e["a"],e["b"]] for e in baseline["atlas"]["relations"] if e["status"]=="Known" and e["value"]]
        expected=dict(declared=metrics(protocol["declared"],map_truth),measured=metrics(predicted,map_truth),budget_spent=baseline["spent"])
        if expected!=mr["comparison"]:raise RuntimeError("Map metrics mismatch")
        report["mapping"]={**mp,"comparison":expected,"sample_provenance_verified":True}
        if shutil.which("node"):
            report["javascript"]={name:json.loads(run(["node",filename])) for name,filename in [
                ("legacy","test_viewer.cjs"),("files","test_live_viewer.cjs"),
                ("organs","test_organ_viewer.cjs"),("mapping","test_map_viewer.cjs")]}
        else:report["javascript"]={"status":"SKIPPED","reason":"Node.js unavailable"}
        with tempfile.TemporaryDirectory(prefix="grfps_organ_cli_") as tmp:
            field=Path(tmp)/"field.json";shutil.copyfile(ROOT/"organ_evidence_run/field.json",field)
            directory=Path(tmp)/"journal"
            run([sys.executable,"organ_runtime.py","watch","--world",str(field),
                 "--out",str(directory),"--duration","0.6","--budget","4"])
            first=recover_segments(directory);seq=first["machine"].seq;spent=first["machine"].spent
            if first["machine"].phase!="STOPPED":raise RuntimeError("First CLI stop absent")
            run([sys.executable,"organ_runtime.py","watch","--out",str(directory),
                 "--resume","--duration","0.6","--budget","6"])
            second=recover_segments(directory,collect_views=True)
            state=second["views"][seq]
            if second["records"][seq]["event"]["kind"]!="resume":
                raise RuntimeError("Resume event absent")
            if any(p["active_refs"] for p in state["kernel"]["percepts"].values()):
                raise RuntimeError("Resume retained old evidence")
            if state["budget"]["spent"]!=spent:
                raise RuntimeError("Resume reset spent budget")
            if second["machine"].phase!="STOPPED":raise RuntimeError("Second CLI stop absent")
            cli=json.loads(run([sys.executable,"organ_runtime.py","replay",str(directory)]))
            if cli["state_digest"]!=second["machine"].snapshot()["state_digest"]:
                raise RuntimeError("CLI replay mismatch")
            verify_segment_checkpoint(directory)
            report["cli_restart"]={"passed":True,"first_transitions":seq,
                "final_transitions":second["machine"].seq,"preserved_spent_budget":spent,
                "old_evidence_expired":True,"checkpoint_verified":True}
        passed=True
    except Exception as err:
        report["error"]=type(err).__name__+": "+str(err);log.append(report["error"])
    finally:
        report["passed"]=passed
        (ROOT/"validation.json").write_text(json.dumps(report,indent=2)+"\n")
        (ROOT/"validation.log").write_text("\n".join(log))
        print(json.dumps(report,indent=2))
    if not passed:raise SystemExit(1)


if __name__=="__main__":
    main()
