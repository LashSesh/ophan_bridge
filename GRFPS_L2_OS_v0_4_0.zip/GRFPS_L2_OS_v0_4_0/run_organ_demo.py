"""Actual subprocess/HTTP integration in a controlled synthetic radial field."""
import argparse
import json
import sys
import threading
import time
from pathlib import Path
from urllib.request import Request,urlopen
from organs import field_config, WORLD_PROFILE
from segments import SegmentEngine,recover_segments,verify_segment_checkpoint
from adapters import MonotonicClock
from field_adapter import FieldRunner
from organ_runtime import OrganService,server_for,viewer_html,export_replay
from session import apply_view_delta


def run_demo(output):
    out=Path(output);out.mkdir(parents=True,exist_ok=False)
    world={"profile":WORLD_PROFILE,"sectors":8,"depth":4,
           "cells":[[{"solid":False,"beacon":False} for _ in range(4)] for _ in range(8)]}
    world["cells"][2][1]["beacon"]=True
    world["cells"][4][0]["solid"]=True
    world["cells"][4][3]["beacon"]=True
    world_path=out/"field.json"
    def write_world():
        temp=world_path.with_suffix(".tmp")
        temp.write_text(json.dumps(world,indent=2))
        temp.replace(world_path)
    write_world()
    c=field_config(world_path,budget=80,ttl_ms=3000,timeout_ms=200,cooldown_ms=0,
                   segment_records=32)
    (out/"config.json").write_text(json.dumps(c,indent=2))
    e=SegmentEngine.create(out/"journal",c);clock=MonotonicClock()
    service=OrganService(e,clock)
    server=server_for(service,0,viewer_html)
    network=threading.Thread(target=server.serve_forever,daemon=True);network.start()
    base=f"http://127.0.0.1:{server.server_port}"
    projection=None;checks=0;phases=[]
    def project():
        nonlocal projection,checks
        q="" if projection is None else f"?cursor={projection['sequence']}&digest={projection['state_digest']}"
        with urlopen(base+"/api/updates"+q,timeout=5) as response:data=json.load(response)
        if data["kind"]=="reset":projection=data["snapshot"]
        else:
            for delta in data["deltas"]:projection=apply_view_delta(projection,delta)
        assert projection==service.current
        checks+=1
    def control(command):
        request=Request(base+"/api/control",data=json.dumps(command).encode(),
                        headers={"Content-Type":"application/json","Origin":base},method="POST")
        with urlopen(request,timeout=5) as response:assert response.status==202
    def until(predicate,timeout=25,nap=.001):
        deadline=time.monotonic()+timeout
        while not predicate():
            assert time.monotonic()<deadline,"Integration condition timed out"
            assert service.cycle(),"Unexpected stop"
            project()
            if nap:time.sleep(nap)
    def settled():
        return not any(o["state"] in ["EXPOSING","WAITING","INTEGRATING"] for o in e.machine.organs.values())
    def completed_count():return len(e.machine.completed)
    def last_result():
        return list(e.machine.completed.values())[-1] if e.machine.completed else None
    def mark(name):
        s=service.current
        phases.append({"phase":name,"sequence":s["sequence"],"clock_ms":s["clock"],
            "requests":s["request_count"],"budget":s["budget"],
            "known":sum(o["percept"]["epistemic"]=="Known" for o in s["objects"].values()),
            "clearance_s0":s["objects"]["clearance.s0"]["percept"]["value"],
            "beacon_s4":s["objects"]["beacon.s4"]["percept"]["epistemic"],
            "organ_states":{k:{"lifecycle":v["lifecycle"],"state":v["state"]} for k,v in s["organs"].items()},
            "last_result":last_result()})
    try:
        until(lambda:completed_count()>=16 and settled())
        assert service.current["objects"]["beacon.s4"]["percept"]["epistemic"]=="Unknown"
        assert "occluded" in service.current["objects"]["beacon.s4"]["percept"]["visibility"]
        mark("both_organs_complete_first_exposure_cycle")
        world["cells"][0][0]["solid"]=True;write_world()
        until(lambda:service.current["objects"]["clearance.s0"]["percept"]["value"] is False and settled())
        mark("external_field_change_detected")
        world["cells"][0][0]["solid"]=False;write_world()
        until(lambda:service.current["objects"]["clearance.s0"]["percept"]["value"] is True and settled())
        mark("external_field_restoration_detected")
        control({"kind":"pause","paused":True})
        until(lambda:service.current["paused"])
        before=e.machine.request_count
        until(lambda:all(o["percept"]["epistemic"]=="Unknown" for o in service.current["objects"].values()),
              timeout=8,nap=.03)
        assert e.machine.request_count==before
        mark("quiescent_bank_evidence_expired")
        control({"kind":"pause","paused":False})
        count=completed_count()
        until(lambda:completed_count()>=count+16 and settled())
        mark("automatic_reacquisition")
        until(lambda:any(o["state"]=="WAITING" for o in e.machine.organs.values()))
        control({"kind":"target","fact":"clearance.s3"})
        until(lambda:last_result()["outcome"]=="SUPERSEDED" and settled())
        mark("epoch_change_rejects_old_binding")
        until(lambda:any(o["state"]=="WAITING" for o in e.machine.organs.values()))
        service.runner=FieldRunner(clock,c,[sys.executable,"-c","import time;time.sleep(3)"])
        until(lambda:last_result()["outcome"]=="TIMEOUT" and settled())
        mark("actual_blocked_process_fault")
        service.runner=FieldRunner(clock,c)
        count=completed_count()
        until(lambda:completed_count()>count and last_result()["outcome"] in ["OK","OCCLUDED"] and settled())
        mark("fault_recovery_and_next_measurement")
        spent=e.machine.spent
        control({"kind":"budget","limit":spent})
        until(lambda:e.machine.limit==spent)
        for _ in range(4):service.cycle();project()
        assert e.machine.spent==spent
        mark("budget_limit_holds_dispatch")
        control({"kind":"budget","limit":spent+2})
        until(lambda:e.machine.spent==spent+2 and settled())
        mark("budget_extension_consumed_exactly")
        control({"kind":"stop"})
        service.cycle();project()
        assert e.machine.phase=="STOPPED"
        e.checkpoint()
        mark("retired_and_sealed")
    finally:
        server.shutdown();server.server_close();network.join();e.close()
    replay=recover_segments(e.directory)
    assert replay["machine"].snapshot()==e.machine.snapshot()
    assert verify_segment_checkpoint(e.directory)
    report=export_replay(e.directory,out/"GRFPS_Second_Layer_Demo.html")
    report.update({"synthetic_world":True,"actual_measurement_processes":True,
        "http_projection_checks":checks,"phases":phases,"checkpoint_verified":True,
        "visual_browser_review":False,"field_mutations_by_harness_only":True})
    (out/"integration_report.json").write_text(json.dumps(report,indent=2))
    return report


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--out",required=True)
    result=run_demo(p.parse_args().out)
    print(json.dumps({k:v for k,v in result.items() if k!="phases"},indent=2))
