import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch as mock
from grfps_l2 import canon
from mapping import MapMachine, atlas, config_default, hashof, inverse, overlap, transform, validate_patch
from map_runtime import MapJournal, measure_process, record, replay
from map_worker import sample
from run_map_demo import world, run

def patch(pid,points=None,edges=None,at=0):
    return dict(id=pid,request='request1',source='sensor',sample_ref='a'*64,frame=0,sampled_at=at,
                points=points or dict(A=[0,0],B=[2,0],C=[0,2]),edges=edges if edges is not None else [['A','B',True]],boundary=['A'])

class MappingTests(unittest.TestCase):
    def test_rotation_inverse(self):
        for r in range(4):
            t=(r,17,-5)
            for p in [[1,2],[-9,3],[0,0]]:self.assertEqual(transform(transform(p,t),inverse(t)),tuple(p))
    def test_exact_join(self):
        a=patch('a');b=patch('b');b['points']={k:list(transform(v,(1,9,-2))) for k,v in a['points'].items()}
        q=overlap(a,b,100);self.assertEqual(q['status'],'GLUED');self.assertEqual(q['witness_ref'],hashof('Overlap',q['witness']))
        self.assertEqual(q['witness']['expires_at'],100)
    def test_single_reference_gap(self):
        self.assertEqual(overlap(patch('a'),patch('b',dict(A=[0,0],D=[1,0]),[['A','D',True]]),100)['status'],'GAP')
    def test_reflection_conflict(self):
        b=patch('b');b['points']['C']=[0,-2]
        self.assertEqual(overlap(patch('a'),b,100)['reason'],'geometry_incompatible')
    def test_relation_conflict_and_unknown_absence(self):
        a=patch('a');b=patch('b',edges=[['A','B',False]])
        v=atlas([a,b],100);self.assertEqual(v['pairs'][0]['status'],'CONFLICT')
        self.assertEqual(v['relations'][0]['status'],'Ambiguous');self.assertIsNone(v['relations'][0]['value'])
        self.assertEqual(len(v['relations']),1) # No other pairs invented.
    def test_cycle_quarantined(self):
        a=patch('a',dict(A=[0,0],B=[1,0],E=[10,0],F=[11,0]),[])
        b=patch('b',dict(A=[0,0],B=[1,0],C=[10,0],D=[11,0]),[])
        c=patch('c',dict(C=[10,0],D=[11,0],E=[20,0],F=[21,0]),[])
        v=atlas([a,b,c],100);self.assertEqual(len(v['components']),3)
        self.assertTrue(all(p['reason']=='component_inconsistent' for p in v['pairs']))
        self.assertTrue(all(p['quarantined'] for p in v['components']))
    def test_conflict_cannot_be_bypassed(self):
        a=patch('a');b=patch('b',edges=[['A','B',False]]);c=patch('c',edges=[])
        v=atlas([a,b,c],100);self.assertFalse(any(p['status']=='GLUED' for p in v['pairs']))
    def test_disjoint_stays_separate(self):
        b=patch('b',dict(D=[0,0],E=[1,0]),[['D','E',True]])
        self.assertEqual(len(atlas([patch('a'),b],100)['components']),2)
    def test_schema_types(self):
        for change in [dict(frame=True),dict(sampled_at=True),dict(edges=[['A','B',1]]),dict(points=dict(A=[True,0],B=[2,0])),dict(edges=[['A','B',True],['A','B',True]]),dict(boundary=['Z'])]:
            p=patch('a');p.update(change)
            with self.assertRaises(ValueError):validate_patch(p)
    def request(self,m,at=0):return m.reduce(dict(kind='request',at=at,window='left',source='sensor'))[0]
    def integrate(self,m,at=1):
        r=m.pending;p=sample(world(),r,at)
        return m.reduce(dict(kind='patch',at=at,exposure_ref=r['exposure_ref'],patch=p))[0]
    def test_bound_request_and_budget(self):
        c=config_default();c['budget']=1;m=self.request(MapMachine(c));self.assertEqual(m.spent,1)
        with self.assertRaises(ValueError):self.request(m)
        m=self.integrate(m)
        with self.assertRaises(ValueError):self.request(m,2)
    def test_wrong_receipt_transactional(self):
        m=self.request(MapMachine(config_default()));old=m.snapshot();p=sample(world(),m.pending,1)
        with self.assertRaises(ValueError):m.reduce(dict(kind='patch',at=1,exposure_ref='bad',patch=p))
        self.assertEqual(old,m.snapshot())
    def test_frame_supersedes_pending(self):
        m=self.request(MapMachine(config_default()));m=m.reduce(dict(kind='frame',at=1))[0];m=self.integrate(m,2)
        self.assertEqual(m.last['status'],'SUPERSEDED');self.assertEqual(m.snapshot()['patches'],[]);self.assertEqual(m.spent,1)
    def test_expiry_boundary(self):
        m=self.integrate(self.request(MapMachine(config_default())))
        m=m.reduce(dict(kind='tick',at=100))[0];self.assertEqual(len(m.snapshot()['patches']),1)
        m=m.reduce(dict(kind='tick',at=101))[0];self.assertEqual(m.snapshot()['inactive'],{'patch1':'EXPIRED'})
    def test_retraction(self):
        m=self.integrate(self.request(MapMachine(config_default())))
        m=m.reduce(dict(kind='retract',at=2,patch='patch1'))[0];self.assertEqual(m.snapshot()['patches'],[])
        with self.assertRaises(ValueError):m.reduce(dict(kind='retract',at=2,patch='patch1'))
    def test_late_receipt(self):
        m=self.integrate(self.request(MapMachine(config_default())),21)
        self.assertEqual(m.last['status'],'TIMEOUT');self.assertEqual(m.snapshot()['patches'],[])
    def test_failure_no_fabricated_patch(self):
        m=self.request(MapMachine(config_default()))
        with self.assertRaises(ValueError):m.reduce(dict(kind='fail',at=1,request='request1',reason='TIMEOUT'))
        m=m.reduce(dict(kind='fail',at=21,request='request1',reason='TIMEOUT'))[0]
        self.assertEqual(m.spent,1);self.assertIsNone(m.pending);self.assertEqual(m.snapshot()['patches'],[])
    def test_duplicate_and_future_receipt(self):
        m=self.request(MapMachine(config_default()));p=sample(world(),m.pending,2)
        e=dict(kind='patch',at=1,exposure_ref=m.pending['exposure_ref'],patch=p)
        with self.assertRaises(ValueError):m.reduce(e)
        e['at']=2;m=m.reduce(e)[0]
        with self.assertRaises(ValueError):m.reduce(e)
    def test_real_worker(self):
        with tempfile.TemporaryDirectory() as t:
            f=Path(t)/'w.json';f.write_text(json.dumps(world()));m=self.request(MapMachine(config_default()))
            e=measure_process(f,m.pending,1);self.assertEqual(e['kind'],'patch')
            m=m.reduce(e)[0];self.assertEqual(len(m.snapshot()['patches']),1)
    def test_bad_world_is_error(self):
        with tempfile.TemporaryDirectory() as t:
            m=self.request(MapMachine(config_default()));e=measure_process(Path(t)/'missing',m.pending,1)
            self.assertEqual(e['reason'],'ERROR')
    def test_fsync_failure_no_publication(self):
        with tempfile.TemporaryDirectory() as t:
            j=MapJournal(Path(t)/'j',config_default());old=j.machine.snapshot()
            try:
                with mock('map_runtime.os.fsync',side_effect=OSError('disk')):
                    with self.assertRaises(OSError):j.commit(dict(kind='tick',at=1))
                self.assertEqual(j.machine.snapshot(),old)
                with self.assertRaises(ValueError):j.commit(dict(kind='tick',at=2))
            finally:j.close()
    def test_replay_tamper_and_torn_reject(self):
        with tempfile.TemporaryDirectory() as t:
            f=Path(t)/'j';j=MapJournal(f,config_default());j.commit(dict(kind='tick',at=1));j.close()
            original=f.read_bytes();self.assertEqual(replay(f)['machine'].seq,1)
            lines=original.splitlines();r=json.loads(lines[1]);r['post']='f'*64;r['digest']=hashof('Transition',{k:v for k,v in r.items() if k!='digest'})
            f.write_bytes(lines[0]+b'\n'+canon(r)+b'\n')
            with self.assertRaises(ValueError):replay(f)
            f.write_bytes(original[:-1])
            with self.assertRaises(ValueError):replay(f)
    def test_end_to_end_eight_actual_processes(self):
        with tempfile.TemporaryDirectory() as t:
            report=run(Path(t)/'run');self.assertEqual(report['spent'],8)
            stages={s['name']:s for s in report['stages']}
            for k in ['witnessed_join','join_restored','new_frame_join']:self.assertEqual(stages[k]['glued'],1)
            for k in ['join_retracted','witness_expired','frame_invalidated']:self.assertEqual(stages[k]['glued'],0)
            self.assertEqual(stages['counterevidence']['conflicts'],1)
            self.assertEqual(report['comparison']['measured'],dict(true_positive=4,false_positive=0,missed_positive=0))
if __name__=='__main__':unittest.main()
