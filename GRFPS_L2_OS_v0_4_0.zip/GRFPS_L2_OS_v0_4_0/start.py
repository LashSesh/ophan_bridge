"""Start a local two-organ field session and open the Second Layer."""
import argparse
import datetime
import json
import uuid
from pathlib import Path
from field_world import generate_world
from organs import field_config
from segments import SegmentEngine
from organ_runtime import serve, export_replay
from adapters import MonotonicClock


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--duration", type=float, default=30)
    p.add_argument("--no-browser", action="store_true")
    args = p.parse_args()
    if not 0 < args.duration <= 86400:
        p.error("Duration must be positive and at most 86400 seconds.")
    parent = Path(__file__).resolve().parent/"organ_runs"
    parent.mkdir(exist_ok=True)
    name = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")+"-"+uuid.uuid4().hex[:8]
    run = parent/name
    run.mkdir()
    world = run/"field.json"
    world.write_text(json.dumps(generate_world(23),indent=2))
    config = field_config(world)
    engine = SegmentEngine.create(run/"journal", config)
    serve(engine, args.duration, open_browser=not args.no_browser, clock=MonotonicClock())
    html = run/"replay.html"
    export_replay(run/"journal", html)
    print("Offline replay:",html)


if __name__ == "__main__":
    main()
