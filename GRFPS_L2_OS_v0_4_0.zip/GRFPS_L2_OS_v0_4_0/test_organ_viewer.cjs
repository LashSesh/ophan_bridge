/* Actual script execution with a minimal DOM; no rendered browser claim. */
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'organ_demo.html'),'utf8');
const raw=html.match(/<script id="organData" type="application\/json">([\s\S]*?)<\/script>/)[1];
const data=JSON.parse(raw),code=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].at(-1)[1];
class Element{
 constructor(){this.children=[];this.style={};this.attrs={};this._text='';}
 set textContent(x){this._text=String(x);this.children=[];}
 get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}
 append(...xs){this.children.push(...xs);}
 replaceChildren(...xs){this._text='';this.children=xs;}
 setAttribute(k,v){this.attrs[k]=v;}
 click(){if(this.onclick)this.onclick();}
}
const nodes=new Map(),get=id=>{if(!nodes.has(id))nodes.set(id,new Element());return nodes.get(id);};
get('organData').textContent=raw;
let interval=null;
const context=vm.createContext({document:{getElementById:get,createElement:()=>new Element(),createElementNS:()=>new Element()},
 clearInterval:()=>{interval=null},setInterval:f=>{interval=f;return 1},setTimeout:()=>{},console,
 fetch:()=>{throw Error('Replay accessed network');}});
vm.runInContext(code,context);
const results=[],check=(name,fn)=>{fn();results.push({name,passed:true});};
const at=i=>get('timeline').oninput({target:{value:i}});
function descendants(node){return [node,...node.children.flatMap(descendants)];}
function select(fact){descendants(get('bank')).find(n=>n.attrs['data-fact']===fact).click();}
check('offline_replay_uses_no_network',()=>assert.equal(get('connection').textContent,'AUFZEICHNUNG'));
check('all_frames_preserve_organ_states_and_budget',()=>{
 for(let i=0;i<data.frames.length;i++){
  at(i);const s=data.frames[i];
  assert.equal(get('bank').children.length,2);
  assert.equal(get('budget').textContent,s.budget.spent+' / '+s.budget.limit);
  assert.equal(get('coverage').textContent,Object.keys(s.attempts).length+' / 16');
  for(const o of Object.values(s.organs))assert(get('bank').textContent.includes(o.state));
 }
});
check('exposure_changes_selected_sector_and_unwrapped_step',()=>{
 const i=data.frames.findIndex(s=>Object.values(s.organs).some(o=>o.unwrapped_step>=8));assert(i>=0);at(i);
 for(const o of Object.values(data.frames[i].organs))assert(get('bank').textContent.includes('Schritt '+o.unwrapped_step));
});
check('occluded_beacon_is_unknown',()=>{
 const i=data.frames.findIndex(s=>s.objects['beacon.s4'].percept.visibility.includes('occluded'));assert(i>=0);at(i);select('beacon.s4');
 assert(get('detail').textContent.includes('Unknown'));assert(get('evidence').textContent.includes('occluded'));
});
check('known_false_is_visible_after_field_change',()=>{
 const i=data.frames.findIndex(s=>s.objects['clearance.s0'].percept.value===false);assert(i>=0);at(i);select('clearance.s0');
 assert(get('detail').textContent.includes('Known / false'));
});
check('fault_is_displayed_as_runtime_phase',()=>{
 const i=data.frames.findIndex(s=>Object.values(s.organs).some(o=>o.state==='FAULT'));assert(i>=0);at(i);
 assert(get('bank').textContent.includes('TIMEOUT'));
});
check('superseded_result_keeps_its_exposure_reference',()=>{
 const i=data.frames.findIndex(s=>Object.values(s.completed).some(r=>r.outcome==='SUPERSEDED'));assert(i>=0);at(i);
 const r=Object.values(data.frames[i].completed).find(r=>r.outcome==='SUPERSEDED');select(r.fact);
 assert(get('outcome').textContent.includes('SUPERSEDED'));assert(get('sample').textContent.includes(r.exposure));
});
check('quiescent_expiry_is_distinct_from_retirement',()=>{
 const i=data.frames.findIndex(s=>s.paused&&Object.values(s.objects).every(o=>o.percept.epistemic==='Unknown'));assert(i>=0);at(i);
 assert(get('bank').textContent.includes('QUIESCENT'));
 at(data.frames.length-1);assert(get('bank').textContent.includes('RETIRED'));assert(get('runtime').textContent.includes('abgeschlossen'));
});
check('adjacent_transition_navigation',()=>{
 at(2);get('previous').click();assert(get('stepLabel').textContent.startsWith('2 /'));
 get('next').click();assert(get('stepLabel').textContent.startsWith('3 /'));
});
check('delta_gap_is_rejected',()=>assert.throws(()=>vm.runInContext('applyDelta({sequence:0,state_digest:"a"},{from:1,pre:"a"})',context),/view_gap/));
console.log(JSON.stringify({checks:results,rendered_browser_review:false},null,2));
