"""Finite witnessed atlas profile. Exact C4 rotations, integer translations.
Landmark identities are supplied by the sensor contract, not inferred.
"""
import copy
import hashlib
from itertools import combinations
from grfps_l2 import canon, fields, ident, loads, require, uint

PROFILE = 'grfps-witnessed-atlas/0.4.0'

def hashof(kind, value):
    return hashlib.sha256(canon([PROFILE, kind, value])).hexdigest()

def rot(p, r):
    x,y=p
    return [(x,y),(-y,x),(-x,-y),(y,-x)][r%4]

def transform(p, t):
    x,y=rot(p,t[0]);return (x+t[1],y+t[2])

def compose(a,b):
    x,y=transform(b[1:],a);return ((a[0]+b[0])%4,x,y)

def inverse(t):
    r=(-t[0])%4;x,y=rot((-t[1],-t[2]),r);return (r,x,y)

def point(p):
    return type(p) is list and len(p)==2 and all(type(x) is int and abs(x)<=100000 for x in p)

def config_default():
    return dict(profile=PROFILE,ttl=100,timeout=20,budget=16,max_events=512,max_patches=32)

def validate_patch(p):
    fields(p,'id request source sample_ref frame sampled_at points edges boundary')
    require(all(ident(p[k]) for k in ['id','request','source']),'patch_identity')
    require(type(p['sample_ref']) is str and len(p['sample_ref'])==64 and all(c in '0123456789abcdef' for c in p['sample_ref']),'sample_ref')
    require(uint(p['frame']) and uint(p['sampled_at']),'patch_time')
    points=p['points']
    require(type(points) is dict and 1<=len(points)<=32,'points_budget')
    require(all(ident(k) and point(v) for k,v in points.items()),'point_type')
    require(len({tuple(x) for x in points.values()})==len(points),'coincident_landmarks')
    require(type(p['edges']) is list and len(p['edges'])<=128,'edges_budget')
    seen=set()
    for e in p['edges']:
        require(type(e) is list and len(e)==3 and type(e[2]) is bool,'edge_type')
        a,b,_=e
        require(type(a) is str and type(b) is str and a in points and b in points and a<b,'edge_endpoints')
        require((a,b) not in seen,'duplicate_edge');seen.add((a,b))
    require(type(p['boundary']) is list and all(type(x) is str and x in points for x in p['boundary']),'boundary')
    require(len(set(p['boundary']))==len(p['boundary']),'duplicate_boundary')


def overlap(a,b,ttl):
    """Transform b into a, supported by every shared landmark, no fitting tolerance."""
    shared=sorted(set(a['points'])&set(b['points']))
    out=dict(a=a['id'],b=b['id'],shared=shared,status='GAP',reason='insufficient_overlap')
    if len(shared)<2:return out
    solutions=[]
    k=shared[0]
    for r in range(4):
        x,y=rot(b['points'][k],r)
        t=(r,a['points'][k][0]-x,a['points'][k][1]-y)
        if all(transform(b['points'][s],t)==tuple(a['points'][s]) for s in shared):solutions.append(t)
    if len(solutions)!=1:return dict(out,status='CONFLICT',reason='geometry_incompatible')
    ae={(x,y):v for x,y,v in a['edges']};be={(x,y):v for x,y,v in b['edges']}
    if any(ae[k]!=be[k] for k in ae.keys()&be.keys()):
        return dict(out,status='CONFLICT',reason='relation_disagreement')
    witness=dict(patches=[hashof('Patch',a),hashof('Patch',b)],shared=shared,
                 transform=list(solutions[0]),expires_at=min(a['sampled_at'],b['sampled_at'])+ttl)
    return dict(out,status='GLUED',reason='exact_overlap',transform=list(solutions[0]),
                witness=witness,witness_ref=hashof('Overlap',witness))


def atlas(patches,ttl):
    pairs=[overlap(a,b,ttl) for a,b in combinations(patches,2)]
    byid={p['id']:p for p in patches};adj={k:[] for k in byid}
    for pair in pairs:
        if pair['status']=='GLUED':
            a,b=pair['a'],pair['b'];t=tuple(pair['transform'])
            adj[a].append((b,t));adj[b].append((a,inverse(t)))
    poses={};components=[]
    for root in sorted(byid):
        if root in poses:continue
        poses[root]=(0,0,0);todo=[root];members=[];bad=False;positions={}
        while todo:
            a=todo.pop(0);members.append(a)
            for k,p in byid[a]['points'].items():
                global_p=transform(p,poses[a])
                if k in positions and positions[k]!=global_p:bad=True
                positions[k]=global_p
            for b,t in adj[a]:
                expected=compose(poses[a],t)
                if b in poses:
                    if poses[b]!=expected:bad=True
                else:poses[b]=expected;todo.append(b)
        if any(p['status']=='CONFLICT' and p['a'] in members and p['b'] in members for p in pairs):bad=True
        if bad:
            for pair in pairs:
                if pair['a'] in members and pair['b'] in members and pair['status']=='GLUED':
                    pair.update(status='CONFLICT',reason='component_inconsistent')
            # Never publish an inconsistent common coordinate system.
            components.extend(dict(id=k,patches=[k],poses={k:[0,0,0]},quarantined=True) for k in sorted(members))
        else:components.append(dict(id=root,patches=sorted(members),poses={k:list(poses[k]) for k in sorted(members)},quarantined=False))
    claims={}
    for p in patches:
        for a,b,v in p['edges']:
            claims.setdefault((a,b),[]).append(dict(patch=p['id'],value=v,ref=hashof('Patch',p)))
    relations=[]
    for (a,b),evidence in sorted(claims.items()):
        values={e['value'] for e in evidence};known=len(values)==1
        relations.append(dict(a=a,b=b,status='Known' if known else 'Ambiguous',
                              value=next(iter(values)) if known else None,evidence=evidence))
    return dict(pairs=pairs,components=components,relations=relations)


class MapMachine:
    def __init__(self,config):
        fields(config,'profile ttl timeout budget max_events max_patches')
        require(config['profile']==PROFILE,'profile')
        require(all(uint(config[k]) and config[k]>0 for k in config if k!='profile'),'config_uint')
        require(config['budget']<=10000 and config['max_events']<=10000 and config['max_patches']<=32 and config['ttl']<=1000000 and config['timeout']<=1000000,'config_limit')
        self.config=copy.deepcopy(config);self.seq=0;self.at=0;self.frame=0;self.spent=0
        self.pending=None;self.patches={};self.retracted=[];self.last=None
    def snapshot(self):
        live=[p for k,p in sorted(self.patches.items()) if k not in self.retracted and p['frame']==self.frame and self.at<p['sampled_at']+self.config['ttl']]
        inactive={k:('RETRACTED' if k in self.retracted else 'OLD_FRAME' if p['frame']!=self.frame else 'EXPIRED') for k,p in sorted(self.patches.items()) if p not in live}
        state=dict(profile=PROFILE,seq=self.seq,at=self.at,frame=self.frame,spent=self.spent,budget=self.config['budget'],
            config=self.config,pending=self.pending,last=self.last,patches=live,inactive=inactive,
            archive_ref=hashof('Archive',dict(patches=self.patches,retracted=self.retracted)),atlas=atlas(live,self.config['ttl']))
        state['state_digest']=hashof('State',state);return copy.deepcopy(state)
    def reduce(self,event):
        canon(event);require(self.seq<self.config['max_events'],'event_budget')
        require(type(event) is dict and uint(event.get('at')) and event['at']>=self.at,'monotonic_time')
        m=copy.deepcopy(self);m._apply(event);m.seq+=1
        # Validate generated arithmetic before publication (JS exactness included).
        canon(m.snapshot());return m,copy.deepcopy(m.last)
    def _apply(self,e):
        self.at=e['at'];kind=e.get('kind');self.last=dict(kind=kind)
        if kind=='request':
            fields(e,'kind at window source')
            require(ident(e['window']) and ident(e['source']),'request_identity')
            require(self.pending is None and self.spent<self.config['budget'],'request_budget_or_busy')
            require(len(self.patches)<self.config['max_patches'],'patch_capacity')
            self.spent+=1
            self.pending=dict(id='request'+str(self.spent),window=e['window'],source=e['source'],frame=self.frame,issued_at=self.at,deadline=self.at+self.config['timeout'])
            self.pending['exposure_ref']=hashof('WindowExposure',self.pending)
            self.last=dict(kind=kind,request=self.pending)
        elif kind=='patch':
            fields(e,'kind at exposure_ref patch');p=e['patch'];validate_patch(p);r=self.pending
            require(r is not None,'no_request')
            require(e['exposure_ref']==r['exposure_ref'] and p['request']==r['id'] and p['source']==r['source'] and p['frame']==r['frame'],'receipt_binding')
            require(r['issued_at']<=p['sampled_at']<=self.at,'sample_time')
            require(p['id'] not in self.patches,'duplicate_patch')
            status='TIMEOUT' if self.at>r['deadline'] else 'SUPERSEDED' if self.frame!=r['frame'] else 'INTEGRATED'
            if status=='INTEGRATED':self.patches[p['id']]=copy.deepcopy(p)
            self.last=dict(kind=kind,status=status,request=r['id']);self.pending=None
        elif kind=='fail':
            fields(e,'kind at request reason');require(self.pending is not None and e['request']==self.pending['id'],'failure_binding')
            require(e['reason'] in ['TIMEOUT','ERROR'],'failure_reason')
            require(e['reason']!='TIMEOUT' or self.at>self.pending['deadline'],'early_timeout')
            self.pending=None;self.last=dict(kind=kind,status=e['reason'])
        elif kind=='retract':
            fields(e,'kind at patch');require(type(e['patch']) is str and e['patch'] in self.patches and e['patch'] not in self.retracted,'retraction_ref')
            self.retracted.append(e['patch'])
        elif kind=='frame':
            fields(e,'kind at');self.frame+=1
        elif kind=='tick':fields(e,'kind at')
        else:raise ValueError('event_kind')
