"""Real filesystem integration: only this harness changes its own fixture files."""
import json
import shutil
import sys
import threading
import time
from pathlib import Path
from urllib.request import urlopen
from adapters import file_config,MonotonicClock,FileRunner
from journal import JournalEngine,recover,verify_checkpoint
from live import LiveService,server_for,export_replay
from session import apply_view_delta

ROOT=Path(__file__).parent


def run_demo(output_dir):
    output_dir=Path(output_dir)
    output_dir.mkdir(parents=True,exist_ok=False)
    fixture=output_dir/"fixture";fixture.mkdir()
    alpha,beta=fixture/"alpha.txt",fixture/"beta.txt"
    alpha.write_text("Controlled test fixture A.")
    beta.write_text("Controlled test fixture B.")
    config=file_config([alpha,beta],ttl_ms=500,refresh_ms=150,timeout_ms=250,
                       max_transitions=600)
    (output_dir/"config.json").write_text(json.dumps(config,indent=2))
    journal=output_dir/"session.jsonl"
    engine=JournalEngine.create(journal,config)
    clock=MonotonicClock()
    service=LiveService(engine,clock)
    server=server_for(service)
    network=threading.Thread(target=server.serve_forever,daemon=True);network.start()
    url="http://127.0.0.1:"+str(server.server_port)+"/api/updates"
    client=None
    phases=[]
    http_updates=0

    def synchronize():
        nonlocal client,http_updates
        suffix="" if client is None else "?cursor="+str(client["sequence"])+"&digest="+client["state_digest"]
        with urlopen(url+suffix,timeout=2) as response:
            body=json.load(response)
        if body["kind"]=="reset":client=body["snapshot"]
        else:
            for delta in body["deltas"]:client=apply_view_delta(client,delta)
        assert client==service.current
        http_updates+=1

    def until(predicate):
        limit=time.monotonic()+5
        while not predicate(service.current):
            assert time.monotonic()<limit,"Demo condition timed out"
            assert service.cycle()
            synchronize()
            time.sleep(.02)

    def mark(name):
        synchronize()
        phases.append({"phase":name,"sequence":service.current["sequence"],
                       "clock_ms":service.current["clock"],
                       "values":{k:{"epistemic":o["percept"]["epistemic"],"value":o["percept"]["value"]}
                                 for k,o in service.current["objects"].items()},
                       "region":service.current["region"],"requests":service.current["request_count"]})

    try:
        until(lambda s:len(s["region"])==3)
        mark("initial_real_acquisition")
        alpha.unlink()
        until(lambda s:s["objects"]["file0"]["percept"]["value"] is False)
        mark("external_file_removal_detected")
        alpha.write_text("Controlled test fixture A restored.")
        until(lambda s:s["objects"]["file0"]["percept"]["value"] is True)
        mark("external_file_restoration_detected")
        service.enqueue({"kind":"pause","paused":True})
        until(lambda s:s["paused"])
        until(lambda s:all(o["percept"]["epistemic"]=="Unknown" for o in s["objects"].values()))
        mark("paused_evidence_expired")
        service.enqueue({"kind":"pause","paused":False})
        until(lambda s:len(s["region"])==3)
        mark("automatic_reacquisition")
        before_count=service.current["request_count"]
        service.runner=FileRunner(clock,[sys.executable,"-c","import time; time.sleep(3)"])
        until(lambda s:s["request_count"]>before_count and
              any(r["outcome"]=="TIMEOUT" for r in s["last_receipt"].values()))
        mark("actual_worker_timeout")
        service.runner=FileRunner(clock)
        until(lambda s:len(s["region"])==3 and
              all(r["outcome"]=="OK" for r in s["last_receipt"].values()))
        mark("recovered_after_timeout")
        service.enqueue({"kind":"stop"})
        service.cycle()
        mark("sealed_stop")
        cp=engine.checkpoint()
    finally:
        server.shutdown();server.server_close();network.join();engine.close()
    restored=recover(journal)
    assert restored["machine"].snapshot()==engine.machine.snapshot()
    assert verify_checkpoint(journal,cp)
    report=export_replay(journal,output_dir/"GRFPS_Second_Layer_Demo.html")
    report.update({"real_filesystem":True,"measurement_processes":True,
                   "fixture_changes_by_harness_only":True,
                   "http_projection_checks":http_updates,"checkpoint_verified":True,
                   "selective_revalidations":engine.machine.kernel.revalidations,
                   "phases":phases,"visual_browser_review":False})
    (output_dir/"integration_report.json").write_text(json.dumps(report,indent=2))
    return report


if __name__=="__main__":
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",required=True)
    print(json.dumps(run_demo(parser.parse_args().out),indent=2))
