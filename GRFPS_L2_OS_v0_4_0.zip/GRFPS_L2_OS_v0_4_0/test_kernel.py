"""Adversarial contract tests, run with python -m unittest -v."""
import copy
import json
import random
import tempfile
import unittest
from pathlib import Path

from grfps_l2 import Kernel, canon, compile_genome, digest, loads, replay


def genome():
    return json.loads(Path(__file__).with_name("genome.json").read_text())


def obs(i, fact="gateway", source="sensor_a", value=True, at=0, time=None,
        quality="valid", visibility="observed"):
    return {"id": "e"+str(i), "kind": "observe", "at": at,
            "time": at if time is None else time, "fact": fact, "source": source,
            "value": value, "quality": quality, "visibility": visibility, "label": "test"}


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.k = Kernel(genome())

    def fact(self, key="gateway"):
        return self.k.snapshot()["percepts"][key]

    def test_genome_normal_form_fixed_point(self):
        g, m = compile_genome(genome())
        self.assertEqual((g,m), compile_genome(g))

    def test_order_independent_compiler(self):
        g = genome()
        g["genes"].reverse()
        g["facts"].reverse()
        g["edges"].reverse()
        self.assertEqual(compile_genome(g), compile_genome(genome()))

    def test_missing_dependency_rejected(self):
        g = genome()
        g["genes"][1]["deps"] = ["missing"]
        with self.assertRaises(ValueError): compile_genome(g)

    def test_wrong_operator_type_rejected(self):
        g = genome()
        g["genes"][0]["output"] = "ViewObject"
        with self.assertRaises(ValueError): compile_genome(g)

    def test_nonfinite_float_and_large_integer_rejected(self):
        for v in [float("nan"), float("inf"), 1.0, 2**53]:
            with self.assertRaises(ValueError): canon(v)

    def test_duplicate_json_keys_rejected(self):
        with self.assertRaises(ValueError): loads('{"a":1,"a":2}')

    def test_unknown_is_not_false(self):
        self.assertEqual(self.fact()["epistemic"], "Unknown")
        self.assertIsNone(self.fact()["value"])

    def test_correlated_sources_do_not_cross_threshold(self):
        self.k.step(obs(1))
        for i in range(2,8): self.k.step(obs(i,source="sensor_a_copy"))
        self.assertEqual(self.fact()["support_groups"], ["group_a"])
        self.assertEqual(self.fact()["epistemic"], "Unknown")

    def test_declared_separate_groups_can_resolve(self):
        self.k.step(obs(1))
        self.k.step(obs(2,source="sensor_b"))
        self.assertEqual(self.fact()["epistemic"], "Known")

    def test_known_false_is_preserved(self):
        self.k.step(obs(1,value=False))
        self.k.step(obs(2,source="sensor_b",value=False))
        self.assertIs(self.fact()["value"], False)
        self.assertEqual(self.fact()["epistemic"], "Known")
        self.assertNotIn("gateway",self.k.snapshot()["region"])

    def test_disagreement_is_ambiguous_and_empty_mirror(self):
        self.k.step(obs(1))
        self.k.step(obs(2,source="sensor_b",value=False))
        self.assertEqual(self.fact()["epistemic"], "Ambiguous")
        self.assertEqual(self.fact()["candidates"], [])

    def test_equal_time_conflict_not_hidden_by_tie_break(self):
        self.k.step(obs(1))
        self.k.step(obs(2,value=False))
        self.assertEqual(self.fact()["epistemic"], "Ambiguous")

    def test_latest_channel_can_resolve_old_conflict(self):
        self.k.step(obs(1,value=False))
        self.k.step(obs(2,source="sensor_b",value=True))
        self.k.step(obs(3,at=1,value=True))
        self.assertEqual(self.fact()["epistemic"], "Known")

    def test_expiry_reopens_candidate_set(self):
        self.k.step(obs(1))
        self.k.step(obs(2,source="sensor_b"))
        self.k.step({"id":"clock","kind":"tick","at":30,"label":"expiry"})
        self.assertEqual(self.fact()["candidates"], [False,True])
        self.assertEqual(self.fact()["freshness"], "stale")

    def test_retraction_does_not_resurrect_old_evidence(self):
        self.k.step(obs(1))
        self.k.step(obs(2,at=1,value=False))
        self.k.step({"id":"remove","kind":"retract","at":1,"ref":"e2","label":"withdraw"})
        self.assertEqual(self.fact()["source_refs"], [])

    def test_occluded_remains_distinct_from_unknown(self):
        self.k.step(obs(1,value=None,visibility="occluded"))
        self.assertEqual(self.fact()["visibility"], ["occluded"])
        self.assertEqual(self.fact()["epistemic"], "Unknown")

    def test_invalid_quality_not_promoted(self):
        self.k.step(obs(1,quality="invalid"))
        self.assertEqual(self.fact()["epistemic"], "Invalid")
        self.assertIsNone(self.fact()["value"])

    def test_out_of_scope_not_promoted(self):
        for i,s in enumerate(["sensor_a","sensor_b"]):
            self.k.step(obs(i,fact="external",source=s))
        self.assertEqual(self.fact("external")["epistemic"], "OutOfScope")

    def test_late_event_cannot_replace_newer_observation(self):
        self.k.step(obs(1,at=8))
        self.k.step(obs(2,at=9,time=1,value=False))
        self.assertEqual(self.fact()["candidates"], [True])
        self.assertIn("LATE_EVIDENCE_RETAINED",self.k.records[-1]["residuals"])

    def test_exact_duplicate_is_idempotent(self):
        e = obs(1)
        self.k.step(e)
        b = self.k.bundle()
        self.k.step(e)
        self.assertEqual(b,self.k.bundle())

    def test_duplicate_id_collision_rejected(self):
        self.k.step(obs(1))
        with self.assertRaises(ValueError): self.k.step(obs(1,value=False))

    def test_malformed_event_transaction_preserves_state(self):
        before = self.k.snapshot()
        e = obs(1)
        e["fact"] = []
        self.k.step(e)
        self.assertEqual(before,self.k.snapshot())
        self.assertEqual(self.k.records[-1]["outcome"],"REJECTED")

    def test_clock_regression_is_recorded_without_commit(self):
        self.k.step(obs(1,at=4))
        self.k.step(obs(2,at=3))
        self.assertEqual(self.k.records[-1]["residuals"],["clock_regression"])

    def test_target_change_preserves_percepts_and_increments_epoch(self):
        self.k.step(obs(1))
        before = self.k.snapshot()["percepts"]
        self.k.step({"id":"target","kind":"target","at":0,"fact":"cache","label":"switch"})
        self.assertEqual(before,self.k.snapshot()["percepts"])
        self.assertEqual(self.k.snapshot()["epoch"],1)

    def test_tracking_loss_disables_navigation(self):
        self.k.step({"id":"lost","kind":"tracking","at":0,"valid":False,"label":"lost"})
        n = self.k.snapshot()["navigation"]
        self.assertEqual(n["status"],"REANCHOR")
        self.assertEqual(n["probes"],[])
        self.assertEqual(n["path"],[])

    def test_boundary_contraction_after_expiry(self):
        for i,s in enumerate(["sensor_a","sensor_b"]): self.k.step(obs(i,source=s))
        self.assertIn("gateway",self.k.snapshot()["region"])
        self.k.step({"id":"expired","kind":"tick","at":30,"label":"expiry"})
        self.assertEqual(self.k.snapshot()["region"],[])

    def test_budget_and_view_provenance(self):
        self.k.step(obs(1))
        snap = self.k.snapshot()
        self.assertLessEqual(snap["navigation"]["budget_used"],self.k.g["probe_budget"])
        for v in snap["view"]:
            p = snap["percepts"][v["fact"]]
            self.assertEqual(v["machine_ref"],digest("Percept",p))
            self.assertEqual(v["epistemic"],p["epistemic"])
            self.assertEqual(v["source_refs"],p["source_refs"])

    def test_replay_matches_complete_bundle(self):
        self.k.step(obs(1))
        self.k.step(obs(2,at=3))
        self.assertTrue(replay(self.k.bundle())["verified"])

    def test_payload_tampering_detected(self):
        self.k.step(obs(1))
        b = self.k.bundle()
        b["records"][0]["input"]["value"] = False
        with self.assertRaises(ValueError): replay(b)

    def test_rehashed_render_tampering_detected_by_reexecution(self):
        self.k.step(obs(1))
        b = self.k.bundle()
        b["snapshots"][0]["view"][0]["epistemic"] = "Known"
        b["bundle_digest"] = digest("Bundle",{k:v for k,v in b.items() if k!="bundle_digest"})
        with self.assertRaises(ValueError): replay(b)

    def test_event_budget_is_enforced(self):
        g = genome()
        g["max_events"] = 1
        k = Kernel(g)
        k.step(obs(1))
        with self.assertRaises(ValueError): k.step(obs(2))

    def test_expiry_overflow_rejected_transactionally(self):
        self.k.step(obs(1,at=2**53-1))
        self.assertEqual(self.k.records[-1]["outcome"],"REJECTED")
        self.assertEqual(self.k.records[-1]["residuals"],["expiry_range"])

    def test_real_file_adapter_observes_present_missing_and_directory(self):
        from capture_files import capture
        with tempfile.TemporaryDirectory() as d:
            present=Path(d)/"present.txt"
            present.write_text("fixture")
            b=capture([present,Path(d)/"missing.txt",Path(d)])
            p=b["snapshots"][-1]["percepts"]
            self.assertIs(p["file0"]["value"],True)
            self.assertIs(p["file1"]["value"],False)
            self.assertIs(p["file2"]["value"],False)
            self.assertTrue(replay(b)["verified"])

    def test_randomized_replay_and_known_invariant(self):
        rng = random.Random(117)
        for i in range(120):
            self.k.step(obs(i,source=rng.choice(list(self.k.g["sources"])),
                            value=bool(rng.randrange(2)),at=i))
            p = self.fact()
            if p["epistemic"] == "Known":
                self.assertGreaterEqual(len(p["support_groups"]),p["threshold"])
                self.assertFalse(p["contradiction"])
                self.assertEqual(p["freshness"],"fresh")
        self.assertTrue(replay(self.k.bundle())["verified"])


if __name__ == "__main__":
    unittest.main()
