"""Read-only finite window sensor. Its C4 pose is hidden from the mapper."""
import sys
from pathlib import Path
from grfps_l2 import loads, require
from mapping import canon, hashof, inverse, transform, validate_patch

def sample(world,r,at):
    require(world['profile']=='grfps-window-world/0.4.0','world_profile')
    w=world['windows'][r['window']];ids=w['landmarks'];pose=w['pose']
    require(type(pose) is list and len(pose)==3 and all(type(x) is int and abs(x)<=100000 for x in pose) and 0<=pose[0]<4,'world_pose')
    require(type(ids) is list and len(set(ids))==len(ids),'world_landmarks')
    points={k:list(transform(world['points'][k],inverse(pose))) for k in ids}
    observed=[e for e in world['relations'] if e[0] in points and e[1] in points]
    p=dict(id='patch'+r['id'][7:],request=r['id'],source=r['source'],sample_ref=hashof('SampleWorld',world),
           frame=r['frame'],sampled_at=at,points=points,edges=observed,boundary=w['boundary'])
    validate_patch(p);return p

def main():
    b=Path(sys.argv[1]).read_bytes();require(len(b)<=1048576,'world_size')
    q=loads(sys.stdin.buffer.read(8193));r=q['request']
    sys.stdout.buffer.write(canon(sample(loads(b),r,q['sampled_at'])))
if __name__=='__main__':
    try:main()
    except Exception:sys.exit(2)
