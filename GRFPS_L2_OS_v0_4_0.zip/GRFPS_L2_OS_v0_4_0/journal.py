"""Append-first session journal, recovery, and materialized checkpoints."""
import copy
import json
import os
from pathlib import Path
from grfps_l2 import canon, digest, loads, require
from session import SESSION, SessionMachine

MAX_LINE = 2*1024*1024


def sealed(kind, payload):
    out = copy.deepcopy(payload)
    out["digest"] = digest(kind,payload)
    return out


def verify_seal(kind, record):
    require(type(record) is dict and "digest" in record, "missing_seal")
    payload = {k:v for k,v in record.items() if k!="digest"}
    require(record["digest"] == digest(kind,payload), "journal_digest")


def header_for(machine):
    return sealed("SessionHeader",{"type":"header","profile":SESSION,
        "config":machine.config,"initial_state":machine.snapshot()["state_digest"]})


def record_for(machine, event, parent):
    before = machine.snapshot()["state_digest"]
    candidate,output = machine.reduce(event)
    rec = sealed("SessionTransition",{"type":"transition","sequence":machine.seq,
        "event":event,"pre":before,"post":candidate.snapshot()["state_digest"],
        "output":output,"parent":parent})
    return candidate,rec


def recover(path, *, allow_torn_tail=False, collect_views=False):
    records,views = [],[]
    with Path(path).open("rb") as stream:
        line = stream.readline(MAX_LINE+1)
        require(line.endswith(b"\n") and len(line)<=MAX_LINE,"journal_header_line")
        header = loads(line)
        verify_seal("SessionHeader",header)
        machine = SessionMachine(header["config"])
        require(header==header_for(machine),"journal_header_semantics")
        parent=header["digest"]
        verified_bytes=len(line)
        torn=0
        while True:
            line=stream.readline(MAX_LINE+1)
            if not line:
                break
            require(len(line)<=MAX_LINE,"journal_line_budget")
            if not line.endswith(b"\n"):
                require(allow_torn_tail,"torn_tail")
                torn=len(line)
                break
            rec=loads(line)
            verify_seal("SessionTransition",rec)
            candidate,expected=record_for(machine,rec["event"],parent)
            require(rec==expected,"journal_semantic_mismatch")
            machine,parent=candidate,rec["digest"]
            records.append(rec)
            if collect_views:
                views.append(machine.snapshot())
            verified_bytes+=len(line)
    return {"header":header,"machine":machine,"records":records,"views":views,
            "head":parent,"verified_bytes":verified_bytes,"torn_tail_bytes":torn}


class JournalEngine:
    def __init__(self,path,machine,stream,head):
        self.path,self.machine,self.stream,self.head=Path(path),machine,stream,head

    @classmethod
    def create(cls,path,config):
        machine=SessionMachine(config)
        header=header_for(machine)
        stream=Path(path).open("xb")
        try:
            stream.write(canon(header)+b"\n")
            stream.flush()
            os.fsync(stream.fileno())
        except BaseException:
            stream.close()
            raise
        return cls(path,machine,stream,header["digest"])

    @classmethod
    def reopen(cls,path):
        restored=recover(path,allow_torn_tail=True)
        if restored["torn_tail_bytes"]:
            # Preserve the exact uncommitted suffix before trimming the journal.
            p=Path(path)
            tail=p.read_bytes()[restored["verified_bytes"]:]
            backup=p.with_name(p.name+".torn")
            with backup.open("xb") as out:
                out.write(tail)
                out.flush()
                os.fsync(out.fileno())
            with p.open("r+b") as out:
                out.truncate(restored["verified_bytes"])
                out.flush()
                os.fsync(out.fileno())
        return cls(path,restored["machine"],Path(path).open("ab"),restored["head"])

    def commit(self,event):
        candidate,record=record_for(self.machine,event,self.head)
        line=canon(record)+b"\n"
        require(len(line)<=MAX_LINE,"journal_line_budget")
        # The new state is not published if write/flush/fsync fails.
        try:
            self.stream.write(line)
            self.stream.flush()
            os.fsync(self.stream.fileno())
        except BaseException:
            self.stream.close()
            raise
        self.machine,self.head=candidate,record["digest"]
        return record

    def checkpoint(self):
        payload={"profile":SESSION,"journal_head":self.head,
                 "verified_bytes":self.stream.tell(),
                 "state":self.machine.snapshot()}
        record=sealed("SessionCheckpoint",payload)
        target=self.path.with_name(self.path.name+".checkpoint.json")
        temp=target.with_name(target.name+".tmp")
        with temp.open("wb") as out:
            out.write(canon(record))
            out.flush()
            os.fsync(out.fileno())
        os.replace(temp,target)
        return target

    def close(self):
        self.stream.close()


def verify_checkpoint(journal_path,checkpoint_path):
    # This profile deliberately validates through replay, not trusted deserialization.
    recovered=recover(journal_path)
    checkpoint=loads(Path(checkpoint_path).read_bytes())
    verify_seal("SessionCheckpoint",checkpoint)
    require(checkpoint["journal_head"]==recovered["head"],"checkpoint_head")
    require(checkpoint["verified_bytes"]==recovered["verified_bytes"],"checkpoint_position")
    require(checkpoint["state"]==recovered["machine"].snapshot(),"checkpoint_state")
    return True
