"""Finite radial test world. Generator/evaluator data never enters the planner."""
import random
from grfps_l2 import fields, require, uint, canon, digest
from organs import WORLD_PROFILE


def generate_world(seed, sectors=8, depth=4):
    rng = random.Random(seed)
    world = {"profile": WORLD_PROFILE, "sectors": sectors, "depth": depth,
             "cells": [[{"solid":rng.randrange(7)==0, "beacon":rng.randrange(5)==0}
                        for _ in range(depth)] for _ in range(sectors)]}
    return validate_world(world)


def validate_world(w):
    canon(w)
    fields(w, "profile sectors depth cells")
    require(w["profile"] == WORLD_PROFILE, "field_profile")
    require(uint(w["sectors"]) and 2 <= w["sectors"] <= 16, "field_sectors")
    require(uint(w["depth"]) and 1 <= w["depth"] <= 32, "field_depth")
    require(type(w["cells"]) is list and len(w["cells"]) == w["sectors"], "field_cells")
    for ray in w["cells"]:
        require(type(ray) is list and len(ray) == w["depth"], "field_ray")
        for cell in ray:
            fields(cell, "solid beacon")
            require(type(cell["solid"]) is bool and type(cell["beacon"]) is bool, "field_value")
    return w


def measure(world, query, sector):
    """A first obstacle is visible; a beacon at that cell is visible too.

    A hidden remainder cannot justify a negative beacon-existence statement.
    """
    validate_world(world)
    require(type(sector) is int and 0 <= sector < world["sectors"], "field_exposure")
    ray = world["cells"][sector]
    if query == "ray_clear":
        return {"outcome":"OK","value":not any(c["solid"] for c in ray)}
    require(query == "beacon_present", "field_query")
    for i, cell in enumerate(ray):
        if cell["beacon"]:
            return {"outcome":"OK","value":True}
        if cell["solid"] and i < len(ray)-1:
            return {"outcome":"OCCLUDED","value":None}
    return {"outcome":"OK","value":False}


def truth(world, query, sector):
    """Evaluator only: includes cells hidden from a measurement."""
    ray = world["cells"][sector]
    return (not any(c["solid"] for c in ray)) if query == "ray_clear" else any(c["beacon"] for c in ray)


def world_ref(world):
    return digest("RadialWorld", world)
