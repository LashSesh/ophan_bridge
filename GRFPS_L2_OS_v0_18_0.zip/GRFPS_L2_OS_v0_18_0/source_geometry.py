"""Fixed-reference joint boxes under every retained calibration; no root gauge.
A node is a calibration root or a projected window. Exact beacon registration
has one pose per calibration/window; no pose candidate is silently removed.
"""
import copy,hashlib
from grfps_l2 import canon
from trace_geometry import box,move,intersect,query_values,witness,Exhausted

def solve(inputs,limit):
    windows=inputs['windows'];candidates=inputs['candidates'];query=inputs['query'];spatial=inputs['spatial'];names=sorted(windows)
    out=dict(status='GAP',complete=True,reason='missing_query_landmark',root=inputs['reference'],nodes=0,solutions=0,support=[],values=[],witnesses={},bounds={},solution_digest=None)
    ids=set().union(*(set(v) for v in windows.values()))
    if not {query['a'],query['b']}<=ids:return out
    h=hashlib.sha256();values=set()
    def charge():
        if out['nodes']>=limit:raise Exhausted()
        out['nodes']+=1
    try:
        for idx,cal in enumerate(candidates):
            row=dict(calibration=cal,complete=False,solutions=0);out['support'].append(row);charge();domains={};poses={};ok=True
            for name in names:
                charge();reg=spatial[name]['rows'][idx]
                if reg['status']!='PASS' or reg['calibration']!=cal:ok=False;continue
                pose=reg['poses'][0];poses[name]=pose
                for k,p in windows[name].items():
                    b=move(move(box(p['center'],p['radius']),cal),pose)
                    merged=intersect(domains[k],b) if k in domains else b
                    if merged is None:ok=False
                    else:domains[k]=merged
            if ok:
                row['solutions']=1;out['solutions']+=1;h.update(canon(dict(calibration=cal,poses=poses,domains=domains))+b'\n')
                for k,b in domains.items():
                    if k not in out['bounds']:out['bounds'][k]=copy.deepcopy(b)
                    else:
                        old=out['bounds'][k];out['bounds'][k]=[[min(old[0][i],b[0][i]) for i in range(2)],[max(old[1][i],b[1][i]) for i in range(2)]]
                for value in query_values(domains,query):
                    values.add(value);out['witnesses'].setdefault(str(value).lower(),witness(domains,poses,cal,query,value))
            row['complete']=True
    except Exhausted:out.update(status='LIMIT',complete=False,reason='search_budget_exhausted')
    else:
        if not out['solutions']:out.update(status='CONFLICT',reason='no_registered_joint_geometry')
        elif any(not r['solutions'] for r in out['support']):out.update(status='GAP',reason='calibration_scope_gap')
        else:out.update(status='FEASIBLE',reason='all_registered_calibrations_covered')
    out['values']=sorted(values);out['solution_digest']=h.hexdigest();return out

def verify_witness(i,w):
    if w['calibration'] not in i['candidates'] or set(w['poses'])!=set(i['windows']):return False
    idx=i['candidates'].index(w['calibration'])
    if set(w['points'])!=set().union(*(set(v) for v in i['windows'].values())):return False
    for n,points in i['windows'].items():
        if w['poses'][n] not in i['spatial'][n]['rows'][idx]['poses']:return False
        for k,p in points.items():
            b=move(move(box(p['center'],p['radius']),w['calibration']),w['poses'][n])
            if not all(type(v) is int and b[0][axis]<=v<=b[1][axis] for axis,v in enumerate(w['points'][k])):return False
    return (w['points'][i['query']['b']][0]>w['points'][i['query']['a']][0]) is w['value']
