"""Read one finite model reference-offset sample."""
import sys,time
from pathlib import Path
from grfps_l2 import canon,loads,fields,require
from calibrated_bridge import validate_fixture,seal

def main():
    r=loads(sys.stdin.buffer.read(65537));fields(r,'start_ns offset exposure')
    with Path(sys.argv[1]).open('rb') as f:data=f.read(65537)
    require(len(data)<=65536,'sample_size');w=validate_fixture(loads(data));at=r['offset']+(time.monotonic_ns()-r['start_ns'])//1000000
    sys.stdout.buffer.write(canon(dict(offset=w['offset'],sampled_at=at,sample_ref=seal('ReferenceWorld',w),exposure=r['exposure'])))
if __name__=='__main__':main()
