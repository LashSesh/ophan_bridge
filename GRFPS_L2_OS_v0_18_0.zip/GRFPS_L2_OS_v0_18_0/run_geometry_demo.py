"""Real subprocesses, loopback HTTP, autonomous refinement and stale solver transport."""
import argparse,copy,json,shutil,tempfile,threading,time,urllib.request
from pathlib import Path
from geometry_runtime import GeometryService,sources,html,export
from geometry_segments import SegmentJournal,replay
from geometry_sensor import fixture,seal as sensor_seal
from noisy_certificate import fixture as chart_fixture,seal as chart_seal
from live import server_for


def run_case(d,case):
    d.mkdir();c=sources(d,'cycle' if case=='live_cycle' else 'refinement');samples=d/'samples';samples.mkdir()
    def write(name,w):
        ref=sensor_seal('Source',w) if name=='sensor' else chart_seal('Series',w)
        raw=json.dumps(w).encode();(samples/(ref+'.json')).write_bytes(raw)
        p=d/(name+'.next');p.write_bytes(raw);p.replace(d/(name+'.json'))
    sensor=fixture('cycle' if case=='live_cycle' else 'refinement');chart=chart_fixture([0,0,0]);write('sensor',sensor);write('calibration',chart)
    c.update(segment_records=16,calibration_refresh=150,calibration_ttl=3000)
    c['bank'].update(budget=256,timeout=3000)
    c['geometry'].update(ttl=2000,refresh=900,retry=100)
    if case=='live_limit':c['geometry'].update(node_limit=1,node_budget=2)
    if case=='live_expiry':c['geometry'].update(ttl=1200,refresh=800,retry=100)
    j=SegmentJournal(d/'journal',c);s=GeometryService(j);stages=[];checks=0;step=0;refined=False
    if case=='live_expiry':
        measure=s.measure
        def delayed(r):
            result=measure(r)
            if r['organ']=='geometry_solver':time.sleep(1.6)
            return result
        s.runner=delayed
    def stage(name):
        st=s.current
        stages.append(dict(stage=name,sequence=st['sequence'],spent=st['spent'],search_budget=st['search_budget'],answer=st['geometry_answer'],last=st['geometry_last'],revision=st['calibration']['revision'],monitor=st['drift']['status']))
    server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));th=threading.Thread(target=server.serve_forever,daemon=True);th.start();url=f'http://127.0.0.1:{server.server_port}'
    def control(kind,**extra):
        req=urllib.request.Request(url+'/api/control',data=json.dumps(dict(kind=kind,**extra)).encode(),headers={'Content-Type':'application/json','Origin':url},method='POST')
        with urllib.request.urlopen(req) as response:assert response.status==202
    end=time.monotonic()+35
    try:
        while time.monotonic()<end:
            assert s.cycle();st=s.current;a=st['geometry_answer'];last=st['geometry_last'];sol=st['geometry_solution'];drift=st['drift']
            with urllib.request.urlopen(url+'/api/updates') as response:v=json.load(response)
            assert v['snapshot']['state_digest']==st['state_digest'];checks+=1
            if case=='live_cycle' and sol and sol['result']['status']=='CONFLICT':stage('global_cycle_conflict');assert a['epistemic']=='Unknown';break
            if case=='live_limit' and st['search_budget']['spent']==2:stage('compute_budget_exhausted');assert a['epistemic']=='Unknown';break
            if case=='live_expiry' and last and last['status']=='STALE_INPUTS':stage('solver_transport_outlives_inputs');assert a['epistemic']=='Unknown';break
            if case=='live_refinement':
                if step==0 and a['epistemic']=='Ambiguous':stage('coarse_geometry_ambiguous');step=1
                elif step==1 and a['epistemic']=='Known':
                    assert a['value'] is True and 'fine' in j.machine.precision.values();refined=True;stage('autonomous_fine_measurement_known');control('pause',paused=True);step=2
                elif step==2 and st['paused']:
                    stage('pause_committed');occluded=copy.deepcopy(sensor)
                    for mode in ['coarse','fine']:occluded['windows']['left'][mode]=dict(outcome='OCCLUDED',points=None)
                    write('sensor',occluded);control('pause',paused=False);step=3
                elif step==3 and a['reason']=='fixed_anchor_missing' and 'right' in st['box_windows']:
                    stage('anchor_loss_does_not_reroot');assert a['anchor']=='left';write('sensor',sensor);step=4
                elif step==4 and a['epistemic']=='Known':
                    stage('anchor_reacquired_and_resolved');bad=copy.deepcopy(chart)
                    for ps in bad['samples'].values():
                        for p in ps:p['raw'][0]+=10
                    write('calibration',bad);step=5
                elif step==5 and drift['status']=='REVOKED':stage('drift_revokes_live_answer');write('calibration',chart);step=6
                elif step==6 and drift['status']=='REVOKED' and drift['sample_class']=='WITHIN':stage('return_keeps_revocation');step=7
                elif step==7 and drift['candidate']['status']=='PASS':stage('fresh_calibration_proposal');control('recalibrate');step=8
                elif step==8 and st['calibration']['revision']==2 and a['epistemic']=='Known':stage('new_revision_fresh_windows_and_solver');break
            time.sleep(.02)
        else:raise AssertionError(json.dumps(dict(case=case,step=step,snapshot=s.current)))
        s.stop_reason='user'
        while s.cycle():time.sleep(.02)
    finally:server.shutdown();server.server_close();th.join();s.close()
    old=replay(d/'journal')['machine'];j=SegmentJournal.reopen(d/'journal');j.commit(dict(kind='resume',at=old.mapper.at+6000));ss=j.machine.snapshot()
    assert ss['spent']==old.spent and ss['search_budget']['spent']==old.nodes_spent and ss['calibration']==old.calibration and ss['geometry_answer']['epistemic']=='Unknown'
    j.commit(dict(kind='stop',at=j.machine.mapper.at,reason='user'));j.close()
    report=export(d/'journal',d/'replay.html');report.update(case=case,http_checks=checks,stages=stages,autonomous_refinement=refined,restart_preserved_spent=old.spent,restart_preserved_nodes=old.nodes_spent,restart_preserved_certificate=True)
    (d/'report.json').write_text(json.dumps(report,indent=2));return report


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='geometry_evidence_run');a=p.parse_args();target=Path(a.out).resolve();assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps013_',dir='/tmp') as tmp:
        work=Path(tmp)/'proof';work.mkdir();reports={name:run_case(work/name,name) for name in ['live_refinement','live_cycle','live_limit','live_expiry']}
        from verify_geometry import verify
        verified=verify(work,export_views=False);(work/'integration_report.json').write_text(json.dumps(verified,indent=2));shutil.copytree(work,target)
    print(json.dumps({name:{k:v for k,v in r.items() if k!='stages'} for name,r in reports.items()},indent=2))

if __name__=='__main__':main()
