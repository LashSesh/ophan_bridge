# Registrierungsvertrag 0.16.0 — präzise Anschlussgrenzen

Das ausführbare Schema wird durch `registration3d.validate` bestimmt. Vollständige Beispiele liegen in jedem Unterordner von `registered3d_evidence_run` als `registration3d.json` zusammen mit der zugehörigen Rohspur und dem Trägermanifest.

## Annahmen

1. Jede wahre lokale und referenzierte Kalibrierposition liegt in ihrer jeweiligen Eingabebox.
2. Der tatsächliche Raumanschluss gehört während des Quellzeitbereichs zur Familie `y = R x + t`: R ist eine der 24 orientierungserhaltenden Achsenpermutationen, t liegt in der gebundenen Verschiebungsbox.
3. Fitrecords besitzen außer dem gemeinsamen Anschluss keine weiteren gekoppelten Einschränkungen. Die Intervallprojektion bleibt bei zusätzlichen unbekannten Kopplungen konservativ, kann aber zusätzliche Modellzeugen enthalten.
4. Die tatsächliche Rate gehört zur expliziten endlichen Familie und ist im Zeitbereich konstant. Wahre Referenzzeiten liegen in den angegebenen Intervallen.
5. Die reale Trägerposition liegt in der Darstellungshülle zuzüglich der deklarierten Sensorfehlerbox.
6. Kennungen, Einheiten und Referenzen sind korrekt deklariert. Inhaltliche Identität ersetzt keine physische Authentisierung oder Erhebungsunabhängigkeit.

Unter diesen Annahmen umschließt die berechnete Modellmenge den tatsächlichen Zustand. Known ist nur als Aussage innerhalb dieses Vertrags zu lesen. Besteht eine Annahme nicht, folgt aus dem Testergebnis keine physische Korrektheitsgarantie.

## Exakte Mengenrechnung

Für eine Rotation R und Fitboxen Li, Wi gilt `TR = bound ∩ intersection_i(Wi − RLi)`. Bei achsenparallelen Boxen und vorzeichenbehafteten Permutationen ist dies eine vollständige Translationserfassung. Eine Kontrollbox muss dagegen **für sämtliche** gehaltenen Translationen enthalten sein: `R Lcheck + TR ⊆ Wcheck`. Ein partieller Kontrolltreffer darf den Fit nicht verkleinern.

Für jede explizite Uhrenrate a gilt `Ba = intersection_i(reference_interval_i − a × local_time_i)`. Eine Kontrolle muss das ganze Intervall `a × local_check + Ba` enthalten. Offsetintervalle können kontinuierliche Werte enthalten, obwohl ihre Grenzwerte exakt rational kodiert sind.

Eine Positionsabfrage wird für jede registrierte Intervallbox ausgewertet. Die Vereinigung aller möglichen Wahrheitswerte entscheidet zwischen Known und Ambiguous. Die globale räumliche Hülle ist nur eine einschließende Darstellung; die per-Rotation-Boxen bleiben im Zustand erhalten. Eckpunktzeugen gehören zum konservativen Intervallmodell und sind keine Behauptung, genau diese Position sei tatsächlich aufgenommen worden.

## Lebenszyklus

Ein Lauf bindet genau ein Zertifikat für die anfängliche Manifestreferenz, Epoche null und die gesamte Rohdatei. Das Zertifikat wird vor dem ersten Trägerrecord eingebracht. Nachträglicher Austausch ist gesperrt. Ein Referenzreset entzieht die registrierte Antwort und kann das alte Zertifikat nicht wieder aktivieren. Dies ist eine bewusste Grenze des aktuellen Profils.

Pause verhindert die Übernahme weiterer Trägerrecords. Stop und Resume erhalten historische Informationen, aber keine neue Frische. Der neue Raum ist vom bisherigen 2D-Raum getrennt. Die registrierte Ausgabe enthält keine orientierte 6-DoF-Pose und keinen externen Effekt-Executor.

## Ressourcen und numerische Grenzen

Bis 64 KiB Registrierungsdaten, höchstens acht Records je Fit-/Kontrollgruppe, 24 Raumrotationsversuche und bis fünf Raten. Die Verschiebungs- und Offsetintervalle werden analytisch berechnet; ihre unendlich vielen inneren Punkte werden nicht einzeln aufgezählt. Der Zähler beschreibt logische Kandidatenversuche, keine gemessene Gesamtrechenzeit.

Alle Referenzkoordinaten besitzen ganzzahlige µm-Grenzen. Zeitstempel sind kanonische Dezimalstrings; rationale Grenzen sind gekürzte Zähler-/Nennerstringpaare. Der Trägerimport prüft Dezimal-Beträge ohne kontextabhängige Zwischenrundung. Daten knapp außerhalb einer numerischen Eingabegrenze werden zurückgewiesen.
