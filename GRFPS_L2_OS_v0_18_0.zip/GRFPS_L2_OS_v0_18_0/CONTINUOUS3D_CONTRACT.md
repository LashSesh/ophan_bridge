# Continuous 3D registration contract 0.17.0

Normative executable definitions: `continuous3d.validate`, `compile_certificate`, `projection`. The prior common fields are checked by `registration3d.validate` after profile conversion; the old runtime semantics remain separate.

Input profile: `grfps-continuous3d/0.17.0`.
Bank profile: `grfps-continuous3d-bank/0.17.0`.
Observation port: `grfps-observation-port/3`.

The input retains all fields of the earlier registration bundle and adds exactly `charts` and `search`. `spatial_fit[*].local_um` must have equal lower and upper endpoints on all axes. These are declared exact local anchors. Reference boxes and control local boxes retain their bounded integer format.

```json
{
  "charts": [{
    "id": "rotation_chart",
    "base": [1, 2, 3],
    "u": [
      [["0", "1"], ["0", "1"]],
      [["0", "1"], ["0", "1"]],
      [["19", "100"], ["21", "100"]]
    ]
  }],
  "search": {"min_depth": 0, "max_depth": 8, "max_cells": 63}
}
```

This is a fragment, not a complete accepted bundle. Run the default CLI to produce complete synthetic input files.

A chart has exactly `id`, `base`, `u`. Its identifier is unique. The base belongs to the proper signed-permutation rotation group. There are one to four charts. Each u endpoint is a canonical reduced rational pair of strings with positive denominator, numerator absolute value and denominator at most 10^9, value within [-1,1]. No float conversion is accepted. Internal bisection endpoints need not retain the input denominator bound.

The search fields are exact integers. 0 <= min_depth <= 3, min_depth <= max_depth <= 8, and number_of_charts <= max_cells <= 127. Minimum depth requests subdivision only for nonempty, splittable fit cells; a fully excluded or degenerate cell needs no subdivision. Children are scheduled only when the remaining budget can evaluate every queued cell and both children. A failed minimum-depth request does not invalidate an already proved universal control and fit existence.

The accepted source is bound to the exact raw carrier hash, manifest identity, initial reference space and epoch zero. Each projected carrier frame explicitly provides reference space and an integer epoch. A new reference epoch cannot reuse the initial certificate. Horizons, sensor error, charts, search limits, controls and query are all included in `bundle_ref`.

Compiler output records every retained leaf and every fit-excluded leaf, with chart ID and binary path. Paths define closed dyadic cells; siblings share their boundary. There is no candidate removal based on a control result. Every excluded cell has an empty outer translation intersection derived only from fit constraints.

Each retained leaf stores `rotation_interval`, `translation_um`, all control results and an optional `fit_witness`. This witness is a rational parameter with an exact nonempty translation box computed from the original exact local fit anchors. A parent witness remains available in every child containing its parameter. At least one witness across the whole cover is necessary for PASS; every retained outer cell must pass all controls.

Clock rates and offset intervals are the previous exact affine family. Controls do not remove rates. All source and target time bounds are inclusive. The target horizon must contain the complete affine time hull at the current frame.

Status priority: SPATIAL_FIT_EMPTY; then unresolved spatial control/existence (SEARCH_LIMIT when blocked by the cell budget, otherwise CONTROL_UNPROVEN or FIT_EXISTENCE_UNPROVEN); then CLOCK_FIT_EMPTY; CLOCK_CHECK_REJECTED; PASS. All per-candidate clock results are preserved even when the main reason is spatial.

Positions, matrices, parameters and offsets in the new certificate/projection use exact rational string pairs. `enclosure_values` gives outer possible query values; `values` lists values supported by concrete witnesses. A singleton outer answer set yields Known. Two feasible opposite witnesses yield Ambiguous. Otherwise an overlapping cover yields Unknown/enclosure_overlap. A missing or invalidated registration yields Unknown with no registered position.

Witness checking must use the original fit constraints, parameter chart, translation bound and current local position interval. Membership in an outer translation box alone is insufficient. `verify_witness` performs that direct check. Witnesses belong to the declared mathematical model, not necessarily to actual measurements.

The owner's `registration3d_result` transition remains single and pre-import. It recomputes and compares the entire certificate. Snapshot and plan calls read cached projections and do not compile or subdivide. The CLI validates inputs and its compiler result before creating a new run directory. Resume validates the original source and registration file before reopening for a new commit. Segment replay reexecutes the full semantic history; no trusted checkpoint deserialization bypasses this.

`work` measures cell evaluations, splits, retained and excluded cells, and declared clock-rate trials. It is not a record of every parent/owner/replay CPU operation. The finite search has no promise of complete decision or physical realtime service.

Declared limits: exact local fit anchors; bounded rational quaternion chart cover; fixed affine rate family; historical file inputs; one initial reference certificate; position-only registered query. Physical sensor bounds, independent physical controls, registered orientation, room_grid joining and effect receipts require separate evidence.
