"""Local noisy bank; explicit reference changes drain the current request."""
import argparse,json,sys,subprocess,threading,time,webbrowser
from pathlib import Path
from grfps_l2 import canon,loads,fields,require
from uncertain_runtime import UncertainService,fixture
from noisy_bridge import config,seal
from noisy_certificate import fixture as calibration_fixture
from uncertain_bridge import probe_fixture
from noisy_segments import SegmentJournal,replay
from field_world import generate_world
from adapters import MonotonicClock
from live import server_for

class NoisyService(UncertainService):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.recalibrate_requested=False
    def wrapped(self,e):
        return e if e['kind'] in ['noisy_result','calibration_result'] else dict(kind='noisy_result',at=e['at'],calibration_ref=self.engine.machine.pending_calibration,event=e)
    def failure(self,r,outcome):
        if r['organ']=='calibration_probe':
            at=max(self.now(),r['deadline']+1) if outcome=='TIMEOUT' else self.now()
            return dict(kind='calibration_result',at=at,request=r['id'],exposure=r['exposure'],outcome=outcome,observation=None,sampled_at=None,sample_ref=None)
        return self.wrapped(super().failure(r,outcome))
    def measure(self,r):
        if r['organ']=='window':
            try:
                p=subprocess.run([sys.executable,str(Path(__file__).with_name('noisy_window_worker.py')),self.engine.machine.config['atlas']['world']],input=canon(dict(request=r['inner'],start_ns=self.clock.start_ns,offset=self.clock.offset)),capture_output=True,timeout=max(.001,(r['deadline']-self.now())/1000))
                require(p.returncode==0 and len(p.stdout)<=262144,'raw_window_protocol');at=self.now()
                return self.wrapped(dict(kind='window_result',at=at,request=r['id'],exposure=r['exposure'],event=dict(kind='patch',at=at,exposure_ref=r['inner']['exposure_ref'],patch=loads(p.stdout))))
            except subprocess.TimeoutExpired:return self.failure(r,'TIMEOUT')
            except (OSError,ValueError):return self.failure(r,'ERROR')
        if r['organ']!='calibration_probe':return self.wrapped(super().measure(r))
        try:
            p=subprocess.run([sys.executable,str(Path(__file__).with_name('noisy_chart_worker.py')),self.engine.machine.contract['calibration_world']],input=canon(dict(start_ns=self.clock.start_ns,offset=self.clock.offset,exposure=r['exposure'],stage=r['payload']['stage'],series_ref=r['payload']['series_ref'])),capture_output=True,timeout=max(.001,(r['deadline']-self.now())/1000))
            require(p.returncode==0 and len(p.stdout)<=65536,'calibration_protocol');v=loads(p.stdout);fields(v,'observation sampled_at sample_ref exposure');require(v['exposure']==r['exposure'],'calibration_exposure')
            return dict(kind='calibration_result',at=self.now(),request=r['id'],exposure=r['exposure'],outcome='OK',observation=v['observation'],sampled_at=v['sampled_at'],sample_ref=v['sample_ref'])
        except subprocess.TimeoutExpired:return self.failure(r,'TIMEOUT')
        except (OSError,ValueError):return self.failure(r,'ERROR')
    def commit(self,e):
        if e['kind']=='noisy_result':
            v=dict(e['event'],at=e['at'])
            if v['kind'] in ['window_result','scoped_boolean']:v['event']=dict(v['event'],at=e['at'])
            e=dict(e,event=v)
        return super().commit(e)
    def enqueue(self,c):
        require(type(c) is dict,'control')
        if c.get('kind')=='recalibrate':
            fields(c,'kind');require(self.current['phase']=='RUNNING' and not self.error,'stopped')
            with self.lock:self.recalibrate_requested=True
        else:super().enqueue(c)
    def cycle(self):
        # Bootstrap only with checked evidence; later adoption requires a command.
        if self.engine.machine.calibration['revision']==0 and self.engine.machine.recalibration_proposal():self.recalibrate_requested=True
        if self.recalibrate_requested and not self.stop_reason and self.engine.machine.phase=='RUNNING' and not self.at_capacity():
            if self.future:
                if not self.future.done():self.commit(dict(kind='tick',at=self.now()));return True
                e=self.future.result();e['at']=max(e['at'],self.now())
                try:self.commit(e)
                except ValueError:self.commit(self.failure(self.engine.machine.pending,'ERROR'))
                self.future=None
            p=self.engine.machine.recalibration_proposal()
            if p:
                try:self.commit(dict(kind='recalibrate',at=self.now(),proposal=p));status='COMMITTED'
                except ValueError:status='EXPIRED'
            else:status='NO_VALID_CERTIFICATE'
            self.command_results.append(dict(command=dict(kind='recalibrate'),status=status))
            with self.lock:self.recalibrate_requested=False
        return super().cycle()

def html(data):return Path(__file__).with_name('noisy_viewer.html').read_text().replace('__MAP_DATA__',json.dumps(data,ensure_ascii=True).replace('<','\\u003c'))
def export(directory,target):
    r=replay(directory,collect=True);Path(target).write_text(html(dict(mode='replay',views=r['views'],events=r['events'],head=r['head'])));m=r['machine']
    return dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,requests=m.request_count,head=r['head'],state_digest=m.snapshot()['state_digest'],revision=m.calibration['revision'],breaches=m.breaches)
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='noisy_run');p.add_argument('--resume',action='store_true');p.add_argument('--duration',type=float,default=15);p.add_argument('--open',action='store_true');a=p.parse_args();require(0<a.duration<=3600,'duration');d=Path(a.out).resolve()
    if a.resume:
        j=SegmentJournal.reopen(d/'journal');offset=j.machine.mapper.at+max(j.machine.mapper.config['ttl'],j.machine.contract['calibration_ttl'])+1;j.commit(dict(kind='resume',at=offset));clock=MonotonicClock(offset)
    else:
        d.mkdir(parents=True,exist_ok=False)
        for name,value in [('world',dict(fixture(),sensor_transform=[1,3,-2])),('field',generate_world(23,sectors=4,depth=2)),('orientation',dict(profile='grfps-orientation-fixture/1',registrations=dict(AB_ray=[0,1,2,3]))),('calibration',calibration_fixture())]:(d/(name+'.json')).write_text(json.dumps(value,indent=2))
        j=SegmentJournal(d/'journal',config(d/'world.json',d/'field.json',d/'orientation.json',d/'calibration.json'));clock=MonotonicClock()
    s=NoisyService(j,clock);server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));t=threading.Thread(target=server.serve_forever,daemon=True);t.start();url=f'http://127.0.0.1:{server.server_port}/';print(url,flush=True)
    if a.open:webbrowser.open(url)
    end=time.monotonic()+a.duration
    try:
        while True:
            if time.monotonic()>=end:s.stop_reason='duration'
            if not s.cycle():break
            time.sleep(.04)
    except KeyboardInterrupt:
        s.stop_reason='user'
        while s.cycle():time.sleep(.04)
    finally:server.shutdown();server.server_close();t.join();s.close()
    print(json.dumps(export(d/'journal',d/'replay.html'),indent=2))
if __name__=='__main__':main()
