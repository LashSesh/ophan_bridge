import copy
from grfps_l2 import require,fields,canon
from carrier_bank import CarrierBank,PROFILE as CARRIER_BANK_PROFILE,checkpoint
from carrier_contract import read_line,sha
from uncertain3d import compile_certificate,projection,seal as reg_seal,ns
from epoch_registration import validate_plan
PROFILE='grfps-epoch3d-bank/0.18.0'
WORK_KEYS='cell_evaluations splits retained_cells discarded_cells rate_trials translation_trials anchor_checks plane_triples'.split()
def seal(kind,value):return reg_seal(kind,dict(profile=PROFILE,value=value))
def config(base,plan):return dict(copy.deepcopy(base),profile=PROFILE,registration_schedule=copy.deepcopy(plan))
class Epoch3DBank(CarrierBank):
    def __init__(self,c):
        require(c.get('profile')==PROFILE and 'registration_schedule' in c,'epoch3d_profile');validate_plan(c['registration_schedule'],c['carrier']);base=copy.deepcopy(c);base.pop('registration_schedule');base['profile']=CARRIER_BANK_PROFILE;super().__init__(base);self.contract=copy.deepcopy(c);self.registration_certificate=None;self.active_registration=None;self.registration_history=[];self.last_carrier_frame_raw=None;self.epoch_start_cursor=0;self.epoch_reset_ref=None;self.epoch_reset_time=None;self.registration_work={k:0 for k in WORK_KEYS};self._project()
    def epoch_entry(self):return next((x for x in self.contract['registration_schedule']['entries'] if x['bundle']['source']['epoch']==self.carrier_state.epoch),None)
    def pending_admission(self):
        entry=self.epoch_entry()
        if entry and self.registration_certificate is None and self.carrier_state.cursor==entry['after_record'] and not any(x['epoch']==self.carrier_state.epoch for x in self.registration_history):return copy.deepcopy(entry)
        return None
    def _project(self):
        entry=self.active_registration or self.epoch_entry() or self.contract['registration_schedule']['entries'][0];self.registered3d=projection(entry['bundle'],self.registration_certificate,self.carrier_state.snapshot(),self.last_carrier_frame_raw)
        if self.registration_certificate is None:self.registered3d['reason']='epoch_registration_pending' if self.epoch_entry() else 'epoch_unbound'
        self.registered3d['source_epoch']=self.carrier_state.epoch
    def snapshot(self):
        s=super().snapshot();s.update(profile=PROFILE,registered3d=copy.deepcopy(self.registered3d),registration_certificate=copy.deepcopy(self.registration_certificate),registration_work=copy.deepcopy(self.registration_work),registration_history=copy.deepcopy(self.registration_history),registration_scope=dict(epoch=self.carrier_state.epoch,reference_space=self.carrier_state.reference,activation_cursor=self.epoch_start_cursor,activation_ref=self.epoch_reset_ref))
        port=s['observation_port'];port['profile']='grfps-observation-port/4';g=s['registered3d'];port['objects'].append(dict(id='registered_carrier_query',referent=g['carrier_ref'],projection='uncertain_anchor_query/1',value=g['value'],epistemic=g['status'],facticity=g['facticity'],scope=g['target']['reference_space'],evidence=g['certificate_ref'],source_epoch=self.carrier_state.epoch));port['registered_target']=dict(reference_space=g['target']['reference_space'],status=g['status'],certificate_ref=g['certificate_ref'],source_epoch=self.carrier_state.epoch);port['loss'].extend(['uncertain_local_anchor_boxes','interval_cover_may_be_strict','orientation_not_registered','registered_target_is_separate_from_room_grid']);port['digest']=reg_seal('WorldSnapshot',{k:v for k,v in port.items() if k!='digest'});s['contract_ref']=seal('Contract',self.contract);s['state_digest']=seal('State',{k:v for k,v in s.items() if k!='state_digest'});return s
    def _registered(self,e):
        if e.get('kind')=='epoch_registration_result':
            fields(e,'kind at epoch after_record activation_ref certificate');entry=self.pending_admission();require(self.phase=='RUNNING' and not self.active.paused and entry is not None,'epoch_admission_lifecycle');require(type(e['epoch']) is int and e['epoch']==self.carrier_state.epoch and type(e['after_record']) is int and e['after_record']==entry['after_record']==self.epoch_start_cursor and e['activation_ref']==entry['activation_ref']==self.epoch_reset_ref,'epoch_admission_binding');b=entry['bundle'];require(b['source']['reference_space']==self.carrier_state.reference,'epoch_reference')
            if self.epoch_reset_time is not None:require(min(ns(x['local_ns']) for x in b['clock_fit'])>=self.epoch_reset_time,'epoch_clock_evidence')
            expected=compile_certificate(b,self.contract['carrier']);require(canon(expected)==canon(e['certificate']),'epoch_certificate_semantics');self._active(dict(kind='tick',at=e['at']));self.registration_certificate=copy.deepcopy(expected);self.active_registration=copy.deepcopy(entry)
            for key in WORK_KEYS:self.registration_work[key]+=expected['work'][key]
            self.registration_history.append(dict(epoch=e['epoch'],reference_space=self.carrier_state.reference,activation_cursor=self.epoch_start_cursor,activation_ref=self.epoch_reset_ref,admitted_at=e['at'],bundle_ref=expected['bundle_ref'],certificate_ref=expected['digest'],status=expected['status'],work=copy.deepcopy(expected['work'])));self.last=dict(kind=e['kind'],epoch=e['epoch'],status=expected['status'],certificate_ref=expected['digest']);self._project()
        else:
            super()._registered(e)
            if e.get('kind')=='carrier_record':
                raw=read_line(e['raw'])
                if raw['record_kind']=='frame':self.last_carrier_frame_raw=e['raw']
                elif raw.get('kind')=='reference_reset':self.registration_certificate=None;self.active_registration=None;self.last_carrier_frame_raw=None;self.epoch_start_cursor=self.carrier_state.cursor;self.epoch_reset_ref=sha(e['raw'].encode('ascii'));self.epoch_reset_time=int(raw['monotonic_time_ns'])
                self._project()
