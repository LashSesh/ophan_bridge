"""Synthetic counterexperiments, never hardware measurements."""
import copy,json
from pathlib import Path
from carrier_contract import manifest,preflight
CASES=['rehearsal','tracking_loss','reference_reset','missing_metrics','native_flags','emulated_webxr']
def dataset(case):
    raw=Path(__file__).with_name('sources').joinpath('carrier_rehearsal.jsonl').read_bytes()
    if case=='rehearsal':return raw,manifest()
    template=json.loads(raw.splitlines()[0]);rows=[];api='WebXR' if case=='emulated_webxr' else 'OpenXR';m=manifest('synthetic',api)
    for i in range(8):
        f=copy.deepcopy(template);f.update(frame_index=i,monotonic_time_ns=(i+1)*11111111,source_api=api,source_epoch=0,reference_space='LOCAL')
        f['head_pose']['position_m']=[i/100,0,0]
        if case=='tracking_loss':
            if i in [2,3]:f.pop('tracking_state')
            if i==4:f['tracking_state']='POSITION_VALID'
            if i==5:f.update(tracking_state='UNAVAILABLE',head_pose=None,views=[])
        if case=='reference_reset' and i>=3:
            if i==3:rows.append(dict(record_kind='event',kind='reference_reset',monotonic_time_ns=f['monotonic_time_ns']-1,previous=0,epoch=1,reference_space='STAGE'))
            f.update(source_epoch=1,reference_space='STAGE')
        if case=='missing_metrics':
            f.pop('registration_error_m');f.pop('application_frame_ms');f.pop('provenance_ref');f['monotonic_time_ns']+=2**53
        if case=='native_flags':
            f['head_location_flags']=3 if i in [2,3] else 15;f['view_state_flags']=3;f['capture_status']=dict(xrLocateSpace=-1 if i==4 else 0,xrLocateViews=-1 if i==5 else 0)
        if case=='emulated_webxr':
            f.update(emulated_position=i in [2,3],predicted_display_time_ns=None,predicted_display_period_ns=None,application_frame_ms=None,registration_error_m=None,callback_time_ns=f['monotonic_time_ns'],callback_interval_ns=None if i==0 else 11111111)
        rows.append(f)
    rows.append(dict(record_kind='event',kind='interaction',action='select',roundtrip_ok=True,monotonic_time_ns=rows[-1]['monotonic_time_ns']+1))
    raw=(''.join(json.dumps(x,ensure_ascii=True)+'\n' for x in rows)).encode('ascii');preflight(raw,m);return raw,m
