"""Versioned finite sensor channels; the worker reads only the requested channel.
The shipped source is synthetic. Source hashes do not authenticate a device.
"""
import copy
from grfps_l2 import fields,ident,require
from noisy_certificate import hash64
from trace_import import uint,strict_load
from mapping import hashof

PROFILE='grfps-live-box-sensor/1'
def seal(kind,x):return hashof(kind,dict(profile=PROFILE,value=x))


def validate_points(ps):
    require(type(ps) is dict and 1<=len(ps)<=8,'point_count')
    for k,p in ps.items():
        require(ident(k),'landmark');fields(p,'center radius')
        require(type(p['center']) is list and len(p['center'])==2 and all(type(x) is int and abs(x)<=16 for x in p['center']),'point_domain')
        require(uint(p['radius'],1),'point_radius')
    return ps


def validate_source(w):
    fields(w,'profile provenance windows');require(w['profile']==PROFILE,'sensor_profile')
    fields(w['provenance'],'kind device');require(w['provenance']['kind'] in ['synthetic','recorded'] and ident(w['provenance']['device']),'source_provenance')
    require(type(w['windows']) is dict and 1<=len(w['windows'])<=4,'windows')
    ids=set()
    for name,channels in w['windows'].items():
        require(ident(name),'window_id');fields(channels,'coarse fine')
        for c in channels.values():
            fields(c,'outcome points');require(c['outcome'] in ['OK','OCCLUDED','ERROR'],'outcome')
            if c['outcome']=='OK':validate_points(c['points']);ids.update(c['points'])
            else:require(c['points'] is None,'failed_points')
    require(len(ids)<=8,'landmark_limit');return w


def capture(w,request):
    validate_source(w);p=request['payload'];name=p['window'];mode=p['mode']
    require(name in w['windows'] and mode in ['coarse','fine'],'channel')
    c=w['windows'][name][mode]
    return dict(profile=PROFILE,source_ref=seal('Source',w),provenance=copy.deepcopy(w['provenance']),
                window=name,mode=mode,outcome=c['outcome'],points=copy.deepcopy(c['points']))


def validate_capture(o,r):
    fields(o,'profile source_ref provenance window mode outcome points')
    require(o['profile']==PROFILE and hash64(o['source_ref']),'capture_profile')
    fields(o['provenance'],'kind device');require(o['provenance']['kind'] in ['synthetic','recorded'] and ident(o['provenance']['device']),'capture_source')
    require(o['window']==r['payload']['window'] and o['mode']==r['payload']['mode'],'capture_channel')
    require(o['outcome'] in ['OK','OCCLUDED','ERROR'],'capture_outcome')
    if o['outcome']=='OK':validate_points(o['points'])
    else:require(o['points'] is None,'failed_points')
    return o


def fixture(case='refinement'):
    from trace_examples import points
    if case=='cycle':
        shapes=dict(left=dict(A=[0,0],B=[2,0]),middle=dict(B=[0,0],C=[2,0]),right=dict(A=[0,0],C=[6,0]))
        windows={n:{mode:dict(outcome='OK',points=points(ps,0)) for mode in ['coarse','fine']} for n,ps in shapes.items()}
    else:
        coarse=dict(A=[0,0],B=[1,0],C=[0,6]);fine=dict(A=[0,0],B=[2,0],C=[0,6])
        if case=='consensus':coarse=fine=dict(A=[0,0],B=[6,0],C=[0,6])
        windows={n:dict(coarse=dict(outcome='OK',points=points(coarse,1)),fine=dict(outcome='OK',points=points(fine,0))) for n in ['left','right']}
    return dict(profile=PROFILE,provenance=dict(kind='synthetic',device='grid_channels'),windows=windows)
