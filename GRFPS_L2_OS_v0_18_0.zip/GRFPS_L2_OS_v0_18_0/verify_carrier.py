"""Reexecute exact XR bytes, carrier transitions and semantic observation ports."""
import json
from pathlib import Path
from grfps_l2 import canon
from carrier_contract import preflight,CarrierState
from carrier_fixtures import CASES
from carrier_runtime import html,export
from carrier_segments import replay
from operator_port import project

def verify(root,export_views=True):
    root=Path(root);out={};gallery=[]
    for name in CASES:
        d=root/name;r=replay(d/'journal',collect=True);m=r['machine'];expected=json.loads((d/'report.json').read_text());mf=json.loads((d/'carrier_manifest.json').read_text());cc,lines,end=preflight((d/'carrier.jsonl').read_bytes(),mf);assert cc==m.contract['carrier'];cs=CarrierState(mf);verified=0;known=0
        for before,e,after in zip(r['views'],r['events'],r['views'][1:]):
            assert project(after)==after['observation_port'];assert after['carrier']['physical_validation']=='Unknown';assert after['observation_port']['external_effects']==[]
            if e['kind']=='carrier_record':
                assert e['index']==cs.cursor and e['raw']==lines[cs.cursor];s=cs.apply(e['raw']);assert dict(s,ingested_at=e['at'])==after['carrier'];verified+=1
            else:assert before['carrier']==after['carrier']
            if e['kind']=='resume':assert after['geometry_answer']['epistemic']=='Unknown' and after['spent']==before['spent'] and after['search_budget']['spent']==before['search_budget']['spent']
            known+=after['geometry_answer']['epistemic']=='Known'
        assert verified==len(lines) and cs.snapshot()==end and known>0
        for k,v in [('transitions',m.seq),('head',r['head']),('state_digest',m.snapshot()['state_digest']),('spent',m.spent),('nodes_spent',m.nodes_spent),('requests',m.request_count)]:assert expected[k]==v
        out[name]=dict(transitions=m.seq,segments=r['index']+1,requests=m.request_count,spent=m.spent,nodes_spent=m.nodes_spent,source_records=verified,frames=end['frames'],events=end['events'],http_checks=expected['http_checks'],known_geometry_states=known,head=r['head'],state_digest=m.snapshot()['state_digest']);gallery.append(dict(name=name,views=r['views'],events=r['events'],head=r['head']))
        if export_views:export(d/'journal',d/'replay.html')
    if export_views:(root.parent/'carrier_demo.html').write_text(html(dict(mode='replay',cases=gallery)))
    return dict(cases=out,transitions=sum(x['transitions'] for x in out.values()),http_checks=sum(x['http_checks'] for x in out.values()),source_records=sum(x['source_records'] for x in out.values()),requests=sum(x['requests'] for x in out.values()),spent=sum(x['spent'] for x in out.values()),nodes_spent=sum(x['nodes_spent'] for x in out.values()),full_semantic_replay=True,physical_measurements=False,synthetic_inputs=True)
if __name__=='__main__':print(json.dumps(verify(Path(__file__).parent/'carrier_evidence_run'),indent=2))
