const fs=require('fs'),vm=require('vm'),assert=require('assert');let checks=0;
function load(path){const text=fs.readFileSync(path,'utf8'),els={};let network=0;const ctx={document:{getElementById:id=>els[id]||(els[id]={setAttribute(k,v){this[k]=v;}})},fetch(){network++;throw Error('network')}};vm.createContext(ctx);vm.runInContext(text.match(/<script>([\s\S]*?)<\/script>/)[1],ctx);assert.equal(network,0);checks++;return {t:ctx.mapTest,els};}
for(const name of ['east','north','consensus','outside']){
 const {t,els}=load('uncertain_evidence_run/'+name+'/replay.html');
 const views=t.DATA.views,idx=views.findIndex(s=>name==='consensus'?s.bridges[0].reason==='unanimous':s.bridges[0].epistemic==='Ambiguous');assert(idx>=0);t.render(idx);assert(els.bridges.textContent.includes('Kandidaten:'));checks++;
 const wanted=name==='outside'?s=>s.bridges[0].reason==='geometry_counterevidence':name==='consensus'?s=>s.bridges[0].epistemic==='Known'&&s.bridges[0].registration_status==='Ambiguous':s=>s.bridges[0].registration_status==='Known'&&s.bridges[0].value===(name==='east');assert(views.some(wanted));checks++;
 assert(views.every((s,i)=>!i||s.spent>=views[i-1].spent));checks++;
}
const {t}=load('uncertain_demo.html');const last=t.DATA.views.at(-1);t.accept(last);assert.throws(()=>t.accept({...last,sequence:last.sequence-1}));checks++;
console.log(JSON.stringify({checks,passed:true,visual_browser_review:false}));
