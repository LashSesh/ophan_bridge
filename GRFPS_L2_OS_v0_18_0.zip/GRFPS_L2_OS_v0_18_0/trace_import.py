"""Strict offline sensor-trace contract, captured-clock reducer and semantic replay.

The source is not authenticated. Hashes bind supplied bytes and decoded content;
they do not prove a device, physical accuracy, or the declared error bound.
"""
import copy
import hashlib
import json
import os
from pathlib import Path
from grfps_l2 import canon, fields, ident, require
from mapping import hashof
from noisy_certificate import validate_fixture, observation, evaluate, validate_observation, assess
from trace_geometry import solve

PROFILE='grfps-sensor-trace/1'
JOURNAL='grfps-trace-session/0.12.0'
CONTRACT=dict(units='model_grid_step',clock='recorded_ms',coordinate_limit=16,
              radius_limit=1,pose_translation_limit=8,max_windows=4,max_landmarks=8,
              max_records=64,window_ttl=100,calibration_ttl=1000,
              window_cost=2,monitor_cost=1,max_bytes=262144)


def seal(kind,value):return hashof(kind,dict(profile=JOURNAL,value=value))
def uint(v,hi):return type(v) is int and 0<=v<=hi


def strict_load(data):
    require(type(data) is bytes and len(data)<=CONTRACT['max_bytes'],'file_size')
    def pairs(ps):
        d={}
        for k,v in ps:
            require(k not in d,'duplicate_json_key');d[k]=v
        return d
    try:
        return json.loads(data.decode('utf-8'),object_pairs_hook=pairs,
                          parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite_json')))
    except (UnicodeError,RecursionError) as e:raise ValueError('invalid_json') from e


def certificate(trace):
    w=trace['calibration']['series']
    campaign=dict(fit=dict(observation=observation(w,'fit')),
                  checks={s:dict(observation=observation(w,s)) for s in ['check0','check1']})
    result=evaluate(campaign);require(result['status']=='PASS','imported_calibration_rejected')
    return result['certificate']


def validate(trace):
    fields(trace,'profile contract provenance query calibration solver_node_limit budget records')
    require(trace['profile']==PROFILE and canon(trace['contract'])==canon(CONTRACT),'trace_protocol')
    p=trace['provenance'];fields(p,'kind device description')
    require(p['kind'] in ['synthetic','recorded'] and ident(p['device']) and type(p['description']) is str and 1<=len(p['description'])<=160,'provenance')
    q=trace['query'];fields(q,'kind a b')
    require(q['kind']=='x_greater' and ident(q['a']) and ident(q['b']) and q['a']!=q['b'],'query')
    c=trace['calibration'];fields(c,'series sampled_at')
    validate_fixture(c['series']);fields(c['sampled_at'],'fit check0 check1')
    times=[c['sampled_at'][s] for s in ['fit','check0','check1']]
    require(all(uint(t,3600000) for t in times) and times[0]<times[1]<times[2] and times[2]-times[0]<CONTRACT['calibration_ttl'],'calibration_times')
    certificate(trace)
    require(type(trace['solver_node_limit']) is int and 1<=trace['solver_node_limit']<=100000,'solver_limit')
    require(uint(trace['budget'],256),'budget')
    records=trace['records'];require(type(records) is list and 1<=len(records)<=64,'record_count')
    at=times[-1];windows=set();landmarks=set()
    for e in records:
        require(type(e) is dict and e.get('kind') in ['window','monitor','tick','frame'],'record_kind')
        require(uint(e.get('at'),3600000) and e['at']>=at,'record_clock');at=e['at']
        if e['kind'] in ['tick','frame']:fields(e,'kind at');continue
        require(uint(e.get('sampled_at'),3600000) and times[-1]<=e['sampled_at']<=at and uint(e.get('frame'),64),'sample_clock_frame')
        if e['kind']=='monitor':
            fields(e,'kind at sampled_at frame observation');validate_observation(e['observation']);continue
        fields(e,'kind at sampled_at frame window outcome points')
        require(ident(e['window']) and e['outcome'] in ['OK','OCCLUDED','ERROR'],'window_record')
        windows.add(e['window'])
        if e['outcome']!='OK':require(e['points'] is None,'failed_points');continue
        require(type(e['points']) is dict and 1<=len(e['points'])<=8,'points')
        for name,p in e['points'].items():
            fields(p,'center radius');require(ident(name),'landmark_id');landmarks.add(name)
            require(type(p['center']) is list and len(p['center'])==2 and all(type(v) is int and abs(v)<=16 for v in p['center']),'coordinate')
            require(uint(p['radius'],1),'radius')
    require(len(windows)<=4 and len(landmarks)<=8,'trace_domain')
    return trace


class TraceMachine:
    def __init__(self,trace,source_bytes_ref):
        self.trace=copy.deepcopy(validate(trace));self.source_bytes_ref=source_bytes_ref
        self.trace_ref=seal('Trace',trace);self.cert=certificate(trace)
        self.cert_ref=seal('ImportedCalibration',dict(certificate=self.cert,window_contract=CONTRACT,
            source_ref=self.trace_ref,sampled_at=trace['calibration']['sampled_at']))
        self.at=trace['calibration']['sampled_at']['check1'];self.cursor=0;self.spent=0
        self.frame=0;self.windows={};self.revoked=False;self.breaches=0
        self.monitor=dict(sampled_at=self.at,frame=0,status='WITHIN',record_ref=self.cert_ref)
        self.last=dict(status='IMPORTED');self._geometry_cache=None

    def live_windows(self):
        return {k:v['points'] for k,v in self.windows.items() if v['frame']==self.frame and self.at<v['sampled_at']+CONTRACT['window_ttl']}

    def snapshot(self):
        live=self.live_windows()
        key=canon(live)
        if self._geometry_cache is None or self._geometry_cache[0]!=key:
            self._geometry_cache=(key,solve(live,self.cert['candidates'],self.trace['query'],self.trace['solver_node_limit'],CONTRACT['pose_translation_limit']))
        geometry=copy.deepcopy(self._geometry_cache[1]);m=self.monitor
        monitor='REVOKED' if self.revoked else m['status'] if m and m['frame']==self.frame and self.at<m['sampled_at']+CONTRACT['calibration_ttl'] else 'UNKNOWN'
        status='Unknown';value=None;reason=geometry['reason']
        if monitor!='WITHIN':reason='calibration_'+monitor.lower()
        elif geometry['status']=='FEASIBLE':
            status='Known' if len(geometry['values'])==1 else 'Ambiguous'
            value=geometry['values'][0] if status=='Known' else None
        s=dict(profile=JOURNAL,trace_ref=self.trace_ref,source_bytes_ref=self.source_bytes_ref,
            sequence=self.cursor,total_records=len(self.trace['records']),at=self.at,frame=self.frame,
            clock='recorded_ms',phase='END' if self.cursor==len(self.trace['records']) else 'REPLAYING',
            spent=self.spent,budget=self.trace['budget'],last=copy.deepcopy(self.last),
            provenance=self.trace['provenance'],query=self.trace['query'],
            query_frame='calibrated_window:'+geometry['root'] if geometry['root'] else None,
            calibration=dict(ref=self.cert_ref,candidates=self.cert['candidates'],monitor=monitor,breaches=self.breaches),
            live_windows=live,geometry=geometry,
            answer=dict(epistemic=status,value=value,reason=reason),
            next_record=self.cursor if self.cursor<len(self.trace['records']) else None)
        s['state_digest']=seal('State',s);return s

    def step(self):
        require(self.cursor<len(self.trace['records']),'end_of_trace')
        e=self.trace['records'][self.cursor];self.at=e['at'];ref=seal('Record',dict(trace_ref=self.trace_ref,index=self.cursor,event=e))
        cost=CONTRACT['window_cost'] if e['kind']=='window' else CONTRACT['monitor_cost'] if e['kind']=='monitor' else 0
        self.last=dict(record_ref=ref,status='TICK',cost=0)
        if self.spent+cost>self.trace['budget']:self.last['status']='BUDGET_EXHAUSTED'
        else:
            self.spent+=cost;self.last['cost']=cost
            if e['kind']=='frame':
                self.frame+=1;self.windows={};self.monitor=None;self.last['status']='FRAME'
            elif e['kind'] in ['window','monitor']:
                ttl=CONTRACT['window_ttl'] if e['kind']=='window' else CONTRACT['calibration_ttl']
                old=self.windows.get(e.get('window')) if e['kind']=='window' else self.monitor
                if e['frame']!=self.frame:self.last['status']='OLD_FRAME'
                elif self.at>=e['sampled_at']+ttl:self.last['status']='EXPIRED'
                elif old and e['sampled_at']<old['sampled_at']:self.last['status']='OLDER_SAMPLE'
                elif e['kind']=='window':
                    if e['outcome']=='OK':self.windows[e['window']]=copy.deepcopy(e)
                    else:self.windows.pop(e['window'],None)
                    self.last['status']=e['outcome']
                else:
                    result=assess(e['observation']['points'],self.cert['candidates'],3)
                    self.monitor=dict(sampled_at=e['sampled_at'],frame=self.frame,status=result['status'],record_ref=ref)
                    self.last['status']=result['status']
                    if result['status']=='DRIFT' and not self.revoked:self.revoked=True;self.breaches+=1
        self.cursor+=1;return self.snapshot()


def import_bytes(data):
    return TraceMachine(strict_load(data),hashlib.sha256(data).hexdigest())


def atomic_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+'.tmp')
    # One owner per session. A complete immutable replacement; no append repair.
    with temporary.open('wb') as stream:
        stream.write(canon(value)+b'\n');stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,path)


def new_session(data):
    m=import_bytes(data)
    return dict(profile=JOURNAL,source_bytes_ref=m.source_bytes_ref,trace=m.trace,
                initial_digest=m.snapshot()['state_digest'],records=[])


def replay(session):
    fields(session,'profile source_bytes_ref trace initial_digest records')
    require(session['profile']==JOURNAL,'session_profile')
    h=session['source_bytes_ref'];require(type(h) is str and len(h)==64 and all(c in '0123456789abcdef' for c in h),'source_hash')
    m=TraceMachine(session['trace'],h);views=[m.snapshot()]
    require(views[0]['state_digest']==session['initial_digest'],'initial_state')
    require(type(session['records']) is list and len(session['records'])<=len(m.trace['records']),'session_records')
    head=seal('SessionStart',dict(source_bytes_ref=h,initial_digest=session['initial_digest']))
    for row in session['records']:
        expected=transition(m,head);require(canon(row)==canon(expected),'semantic_replay_mismatch')
        head=row['digest'];views.append(m.snapshot())
    return dict(machine=m,views=views,head=head)


def transition(m,head):
    before=m.snapshot();event=copy.deepcopy(m.trace['records'][m.cursor]);after=m.step()
    row=dict(sequence=m.cursor,parent=head,event=event,pre=before['state_digest'],post=after['state_digest'],output=m.last)
    row['digest']=seal('Transition',row);return copy.deepcopy(row)


def advance(session,steps=None):
    rr=replay(session);m=rr['machine'];head=rr['head'];remaining=len(m.trace['records'])-m.cursor
    count=remaining if steps is None else steps;require(uint(count,64),'steps')
    out=copy.deepcopy(session)
    for _ in range(min(count,remaining)):
        row=transition(m,head);out['records'].append(row);head=row['digest']
    return out
