"""Read one declared orientation-set fixture. No external sensor authentication."""
import sys,time
from pathlib import Path
from grfps_l2 import canon,loads,fields,require
from uncertain_bridge import validate_probe,seal

def main():
    request=loads(sys.stdin.buffer.read(65537));fields(request,'registration start_ns offset exposure')
    data=Path(sys.argv[1]).read_bytes();require(len(data)<=65536,'world_size');w=validate_probe(loads(data))
    sectors=w['registrations'][request['registration']]
    at=request['offset']+(time.monotonic_ns()-request['start_ns'])//1000000
    sys.stdout.buffer.write(canon(dict(sectors=sectors,sampled_at=at,sample_ref=seal('OrientationWorld',w),exposure=request['exposure'])))
if __name__=='__main__':main()
