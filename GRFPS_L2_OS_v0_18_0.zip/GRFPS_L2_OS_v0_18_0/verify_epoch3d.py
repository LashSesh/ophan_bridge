import json
from pathlib import Path
from carrier_contract import preflight,CarrierState
from uncertain3d import compile_certificate,projection,verify_witness
from epoch_registration import validate_plan
from epoch3d_fixtures import CASES
from epoch3d_runtime import html,export
from epoch3d_segments import replay
def verify(root,export_views=True):
    root=Path(root);out={};gallery=[]
    for name in CASES:
        d=root/name;r=replay(d/'journal',collect=True);m=r['machine'];expected=json.loads((d/'report.json').read_text());plan=json.loads((d/'registration_plan.json').read_text());mf=json.loads((d/'carrier_manifest.json').read_text());cc,lines,_=preflight((d/'carrier.jsonl').read_bytes(),mf);validate_plan(plan,cc,lines);assert cc==m.contract['carrier'] and plan==m.contract['registration_schedule'];cs=CarrierState(mf);last=None;records=0;witnesses=0;admissions=0;seen=[];by_epoch={x['bundle']['source']['epoch']:x for x in plan['entries']};current=None
        for before,e,after in zip(r['views'],r['events'],r['views'][1:]):
            if e['kind']=='epoch_registration_result':
                current=by_epoch[e['epoch']];assert e['certificate']==compile_certificate(current['bundle'],cc);admissions+=1
            if e['kind']=='carrier_record':
                assert e['index']==cs.cursor and e['raw']==lines[cs.cursor];row=json.loads(e['raw']);cs.apply(e['raw']);records+=1
                if row['record_kind']=='frame':last=e['raw']
                elif row.get('kind')=='reference_reset':last=None;current=None;assert after['registration_certificate'] is None and after['registration_history']==before['registration_history']
            entry=current or by_epoch.get(cs.epoch) or plan['entries'][0];b=entry['bundle'];g=projection(b,after['registration_certificate'],cs.snapshot(),last)
            if after['registration_certificate'] is None:g['reason']='epoch_registration_pending' if cs.epoch in by_epoch else 'epoch_unbound'
            g['source_epoch']=cs.epoch;assert g==after['registered3d'];assert g['physical_validation']=='Unknown' and g['facticity']=='Simulated';assert after['observation_port']['joining']==dict(spatial='Unknown',clock='Unknown') and not after['observation_port']['external_effects']
            if e['kind']=='carrier_record':seen.append((cs.epoch,g['status'],g['reason']))
            for w in g['witnesses'].values():
                local=[[a-err,z+err] for (a,z),err in zip(cs.latest['pose']['position_um'],b['sensor_error_um'])];assert verify_witness(b,w,local);witnesses+=1
            if e['kind']=='resume':
                for key in ['registered3d','registration_certificate','registration_history','registration_work']:assert before[key]==after[key]
        assert records==len(lines) and admissions==expected['compiler_subprocesses']==len(m.registration_history)
        if name in ['correlated_empty','search_limit']:assert all(x[1]=='Unknown' for x in seen)
        if name in ['baseline','noncentral_anchors']:assert seen[0][1]=='Known' and seen[-1][1]=='Known'
        if name=='two_witnesses':assert any(x[1]=='Ambiguous' for x in seen)
        if name in ['epoch_rebind','resume_barrier']:assert any(x[0]==1 and x[1]=='Known' for x in seen) and len(m.registration_history)==2
        if name=='epoch_missing':assert seen[-1][2]=='epoch_unbound' and len(m.registration_history)==1
        if name=='epoch_return':assert seen[-1]==(2,'Unknown','epoch_unbound') and m.carrier_state.reference=='LOCAL'
        if name=='epoch_bad_control':assert seen[-1][2]=='CONTROL_UNPROVEN' and m.registration_history[0]['status']=='PASS'
        if name=='resume_barrier':assert expected['barrier_preserved'] and any(e['kind']=='resume' and before['carrier']['cursor']==6 and before['registration_certificate'] is None for before,e in zip(r['views'],r['events']))
        for k,v in [('transitions',m.seq),('head',r['head']),('state_digest',m.snapshot()['state_digest']),('spent',m.spent),('nodes_spent',m.nodes_spent),('requests',m.request_count)]:assert expected[k]==v
        out[name]=dict(transitions=m.seq,segments=r['index']+1,requests=m.request_count,spent=m.spent,nodes_spent=m.nodes_spent,http_checks=expected['http_checks'],source_records=records,admissions=admissions,statuses=[x['status'] for x in m.registration_history],verified_witnesses=witnesses,compiler_work=m.registration_work,head=r['head'],state_digest=m.snapshot()['state_digest']);gallery.append(dict(name=name,views=r['views'],events=r['events'],head=r['head']))
        if export_views:export(d/'journal',d/'replay.html')
    if export_views:(root.parent/'GRFPS_Second_Layer_Demo.html').write_text(html(dict(mode='replay',cases=gallery)))
    totals={k:sum(x[k] for x in out.values()) for k in ['transitions','requests','spent','nodes_spent','http_checks','source_records','admissions']};totals['compiler_work']={k:sum(x['compiler_work'][k] for x in out.values()) for k in m.registration_work};return dict(cases=out,**totals,full_semantic_replay=True,physical_measurements=False)
if __name__=='__main__':print(json.dumps(verify(Path(__file__).parent/'epoch3d_evidence_run'),indent=2))
