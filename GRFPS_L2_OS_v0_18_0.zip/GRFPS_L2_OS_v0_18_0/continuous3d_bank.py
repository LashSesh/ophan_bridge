import copy
from grfps_l2 import require,fields,canon
from carrier_bank import CarrierBank,PROFILE as CARRIER_BANK_PROFILE,checkpoint
from continuous3d import validate,compile_certificate,projection,seal as reg_seal
PROFILE='grfps-continuous3d-bank/0.17.0'
def seal(kind,value):return reg_seal(kind,dict(profile=PROFILE,value=value))
def config(base,bundle):return dict(copy.deepcopy(base),profile=PROFILE,registration3d=copy.deepcopy(bundle))
class Continuous3DBank(CarrierBank):
    def __init__(self,c):
        require(c.get('profile')==PROFILE and 'registration3d' in c,'registered3d_profile');validate(c['registration3d'],c['carrier']);base=copy.deepcopy(c);base.pop('registration3d');base['profile']=CARRIER_BANK_PROFILE;super().__init__(base);self.contract=copy.deepcopy(c);self.registration_certificate=None;self.last_carrier_frame_raw=None;self.registered3d=projection(c['registration3d'],None,self.carrier_state.snapshot());self.registration_work=dict(cell_evaluations=0,splits=0,retained_cells=0,discarded_cells=0,rate_trials=0)
    def snapshot(self):
        s=super().snapshot();s['profile']=PROFILE;s['registered3d']=copy.deepcopy(self.registered3d);s['registration_certificate']=copy.deepcopy(self.registration_certificate);s['registration_work']=copy.deepcopy(self.registration_work)
        port=s['observation_port'];port['profile']='grfps-observation-port/3';g=s['registered3d'];port['objects'].append(dict(id='registered_carrier_query',referent=g['carrier_ref'],projection='continuous_axis_query/1',value=g['value'],epistemic=g['status'],facticity=g['facticity'],scope=g['target']['reference_space'],evidence=g['certificate_ref']))
        port['registered_target']=dict(reference_space=g['target']['reference_space'],status=g['status'],certificate_ref=g['certificate_ref']);port['loss'].extend(['interval_cover_may_be_strict','orientation_not_registered','registered_target_is_separate_from_room_grid']);port['digest']=reg_seal('WorldSnapshot',{k:v for k,v in port.items() if k!='digest'})
        s['contract_ref']=seal('Contract',self.contract);s['state_digest']=seal('State',{k:v for k,v in s.items() if k!='state_digest'});return s
    def _registered(self,e):
        if e.get('kind')=='registration3d_result':
            fields(e,'kind at certificate');require(self.phase=='RUNNING' and not self.active.paused and self.registration_certificate is None and self.carrier_state.cursor==0,'registration_lifecycle');expected=compile_certificate(self.contract['registration3d'],self.contract['carrier']);require(canon(e['certificate'])==canon(expected),'registration_semantics');self._active(dict(kind='tick',at=e['at']));self.registration_certificate=copy.deepcopy(expected);self.registration_work=copy.deepcopy(expected['work']);self.last=dict(kind=e['kind'],status=expected['status'],certificate_ref=expected['digest'])
        else:
            super()._registered(e)
            if e.get('kind')=='carrier_record':
                from carrier_contract import read_line
                if read_line(e['raw'])['record_kind']=='frame':self.last_carrier_frame_raw=e['raw']
        if e.get('kind') in ['carrier_record','registration3d_result']:self.registered3d=projection(self.contract['registration3d'],self.registration_certificate,self.carrier_state.snapshot(),self.last_carrier_frame_raw)
