"""Full semantic history and archived source checks, including every Known state."""
import json
from pathlib import Path
from geometry_segments import replay
from geometry_sensor import capture
from geometry_runtime import html,export
from noisy_certificate import observation,seal as chart_seal
from trace_geometry import verify_witness

CASES=['live_refinement','live_cycle','live_limit','live_expiry']
def verify(directory,export_views=True):
    root=Path(directory);out={};gallery=[]
    for name in CASES:
        d=root/name;r=replay(d/'journal',collect=True);m=r['machine'];s=m.snapshot();expected=json.loads((d/'report.json').read_text());counts=dict(window=0,solver=0,calibration=0,witnesses=0,known_states=0)
        for k,value in dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,requests=m.request_count,nodes_spent=m.nodes_spent,head=r['head'],state_digest=s['state_digest']).items():assert expected[k]==value,(name,k)
        for before,e,after in zip(r['views'],r['events'],r['views'][1:]):
            pending=before['pending']
            if e['kind']=='geometry_result' and e['outcome']=='OK':
                if pending['organ']=='geometry_window':
                    source=json.loads((d/'samples'/(e['data']['source_ref']+'.json')).read_text())
                    assert capture(source,pending)==e['data'];counts['window']+=1
                else:
                    counts['solver']+=1;i=pending['payload']['inputs']
                    for w in e['data']['witnesses'].values():assert verify_witness(i['windows'],i['candidates'],i['query'],w,i['pose_bound']);counts['witnesses']+=1
            if e['kind']=='calibration_result' and e['outcome']=='OK':
                o=e['observation'];source=json.loads((d/'samples'/(o['series_ref']+'.json')).read_text())
                assert observation(source,pending['payload']['stage'])==o;counts['calibration']+=1
            assert after['search_budget']['spent']+after['search_budget']['reserved']<=after['search_budget']['total']
            if after['geometry_answer']['epistemic']=='Known':
                result=after['geometry_solution']['result'];assert after['drift']['status']=='VALID' and result['complete'] and result['status']=='FEASIBLE'
                assert all(x['complete'] and x['solutions']>0 for x in result['support'])
                assert result['values']==[after['geometry_answer']['value']]
                assert name=='live_refinement' and after['geometry_answer']['value'] is True
                counts['known_states']+=1
            if e['kind']=='resume':
                assert after['spent']==before['spent'] and after['search_budget']['spent']==before['search_budget']['spent'] and after['calibration']==before['calibration']
                assert after['geometry_answer']['epistemic']=='Unknown' and after['box_windows']=={}
        if name=='live_refinement':
            labels=[x['stage'] for x in expected['stages']]
            assert labels==['coarse_geometry_ambiguous','autonomous_fine_measurement_known','pause_committed','anchor_loss_does_not_reroot','anchor_reacquired_and_resolved','drift_revokes_live_answer','return_keeps_revocation','fresh_calibration_proposal','new_revision_fresh_windows_and_solver']
            assert expected['autonomous_refinement'] and m.calibration['revision']==2 and m.breaches==1
        else:assert counts['known_states']==0
        out[name]=dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,requests=m.request_count,nodes_spent=m.nodes_spent,head=r['head'],state_digest=s['state_digest'],http_checks=expected['http_checks'],verified=counts)
        gallery.append(dict(name=name,views=r['views'],events=r['events'],head=r['head']))
        if export_views:export(d/'journal',d/'replay.html')
    if export_views:(root.parent/'geometry_demo.html').write_text(html(dict(mode='replay',cases=gallery)))
    return dict(cases=out,transitions=sum(x['transitions'] for x in out.values()),http_checks=sum(x['http_checks'] for x in out.values()),requests=sum(x['requests'] for x in out.values()),nodes_spent=sum(x['nodes_spent'] for x in out.values()),synthetic_sources_only=True,full_semantic_replay=True)

if __name__=='__main__':print(json.dumps(verify(Path(__file__).parent/'geometry_evidence_run'),indent=2))
