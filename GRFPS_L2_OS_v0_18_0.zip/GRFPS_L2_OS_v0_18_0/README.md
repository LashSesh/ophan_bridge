# GRFPS · 2nd-Layer Synthetic Perception OS · 0.18.0

Diese Phase integriert **unsichere lokale Kalibrieranker und eigene Registrierungszulassungen für neue Referenzepochen** in die bestehende Runtime. Compiler, Owner, Journal, Replay, Beobachtungsport, Hauptdemo und Gesamtentwurf verwenden denselben gebundenen Vertrag. Die bisherigen Profile einschließlich WFB-Bewertung, Physical-Carrier-Anschluss und OPERATORIUM-Verwertung bleiben erhalten.

Nach einem Reset verliert das aktuelle Zertifikat seine Gültigkeit. Die neue Epoche benötigt ihr eigenes geprüftes Ergebnis und anschließend einen passenden neuen Frame. Alte Zulassungen bleiben mit ihrer ursprünglichen Bedeutung in der Historie erhalten. Ein alter Raumname in einer neuen Epoche reaktiviert kein früheres Zertifikat.

## Start

Python 3.10+ mit Standardbibliothek; Node.js für die Anzeigeprüfungen. Der Ordner muss beim Erststart fehlen.

```bash
python epoch3d_runtime.py --out mein_raum --open
python epoch3d_runtime.py --out epochen --case epoch_rebind --open
python epoch3d_runtime.py --out epochen --resume --open
python validate.py
```

Standardlaufzeit: drei Sekunden, veränderbar über `--duration`. Die mitgelieferte **GRFPS_Second_Layer_Demo.html** enthält zwölf offline lesbare Replays. Die laufende lokale Runtime verbindet synthetische historische XR-Daten mit der erhaltenen aktiven Geometrie. Der XR-Import wird durch seine Ausführung nicht zu einer Liveaufnahme.

Eigene Eingaben müssen als zusammengehörige Spur, Manifest und vollständiger Epochenplan bereitstehen:

```bash
python epoch3d_runtime.py --out eigene_sitzung   --trace carrier.jsonl --manifest carrier_manifest.json   --registration registration_plan.json --open
python run_epoch3d_demo.py --out neue_versuche
```

Die neue Registrierungsdatei ist ein Plan mit `profile` und `entries`. Jeder Eintrag enthält `after_record`, `activation_ref` und einen vollständigen `bundle`. Vollständige synthetische Beispiele stehen in `epoch3d_evidence_run/*/registration_plan.json`. Veränderliche Journale sollten in einem stabilen lokalen Arbeitsverzeichnis laufen; das Paket hält geprüfte unveränderliche Versuchskopien.

## Gemeinsamer Fit mit unsicheren Ankern

Für jeden lokalen Anker gilt eine Box Li, für seine Referenz eine Box Wi. Ein Fit benötigt **eine gemeinsame Rotation R und Verschiebung t**, mit je einem Punkt xi in Li und R·xi+t in Wi für sämtliche Anker. Die Mittelpunkte sind mögliche Zeugenversuche; sie ersetzen keine Unsicherheitsbox.

| Bestandteil | Semantik |
|---|---|
| Rotation | Eine bis vier rationale Quaternionkarten mit kontinuierlichen Parameterboxen |
| Lokale Fit-Anker | Drei bis acht ganzzahlige µm-Boxen; auch Punkte oder Strecken zulässig |
| Referenzanker | Zugehörige ganzzahlige µm-Boxen |
| Gemeinsame Transformation | Ein R,t für alle ursprünglichen Korrespondenzen |
| Äußere Fitmenge | Intervallschnitt hält sämtliche zulässigen Transformationen |
| Konkreter Fit | Ein u, ein t und je ein direkt geprüfter lokaler und Referenzpunkt |
| Ankerprüfung | Zwölf lineare Ungleichungen; höchstens 220 Ebenentripel bei festem R,t |
| Globale Suche | Höchstens 127 Zellprüfungen, Tiefe 8; unvollständig |
| Kontrolle | Sämtliche gehaltenen äußeren Kontrollboxen müssen getragen sein |
| Known | Gesamte äußere Abfragemenge trägt dieselbe Antwort bei freigegebenem Zertifikat |
| Ambiguous | Zwei gegen alle ursprünglichen Bedingungen geprüfte, entgegengesetzte Modellzeugen |
| Unknown | Fehlende Zulassung, ungültiger Bereich oder offener Nachweis |

Bei festem R,t bilden lokale und zurücktransformierte Referenzbox zusammen ein beschränktes Polyeder. Zwei schnelle Punktversuche gehen der vollständigen Prüfung aller C(12,3)=220 aktiven Ebenentripel voraus. Jeder nichtleere beschränkte Schnitt besitzt einen Extrempunkt mit drei unabhängigen aktiven Ebenen; dies gilt auch für entartete Boxen. Die linearen Gleichungen und Ungleichungen werden exakt mit `Fraction` ausgewertet.

**Diese Vollständigkeit gilt nur bei festem R,t.** Pro geprüftem Rotationsparameter versucht der Compiler höchstens drei Verschiebungen aus dessen äußerer Box: Mitte, untere Ecke und obere Ecke. Bei Bedarf wird zusätzlich ein vorhandener Elternparameter erneut geprüft. Die globale Suche kann zulässige Fits übersehen. Ein gescheiterter Zeugenversuch entfernt deshalb keine äußere Rotationszelle und beweist keine leere gemeinsame Fitmenge.

Die Ankerboxen beschreiben ein Produktmodell. Zusätzliche Abhängigkeiten zwischen unterschiedlichen Ankern, etwa ein gemeinsamer korrelierter Messfehler, sind darin nicht codiert. Konkrete Zeugen sind zulässige **Modellzustände**, keine nachträglich ermittelten tatsächlichen Messwerte. Der Einschluss kann trotz exakter Arithmetik zu breit sein.

## Neue Referenzepochen

| Ereignis | Zulassung und Raumantwort |
|---|---|
| Anfang | Epoche null wird vor dem ersten Rohrecord geprüft |
| Reset mit geplantem Vertrag | Aktuelles Zertifikat und letzte Pose entfallen; `epoch_registration_pending` |
| Reset ohne geplanten Vertrag | `epoch_unbound`; keine Wiederverwendung älterer Zulassungen |
| Neue Zulassung PASS | Neues Zertifikat; passende neue Pose und gültige Horizonte weiterhin erforderlich |
| Neue Zulassung fehlgeschlagen | Fehlerstatus bleibt sichtbar; kein Rückgriff auf den alten Fit |
| Neustart an der Resetgrenze | Offene Zulassung, Historie und Arbeit bleiben erhalten |
| Rückkehr zum alten Raumnamen | Neue Generation benötigt dennoch eigene Zulassung |

Ein Plan bindet eine bis vier Einträge, streng steigende Epochen und Cursor sowie ein gemeinsames Ziel und dieselbe Abfrage. Spätere Aktivierungsbelege müssen Hashes tatsächlich importierter Resetrecords sein. Belegkennungen werden zwischen Epochen nicht wiederverwendet. Die Uhrfitpunkte liegen frühestens beim Reset, Kontrollen danach und vor dem gültigen Quellhorizont. Die ganze transformierte Zeithülle muss in den Zielhorizont passen. Räumliche Anker besitzen keine eigenen Aufnahmezeitfelder; deren zeitliche Herkunft wird dadurch nicht bewiesen.

Das eigene Ereignis `epoch_registration_result` ist nur an der exakten Aktivierungsgrenze zulässig. Der Owner berechnet das vollständige Zertifikat neu, bevor er es akzeptiert. Verspätete, verfrühte, doppelte, veränderte und epochenfremde Ergebnisse werden atomar abgewiesen. Auch ein negatives Ergebnis verbraucht die einzelne Zulassung dieser Epoche. Snapshot- und Planlesezugriffe kompilieren nicht.

Die Historie hält Vertrags- und Zertifikatreferenzen, Status, Aktivierungsbeleg, Cursor, Zulassungszeit und Arbeit. Vollständige Zertifikate bleiben im Journal. Wiederanlauf prüft die ursprüngliche Spur und den Plan vor dem nächsten Commit; Replay führt alle Übergänge semantisch erneut aus.

**Die Kalibrierverträge sind vorab gebundene historische Daten.** Der spätere Compiler startet erst an seiner Resetgrenze, nimmt aber noch keine neuen, vorher unbekannten Kalibrierbelege entgegen. Unterschiedliche Belegkennungen beweisen keine physisch unabhängige Erhebung.

## Ausgeführte Prüfung

**560 Python-Tests und 419 JavaScript-Prüfungen bestanden**, darunter 40 neue Python-Tests und 61 neue Anzeigeprüfungen.

Die neuen Prüfungen decken den exakten Ankertest, degenerierte Schnitte, ursprüngliche Korrespondenzen, gemeinsame Transformation, Budgetgrenzen, echte Compilerprozesse, Epochenbindung, manipulationsfreie Ablehnung und Wiederanlauf ab. Ein positiver Polyederfall benötigt 30 Ebenentripel. Der vorhandene mathematische Testbestand prüft weiterhin Quaternionen, Orthogonalität, Determinante, Intervallinklusion und erhaltene Blattpartitionen.

Zwei Gegenfälle zeigen den Unterschied zur Punktannahme und zur bloßen Achsenhülle:

- Ein gültiger Fit mit verschieden verschobenen Ankern innerhalb ihrer Boxen erreicht PASS. Ersetzt man alle lokalen Boxen durch ihre Mitten, wird der Fit unmöglich.
- Bei R mit cos=12/13 und sin=5/13, L=[−13,13]²×{0}, W={(17,17,0)} und t=0 überlappen die Achsenhüllen. Der eindeutige Rücktransport hat jedoch x=289/13>13. Alle 220 Ebenentripel scheitern; der Compiler bleibt bei `FIT_EXISTENCE_UNPROVEN`.

Zwölf tatsächliche Owner-/Compiler-/Worker-/HTTP-Läufe mit synthetischen Eingaben:

| Fall | Übergänge | XR-Records | Zulassungen | HTTP |
|---|---:|---:|---:|---:|
| `baseline` | 75 | 12 | 1 | 34 |
| `noncentral_anchors` | 76 | 12 | 1 | 35 |
| `correlated_empty` | 77 | 12 | 1 | 36 |
| `search_limit` | 76 | 12 | 1 | 35 |
| `two_witnesses` | 74 | 12 | 1 | 33 |
| `epoch_rebind` | 75 | 13 | 2 | 32 |
| `epoch_missing` | 78 | 13 | 1 | 36 |
| `epoch_return` | 76 | 14 | 2 | 32 |
| `epoch_bad_control` | 84 | 13 | 2 | 33 |
| `resume_barrier` | 88 | 13 | 2 | 41 |
| `tracking_loss` | 76 | 12 | 1 | 35 |
| `horizon` | 76 | 12 | 1 | 35 |
| **Gesamt** | **931** | **150** | **16** | **417** |

Die 16 Compilerzulassungen führen 48 Zellprüfungen, 16 Teilungen, 32 gehaltene Blätter, 48 Raten- und Verschiebungsversuche, 142 Ankerprüfungen und 220 Ebenentripel aus. Die geerbte aktive Geometrie führt 137 Aufträge mit 162 Messkosteneinheiten und 648 logischen Suchknoten aus. Die Zähler erfassen logische Arbeit, keine sämtliche Owner-/Verifikations-/Replaykosten und keine Echtzeitgarantie.

Ein eigener Prozessversuch unterbricht die Sitzung genau nach dem Reset und vor Zulassung. Nach Wiederanlauf entsteht das neue Zertifikat in einem neuen Compilerprozess. Der zusätzliche CLI-Test setzt seinen Cursor von **4 auf 13** fort und erreicht zwei Zulassungen in Epoche eins. Ein veränderter Plan wird vor einem weiteren Commit abgewiesen.

Alle gespeicherten Verläufe werden vollständig semantisch geprüft; HTTP-Projektionen stimmen mit dem Owner überein. Owner und Prüfer verwenden dieselbe Compilerimplementierung und sind kein unabhängig entwickeltes vollständiges Solverpaar. Die 46 ursprünglichen Physical-Carrier-Tests bleiben mit ihrem Bericht aus 0.15.0 gesondert erhalten.

Die Anzeigelogik wurde unter Node.js ausgeführt. Eine visuelle Browserprüfung, native OpenXR-Kompilation und reale Headsetsitzung wurden nicht durchgeführt. Der Gesamtentwurf wurde eigenständig mit LaTeX kompiliert, gerendert und geprüft.

## Grenzen und nächste Phase

Der neue Zielraum `uncertain_lab3d` besitzt eine eigene Modellsemantik. Physische Geräteherkunft, realistische Sensorgrenzen, unabhängige Referenzmessungen, registrierte Orientierung, frei veränderliche Uhrdrift, der Anschluss an `room_grid` und bestätigte externe Wirkungen bleiben offen.

Die nächste Phase betrifft **die explizite Aufnahme neuer Kalibrierbelege während einer Sitzung und eine daran gebundene Registrierungsrevision**. Alte Aussagen müssen ihre ursprünglichen Verträge behalten. Eine vollständigere gemeinsame Translationssuche und ein explizites Modell gemeinsamer Ankerfehler sind weitere mathematische Erweiterungen. Physische Referenzmessungen setzen tatsächlich verfügbare Aufnahmen voraus.

## Dateien

- `GRFPS_2nd_Layer_OS.pdf` / `.tex`: integrierter Gesamtentwurf einschließlich aller Vorprofile.
- `GRFPS_Second_Layer_Demo.html`: zwölf aktuelle Replays mit Epochenhistorie und Ankerzeugen.
- `uncertain3d.py`: exakter Ankertest, konservativer Compiler, Projektion und Zeugenprüfung.
- `epoch_registration.py`: vollständiger gebundener Epochenplan.
- `epoch3d_bank.py`, `epoch3d_runtime.py`, `epoch3d_segments.py`, `uncertain3d_worker.py`: Owner-, Prozess- und Journalanschluss.
- `epoch3d_fixtures.py`, `run_epoch3d_demo.py`, `verify_epoch3d.py`: Gegenversuche und vollständige Replayprüfung.
- `EPOCH3D_CONTRACT.md`: kompakter normativer Eingabe- und Zustandsvertrag.
- `validation.json`, `validation.log`, `PROJECT_STATE.json`: ausgeführte Prüfungen und Übergabestand.
- `continuous3d_demo.html`, `finite3d_demo.html`, ältere Demos und Quellen: erhaltene Vorprofile.
