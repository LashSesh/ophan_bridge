# Bewertung der beiden neuen Ressourcen — GRFPS 0.15.0

**Beide Ressourcen sind verwendbar, mit klar begrenztem Umfang.** Das ZIP liefert praktische Transportbausteine; OPERATORIUM liefert einen passenden Vertrag zwischen Wahrnehmung, Ansicht und Handlung. Weder das ZIP noch die Monografie belegen einen bereits validierten physischen Second Layer.

## Physical Carrier Integration v0.6.0

Die vollständige Archivstruktur wurde erfasst: 363 Einträge, 5.529.624 unkomprimierte Bytes. Schwerpunktprüfung: Recorder, Evaluator, Capability-Ausgabe, Schemas, native OpenXR-Brücke, WebXR-Probe, Tests und vorhandene Versuchsbelege. Die 46 mitgelieferten Tests wurden mit Python 3.12 erneut ausgeführt; alle bestehen. `sources/upstream_test_report.txt` dokumentiert dies.

| Material | Entscheidung | Umsetzung |
|---|---|---|
| JSONL-Frames und Ereignisse | Verwertet | Bytegenauer, begrenzter Import in bestehendes Journal |
| Probelauf mit 180 Frames und 5 Ereignissen | Verwertet | Vollständiger erster Prozessversuch; Herkunft Simulated |
| Messklassen und Provenienz | Konkretisiert | Produzentenangabe, Aufnahmeherkunft und physische Validierung getrennt |
| Physischer Evaluator und Capability-Siegel | Semantik verworfen | Keine automatische Hochstufung zu Gerätevalidierung |
| WebXR-Probe | Neu implementiert | Keine Ersatzpose; explizite Herkunft, Reset, partielle Position und Messlücken |
| Native OpenXR-Brücke | Als Referenz erhalten | Keine vollständige Anwendung und kein nativer Build behauptet |
| Weitere Rotor-/Graphmodule | Nicht in diesen Anschluss übernommen | Kein ausreichender zusätzlicher Nutzen für den begrenzten XR-Port; Vorprofile bleiben verfügbar |

`audit_carrier_intake.py` importiert zwei unveränderte Originalmodule aus dem hashgebundenen ZIP. Die Prüfung benötigt nur die Standardbibliothek. Sie reproduziert acht konkrete Grenzen:

1. Der DRY_RUN-Probelauf wird im Evaluator als MEASURED_PASS und in der Capability-Ausgabe als DEVICE_MEASURED ausgezeichnet.
2. Fehlendes Tracking wird als vollständig getrackt gezählt.
3. POSITION_VALID wird ebenfalls als vollständiges Tracking gewertet.
4. Eine nachträglich geänderte Pose bei unveränderten Record-/Sessionhashes kann die Auswertung weiter bestehen.
5. Ein Frame überschreibt die im Recorder vorgegebene Sitzungskennung.
6. Eine Positionsliste mit einem Boolean und falscher Dimension wird angenommen.
7. Fehlende Interaktionsereignisse lassen die Interaktionsprüfung bestehen.
8. Ein leeres externes Displaymessobjekt erfüllt die entsprechende Anwesenheitsprüfung.

Eine Gegenkontrolle zeigt: Fehlende Registrierungswerte werden tatsächlich ausgelassen und ergeben ohne Messwerte keinen Registrierungspass. Es wäre falsch, den Originalcode pauschal als Null-Imputation aller fehlenden Kennzahlen zu beschreiben.

Die alten Hashes werden nicht als Authentizitätsnachweis übernommen. Die neue Runtime prüft Rohbytes, Statussemantik und den gesamten Verlauf erneut. Ein vollständig gefälschter Produzent bleibt außerhalb der Aussagekraft reiner Inhaltsprüfung.

OpenXR unterscheidet VALID- von TRACKED-Bits; deshalb darf die native Gültigkeit nicht stillschweigend als vollständiges Tracking erscheinen. Die neue Implementierung berücksichtigt vorhandene Bits und Erfassungsfehler konservativ. [Khronos: XrSpaceLocationFlagBits](https://registry.khronos.org/OpenXR/specs/1.1/man/html/XrSpaceLocationFlagBits.html).

WebXR kennt geschätzte Positionen und Referenzraum-Resets. Der neue Recorder bindet diese Angaben, hält Callbackzeit und optionales predictedDisplayTime getrennt und schätzt daraus keine Displaylatenz. [W3C: WebXR Device API, Abschnitte 4.3, 5.1 und Referenzräume](https://www.w3.org/TR/webxr/).

## OPERATORIUM v1.0.0

Die 98-seitige Monografie wurde einschließlich der substanziellen Kapitel und Anhänge gelesen. Sie enthält eine normative Architektur mit 39 Records und 36 Invarianten, jedoch keine hier ausführbare Implementierung und keine gemessenen Ergebnisse zu ihren Interfacehypothesen.

| Passage im bereitgestellten PDF | Verwertung im Projekt |
|---|---|
| PDF 21–22: acht versionierte Ports | Begrenzter eigener Beobachtungsport; keine gemeinsamen veränderlichen Innentypen |
| PDF 25: Facticity und Promotionsgrenzen | Simulated, Recorded-Deklaration und physische Validierung getrennt |
| PDF 27–28: semantische Anker und ViewContract | Referent, Projektion, Bestimmtheit, Scope und Evidenz in jedem Viewobjekt |
| PDF 37–38: Compilation und Gegenbelege | Gesamtdatei vorprüfen; ungültige Eingaben vor Outputmutation ablehnen |
| PDF 43–44: verkörperte Schleife | Trägerbewegung und lokale Ansicht nicht mit Weltänderung gleichsetzen |
| PDF 53–57: Wirkungsabgleich, Ereignis- und Eingangszeit | Eingabe ist keine Wirkung; Einlesezeit ist keine Aufnahmefrische |
| PDF 63: Replayklassen | Semantisches Maschinenreplay; kein Anspruch auf vollständiges ExperienceReplay |
| PDF 69–79: Invarianten und H1–H10 | Prüfinspiration; keine pauschale Konformitäts- oder Überlegenheitsbehauptung |

Der neue Port liefert zwei Objekte: die konditionale geometrische Antwort und die berichtete Trägerpose. Lokale Inspektion und Replay sind möglich; externe Effekte werden nicht freigegeben. Raum- und Uhranschluss zwischen 3D-Träger und 2D-Modell bleiben Unknown.

Mathematische Grenzen: Gleiche Ports **als Schematypen** beweisen keine Austauschbarkeit; dazu braucht es passendes beobachtbares Verhalten. Ein endlicher Compiler mit neun Pässen beweist keine polynomiale Gesamtlaufzeit. Ein deklarierter symmetrisch-monoidaler Kompositionsentwurf benötigt seine Gesetzes- und Abschlussnachweise. Ein Hash ist ein Inhaltsbezeichner unter kryptographischer Annahme, kein Beweis richtiger Darstellung oder physischer Herkunft. Die Hypothesen H1–H10 bleiben experimentell zu prüfen.

## Ergebnis und Anschluss

Version 0.15.0 realisiert den nützlichen gemeinsamen Kern: XR-Rohdaten werden über einen typisierten, begrenzten Vertrag in den bestehenden Owner aufgenommen und als nachvollziehbarer Beobachtungszustand dargestellt. Die neue Demo belegt diesen Ablauf mit sechs real ausgeführten Prozessversuchen auf synthetischen Daten. Der nächste Schritt ist eine reale Aufnahme mit unabhängig bezeugter Raum- und Uhrregistrierung. Die neue WebXR-Seite ist dafür ein vorbereitetes Erfassungswerkzeug, kein bereits erbrachter Hardwareversuch.

## Quellenidentität

- Physical-Carrier-ZIP: `92e8099645eabd4e2938bee436cd1bfdb921796940d0719fd4d3a9880b7063b4`.
- OPERATORIUM-PDF: `b9fc1b1350a3b2ae901670cd6321ff607194c353a853aafd347cc3f4b19ae2ef`.

Originale bleiben unter `sources` unverändert erhalten. Prüfdatum: 14. September 2026.
