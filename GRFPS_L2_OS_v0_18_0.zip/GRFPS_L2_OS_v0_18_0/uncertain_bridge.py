"""Finite set-valued model registration; universal answers and active discrimination."""
import copy
from pathlib import Path
from grfps_l2 import canon,fields,ident,uint,require
from domain_bridge import RegisteredBank,config as registered_config,checkpoint
from organ_bank import seal as bank_seal
from mapping import hashof
PROFILE='grfps-uncertain-bank/0.8.0'
def seal(kind,x):return hashof(kind,dict(profile=PROFILE,value=x))
def config(world,field,probe):
    c=registered_config(world,field);c.update(profile=PROFILE,probe_world=str(Path(probe).resolve()),probe_cost=2)
    c['registrations']=[dict(id='AB_ray',window='left',a='A',b='B',query='ray_clear',error_bound=2,hypotheses=[dict(id='east',sector=0),dict(id='north',sector=1)])]
    return c
def scope_ref(c):return seal('Scope',dict(sectors=4,cells=c['scope_cells'],units='model_grid_step',sampling='one_cell_per_step',contract='finite_radial_model@1'))
def probe_fixture():return dict(profile='grfps-orientation-fixture/1',registrations=dict(AB_ray=[0]))
def validate_probe(w):
    fields(w,'profile registrations');require(w['profile']=='grfps-orientation-fixture/1' and type(w['registrations']) is dict and 1<=len(w['registrations'])<=16,'probe_world')
    for k,v in w['registrations'].items():
        require(ident(k) and type(v) is list and 1<=len(v)<=4 and all(uint(s) and s<4 for s in v) and v==sorted(set(v)),'probe_sectors')
    return w

class UncertainBank(RegisteredBank):
    def __init__(self,c):
        fields(c,'profile bank segment_records max_segments scope_cells registrations probe_world probe_cost');canon(c)
        require(c['profile']==PROFILE and type(c['probe_world']) is str and 0<len(c['probe_world'])<=1024,'profile_path')
        require(uint(c['probe_cost']) and 1<=c['probe_cost']<=16,'probe_cost')
        require(type(c['registrations']) is list and 1<=len(c['registrations'])<=16,'registration_limit')
        legacy=copy.deepcopy(c);legacy.pop('probe_world');legacy.pop('probe_cost');legacy['profile']='grfps-registered-bank/0.7.0';legacy['registrations']=[]
        for r in c['registrations']:
            fields(r,'id window a b query error_bound hypotheses')
            require(uint(r['error_bound']) and r['error_bound']<=32,'error_bound')
            hs=r['hypotheses'];require(type(hs) is list and 1<=len(hs)<=4,'hypothesis_limit');ids=set();sectors=set()
            for h in hs:
                fields(h,'id sector');require(ident(h['id']) and h['id'] not in ids and uint(h['sector']) and h['sector']<4 and h['sector'] not in sectors,'hypothesis_identity');ids.add(h['id']);sectors.add(h['sector'])
            s=hs[0]['sector'];n=c['scope_cells'];v=[[n,0],[0,n],[-n,0],[0,-n]][s]
            legacy['registrations'].append({k:r[k] for k in ['id','window','a','b','query']}|dict(vector=v,sector=s))
        super().__init__(legacy);self.contract=copy.deepcopy(c);self.probes={};self.probe_attempts={}
    def bind_proposal(self):return None
    def context(self,r):
        state=self.mapper.snapshot();ps=[p for p in state['patches'] if self.patch_windows.get(p['id'])==r['window'] and r['a'] in p['points'] and r['b'] in p['points']]
        refs=sorted(hashof('Patch',p) for p in ps);n=self.contract['scope_cells'];vectors=[[n,0],[0,n],[-n,0],[0,-n]]
        quarantined=any(c['quarantined'] and any(p['id'] in c['patches'] for p in ps) for c in state['atlas']['components'])
        hs=[h for h in r['hypotheses'] if ps and all(max(abs(p['points'][r['b']][i]-p['points'][r['a']][i]-vectors[h['sector']][i]) for i in range(2))<=r['error_bound'] for p in ps)]
        binding=seal('GeometrySupport',dict(registration=r,patches=refs,frame=self.mapper.frame,scope_ref=scope_ref(self.contract)))
        e=self.probes.get(r['id']);valid=e is not None and e['binding']==binding and e['frame']==self.mapper.frame and self.mapper.at<e['sampled_at']+self.config['ttl']
        if valid:hs=[h for h in hs if h['sector'] in e['sectors']]
        return dict(hypotheses=hs,patch_refs=refs,binding=binding,probe=e if valid else None,quarantined=quarantined)
    def projections(self):
        out=[]
        for r in self.contract['registrations']:
            c=self.context(r);hs=c['hypotheses'];answers=[]
            for h in hs:
                e=self.boolean.get(self.bool_key(r['query'],h['sector']));fresh=e is not None and self.bool_active(e);known=fresh and e['outcome']=='OK'
                answers.append(dict(id=h['id'],sector=h['sector'],status='Known' if known else 'Unknown',value=e['value'] if known else None,field_ref=bank_seal('Boolean',e) if fresh else None))
            supported=bool(hs) and not c['quarantined'];complete=supported and all(a['status']=='Known' for a in answers);values={a['value'] for a in answers if a['status']=='Known'}
            unanimous=complete and len(values)==1
            reason='unobserved_geometry' if not c['patch_refs'] else 'geometry_counterevidence' if not supported else 'missing_field_evidence' if not complete else 'unanimous' if unanimous else 'hypothesis_disagreement'
            out.append(dict(id=r['id'],a=r['a'],b=r['b'],predicate=r['query'],gate='ADMITTED' if unanimous else 'HOLD',reason=reason,
                epistemic='Known' if unanimous else 'Ambiguous' if complete else 'Unknown',value=answers[0]['value'] if unanimous else None,
                registration_status='Unknown' if not supported else 'Known' if len(hs)==1 else 'Ambiguous',hypotheses=answers,
                witness_ref=c['binding'],patch_refs=c['patch_refs'],scope_ref=scope_ref(self.contract),probe_ref=seal('ProbeEvidence',c['probe']) if c['probe'] else None))
        return out
    def plan(self):
        if self.phase!='RUNNING' or self.active.paused or self.pending:return None
        for r in self.contract['registrations']:
            c=self.context(r)
            if c['quarantined'] or len(c['hypotheses'])<2:continue
            # Fill relevant unanswered sectors before buying a geometric discriminator.
            for h in c['hypotheses']:
                k=self.bool_key(r['query'],h['sector']);e=self.boolean.get(k)
                if (not e or not self.bool_active(e) or e['outcome']!='OK') and self.mapper.at-self.attempts.get(k,-self.config['refresh'])>=self.config['refresh']:
                    cost=self.config['costs'][r['query']]
                    if self.spent+cost<=self.config['budget']:return dict(organ=r['query'],payload=dict(query=r['query'],sector=h['sector']),cost=cost,frame=self.mapper.frame)
            projection=next(x for x in self.projections() if x['id']==r['id'])
            last=self.probe_attempts.get(r['id'],-self.config['refresh'])
            if projection['epistemic']=='Ambiguous' and self.mapper.at-last>=self.config['refresh'] and self.spent+self.contract['probe_cost']<=self.config['budget']:
                return dict(organ='registration_probe',payload=dict(registration=r['id'],binding=c['binding']),cost=self.contract['probe_cost'],frame=self.mapper.frame)
        return super().plan()
    def snapshot(self):
        s=super().snapshot();s.update(profile=PROFILE,bridges=self.projections(),probe_evidence=copy.deepcopy(self.probes),probe_attempts=copy.deepcopy(self.probe_attempts),contract_ref=seal('Contract',self.contract))
        s['bank'].append(dict(id='registration_probe',type='OrientationSet',cost=self.contract['probe_cost'],last_dispatch=None))
        s['state_digest']=seal('State',{k:v for k,v in s.items() if k!='state_digest'});return s
    def _registered(self,e):
        k=e.get('kind')
        if k=='bind':raise ValueError('automatic_set_registration')
        if k=='dispatch' and e.get('proposal',{}).get('organ')=='registration_probe':
            fields(e,'kind at proposal');require(self.phase=='RUNNING','stopped');self._active(dict(kind='tick',at=e['at']));p=self.plan();require(p is not None and canon(p)==canon(e['proposal']),'proposal_binding')
            self.spent+=p['cost'];self.request_count+=1
            r=dict(id='bank'+str(self.request_count),organ=p['organ'],cost=p['cost'],frame=self.mapper.frame,issued_at=e['at'],deadline=e['at']+self.config['timeout'],payload=copy.deepcopy(p['payload']))
            r['exposure']=seal('ProbeExposure',r);self.pending=r;self.probe_attempts[r['payload']['registration']]=e['at'];self.last=dict(kind=k,request=r)
        elif k=='probe_result':
            fields(e,'kind at request exposure outcome sectors sampled_at sample_ref');r=self.pending
            require(self.phase=='RUNNING' and r and r['organ']=='registration_probe' and e['request']==r['id'] and e['exposure']==r['exposure'],'probe_binding')
            require(e['outcome'] in ['OK','ERROR','TIMEOUT'],'probe_outcome');require(e['outcome']!='TIMEOUT' or e['at']>=r['deadline'],'early_timeout')
            if e['outcome']=='OK':
                v=e['sectors'];require(type(v) is list and 1<=len(v)<=4 and all(uint(s) and s<4 for s in v) and v==sorted(set(v)),'probe_sectors')
                require(uint(e['sampled_at']) and r['issued_at']<=e['sampled_at']<=e['at'],'sample_time')
                require(type(e['sample_ref']) is str and len(e['sample_ref'])==64 and all(c in '0123456789abcdef' for c in e['sample_ref']),'sample_ref')
            else:require(e['sectors'] is None and e['sampled_at'] is None and e['sample_ref'] is None,'failure_payload')
            self._active(dict(kind='tick',at=e['at']));reg=self.registration(r['payload']['registration']);ctx=self.context(reg)
            status='SUPERSEDED' if r['frame']!=self.mapper.frame or r['payload']['binding']!=ctx['binding'] else 'TIMEOUT' if e['at']>r['deadline'] else e['outcome']
            if status=='OK':self.probes[reg['id']]=dict(request=r['id'],frame=r['frame'],binding=r['payload']['binding'],sectors=e['sectors'],sampled_at=e['sampled_at'],sample_ref=e['sample_ref'])
            self.pending=None;self.last=dict(kind=k,status=status)
        elif k=='scoped_boolean':
            fields(e,'kind at scope_ref event');require(e['scope_ref']==scope_ref(self.contract),'scope_binding');require(type(e['event']) is dict and e['event'].get('kind')=='boolean_result' and e['event'].get('at')==e['at'],'scoped_type')
            from organ_bank import OrganBank
            OrganBank._apply(self,e['event']);self.last=dict(self.last,kind=k,scope_ref=e['scope_ref'])
        else:super()._registered(e)
