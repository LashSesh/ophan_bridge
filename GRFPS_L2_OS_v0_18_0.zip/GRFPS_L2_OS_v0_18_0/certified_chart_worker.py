"""One bounded, read-only chart acquisition per process."""
import sys,time
from pathlib import Path
from grfps_l2 import loads,canon,fields,require
from calibration_certificate import validate_chart,seal
try:
    with Path(sys.argv[1]).open('rb') as f:raw=f.read(65537)
    require(len(raw)<=65536,'chart_size');w=validate_chart(loads(raw));q=loads(sys.stdin.buffer.read(8193));fields(q,'start_ns offset exposure')
    at=q['offset']+(time.monotonic_ns()-q['start_ns'])//1000000
    sys.stdout.buffer.write(canon(dict(chart=w,sampled_at=at,sample_ref=seal('Chart',w),exposure=q['exposure'])))
except Exception:sys.exit(2)
