"""Bounded exact interval cover of continuous quaternion charts.
No floating-point decision arithmetic. Local fit anchors are genuine uncertainty boxes.
An outer enclosure proves Known; Ambiguous requires two concrete model witnesses.
"""
import copy,itertools
from fractions import Fraction as F
from pathlib import Path
from grfps_l2 import require,fields,canon,loads
import registration3d as old
from carrier_contract import read_line
from registration3d import integer,ns,label,box,timebox
PROFILE='grfps-uncertain3d/0.18.0'
MAX_BYTES=65536
frac=old.frac;unfrac=old.unfrac
def seal(kind,value):return old.sha(canon(dict(profile=PROFILE,kind=kind,value=value)))
def encode(x):
    if isinstance(x,F):return frac(x)
    if isinstance(x,(tuple,list)):return [encode(v) for v in x]
    return x
def decode_box(x):return [[unfrac(v) for v in a] for a in x]
def scalar(x):return [F(x),F(x)]
def add(a,b):return [a[0]+b[0],a[1]+b[1]]
def neg(a):return [-a[1],-a[0]]
def sub(a,b):return add(a,neg(b))
def mul(a,b):
    v=[x*y for x in a for y in b];return [min(v),max(v)]
def square(a):return [F(0) if a[0]<=0<=a[1] else min(x*x for x in a),max(x*x for x in a)]
def divide_positive(a,b):
    require(b[0]>0,'positive_interval_denominator');return mul(a,[1/b[1],1/b[0]])
def sum_interval(xs):
    r=scalar(0)
    for x in xs:r=add(r,x)
    return r
def matrix(u,base):
    """R_base * R(1,u), normalized quaternion written without a square root."""
    s=sum_interval([square(x) for x in u]);den=add(scalar(1),s)
    cross=[[scalar(0),neg(u[2]),u[1]],[u[2],scalar(0),neg(u[0])],[neg(u[1]),u[0],scalar(0)]]
    m=[]
    for i in range(3):
        row=[]
        for j in range(3):
            # Diagonal u_i^2 is kept as a square, with a nonnegative lower bound.
            v=mul(scalar(2),square(u[i]) if i==j else mul(u[i],u[j]));v=add(v,mul(scalar(2),cross[i][j]))
            if i==j:v=add(v,sub(scalar(1),s))
            row.append(divide_positive(v,den))
        m.append(row)
    return [[a if v>0 else neg(a) for a in m[abs(v)-1]] for v in base]
def exact_matrix(u,base):return [[x[0] for x in row] for row in matrix([scalar(v) for v in u],base)]
def transform(m,box):return [sum_interval([mul(a,x) for a,x in zip(row,box)]) for row in m]
def exact_transform(m,p):return [sum(a*x for a,x in zip(row,p)) for row in m]
def translate(a,t):return [add(x,y) for x,y in zip(a,t)]
def intersection(a,b):return [[max(x[0],y[0]),min(x[1],y[1])] for x,y in zip(a,b)]
def nonempty(a):return all(x<=y for x,y in a)
def inside(a,b):return all(y[0]<=x[0] and x[1]<=y[1] for x,y in zip(a,b))
def parameter(x):
    require(type(x) is list and len(x)==2 and all(type(v) is str and len(v)<=11 for v in x),'parameter_fraction')
    try:r=F(int(x[0]),int(x[1]))
    except (ValueError,ZeroDivisionError):raise ValueError('parameter_fraction')
    require(frac(r)==x and abs(r.numerator)<=10**9 and r.denominator<=10**9 and abs(r)<=1,'parameter_canonical_bound');return r
def validate_common(b,carrier):
    fields(b,'profile origin source target valid_source_ns valid_reference_ns sensor_error_um translation_bound_um rates_ppm spatial_fit spatial_check clock_fit clock_check query')
    require(b['profile']==PROFILE and b['origin'] in ['synthetic','recorded'],'registration_profile')
    fields(b['source'],'trace_sha256 session_id carrier_id reference_space epoch timebase')
    m=carrier['manifest'];q=b['source'];require(q['trace_sha256']==carrier['raw_sha256'] and q['session_id']==m['session_id'] and q['carrier_id']==m['carrier_id'] and q['timebase']==m['timebase'],'registration_source_binding');label(q['reference_space']);require(type(q['epoch']) is int and 0<=q['epoch']<=128 and (q['epoch']!=0 or q['reference_space']==m['reference_space']),'source_epoch')
    fields(b['target'],'reference_space timebase axes unit');label(b['target']['reference_space']);label(b['target']['timebase']);require(b['target']['axes']==['x','y','z'] and b['target']['unit']=='um','target_units')
    lo,hi=timebox(b['valid_source_ns']);timebox(b['valid_reference_ns']);require(lo<hi,'valid_horizon')
    require(type(b['sensor_error_um']) is list and len(b['sensor_error_um'])==3 and all(type(x) is int and 0<=x<=100000 for x in b['sensor_error_um']),'sensor_error')
    integer(b['translation_bound_um']);require(b['translation_bound_um']>=0,'translation_bound')
    rates=b['rates_ppm'];require(type(rates) is list and 1<=len(rates)<=5 and all(type(x) is int and 999000<=x<=1001000 for x in rates) and sorted(set(rates))==rates,'rates')
    seen=set()
    for group in ['spatial_fit','spatial_check','clock_fit','clock_check']:
        require(type(b[group]) is list and (3 if group=='spatial_fit' else 2)<=len(b[group])<=8,'observation_count')
        for row in b[group]:
            fields(row,'id evidence_ref local_um reference_um' if group.startswith('spatial') else 'id evidence_ref local_ns reference_ns');label(row['id']);label(row['evidence_ref']);require(row['id'] not in seen and row['evidence_ref'] not in seen,'disjoint_evidence');require(row['id']!=row['evidence_ref'],'evidence_identity');seen.update([row['id'],row['evidence_ref']])
            if group.startswith('spatial'):box(row['local_um']);box(row['reference_um'])
            else:ns(row['local_ns']);timebox(row['reference_ns'])
    fits=[ns(x['local_ns']) for x in b['clock_fit']];checks=[ns(x['local_ns']) for x in b['clock_check']]
    require(all(x<y for x,y in zip(fits,fits[1:])) and all(x<y for x,y in zip(checks,checks[1:])) and max(fits)<min(checks) and max(checks)<=lo,'clock_observation_order')
    fields(b['query'],'kind axis threshold_um');require(b['query']['kind']=='axis_greater' and type(b['query']['axis']) is int and 0<=b['query']['axis']<3,'query');integer(b['query']['threshold_um']);canon(b);return b

def validate(b,carrier):
    fields(b,'profile origin source target valid_source_ns valid_reference_ns sensor_error_um translation_bound_um rates_ppm spatial_fit spatial_check clock_fit clock_check query charts search')
    require(b['profile']==PROFILE,'continuous_profile')
    legacy={k:copy.deepcopy(v) for k,v in b.items() if k not in ['charts','search']};legacy['profile']=PROFILE;validate_common(legacy,carrier)
    require(type(b['charts']) is list and 1<=len(b['charts'])<=4,'chart_count');seen=set()
    for c in b['charts']:
        fields(c,'id base u');old.label(c['id']);require(c['id'] not in seen,'chart_identity');seen.add(c['id'])
        require(type(c['base']) is list and all(type(x) is int for x in c['base']) and c['base'] in old.ROTATIONS,'proper_chart_base')
        require(type(c['u']) is list and len(c['u'])==3,'parameter_box')
        for x in c['u']:require(type(x) is list and len(x)==2 and parameter(x[0])<=parameter(x[1]),'parameter_interval')
    s=b['search'];fields(s,'min_depth max_depth max_cells');require(all(type(v) is int for v in s.values()) and 0<=s['min_depth']<=3 and s['min_depth']<=s['max_depth']<=8 and len(b['charts'])<=s['max_cells']<=127,'search_bound');canon(b);return b
def fit_translation(b,m):
    bound=b['translation_bound_um'];t=[[F(-bound),F(bound)] for _ in range(3)]
    for row in b['spatial_fit']:
        a=transform(m,row['local_um']);w=row['reference_um'];t=intersection(t,[[F(w[j][0])-a[j][1],F(w[j][1])-a[j][0]] for j in range(3)])
    return t
def det3(m):
    a,b,c=m;return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def solve3(a,b):
    d=det3(a)
    if not d:return None
    return [det3([[b[i] if j==k else a[i][j] for j in range(3)] for i in range(3)])/d for k in range(3)]
def anchor_point(m,t,local,reference,work):
    """Exact feasibility for a bounded 3D polytope at a fixed rotation/shift."""
    work['anchor_checks']+=1;constraints=[]
    for j in range(3):
        axis=[F(int(k==j)) for k in range(3)];constraints.extend([(axis,F(local[j][1])),([-x for x in axis],F(-local[j][0]))])
        constraints.extend([(m[j],F(reference[j][1])-t[j]),([-x for x in m[j]],t[j]-F(reference[j][0]))])
    def valid(x):return all(sum(a*v for a,v in zip(row,x))<=bound for row,bound in constraints)
    center=[F(a+z,2) for a,z in local];refcenter=[F(a+z,2)-x for (a,z),x in zip(reference,t)];inverse=[sum(m[i][j]*refcenter[i] for i in range(3)) for j in range(3)];clamped=[max(F(a),min(F(z),x)) for x,(a,z) in zip(inverse,local)]
    for point in [center,clamped]:
        if valid(point):return point
    # A nonempty bounded polyhedron has a vertex, also in lower dimension.
    for planes in itertools.combinations(constraints,3):
        work['plane_triples']+=1;point=solve3([x[0] for x in planes],[x[1] for x in planes])
        if point is not None and valid(point):return point
    return None
def concrete_fit(b,u,base,work):
    m=exact_matrix(u,base);outer=fit_translation(b,[[scalar(x) for x in row] for row in m])
    if not nonempty(outer):return None
    candidates=[[(a+z)/2 for a,z in outer],[a for a,z in outer],[z for a,z in outer]];seen=set()
    for t in candidates:
        if tuple(t) in seen:continue
        seen.add(tuple(t));work['translation_trials']+=1;anchors=[]
        for row in b['spatial_fit']:
            x=anchor_point(m,t,row['local_um'],row['reference_um'],work)
            if x is None:break
            anchors.append(dict(id=row['id'],local_um=encode(x),reference_um=encode([a+z for a,z in zip(exact_transform(m,x),t)])))
        else:return dict(u=encode(u),translation_um=encode(t),anchors=anchors)
    return None

def clock_candidates(b):
    out=[]
    for ppm in b['rates_ppm']:
        a=F(ppm,1000000);lo=None;hi=None
        for row in b['clock_fit']:
            t=old.ns(row['local_ns']);w=old.timebox(row['reference_ns']);x,y=F(w[0])-a*t,F(w[1])-a*t;lo=x if lo is None else max(lo,x);hi=y if hi is None else min(hi,y)
        if lo>hi:continue
        checks=[]
        for row in b['clock_check']:
            t=old.ns(row['local_ns']);w=old.timebox(row['reference_ns']);x,y=a*t+lo,a*t+hi;checks.append(dict(id=row['id'],predicted_ns=encode([x,y]),passed=w[0]<=x and y<=w[1]))
        out.append(dict(rate_ppm=ppm,offset_ns=encode([lo,hi]),checks=checks,passed=all(x['passed'] for x in checks)))
    return out
def compile_certificate(b,carrier):
    validate(b,carrier);s=b['search'];pending=[dict(chart=c,u=decode_box(c['u']),depth=0,path='') for c in b['charts']];leaves=[];discarded=[];nodes=0;splits=0;budget_blocked=False;witness_work=dict(translation_trials=0,anchor_checks=0,plane_triples=0)
    while pending:
        cell=pending.pop(0);c=cell['chart'];u=cell['u'];m=matrix(u,c['base']);t=fit_translation(b,m);nodes+=1
        record=dict(chart_id=c['id'],path=cell['path'],depth=cell['depth'],base=c['base'],u=encode(u))
        if not nonempty(t):discarded.append(dict(record,reason='fit_interval_empty'));continue
        checks=[]
        for row in b['spatial_check']:
            predicted=translate(transform(m,row['local_um']),t);checks.append(dict(id=row['id'],predicted_um=encode(predicted),passed=inside(predicted,row['reference_um'])))
        midpoint=[(a+z)/2 for a,z in u];witness_point=midpoint;exact=concrete_fit(b,witness_point,c['base'],witness_work);has_witness=exact is not None
        if not has_witness and cell.get('inherited_witness') is not None:
            witness_point=cell['inherited_witness'];exact=concrete_fit(b,witness_point,c['base'],witness_work);has_witness=exact is not None
        passed=all(x['passed'] for x in checks);widths=[z-a for a,z in u];split_axis=max(range(3),key=lambda j:widths[j]);want_split=cell['depth']<s['min_depth'] or not passed or not has_witness
        if want_split and widths[split_axis]>0 and cell['depth']<s['max_depth']:
            if nodes+len(pending)+2<=s['max_cells']:
                middle=midpoint[split_axis]
                for side in range(2):
                    v=copy.deepcopy(u);v[split_axis][1-side]=middle;inherited=witness_point if has_witness and all(a<=x<=z for x,(a,z) in zip(witness_point,v)) else None;pending.append(dict(chart=c,u=v,depth=cell['depth']+1,path=cell['path']+str(side),inherited_witness=inherited))
                splits+=1;continue
            budget_blocked=True
        leaves.append(dict(record,rotation_interval=encode(m),translation_um=encode(t),checks=checks,passed=passed,fit_witness=exact if has_witness else None))
    clocks=clock_candidates(b);exists=any(x['fit_witness'] is not None for x in leaves)
    if not leaves:status='SPATIAL_FIT_EMPTY'
    elif not all(x['passed'] for x in leaves) or not exists:status='SEARCH_LIMIT' if budget_blocked else 'CONTROL_UNPROVEN' if not all(x['passed'] for x in leaves) else 'FIT_EXISTENCE_UNPROVEN'
    elif not clocks:status='CLOCK_FIT_EMPTY'
    elif not all(x['passed'] for x in clocks):status='CLOCK_CHECK_REJECTED'
    else:status='PASS'
    cert=dict(profile=PROFILE,bundle_ref=seal('Bundle',b),source=copy.deepcopy(b['source']),target=copy.deepcopy(b['target']),status=status,spatial_candidates=leaves,discarded_cells=discarded,clock_candidates=clocks,fit_existence_witnessed=exists,work=dict(cell_evaluations=nodes,splits=splits,retained_cells=len(leaves),discarded_cells=len(discarded),rate_trials=len(b['rates_ppm']),**witness_work),physical_validation='Unknown')
    cert['digest']=seal('Certificate',cert);return cert
def query_witnesses(b,cert,local):
    witnesses={};axis=b['query']['axis'];threshold=b['query']['threshold_um']
    for c in cert['spatial_candidates']:
        w=c['fit_witness']
        if w is None:continue
        u=[unfrac(x) for x in w['u']];shift=[unfrac(x) for x in w['translation_um']];m=exact_matrix(u,c['base'])
        for high in [False,True]:
            p=[F(x[int(high) if coefficient>=0 else int(not high)]) for x,coefficient in zip(local,m[axis])];mapped=[a+z for a,z in zip(exact_transform(m,p),shift)];value=mapped[axis]>threshold
            witnesses.setdefault(str(value).lower(),dict(chart_id=c['chart_id'],path=c['path'],base=c['base'],u=encode(u),local_um=encode(p),translation_um=encode(shift),reference_um=encode(mapped),anchors=copy.deepcopy(w['anchors']),value=value))
    return witnesses
def verify_fit_witness(b,w,base):
    u=[unfrac(x) for x in w['u']];t=[unfrac(x) for x in w['translation_um']];m=exact_matrix(u,base);assert all(abs(x)<=b['translation_bound_um'] for x in t);assert len(w['anchors'])==len(b['spatial_fit'])
    for row,anchor in zip(b['spatial_fit'],w['anchors']):
        assert row['id']==anchor['id'];point=[unfrac(x) for x in anchor['local_um']];assert all(a<=x<=z for x,(a,z) in zip(point,row['local_um']));mapped=[x+y for x,y in zip(exact_transform(m,point),t)];assert encode(mapped)==anchor['reference_um'] and all(a<=x<=z for x,(a,z) in zip(mapped,row['reference_um']))
    return True
def verify_witness(b,w,local):
    chart=next(x for x in b['charts'] if x['id']==w['chart_id']);u=[unfrac(x) for x in w['u']];assert w['base']==chart['base'] and all(a<=x<=z for x,(a,z) in zip(u,decode_box(chart['u'])));verify_fit_witness(b,w,chart['base'])
    t=[unfrac(x) for x in w['translation_um']];point=[unfrac(x) for x in w['local_um']];assert all(a<=x<=z for x,(a,z) in zip(point,local));mapped=[x+y for x,y in zip(exact_transform(exact_matrix(u,chart['base']),point),t)];assert encode(mapped)==w['reference_um'] and (mapped[b['query']['axis']]>b['query']['threshold_um'])==w['value'];return True
def projection(b,certificate,carrier,last_raw=None):
    g=dict(profile=PROFILE,status='Unknown',reason='registration_pending',facticity='Simulated' if carrier['origin']=='synthetic' or b['origin']=='synthetic' else 'Recorded',physical_validation='Unknown',temporal_scope='historical_file',target=copy.deepcopy(b['target']),query=copy.deepcopy(b['query']),value=None,values=[],enclosure_values=[],position_um=None,reference_time_ns=None,orientation='Unknown',certificate_ref=certificate['digest'] if certificate else None,carrier_ref=carrier['head'],rows=[],witnesses={})
    if certificate is None:return g
    require(certificate['bundle_ref']==seal('Bundle',b),'projection_bundle_binding')
    if certificate['status']!='PASS':g['reason']=certificate['status'];return g
    if carrier['epoch']!=b['source']['epoch'] or carrier['reference_space']!=b['source']['reference_space']:g['reason']='reference_scope_changed';return g
    last=carrier['latest']
    if not last or last['pose'] is None:g['reason']='pose_unavailable';return g
    raw=read_line(last_raw) if last_raw is not None else {}
    if type(raw.get('source_epoch')) is not int or raw.get('source_epoch')!=carrier['epoch'] or raw.get('reference_space')!=carrier['reference_space']:g['reason']='explicit_scope_missing';return g
    t=old.ns(last['source_time_ns']);lo,hi=old.timebox(b['valid_source_ns'])
    if not lo<=t<=hi:g['reason']='source_horizon';return g
    times=[[F(x['rate_ppm'],1000000)*t+unfrac(v) for v in x['offset_ns']] for x in certificate['clock_candidates']];lower=min(x[0] for x in times);upper=max(x[1] for x in times);g['reference_time_ns']=encode([lower,upper]);vlo,vhi=old.timebox(b['valid_reference_ns'])
    if lower<vlo or upper>vhi:g['reason']='reference_horizon';return g
    local=[[F(a-e),F(z+e)] for (a,z),e in zip(last['pose']['position_um'],b['sensor_error_um'])];rows=[];hulls=[];possible=set();axis=b['query']['axis'];threshold=b['query']['threshold_um']
    for c in certificate['spatial_candidates']:
        m=[decode_box(row) for row in c['rotation_interval']];world=translate(transform(m,local),decode_box(c['translation_um']));a,z=world[axis];vs=[False] if z<=threshold else [True] if a>threshold else [False,True];possible.update(vs);hulls.append(world);rows.append(dict(chart_id=c['chart_id'],path=c['path'],position_um=encode(world),enclosure_values=vs))
    w=query_witnesses(b,certificate,local);actual=sorted(x['value'] for x in w.values());hull=[[min(x[j][0] for x in hulls),max(x[j][1] for x in hulls)] for j in range(3)]
    status='Known' if len(possible)==1 else 'Ambiguous' if len(actual)==2 else 'Unknown';reason='universal_continuous_query' if status=='Known' else 'two_feasible_model_witnesses' if status=='Ambiguous' else 'enclosure_overlap'
    g.update(status=status,reason=reason,value=next(iter(possible)) if status=='Known' else None,values=actual,enclosure_values=sorted(possible),position_um=encode(hull),rows=rows,witnesses=w);return g
def load_bundle(path,carrier):
    with Path(path).open('rb') as f:raw=f.read(MAX_BYTES+1)
    require(0<len(raw)<=MAX_BYTES,'bundle_size');b=loads(raw);validate(b,carrier);return b
