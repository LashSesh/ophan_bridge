# GRFPS — 2nd-Layer Synthetic Perception OS, 0.16.0

Diese Phase liefert einen **begrenzten 3D-Raum- und Uhranschluss für historische Trägerpositionen**. Der Compiler erhält alle zulässigen Raum- und Uhrenkandidaten aus dem Fit. Separate Kontrollen müssen sämtliche Kandidaten tragen. Eine Antwort wird nur dann eindeutig, wenn alle gehaltenen Raumzustände denselben Wahrheitswert liefern.

Der Zielraum `lab3d` ist ein eigener dreidimensionaler Modellraum. Der Anschluss an die vorherige 2D-Geometrie `room_grid`, registrierte Orientierung, physische Gerätevalidierung und externe Wirkungen bleiben getrennte offene Nachweise.

## Ausführen

Python 3.10 oder neuer mit Standardbibliothek; Node.js für die ergänzenden Browserlogikprüfungen. Im entpackten Projektordner:

```sh
python registered3d_runtime.py --out mein_3d_raum --open
python registered3d_runtime.py --out mein_3d_raum --resume --open
python registered3d_runtime.py --out kontrollfehler --case partial_holdout --open
python run_registered3d_demo.py --out neue_3d_versuche
python validate.py
```

Der Standardstart erstellt eine synthetische Sitzung. Der Ausgabeordner muss fehlen. Standardlaufzeit: drei Sekunden; `--duration` passt sie an. Ein lokaler Loopbackserver zeigt den Ownerzustand; `replay.html` hält danach den historischen Verlauf fest. Resume erhält Zertifikat, Importcursor und Verbrauch. Änderungen an Rohspur oder Registrierungsvertrag werden vor einem neuen Commit abgewiesen.

Eigene Aufnahmen benötigen drei zusammengehörige Dateien:

```sh
python registered3d_runtime.py --out eigene_3d_sitzung --trace carrier.jsonl --manifest carrier_manifest.json --registration registration3d.json --open
```

`registration3d.json` bindet den exakten Rohdateihash. Seine Quellreferenz muss der anfänglichen Manifestreferenz und Epoche null entsprechen. Jeder registrierte Frame muss Referenzraum und Epoche ausdrücklich enthalten. Die Dateien im erzeugten Standardlauf sind vollständige Beispiele für die drei Formate. Daten ohne expliziten Referenzbezug können im alten Trägerprofil gelesen werden, erlauben aber keinen neuen registrierten 3D-Wert.

## Raumvertrag

| Bestandteil | Semantik |
|---|---|
| Rotationen | Genau 24 orientierungserhaltende vorzeichenbehaftete Achsenpermutationen |
| Rotation `[1,-3,2]` | `(x,y,z) → (x,−z,y)` |
| Verschiebung | Kontinuierliche Intervallbox mit ganzzahligen µm-Grenzen, innerhalb der deklarierten Schranke |
| Raumfit | Drei bis acht lokale/Referenz-Boxkorrespondenzen |
| Raumkontrolle | Zwei bis acht zusätzliche Records mit getrennten Kennungen |
| Fitmenge | Für jedes R: Schnitt aller zulässigen Verschiebungsboxen |
| Kontrollregel | Gesamte transformierte Kontrollbox einschließlich aller Verschiebungen muss in der Referenzbox liegen |
| Teilweise bestandene Kontrolle | Gesamte Freigabe gesperrt; Kandidaten bleiben erhalten |
| Positionsmodell | Dezimaldarstellungshülle plus separat deklarierte Sensorfehlerschranke |
| Abfrage | Eine benannte Zielachse liegt strikt über einem Schwellenwert in µm |
| Antwort | Known bei vollständigem Konsens, Ambiguous bei beiden Werten, Unknown bei fehlender Freigabe |
| Zeugen | Rotation, lokale Position, Verschiebung und Zielposition für jeden möglichen Wahrheitswert |

Die Kandidatenboxen repräsentieren Intervalle, nicht nur ihre Mittelpunkte oder Eckpunkte. Die ausgegebenen Eckpunktzeugen gehören zum verwendeten konservativen Intervallmodell; sie behaupten keine tatsächlich gemessenen Einzelpositionen. Die globale Box ist eine einschließende Hülle. Die einzelnen Rotationsboxen bleiben separat enthalten, damit ihre Vereinigung nicht mit einem einzigen vollständig belegten Raumvolumen verwechselt wird.

Im Hauptversuch bleibt eine Rotation mit der Verschiebungsbox `[99970,100030] × [199970,200030] × [−50030,−49970] µm`. Die Positionsabfrage durchläuft ein eindeutiges Nein, Mehrdeutigkeit und ein eindeutiges Ja. Bei einer degenerierten Referenzanordnung bleiben 24 Rotationen möglich. Werden nur einige davon durch die Kontrolle getragen, lautet das Ergebnis Unknown; werden alle getragen, kann die Abfrage weiterhin Ambiguous sein.

## Uhrvertrag

Die Abbildung lautet `reference_ns = rate × local_ns + offset`. Es gibt eine bis fünf explizite Raten zwischen `999000/1000000` und `1001000/1000000`. Der Standardfall hält alle drei Raten `999999/1000000`, `1` und `1000001/1000000`. Offsets bleiben Intervalle; alle Rechnungen verwenden exakte rationale Zahlen.

Fit und spätere Kontrolle bestehen aus jeweils zwei bis acht Zeitkorrespondenzen. Leere Fitintervalle entfallen. Kontrollen dürfen keine übrigen Kandidaten entfernen. Im Gegenversuch mit engerer Kontrolle besteht nur die Einheitsrate; dennoch bleiben drei Fitkandidaten sichtbar und die Freigabe gesperrt.

Die konkrete Quellzeit muss im gebundenen Quellzeitbereich liegen. Die vollständige Zielzeitmenge über alle gehaltenen Raten und Offsets muss im gebundenen Zielzeitbereich liegen. Grenzen sind inklusive. Nanosekunden jenseits der exakten JavaScript-Ganzzahlgrenze bleiben als Strings erhalten; rationale Grenzen sind `[Zählerstring, Nennerstring]`. Der Host-Millisekundentakt ist keine dieser beiden Uhren.

## Laufzeit und Herkunft

- Der Compiler wird als eigener Prozess gestartet. Parent und Owner prüfen das zurückgegebene Zertifikat erneut.
- `registration3d_result` ist genau einmal, vor dem ersten Trägerrecord, zulässig.
- Ein Zertifikat bindet auch Abfrage, Sensorfehlergrenzen und Gültigkeitsbereiche. Geänderte Parameter können es nicht weiterverwenden.
- Ein Referenzreset entzieht den Anschluss dauerhaft für diesen Lauf. Neue Epochen benötigen künftig eigene Zertifikate; diese Version reaktiviert das anfängliche Zertifikat nicht.
- Trackingverlust entfernt die registrierte Pose. Nach Rückkehr innerhalb desselben gültigen Vertrags kann die Antwort wieder verfügbar sein.
- Stop und Resume erhalten die historische Projektion. Die Aufnahme wird dadurch nicht aktuell.
- Der Beobachtungsport `/2` ergänzt `registered_carrier_query`. Der Anschluss an `room_grid` bleibt Unknown; es gibt keine externe Effektfreigabe.

Unterschiedliche Evidenzkennungen verhindern direkte Recordwiederverwendung. Sie beweisen keine unabhängige physische Erhebung. Ein Hash bindet Inhalte, authentisiert aber kein Gerät. Die Sensorfehlerschranke ist eine Eingabeannahme. Eine reale Headsetsitzung wurde nicht durchgeführt.

## Ausgeführte Prüfung

**478 Python-Tests und 301 JavaScript-Prüfungen bestanden**, darunter 46 neue Python-Tests und 46 neue Browserlogikprüfungen. Nach einer Korrektur der exakten Dezimal-Betragsprüfung wurden die 86 betroffenen Träger- und Registrierungsprüfungen zusätzlich ausgeführt. Die 46 Originaltests des Physical-Carrier-Archivs bleiben gesondert aus der vorherigen Phase dokumentiert.

Die räumliche Fitberechnung wurde unabhängig gegen vollständige Aufzählung eines kleinen ganzzahligen 3D-Teilmodells geprüft. Weitere Prüfungen betreffen Gruppenabschluss, unvollständige Kontrollen, leere Kandidatenmengen, große Zeitwerte, gebrochene Offsets, Referenzwechsel, Zeitgrenzen, falsche Einheiten, veränderte Zertifikate, erhaltene Historie und vollständiges Segmentreplay.

| Versuch | Übergänge | XR-Records | Geometrieaufträge | Messkosten | Suchknoten | HTTP |
|---|---:|---:|---:|---:|---:|---:|
| baseline | 76 | 12 | 11 | 13 | 54 | 35 |
| spatial_rejection | 77 | 12 | 11 | 13 | 54 | 36 |
| clock_rejection | 78 | 12 | 11 | 13 | 54 | 37 |
| ambiguous_registration | 78 | 12 | 12 | 14 | 54 | 35 |
| partial_holdout | 73 | 12 | 11 | 13 | 54 | 32 |
| reference_reset | 79 | 13 | 11 | 13 | 54 | 37 |
| horizon | 77 | 12 | 11 | 13 | 54 | 36 |
| tracking_loss | 76 | 12 | 11 | 13 | 54 | 35 |
| **Gesamt** | **614** | **97** | **89** | **105** | **432** | **283** |

Jeder Versuch nutzt einen eigenen Compilerprozess, tatsächliche Geometrieworker und einen tatsächlichen lokalen HTTP-Server. Acht Compileraufträge prüfen insgesamt 192 Rotationen und 24 Raten. Diese logischen Problemzähler messen keine gesamte CPU-Arbeit: Verifikation, Projektion, Hashing und Replay benötigen weitere Rechenarbeit. Durch Prozessplanung können die Übergangszahlen bei neuen Durchführungen abweichen. Die archivierten Verläufe bleiben exakt replaybar.

Der zusätzliche CLI-Start importierte sechs Records; Resume führte den Cursor auf zwölf fort. Zertifikat, Arbeitszähler und Verbrauch blieben erhalten. Eine nachträglich veränderte Abfrage scheiterte ohne neuen Journalrecord. Die Browserlogik wurde ausgeführt; ein visueller Browserdurchlauf ist nicht enthalten. Der 128-seitige Gesamtentwurf wurde eigenständig kompiliert, gerendert und visuell geprüft.

## Grenzen und nächster Schritt

Die Rotation gehört zu einer diskreten Familie. Eine gewöhnliche Headsetlage mit beliebigem Zwischenwinkel ist dadurch nicht allgemein abgedeckt. Fit- und Kontrollboxen sowie Sensorfehlergrenzen werden als gültige Eingabeannahmen behandelt. Gleichgerichtete Biasfehler können Fit und Kontrolle gemeinsam täuschen. Die deklarierte Uhrenrate muss zu den erlaubten Raten gehören und im Gültigkeitsbereich konstant sein.

Der nächste Ausbauschritt ist eine konservativ repräsentierte kontinuierliche Rotationsunsicherheit, anschließend der Anschluss unabhängig erhobener physischer Referenzmessungen. Ein einzelner numerischer Optimierer ohne verbleibende Fehlerhülle erfüllt diesen Vertrag nicht. Orientierungsregistrierung, neue Zertifikate nach Referenzwechsel, zeitabhängige Uhrdrift und die Verbindung mehrerer Operationsräume benötigen zusätzliche Profile.

## Dateien

- `GRFPS_2nd_Layer_OS.pdf` / `.tex`: Gesamtentwurf, neue Abschnitte 90–97, Bedien- und Formatanhang.
- `GRFPS_Second_Layer_Demo.html`: acht eigenständige 3D-Replays.
- `registration3d.py`: Vertrag, analytischer Fit, universelle Kontrollen und Positionsprojektion.
- `registration3d_worker.py`: eigener Compilerprozess.
- `registered3d_bank.py`, `registered3d_segments.py`: Ownerübergänge und vollständiges Replay.
- `registered3d_runtime.py`, `registered3d_viewer.html`: CLI und Beobachtungsansicht.
- `registered3d_evidence_run`: vollständige Rohdaten, Registrierungsverträge, Journale und Berichte.
- `validation.json`, `validation.log`: ausgeführte Gesamtprüfung.
- `carrier_demo.html` / `README_v0_15_0.md`: erhaltenes Trägerprofil.
- `source_demo.html` / `README_v0_14_0.md`: erhaltenes Mehrquellenprofil.

Alle ursprünglichen Ressourcen, Bewertungen und früheren Nachweise bleiben im Paket erhalten.
