"""Independent finite checks and counterexamples; not the missing WFB E-scripts."""
import itertools,json
# +/-1, +/-i, +/-j, +/-k as (sign,basis).
Q=[(s,b) for s in [1,-1] for b in range(4)]
TABLE=[[(1,0),(1,1),(1,2),(1,3)],[(1,1),(-1,0),(1,3),(-1,2)],[(1,2),(-1,3),(-1,0),(1,1)],[(1,3),(1,2),(-1,1),(-1,0)]]
def mul(a,b):s,k=TABLE[a[1]][b[1]];return a[0]*b[0]*s,k
def inv(a):return a if a[1]==0 else (-a[0],a[1])
def conj(a,b):return mul(mul(a,b),inv(a))
def report():
    identity=(1,0);minus=(-1,0)
    subgroups=[]
    for mask in range(1<<8):
        h={Q[i] for i in range(8) if mask>>i&1}
        if identity in h and all(mul(a,b) in h for a in h for b in h) and all(conj(g,a) in h for g in Q for a in h):subgroups.append(h)
    assert len(subgroups)==6 and {identity} in subgroups
    classes={frozenset(conj(g,a) for g in Q) for a in Q};assert len(classes)==5
    centre={a for a in Q if all(mul(a,b)==mul(b,a) for b in Q)};assert centre=={identity,minus}
    commutator=mul(mul(mul((1,1),(1,2)),inv((1,1))),inv((1,2)));assert commutator==minus
    assert {mul(mul(mul(a,b),inv(a)),inv(b)) for a in Q for b in Q}==centre
    # Quotient Q8/{+1,-1}: basis is retained, sign is deliberately discarded.
    assert identity[1]==minus[1] and identity!=minus
    S=[0,1];F=lambda x:x;G=lambda x:x;C1=lambda x:0;C2=lambda x:x
    assert all(C1(G(F(x)))==C1(x) and C2(F(G(x)))==C2(x) for x in S)
    assert all(C1(C1(x))==C1(x) and C2(C2(x))==C2(x) for x in S)
    assert len({C1(x) for x in S})==1 and len({C2(x) for x in S})==2
    # m(t)=t^2 touches zero without a sign reversal; positive signs on both sides.
    assert (-1)**2>0 and 1**2>0
    return dict(q8=dict(order=8,conjugacy_classes=5,normal_subgroups=6,centre_equals_commutator_subgroup=True,projection_identifies_opposite_centre=True),counterexamples=dict(
        II_3=dict(pdf_page=8,normal_subgroup=['+1'],contains_minus_one=False,repair='every nontrivial normal subgroup'),
        VI_6=dict(pdf_page=18,F=[0,1],G=[0,1],Can1=[0,0],Can2=[0,1],premises_hold=True,quotient_sizes=[1,2],repair='require F and G to respect the canonical equivalence relations'),
        VI_1_a=dict(pdf_page=17,signal='m(t)=t^2',zero_at=0,sign_reversal=False,repair='simple sign-changing zeros and a stated signal model')),
        scope='Four independent audit checks. Original E11-E111 experiments not reproduced.')
if __name__=='__main__':print(json.dumps(report(),indent=2))
