"""Six real owner/worker/HTTP runs over synthetic XR input; full-history replay."""
import argparse,json,shutil,tempfile,threading,time,urllib.request
from pathlib import Path
from carrier_contract import preflight
from carrier_fixtures import CASES,dataset
from carrier_bank import config
from carrier_runtime import CarrierService,sources,html,export
from carrier_segments import SegmentJournal,replay
from live import server_for

def run_case(d,name):
    raw,mf=dataset(name);cc,lines,_=preflight(raw,mf);d.mkdir();(d/'carrier.jsonl').write_bytes(raw);(d/'carrier_manifest.json').write_text(json.dumps(mf));c=config(sources(d),cc);c.update(segment_records=16,calibration_refresh=500,calibration_ttl=5000);c['bank']['budget']=256
    j=SegmentJournal(d/'journal',c);s=CarrierService(j,lines=lines);server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));th=threading.Thread(target=server.serve_forever,daemon=True);th.start();url=f'http://127.0.0.1:{server.server_port}';checks=0;known=False;end=time.monotonic()+30
    try:
        while time.monotonic()<end:
            assert s.cycle();st=s.current;known=known or st['geometry_answer']['epistemic']=='Known'
            with urllib.request.urlopen(url+'/api/updates') as response:v=json.load(response)
            assert v['snapshot']['state_digest']==st['state_digest'];assert v['snapshot']['observation_port']==st['observation_port'];checks+=1
            if st['carrier']['cursor']==len(lines) and known:break
            time.sleep(.02)
        else:raise AssertionError('carrier_run_timeout '+name)
        s.stop_reason='user'
        while s.cycle():time.sleep(.02)
    finally:server.shutdown();server.server_close();th.join();s.close()
    old=replay(d/'journal')['machine'];j=SegmentJournal.reopen(d/'journal');j.commit(dict(kind='resume',at=old.mapper.at+6000));assert j.machine.snapshot()['carrier']==old.snapshot()['carrier'];assert j.machine.spent==old.spent and j.machine.nodes_spent==old.nodes_spent;j.commit(dict(kind='stop',at=j.machine.mapper.at,reason='user'));j.close()
    report=export(d/'journal',d/'replay.html');report.update(case=name,http_checks=checks,source_records=len(lines),synthetic_input=True,geometry_known_seen=known,carrier_resume_preserved=True);(d/'report.json').write_text(json.dumps(report,indent=2));return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='carrier_evidence_run');a=p.parse_args();target=Path(a.out).resolve();assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps015_',dir='/tmp') as tmp:
        work=Path(tmp)/'proof';work.mkdir()
        for name in CASES:
            r=run_case(work/name,name);print(json.dumps({name:{k:r[k] for k in ['transitions','spent','requests','nodes_spent','http_checks']}}),flush=True)
        from verify_carrier import verify
        verified=verify(work,export_views=False);(work/'integration_report.json').write_text(json.dumps(verified,indent=2));shutil.copytree(work,target)
if __name__=='__main__':main()
