"""Bounded, local, offline trace import and resumable semantic replay (stdlib)."""
import argparse
import hashlib
import json
import os
from pathlib import Path
from grfps_l2 import canon,require
from trace_import import strict_load,new_session,advance,replay,atomic_json,CONTRACT

ROOT=Path(__file__).resolve().parent


def read_bounded(path):
    with Path(path).open('rb') as stream:data=stream.read(CONTRACT['max_bytes']+1)
    require(len(data)<=CONTRACT['max_bytes'],'file_size');return data


def checked_session(directory):
    data=read_bounded(directory/'source.json');session=strict_load(read_bounded(directory/'session.json'))
    require(hashlib.sha256(data).hexdigest()==session['source_bytes_ref'],'source_bytes_changed')
    require(canon(strict_load(data))==canon(session['trace']),'source_content_changed')
    replay(session);return session


def export(session,directory):
    rr=replay(session);state=rr['machine'].snapshot()
    data=json.dumps(dict(profile='grfps-trace-view/1',views=rr['views'],head=rr['head']),ensure_ascii=True,separators=(',',':')).replace('<','\\u003c')
    html=(ROOT/'trace_viewer.html').read_text().replace('/*TRACE_DATA*/null',data)
    (directory/'replay.html').write_text(html)
    report=dict(version='0.12.0',transitions=state['sequence'],spent=state['spent'],head=rr['head'],
                state_digest=state['state_digest'],source_bytes_ref=state['source_bytes_ref'],
                answer=state['answer'],geometry=state['geometry']['status'],clock='recorded_ms')
    atomic_json(directory/'report.json',report);return report


def export_gallery(directory,target):
    cases=[]
    for name in ['joint_consensus','refinement','cycle_conflict','search_limit','disconnected','calibration_ambiguity','negative_consensus','measurement_budget']:
        rr=replay(checked_session(Path(directory)/name))
        cases.append(dict(name=name,views=rr['views'],head=rr['head']))
    data=json.dumps(dict(profile='grfps-trace-gallery/1',cases=cases),ensure_ascii=True,separators=(',',':')).replace('<','\\u003c')
    Path(target).write_text((ROOT/'trace_viewer.html').read_text().replace('/*TRACE_DATA*/null',data))


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['import','resume','replay'])
    p.add_argument('--trace',type=Path);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--steps',type=int)
    a=p.parse_args(argv);directory=a.out
    if a.steps is not None:require(0<=a.steps<=64,'steps')
    if a.command=='import':
        require(a.trace is not None,'trace_required');data=read_bounded(a.trace)
        session=advance(new_session(data),a.steps)  # Validate before creating user output.
        directory.mkdir(parents=True,exist_ok=False)
        (directory/'source.json').write_bytes(data)
        atomic_json(directory/'session.json',session)
    else:
        require(a.trace is None,'resume_source_is_immutable')
        lock=directory/'session.lock'
        fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        try:
            session=checked_session(directory)
            if a.command=='resume':
                session=advance(session,a.steps);atomic_json(directory/'session.json',session)
            report=export(session,directory)
        finally:os.close(fd);lock.unlink()
        print(json.dumps(report));return
    print(json.dumps(export(session,directory)))


if __name__=='__main__':main()
