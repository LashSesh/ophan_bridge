"""Actual CLI imports, split-process resume and independent semantic verification."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from trace_examples import cases,EXPECTED
from trace_import import atomic_json
from trace_runtime import checked_session
from trace_import import replay
from trace_geometry import verify_witness,solve

ROOT=Path(__file__).resolve().parent


def verify(directory):
    directory=Path(directory);report={};total=0
    for name in cases():
        case=directory/name;session=checked_session(case);rr=replay(session);ss=rr['views'];s=ss[-1]
        assert [v['answer']['epistemic'] for v in ss[1:]]==EXPECTED[name],name
        assert json.loads((case/'report.json').read_text())['state_digest']==s['state_digest']
        count=0
        for v in ss:
            for w in v['geometry']['witnesses'].values():
                assert verify_witness(v['live_windows'],v['calibration']['candidates'],v['query'],w)
                count+=1
            if v['answer']['epistemic']=='Known':
                assert v['geometry']['complete'] and v['geometry']['status']=='FEASIBLE'
                assert all(r['complete'] and r['solutions'] for r in v['geometry']['support'])
                assert v['geometry']['values']==[v['answer']['value']]
        extra={}
        if name=='cycle_conflict':
            import itertools
            ws=s['live_windows'];pairs=[]
            for a,b in itertools.combinations(ws,2):
                pair=solve({a:ws[a],b:ws[b]},s['calibration']['candidates'],s['query'])
                assert pair['status']=='FEASIBLE';pairs.append(dict(windows=[a,b],solutions=pair['solutions']))
            assert s['geometry']['status']=='CONFLICT';extra['pairwise_feasible']=pairs
        total+=count
        report[name]=dict(transitions=s['sequence'],spent=s['spent'],verified_witnesses=count,
            geometry=s['geometry']['status'],answer=s['answer'],nodes=s['geometry']['nodes'],
            source_bytes_ref=s['source_bytes_ref'],head=rr['head'],state_digest=s['state_digest'],**extra)
    return dict(cases=report,verified_witnesses=total,transitions=sum(x['transitions'] for x in report.values()),
                synthetic_only=True,semantic_replay=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    assert not a.out.exists()
    calls=[]
    with tempfile.TemporaryDirectory(prefix='grfps012_',dir='/tmp') as tmp:
        work=Path(tmp);fixtures=work/'fixtures';fixtures.mkdir();runs=work/'runs';runs.mkdir()
        def cli(args):
            r=subprocess.run([sys.executable,str(ROOT/'trace_runtime.py'),*args],capture_output=True,text=True,timeout=90)
            if r.returncode:raise RuntimeError(r.stderr)
            result=json.loads(r.stdout);calls.append(dict(command=args[0],result=result));return result
        for name,trace in cases().items():
            source=fixtures/(name+'.json');atomic_json(source,trace);case=runs/name
            args=['import','--trace',str(source),'--out',str(case)]
            if name=='joint_consensus':
                cli(args+['--steps','2']);before=checked_session(case)
                assert len(before['records'])==2
                cli(['resume','--out',str(case),'--steps','3'])
                assert len(checked_session(case)['records'])==5
                cli(['resume','--out',str(case)])
            else:cli(args)
            cli(['replay','--out',str(case)])
            assert source.read_bytes()==(case/'source.json').read_bytes()
        result=verify(runs);result['process_calls']=len(calls);result['split_process_resume']=True
        atomic_json(runs/'integration_report.json',result)
        atomic_json(runs/'process_calls.json',calls)
        # Freeze completed results only after full semantic replay under /tmp.
        shutil.copytree(runs,a.out)
        shutil.copytree(fixtures,a.out/'fixtures')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
