"""Historical synthetic uncertain anchors and independently named epoch evidence."""
import copy,json,math
from fractions import Fraction as F
from continuous3d_fixtures import dataset as continuous_dataset,BASE,U,T
from uncertain3d import PROFILE,encode,exact_matrix,exact_transform
from carrier_contract import preflight
from epoch_registration import PROFILE as PLAN_PROFILE
CASES=['baseline','noncentral_anchors','correlated_empty','search_limit','two_witnesses','epoch_rebind','epoch_missing','epoch_return','epoch_bad_control','resume_barrier','tracking_loss','horizon']
def box(v,r):return [[math.floor(x)-r,math.ceil(x)+r] for x in v]
def epoch_bundle(base,epoch,reference,shift,reset_time=0):
    b=copy.deepcopy(base);b['profile']=PROFILE;b['source'].update(epoch=epoch,reference_space=reference);b['target']['reference_space']='uncertain_lab3d';b['search']=dict(min_depth=0,max_depth=4,max_cells=31)
    if epoch:
        for group in ['clock_fit','clock_check']:
            for row in b[group]:row['local_ns']=str(int(row['local_ns'])+reset_time);row['reference_ns']=[str(int(x)+reset_time) for x in row['reference_ns']]
        b['valid_source_ns']=[str(int(x)+reset_time) for x in b['valid_source_ns']];b['valid_reference_ns']=[str(int(x)+reset_time) for x in b['valid_reference_ns']]
    delta=[x-y for x,y in zip(shift,T)]
    for row in b['spatial_fit']:
        row['local_um']=[[a-200,z+200] for a,z in row['local_um']];row['reference_um']=[[a+d,z+d] for (a,z),d in zip(row['reference_um'],delta)]
    for row in b['spatial_check']:
        center=[F(a+z,2)+d for (a,z),d in zip(row['reference_um'],delta)];row['reference_um']=box(center,1500)
    for group in ['spatial_fit','spatial_check','clock_fit','clock_check']:
        for row in b[group]:
            for key in ['id','evidence_ref']:row[key]='epoch'+str(epoch)+'_'+row[key]
    return b
def dataset(case='baseline'):
    raw,m,base=continuous_dataset(case if case in ['tracking_loss','horizon','two_witnesses'] else 'baseline');rows=[json.loads(x) for x in raw.splitlines()];reset_cases=['epoch_rebind','epoch_missing','epoch_return','epoch_bad_control','resume_barrier'];reset_time=None
    if case in reset_cases:
        changed=[]
        for i,row in enumerate(rows):
            if i==5:reset_time=row['monotonic_time_ns']-1;changed.append(dict(record_kind='event',kind='reference_reset',monotonic_time_ns=reset_time,previous=0,epoch=1,reference_space='STAGE'))
            if i>=5:row.update(source_epoch=1,reference_space='STAGE')
            if case=='epoch_return' and i>=9:
                if i==9:changed.append(dict(record_kind='event',kind='reference_reset',monotonic_time_ns=row['monotonic_time_ns']-1,previous=1,epoch=2,reference_space='LOCAL'))
                row.update(source_epoch=2,reference_space='LOCAL')
            changed.append(row)
        rows=changed
    raw=''.join(json.dumps(x)+'\n' for x in rows).encode('ascii');cc,ls,_=preflight(raw,m);base['source']['trace_sha256']=cc['raw_sha256'];b=epoch_bundle(base,0,'LOCAL',T)
    if case=='noncentral_anchors':
        rotation=exact_matrix(U,BASE)
        for row,offset in zip(b['spatial_fit'],[[100,-70,30],[-80,50,-60],[40,100,70]]):
            point=[F(a+z,2)+e for (a,z),e in zip(row['local_um'],offset)];row['reference_um']=box([a+z for a,z in zip(exact_transform(rotation,point),T)],20)
    if case=='correlated_empty':
        b['translation_bound_um']=0;b['charts'][0]['u']=encode([[x,x] for x in U]);b['search']=dict(min_depth=0,max_depth=0,max_cells=1)
        for row in b['spatial_fit']:row['local_um']=[[-13,13],[-13,13],[0,0]];row['reference_um']=[[17,17],[17,17],[0,0]]
        for row in b['spatial_check']:row['local_um']=[[0,0]]*3;row['reference_um']=[[-1,1]]*3
    if case=='search_limit':b['charts'][0]['u']=encode([[F(0),F(0)],[F(0),F(0)],[F(19,100),F(21,100)]]);b['search']['max_cells']=1
    if case=='two_witnesses':b['search']=dict(min_depth=1,max_depth=1,max_cells=3)
    entries=[dict(after_record=0,activation_ref=None,bundle=b)]
    if case in reset_cases and case!='epoch_missing':
        second=epoch_bundle(base,1,'STAGE',[-200000,100000,80000],reset_time)
        if case=='epoch_bad_control':second['spatial_check'][0]['reference_um'][0]=[x+10000 for x in second['spatial_check'][0]['reference_um'][0]]
        entries.append(dict(after_record=6,activation_ref=cc['record_refs'][5],bundle=second))
    return raw,m,dict(profile=PLAN_PROFILE,entries=entries)
