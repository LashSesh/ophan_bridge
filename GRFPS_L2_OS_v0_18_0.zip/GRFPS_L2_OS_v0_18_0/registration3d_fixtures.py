"""Synthetic, independently named fit/check records for finite 3-D models."""
import copy,json
from pathlib import Path
from carrier_contract import manifest,preflight
from registration3d import PROFILE,rotate_point,compile_certificate
CASES=['baseline','spatial_rejection','clock_rejection','ambiguous_registration','partial_holdout','reference_reset','horizon','tracking_loss']
R=[1,-3,2];T=[100000,200000,-50000]
def around(v,radius):return [[x-radius,x+radius] for x in v]
def dataset(case='baseline'):
    template=json.loads(Path(__file__).with_name('sources').joinpath('carrier_rehearsal.jsonl').read_bytes().splitlines()[0]);rows=[]
    for i in range(12):
        f=copy.deepcopy(template);f.update(frame_index=i,monotonic_time_ns=(i+1)*11111111,source_epoch=0,reference_space='LOCAL');f['head_pose']['position_m']=[(i-2)/100,0,i/200]
        if case=='reference_reset' and i>=5:
            if i==5:rows.append(dict(record_kind='event',kind='reference_reset',monotonic_time_ns=f['monotonic_time_ns']-1,previous=0,epoch=1,reference_space='STAGE'))
            f.update(source_epoch=1,reference_space='STAGE')
        if case=='tracking_loss' and i in [5,6,7]:f.update(tracking_state='UNAVAILABLE',head_pose=None,views=[])
        rows.append(f)
    raw=(''.join(json.dumps(x)+'\n' for x in rows)).encode('ascii');m=manifest();cc,_,_=preflight(raw,m)
    source=dict(trace_sha256=cc['raw_sha256'],session_id=m['session_id'],carrier_id=m['carrier_id'],reference_space='LOCAL',epoch=0,timebase=m['timebase'])
    fits=[[0,0,0],[1000000,0,0],[0,1000000,0]];checks=[[0,0,1000000],[-500000,500000,500000]]
    if case in ['ambiguous_registration','partial_holdout']:fits=[[0,0,0]]*3
    if case=='ambiguous_registration':checks=[[0,0,0]]*2
    def spatial(v,i,group):
        ref=[a+b for a,b in zip(rotate_point(v,R),T)];return dict(id=group+str(i),evidence_ref='evidence_'+group+str(i),local_um=around(v,10 if group=='sf' else 5),reference_um=around(ref,20 if group=='sf' else 100))
    def clock(t,i,group):
        radius=50 if group=='cf' else 100;return dict(id=group+str(i),evidence_ref='evidence_'+group+str(i),local_ns=str(t),reference_ns=[str(t+1000000-radius),str(t+1000000+radius)])
    b=dict(profile=PROFILE,origin='synthetic',source=source,target=dict(reference_space='lab3d',timebase='lab_clock_ns',axes=['x','y','z'],unit='um'),valid_source_ns=['10000000','150000000'],valid_reference_ns=['10999000','151001000'],sensor_error_um=[10,10,10],translation_bound_um=2000000,rates_ppm=[999999,1000000,1000001],spatial_fit=[spatial(v,i,'sf') for i,v in enumerate(fits)],spatial_check=[spatial(v,i,'sc') for i,v in enumerate(checks)],clock_fit=[clock(t,i,'cf') for i,t in enumerate([1000000,2000000])],clock_check=[clock(t,i,'cc') for i,t in enumerate([3000000,4000000])],query=dict(kind='axis_greater',axis=0,threshold_um=100000))
    if case=='spatial_rejection':b['spatial_check'][0]['reference_um'][0]=[x+1000 for x in b['spatial_check'][0]['reference_um'][0]]
    if case=='clock_rejection':b['clock_check'][0]['reference_ns']=[str(int(x)+1000) for x in b['clock_check'][0]['reference_ns']]
    if case=='horizon':b['valid_source_ns'][1]=str(5*11111111)
    compile_certificate(b,cc);return raw,m,b
