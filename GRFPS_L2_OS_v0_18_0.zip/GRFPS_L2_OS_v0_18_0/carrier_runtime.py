"""Bounded historical XR ingestion alongside the existing live synthetic geometry."""
import copy,queue
import argparse,json,subprocess,sys,threading,time,webbrowser
from pathlib import Path
from grfps_l2 import canon,loads,fields,require
from noisy_runtime import NoisyService
from source_bank import config as source_config
from carrier_bank import config
from carrier_contract import load,manifest
from source_runtime import SourceService,sources
from carrier_segments import SegmentJournal,replay
from source_registration import fixture as sensor_fixture
from noisy_certificate import fixture as chart_fixture
from bank_runtime import fixture as atlas_fixture
from field_world import generate_world
from adapters import MonotonicClock
from live import server_for


class CarrierService(SourceService):
    def __init__(self,*args,lines,**kw):
        super().__init__(*args,**kw);self.carrier_lines=lines
    def cycle(self):
        m=self.engine.machine
        if m.phase=='RUNNING' and not m.active.paused and not self.stop_reason and not self.at_capacity() and m.carrier_state.cursor<len(self.carrier_lines):
            self.commit(dict(kind='carrier_record',at=self.now(),index=m.carrier_state.cursor,raw=self.carrier_lines[m.carrier_state.cursor]))
        return super().cycle()


def html(data):return Path(__file__).with_name('carrier_viewer.html').read_text().replace('__CARRIER_DATA__',json.dumps(data,ensure_ascii=True).replace('<','\\u003c'))


def export(directory,target):
    r=replay(directory,collect=True);Path(target).write_text(html(dict(mode='replay',views=r['views'],events=r['events'],head=r['head'])))
    m=r['machine'];return dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,requests=m.request_count,nodes_spent=m.nodes_spent,head=r['head'],state_digest=m.snapshot()['state_digest'],revision=m.calibration['revision'],breaches=m.breaches)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',default='carrier_run');p.add_argument('--trace');p.add_argument('--manifest');p.add_argument('--resume',action='store_true');p.add_argument('--duration',type=float,default=15);p.add_argument('--open',action='store_true');a=p.parse_args()
    require(0<a.duration<=3600,'duration');d=Path(a.out).resolve()
    if a.resume:
        j=SegmentJournal.reopen(d/'journal');offset=j.machine.mapper.at+max(j.machine.geometry_contract['ttl'],j.machine.contract['calibration_ttl'])+1
        cc,lines,_=load(d/'carrier.jsonl',j.machine.contract['carrier']['manifest']);require(cc==j.machine.contract['carrier'],'carrier_source_changed')
        j.commit(dict(kind='resume',at=offset));clock=MonotonicClock(offset)
    else:
        require(a.trace and a.manifest,'trace_and_manifest_required');mf=json.loads(Path(a.manifest).read_text());cc,lines,_=load(a.trace,mf)
        d.mkdir(parents=True,exist_ok=False);(d/'carrier.jsonl').write_bytes(''.join(lines).encode('ascii'));(d/'carrier_manifest.json').write_text(json.dumps(mf))
        j=SegmentJournal(d/'journal',config(sources(d),cc));clock=MonotonicClock()
    s=CarrierService(j,clock,lines=lines);server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])))
    t=threading.Thread(target=server.serve_forever,daemon=True);t.start();url=f'http://127.0.0.1:{server.server_port}/';print(url,flush=True)
    if a.open:webbrowser.open(url)
    end=time.monotonic()+a.duration
    try:
        while True:
            if time.monotonic()>=end:s.stop_reason='duration'
            if not s.cycle():break
            time.sleep(.03)
    except KeyboardInterrupt:
        s.stop_reason='user'
        while s.cycle():time.sleep(.03)
    finally:server.shutdown();server.server_close();t.join();s.close()
    print(json.dumps(export(d/'journal',d/'replay.html'),indent=2))

if __name__=='__main__':main()
