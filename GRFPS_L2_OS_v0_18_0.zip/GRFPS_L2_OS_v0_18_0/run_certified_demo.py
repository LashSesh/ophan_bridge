"""Actual subprocess/HTTP experiment with rejected charts and two transformations."""
import argparse,json,shutil,tempfile,threading,time,urllib.request
from pathlib import Path
from certified_bridge import config
from certified_runtime import CertifiedService,fixture,html,export
from certified_segments import SegmentJournal,replay
from calibration_certificate import chart_fixture,seal
from uncertain_bridge import probe_fixture,seal as uncertain_seal
from test_registered import field
from mapping import hashof
from field_world import world_ref
from live import server_for

def run(d):
    d.mkdir();samples=d/'samples';samples.mkdir()
    def write(name,w,ref):
        temp=d/(name+'.next');temp.write_text(json.dumps(w));temp.replace(d/(name+'.json'));(samples/(ref+'.json')).write_text(json.dumps(w))
    def world(t):
        w=dict(fixture(),sensor_transform=t);write('world',w,hashof('SampleWorld',w))
    def chart(w):write('calibration',w,seal('Chart',w))
    f=field();f['cells'][1][0]['solid']=True;o=probe_fixture();write('field',f,world_ref(f));write('orientation',o,uncertain_seal('OrientationWorld',o));world([1,3,-2])
    badfit=chart_fixture();badfit['points'][1]['reference'][0]+=1
    badcheck=chart_fixture();badcheck['points'][-1]['reference'][0]+=1
    chart(badfit);c=config(d/'world.json',d/'field.json',d/'orientation.json',d/'calibration.json');c['segment_records']=16;c['bank'].update(budget=256,ttl=5000,refresh=1000,timeout=2000);c['bank']['atlas']['atlas']['ttl']=5000
    j=SegmentJournal(d/'journal',c);s=CertifiedService(j);stages=[];step=0;original=s.commit
    def stage(name):stages.append(dict(stage=name,sequence=s.current['sequence'],spent=s.current['spent'],drift=s.current['drift'],projection=s.current['bridges'][0]))
    def capture(e):
        original(e)
        if e['kind']=='recalibrate':stage('adopted_v'+str(s.current['calibration']['revision'])+'_requires_evidence')
    s.commit=capture
    server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();url=f'http://127.0.0.1:{server.server_port}';checks=0;end=time.monotonic()+20
    def control():
        req=urllib.request.Request(url+'/api/control',data=b'{"kind":"recalibrate"}',headers={'Content-Type':'application/json','Origin':url},method='POST')
        with urllib.request.urlopen(req) as response:assert response.status==202
    rejected=False
    try:
        while time.monotonic()<end:
            assert s.cycle();m=s.current['drift'];p=s.current['bridges'][0];candidate=m['candidate'];cs=candidate['status'] if candidate else None
            with urllib.request.urlopen(url+'/api/updates') as response:r=json.load(response)
            assert r['snapshot']['state_digest']==s.current['state_digest'];checks+=1
            if step==0 and cs=='FIT_REJECTED':stage('fit_rejected');chart(badcheck);step=1
            elif step==1 and cs=='CHECK_REJECTED':stage('check_rejected');chart(chart_fixture());step=2
            elif step==2 and p['epistemic']=='Known':stage('known_v1_corrected');chart(badcheck);step=3
            elif step==3 and m['status']=='REVOKED' and cs=='CHECK_REJECTED':stage('failed_check_revokes');control();step=4
            elif step==4 and any(c['status']=='NO_VALID_CERTIFICATE' for c in s.command_results):
                with urllib.request.urlopen(url+'/api/status') as response:status=json.load(response)
                assert 'NO_VALID_CERTIFICATE' in json.dumps(status);assert m['revision']==1;rejected=True;stage('invalid_adoption_rejected');chart(chart_fixture());step=5
            elif step==5 and m['status']=='REVOKED' and m['sample_class']=='WITHIN':
                stage('return_stays_revoked');world([2,1,0]);chart(chart_fixture([2,1,0]));step=6
            elif step==6 and cs=='PASS' and candidate['transform']==[2,1,0]:stage('new_candidate_checked');control();step=7
            elif step==7 and m['revision']==2 and p['epistemic']=='Known':stage('known_v2_corrected');s.stop_reason='user';break
            time.sleep(.02)
        else:raise AssertionError('scenario timeout: '+str(step))
        while s.cycle():time.sleep(.02)
    finally:server.shutdown();server.server_close();thread.join();s.close()
    first=replay(d/'journal');old=first['machine'];j=SegmentJournal.reopen(d/'journal');j.commit(dict(kind='resume',at=old.mapper.at+6000));resumed=j.machine.snapshot();assert resumed['spent']==old.spent and resumed['calibration']==old.calibration and resumed['drift']['status']=='UNKNOWN';assert resumed['bridges'][0]['epistemic']=='Unknown';j.commit(dict(kind='stop',at=j.machine.mapper.at,reason='user'));j.close()
    report=export(d/'journal',d/'replay.html');report.update(stages=stages,http_checks=checks,rejected_control_verified=rejected,restart_preserved_spent=old.spent,restart_preserved_certificate=True);(d/'report.json').write_text(json.dumps(report,indent=2));return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='certified_evidence_run');a=p.parse_args();target=Path(a.out).resolve();assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps010-',dir='/tmp') as tmp:
        d=Path(tmp)/'proof';r=run(d);shutil.copytree(d,target)
    print(json.dumps({k:v for k,v in r.items() if k!='stages'},indent=2))
if __name__=='__main__':main()
