"""Reexecute every transition and sample from the archived v0.8 fixtures."""
import json
from pathlib import Path
from uncertain_segments import replay
from uncertain_runtime import export
from uncertain_bridge import seal,validate_probe
from map_worker import sample
from field_world import measure,world_ref

def verify(root):
    report={}
    for case in ['east','north','consensus','outside']:
        d=root/'uncertain_evidence_run'/case;r=replay(d/'journal',collect=True);m=r['machine'];expected=json.loads((d/'report.json').read_text());count=0
        for k,v in [('transitions',m.seq),('spent',m.spent),('head',r['head']),('state_digest',m.snapshot()['state_digest'])]:assert expected[k]==v,(case,k)
        for before,e in zip(r['views'],r['events']):
            req=before['pending']
            if e['kind']=='window_result' and e['event']['kind']=='patch':
                p=e['event']['patch'];w=json.loads((d/'samples'/(p['sample_ref']+'.json')).read_text());assert sample(w,req['inner'],p['sampled_at'])==p;count+=1
            elif e['kind']=='scoped_boolean' and e['event']['outcome'] in ['OK','OCCLUDED']:
                v=e['event'];w=json.loads((d/'samples'/(v['sample_ref']+'.json')).read_text());a=measure(w,req['organ'],req['payload']['sector']);assert world_ref(w)==v['sample_ref'] and w['depth']==m.contract['scope_cells'];assert (a['outcome'],a['value'])==(v['outcome'],v['value']);count+=1
            elif e['kind']=='probe_result' and e['outcome']=='OK':
                w=validate_probe(json.loads((d/'samples'/(e['sample_ref']+'.json')).read_text()));assert seal('OrientationWorld',w)==e['sample_ref'];assert w['registrations'][req['payload']['registration']]==e['sectors'];count+=1
        for stage in expected['stages']:
            s=next(s for s in r['views'] if s['sequence']==stage['sequence']);assert s['bridges'][0]==stage['projection'] and s['spent']==stage['spent']
        report[case]=dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,verified_samples=count,probe_results=expected['probe_results'],original_http_checks=expected['http_checks'],head=r['head'])
        export(d/'journal',d/'replay.html')
        if case=='east':export(d/'journal',root/'uncertain_demo.html')
    return report
if __name__=='__main__':print(json.dumps(verify(Path(__file__).resolve().parent),indent=2))
