"""Registered organ bank with continuous segmented state and live relevance gates."""
import argparse,json,sys,threading,time,webbrowser,subprocess
from pathlib import Path
from grfps_l2 import require,canon,loads,fields
from bank_runtime import BankService,fixture
from uncertain_bridge import config,scope_ref,probe_fixture
from uncertain_segments import SegmentJournal,replay
from field_adapter import FieldRunner
from field_world import generate_world
from adapters import MonotonicClock
from live import server_for

class UncertainService(BankService):
    def scoped(self,event):
        if event['kind']!='boolean_result':return event
        return dict(kind='scoped_boolean',at=event['at'],scope_ref=scope_ref(self.engine.machine.contract),event=event)
    def failure(self,r,outcome):
        if r['organ']=='registration_probe':
            at=max(self.now(),r['deadline']+1) if outcome=='TIMEOUT' else self.now()
            return dict(kind='probe_result',at=at,request=r['id'],exposure=r['exposure'],outcome=outcome,sectors=None,sampled_at=None,sample_ref=None)
        return self.scoped(super().failure(r,outcome))
    def measure(self,r):
        if r['organ']=='registration_probe':
            try:
                p=subprocess.run([sys.executable,str(Path(__file__).with_name('orientation_worker.py')),self.engine.machine.contract['probe_world']],input=canon(dict(registration=r['payload']['registration'],start_ns=self.clock.start_ns,offset=self.clock.offset,exposure=r['exposure'])),capture_output=True,timeout=max(.001,(r['deadline']-self.now())/1000))
                require(p.returncode==0 and len(p.stdout)<=65536,'probe_protocol');v=loads(p.stdout);fields(v,'sectors sampled_at sample_ref exposure');require(v['exposure']==r['exposure'],'probe_exposure')
                return dict(kind='probe_result',at=self.now(),request=r['id'],exposure=r['exposure'],outcome='OK',sectors=v['sectors'],sampled_at=v['sampled_at'],sample_ref=v['sample_ref'])
            except subprocess.TimeoutExpired:return self.failure(r,'TIMEOUT')
            except (OSError,ValueError):return self.failure(r,'ERROR')
        if r['organ']=='window':return super().measure(r)
        request=dict(id=r['id'],organ=r['organ'],exposure=r['exposure'],query=r['organ'],sector=r['payload']['sector'],issued_at=r['issued_at'],deadline=r['deadline'])
        c=self.engine.machine.config
        runner=FieldRunner(self.clock,dict(world_path=c['field_world'],sectors=c['sectors']),command=[sys.executable,str(Path(__file__).with_name('scoped_field_worker.py')),str(self.engine.machine.contract['scope_cells'])])
        e=runner.run(request)
        return self.scoped(dict(kind='boolean_result',at=e['at'],request=r['id'],exposure=r['exposure'],outcome=e['outcome'],value=e['value'],sampled_at=e['sampled_at'],sample_ref=e['sample_ref']))
    def commit(self,e):
        if e['kind']=='scoped_boolean':e=dict(e,event=dict(e['event'],at=e['at']))
        return super().commit(e)
    def at_capacity(self):
        m=self.engine.machine;return m.seq>=m.contract['segment_records']*m.contract['max_segments']-8
    def cycle(self):
        running=super().cycle()
        if running and not self.stop_reason and not self.at_capacity():
            p=self.engine.machine.bind_proposal()
            if p:self.commit(dict(kind='bind',at=self.engine.machine.mapper.at,witness=p))
        return running

def html(data):return Path(__file__).with_name('uncertain_viewer.html').read_text().replace('__MAP_DATA__',json.dumps(data,ensure_ascii=True).replace('<','\\u003c'))
def export(directory,target):
    r=replay(directory,collect=True);Path(target).write_text(html(dict(mode='replay',views=r['views'],events=r['events'],head=r['head'])))
    m=r['machine'];return dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,requests=m.request_count,archive=m.archive,head=r['head'],state_digest=m.snapshot()['state_digest'])
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='uncertain_run');p.add_argument('--resume',action='store_true');p.add_argument('--duration',type=float,default=15);p.add_argument('--open',action='store_true');a=p.parse_args();require(0<a.duration<=3600,'duration')
    d=Path(a.out).resolve()
    if a.resume:
        e=SegmentJournal.reopen(d/'journal');offset=e.machine.mapper.at+e.machine.mapper.config['ttl']+1;e.commit(dict(kind='resume',at=offset));clock=MonotonicClock(offset)
    else:
        d.mkdir(parents=True,exist_ok=False);w=d/'world.json';w.write_text(json.dumps(fixture(),indent=2));f=d/'field.json';f.write_text(json.dumps(generate_world(23,sectors=4,depth=2),indent=2));o=d/'orientation.json';o.write_text(json.dumps(probe_fixture(),indent=2));e=SegmentJournal(d/'journal',config(w,f,o));clock=MonotonicClock()
    s=UncertainService(e,clock);server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));t=threading.Thread(target=server.serve_forever,daemon=True);t.start();url=f'http://127.0.0.1:{server.server_port}/';print(url,flush=True)
    if a.open:webbrowser.open(url)
    end=time.monotonic()+a.duration
    try:
        while True:
            if time.monotonic()>=end:s.stop_reason='duration'
            if not s.cycle():break
            time.sleep(.04)
    except KeyboardInterrupt:
        s.stop_reason='user'
        while s.cycle():time.sleep(.04)
    finally:server.shutdown();server.server_close();t.join();s.close()
    print(json.dumps(export(d/'journal',d/'replay.html'),indent=2))
if __name__=='__main__':main()
