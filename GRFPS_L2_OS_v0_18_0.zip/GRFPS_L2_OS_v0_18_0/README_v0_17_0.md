# GRFPS — 2nd-Layer Synthetic Perception OS, 0.17.0

Diese Phase liefert einen **kontinuierlichen 3D-Raumanschluss mit exakter Intervallrechnung**. Rationale Quaternionkarten ersetzen die Beschränkung auf 24 einzelne Achsenrotationen. Eine endliche Zahl von Zellen überdeckt kontinuierlich viele Rotationen und Verschiebungen. Der Compiler erhält alle mit dem Fit vereinbaren Raumlagen in einer konservativen äußeren Menge.

**Known** verlangt Antwortkonsens über diese gesamte Hülle. **Ambiguous** verlangt zwei konkrete zulässige Modellzustände mit entgegengesetzten Antworten. Eine überlappende Hülle ohne zweiten gefundenen Zeugen bleibt **Unknown**.

Die lokalen Fit-Anker gelten in dieser Version als exakte Modellpunkte. Ihre Referenzpositionen sowie Rotation, Verschiebung und laufende Trägerposition sind intervallgebunden. Physische Exaktheit gemessener Anker wird damit nicht behauptet. Das vorherige Profil mit lokalen Fitboxen bleibt eigenständig ausführbar.

## Ausführen

Python 3.10 oder neuer und die Standardbibliothek genügen für die Runtime; Node.js prüft ergänzend die Browserlogik. Im entpackten Projektordner:

```sh
python continuous3d_runtime.py --out mein_raum --open
python continuous3d_runtime.py --out mein_raum --resume --open
python continuous3d_runtime.py --out verfeinerung --case refinement --open
python continuous3d_runtime.py --out budgetgrenze --case search_limit --open
python run_continuous3d_demo.py --out neue_versuche
python validate.py
```

Der Erststart verlangt einen noch nicht vorhandenen Ausgabeordner und erzeugt synthetische Daten. Standardlaufzeit: drei Sekunden; `--duration` verändert sie. Ein lokaler Loopbackserver zeigt den aktuellen Ownerzustand. `replay.html` erhält danach den historischen Verlauf. Der CLI-Wiederanlauf erhält Registrierung und Verbrauch und setzt den Import fort.

Eigene Eingaben benötigen drei gebundene Dateien:

```sh
python continuous3d_runtime.py --out eigene_sitzung --trace carrier.jsonl --manifest carrier_manifest.json --registration registration3d.json --open
```

Die Registrierungsdatei trägt `grfps-continuous3d/0.17.0`. Sie bindet Rohdateihash, Sitzung, Träger, initiale Referenz und Epoche null. Jeder registrierte Frame benötigt ausdrücklich `reference_space` und eine ganzzahlige `source_epoch`. Alle Aufnahmen bleiben historische Daten, auch bei aktiver lokaler Runtime. Ein Referenzreset entzieht das ursprüngliche Zertifikat.

## Modell und Garantie

Eine Karte beschreibt `R(u) = B Q(u)` mit einer bisherigen orientierungserhaltenden Achsenrotation B und einer rationalen Box U innerhalb `[-1,1]^3`. Dabei gilt:

`Q(u) = ((1 − u·u) I + 2 u uᵀ + 2 [u]×) / (1 + u·u)`.

Die Formel ist die normalisierte Quaternionrotation von `(1,u)`. Sie benötigt keine Quadratwurzel in der Matrixauswertung. Der Hauptversuch liegt um `u=(0,0,1/5)`; seine zentrale Matrix enthält `12/13` und `5/13` und ist keine Achsenpermutation. Die Parameterbox ist in allen drei Rotationskomponenten kontinuierlich.

Vier geeignete Basiskarten mit jeweils `[-1,1]^3` können SO(3) parametrisch überdecken. Das ist keine Zusage vollständiger Kalibrierungsentscheidung bei begrenztem Suchbudget. Die ausgeführten Versuche verwenden engere deklarierte Karten.

| Bestandteil | Semantik |
|---|---|
| Karten | Eine bis vier; rationale Parameterbox und orientierungserhaltende Basis |
| Parameter | Gekürzte Paare kanonischer Dezimalstrings; Nenner positiv; Betrag höchstens 1 |
| Grenzen | Zählerbetrag und Nenner der Eingaben höchstens 10⁹ |
| Lokale Fit-Anker | Exakte vorgegebene Punkte, als degenerierte Boxen codiert |
| Referenz-Anker | Ganzzahlige µm-Intervallboxen |
| Äußere Fitbox | Schnitt der aus allen Ankern abgeleiteten Verschiebungsintervalle |
| Ausschluss | Nur wenn eine äußere Fitbox leer ist |
| Verfeinerung | Binäre Teilung der längsten Parameterseite; exakte gemeinsame Grenze |
| Grenzen der Suche | Höchstens 127 Zellprüfungen und Tiefe 8 |
| Kontrolle | Jede gehaltene äußere transformierte Kontrollbox muss vollständig getragen sein |
| Existenz | Mindestens ein konkreter rationaler Parameter mit exakter nichtleerer Fit-Verschiebungsbox |
| Antwortzeugen | Prüfung direkt gegen ursprüngliche Fit-Anker und Referenzen |

Alle Entscheidungsrechnungen verwenden Python `Fraction`. Es entsteht kein numerischer Rundungsfehler in diesen Grenzen. Die äußere Intervallmenge kann trotzdem zu breit sein, weil gemeinsame Parameterabhängigkeiten verloren gehen. Das ist **Überapproximation**, kein Rundungsfehler und keine physische Sensorfehlerschätzung.

Ein Zelllimit entfernt keine offene Raumlage. Es verhindert weitere Verfeinerung und kann eine Freigabe offenlassen. Eine erfolglose Kontrolle darf keine Kandidaten aus der Fitmenge herausfiltern. Zellmittelpunkte sind lediglich Quellen konkreter Existenzzeugen; sie ersetzen nicht die kontinuierliche Überdeckung. Bereits gefundene Zeugen bleiben bei passenden Unterteilungen erhalten.

## Zustände und Zeit

| Status / Grund | Bedeutung |
|---|---|
| `SPATIAL_FIT_EMPTY` | Sämtliche Wurzelkarten durch Fit ausgeschlossen |
| `SEARCH_LIMIT` | Nötige weitere Verfeinerung scheitert am Zellbudget |
| `CONTROL_UNPROVEN` | Mindestens eine äußere Kontrollmenge nicht getragen |
| `FIT_EXISTENCE_UNPROVEN` | Äußere Zellen vorhanden, aber noch kein konkreter Fit gefunden |
| `CLOCK_FIT_EMPTY` | Keine der deklarierten Uhrenraten passt zum Fit |
| `CLOCK_CHECK_REJECTED` | Mindestens ein gehaltener Uhrenkandidat verletzt eine Kontrolle |
| `PASS` | Raumexistenz bezeugt und alle Raum-/Uhrkontrollen getragen |
| `enclosure_overlap` | Zertifikat PASS, aber äußere Abfragemenge überlappt und zweiter Zeuge fehlt |

Diese Hauptgründe folgen der Reihenfolge im Compiler. Die einzelnen Prüfresultate bleiben im Zertifikat sichtbar. Ein räumlicher Hauptgrund kann einen gleichzeitig vorhandenen Uhrfehler überdecken.

Die Uhrabbildung bleibt `reference_ns = rate × local_ns + offset`. Eine bis fünf deklarierte konstante rationale Raten werden vollständig gehalten. Offsetintervalle und Zielzeitgrenzen sind exakt. Die ganze Zielzeithülle muss im gebundenen Gültigkeitsbereich liegen. Beliebige zeitabhängige Drift gehört nicht zu diesem Modell.

Die Projektionsfelder unterscheiden:

- `position_um`: einschließende rationale Positionsbox;
- `enclosure_values`: äußerlich mögliche Wahrheitswerte;
- `values` und `witnesses`: konkret nachgewiesene Modellwerte;
- `rows`: Positionshülle je Raumzelle;
- `status`, `reason`, `value`: freigegebene Antwort oder offener Nachweis.

Die Diagrammkoordinaten werden nur für die Bildschirmdarstellung angenähert. Die Intervallgrenzen bleiben darunter als exakte Brüche sichtbar. Der Browser bestimmt keinen neuen Wahrheitswert aus gerundeten Bildkoordinaten.

## Ausgeführte Prüfung

**520 Python-Tests und 358 JavaScript-Prüfungen bestanden**, darunter 42 neue Python-Tests und 57 neue Browserlogikprüfungen. Die Mathematik wurde gegen eine unabhängig formulierte Quaternionmultiplikation geprüft, zusätzlich auf Orthogonalität, Determinante +1, alle 24 Basen, Vier-Karten-Überdeckung, innere Intervallpunkte, lückenlose Blattpartitionen und erhaltene zulässige Fits.

Ein gezielter Gegenversuch hat ausschließlich tatsächlich positive Antworten, aber eine zu breite äußere Hülle. Er bleibt Unknown und erzeugt keine falsche Mehrdeutigkeit. Zwei explizite Zustände mit verschiedenen Antworten ergeben dagegen Ambiguous. Veränderte und neu gehashte Zertifikate werden atomar abgewiesen.

Elf tatsächliche Compiler-/Owner-/Worker-/HTTP-Versuche mit synthetischen Eingaben:

| Fall | Übergänge | XR-Records | Compilerzellen | HTTP |
|---|---:|---:|---:|---:|
| `baseline` | 76 | 12 | 1 | 35 |
| `refinement` | 74 | 12 | 19 | 33 |
| `search_limit` | 76 | 12 | 1 | 35 |
| `control_unproven` | 75 | 12 | 31 | 34 |
| `enclosure_overlap` | 76 | 12 | 1 | 35 |
| `two_witnesses` | 76 | 12 | 3 | 35 |
| `fit_empty` | 77 | 12 | 1 | 36 |
| `clock_rejection` | 78 | 12 | 1 | 37 |
| `reference_reset` | 77 | 13 | 1 | 35 |
| `horizon` | 76 | 12 | 1 | 35 |
| `tracking_loss` | 76 | 12 | 1 | 35 |
| **Gesamt** | **837** | **133** | **61** | **385** |

Die Compiler führten 25 Teilungen und 33 Ratenprüfungen aus. Die geerbte aktive Geometrie führte 121 Aufträge mit 143 Messkosteneinheiten und 594 logischen Suchknoten aus. Die Zähler sind keine CPU-Zeit- oder Echtzeitgarantie; Verifikation und Replay führen zusätzliche Arbeit aus.

Beim zusätzlichen CLI-Wiederanlauf wurde der Cursor von **5 auf 12** fortgesetzt. Zertifikat, Historie und Arbeitszähler blieben erhalten. Eine veränderte Registrierungsabfrage wurde vor einem neuen Journalcommit abgewiesen. Alle archivierten Verläufe wurden vollständig semantisch wiedergegeben.

Die 46 Tests des ursprünglichen Physical-Carrier-Archivs bleiben gesondert mit ihrem Bericht aus Version 0.15.0 erhalten. Die Browserlogik wurde in Node.js ausgeführt; ein visueller Browserdurchlauf, native OpenXR-Kompilation und eine reale Headsetsitzung wurden nicht durchgeführt. Der Gesamtentwurf wurde eigenständig mit LaTeX kompiliert und als PDF gerendert und geprüft.

## Grenzen und nächste Phase

Der Zielraum `continuous_lab3d` ist ein eigener Modellraum. Der Anschluss an die bisherige 2D-Geometrie `room_grid`, registrierte Orientierung, physische Gerätevalidierung und externe Wirkungsausführung bleiben offen. Ein als aufgezeichnet deklariertes Artefakt beweist seine physische Herkunft nicht. Verschiedene Fit-/Kontrollkennungen beweisen keine unabhängig erhobenen Messungen.

Die nächste Phase betrifft **unsichere lokale Fit-Anker** und **neue, durch eigene Evidenz freigegebene Referenzepochen**. Physische Referenzmessungen können erst mit tatsächlich verfügbaren Aufnahmen angebunden werden. Ein höherer Anteil eindeutiger Ausgaben genügt nicht als Fortschrittsbeleg; er muss durch erhaltene Einschluss- und Zeugenkorrektheit gedeckt sein.

## Dateien

- `GRFPS_2nd_Layer_OS.pdf` / `.tex`: vollständiger Gesamtentwurf einschließlich der früheren Profile.
- `GRFPS_Second_Layer_Demo.html`: elf aktuelle Replays.
- `continuous3d.py`: Intervallrechnung, Compiler, Projektion und direkte Zeugenprüfung.
- `continuous3d_worker.py`, `continuous3d_runtime.py`, `continuous3d_bank.py`, `continuous3d_segments.py`: Prozess- und Journalanschluss.
- `continuous3d_fixtures.py`, `run_continuous3d_demo.py`, `verify_continuous3d.py`: tatsächliche Versuche und Replayprüfung.
- `CONTINUOUS3D_CONTRACT.md`: kompakter Eingabe- und Ausgabevertrag.
- `validation.json`, `validation.log`: ausgeführte Gesamtprüfung.
- `finite3d_demo.html`, `carrier_demo.html`, `source_demo.html`: erhaltene Ansichten der vorherigen Phasen.

Veränderliche Journale sollten in einem stabilen lokalen Arbeitsverzeichnis laufen. Das Paket enthält bereits vollständig geprüfte unveränderliche Versuchskopien.
