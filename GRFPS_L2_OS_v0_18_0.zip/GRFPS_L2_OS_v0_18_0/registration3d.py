"""Exact finite 3-D registration: cube rotations, translation boxes, affine clocks.
All fitted candidates must pass held-out containment checks; no check pruning.
This is a conditional micrometre interval model, not an arbitrary SO(3) solver.
"""
import copy,itertools,json
from fractions import Fraction as F
from pathlib import Path
from grfps_l2 import require,fields,ident,canon,loads
from carrier_contract import sha,read_line
PROFILE='grfps-registration3d/0.16.0';LIMIT=100000000;MAX_BYTES=65536

def seal(kind,value):return sha(canon(dict(profile=PROFILE,kind=kind,value=value)))
def integer(x,bound=LIMIT):require(type(x) is int and abs(x)<=bound,'integer_bound');return x
def ns(x):
    require(type(x) is str and x.isascii() and x.isdigit() and len(x)<=19 and str(int(x))==x and int(x)<=2**63-1,'ns_string');return int(x)
def label(x):require(ident(x),'identifier');return x
def box(x):
    require(type(x) is list and len(x)==3,'box_dimension')
    for a in x:require(type(a) is list and len(a)==2 and integer(a[0])<=integer(a[1]),'box_interval')
    return x
def timebox(x):require(type(x) is list and len(x)==2 and ns(x[0])<=ns(x[1]),'time_interval');return [ns(v) for v in x]
def frac(x):return [str(x.numerator),str(x.denominator)]
def unfrac(x):return F(int(x[0]),int(x[1]))
def rotations():
    out=[]
    for perm in itertools.permutations(range(3)):
        parity=(-1)**sum(perm[i]>perm[j] for i in range(3) for j in range(i+1,3))
        for signs in itertools.product([-1,1],repeat=3):
            if parity*signs[0]*signs[1]*signs[2]==1:out.append([signs[i]*(perm[i]+1) for i in range(3)])
    return out
ROTATIONS=rotations()
def rotate_box(b,r):return [list(b[abs(a)-1]) if a>0 else [-b[abs(a)-1][1],-b[abs(a)-1][0]] for a in r]
def rotate_point(v,r):return [v[abs(a)-1]*(1 if a>0 else -1) for a in r]
def intersection(a,b):return [[max(x[0],y[0]),min(x[1],y[1])] for x,y in zip(a,b)]
def nonempty(b):return all(x<=y for x,y in b)
def add(a,b):return [[x[0]+y[0],x[1]+y[1]] for x,y in zip(a,b)]
def inside(a,b):return all(y[0]<=x[0] and x[1]<=y[1] for x,y in zip(a,b))

def validate(b,carrier):
    fields(b,'profile origin source target valid_source_ns valid_reference_ns sensor_error_um translation_bound_um rates_ppm spatial_fit spatial_check clock_fit clock_check query')
    require(b['profile']==PROFILE and b['origin'] in ['synthetic','recorded'],'registration_profile')
    fields(b['source'],'trace_sha256 session_id carrier_id reference_space epoch timebase')
    m=carrier['manifest'];q=b['source'];require(q['trace_sha256']==carrier['raw_sha256'] and q['session_id']==m['session_id'] and q['carrier_id']==m['carrier_id'] and q['timebase']==m['timebase'],'registration_source_binding');label(q['reference_space']);require(type(q['epoch']) is int and q['epoch']==0 and q['reference_space']==m['reference_space'],'source_epoch')
    fields(b['target'],'reference_space timebase axes unit');label(b['target']['reference_space']);label(b['target']['timebase']);require(b['target']['axes']==['x','y','z'] and b['target']['unit']=='um','target_units')
    lo,hi=timebox(b['valid_source_ns']);timebox(b['valid_reference_ns']);require(lo<hi,'valid_horizon')
    require(type(b['sensor_error_um']) is list and len(b['sensor_error_um'])==3 and all(type(x) is int and 0<=x<=100000 for x in b['sensor_error_um']),'sensor_error')
    integer(b['translation_bound_um']);require(b['translation_bound_um']>=0,'translation_bound')
    rates=b['rates_ppm'];require(type(rates) is list and 1<=len(rates)<=5 and all(type(x) is int and 999000<=x<=1001000 for x in rates) and sorted(set(rates))==rates,'rates')
    seen=set()
    for group in ['spatial_fit','spatial_check','clock_fit','clock_check']:
        require(type(b[group]) is list and (3 if group=='spatial_fit' else 2)<=len(b[group])<=8,'observation_count')
        for row in b[group]:
            fields(row,'id evidence_ref local_um reference_um' if group.startswith('spatial') else 'id evidence_ref local_ns reference_ns');label(row['id']);label(row['evidence_ref']);require(row['id'] not in seen and row['evidence_ref'] not in seen,'disjoint_evidence');require(row['id']!=row['evidence_ref'],'evidence_identity');seen.update([row['id'],row['evidence_ref']])
            if group.startswith('spatial'):box(row['local_um']);box(row['reference_um'])
            else:ns(row['local_ns']);timebox(row['reference_ns'])
    fits=[ns(x['local_ns']) for x in b['clock_fit']];checks=[ns(x['local_ns']) for x in b['clock_check']]
    require(all(x<y for x,y in zip(fits,fits[1:])) and all(x<y for x,y in zip(checks,checks[1:])) and max(fits)<min(checks) and max(checks)<=lo,'clock_observation_order')
    fields(b['query'],'kind axis threshold_um');require(b['query']['kind']=='axis_greater' and type(b['query']['axis']) is int and 0<=b['query']['axis']<3,'query');integer(b['query']['threshold_um']);canon(b);return b

def compile_certificate(b,carrier):
    validate(b,carrier);spatial=[];clock=[];bound=b['translation_bound_um']
    for index,r in enumerate(ROTATIONS):
        t=[[-bound,bound] for _ in range(3)]
        for row in b['spatial_fit']:
            a=rotate_box(row['local_um'],r);w=row['reference_um'];allowed=[[w[j][0]-a[j][1],w[j][1]-a[j][0]] for j in range(3)];t=intersection(t,allowed)
        if not nonempty(t):continue
        checks=[]
        for row in b['spatial_check']:
            predicted=add(rotate_box(row['local_um'],r),t);checks.append(dict(id=row['id'],predicted_um=predicted,passed=inside(predicted,row['reference_um'])))
        spatial.append(dict(rotation_id=index,rotation=r,translation_um=t,checks=checks,passed=all(x['passed'] for x in checks)))
    for ppm in b['rates_ppm']:
        a=F(ppm,1000000);offset=None
        for row in b['clock_fit']:
            t=ns(row['local_ns']);ref=timebox(row['reference_ns']);allowed=[F(ref[0])-a*t,F(ref[1])-a*t];offset=allowed if offset is None else [max(offset[0],allowed[0]),min(offset[1],allowed[1])]
        if offset[0]>offset[1]:continue
        checks=[]
        for row in b['clock_check']:
            t=ns(row['local_ns']);ref=timebox(row['reference_ns']);pred=[a*t+offset[0],a*t+offset[1]];checks.append(dict(id=row['id'],predicted_ns=[frac(v) for v in pred],passed=F(ref[0])<=pred[0] and pred[1]<=F(ref[1])))
        clock.append(dict(rate_ppm=ppm,offset_ns=[frac(x) for x in offset],checks=checks,passed=all(x['passed'] for x in checks)))
    status=('SPATIAL_FIT_EMPTY' if not spatial else 'SPATIAL_CHECK_REJECTED' if not all(x['passed'] for x in spatial) else 'CLOCK_FIT_EMPTY' if not clock else 'CLOCK_CHECK_REJECTED' if not all(x['passed'] for x in clock) else 'PASS')
    c=dict(profile=PROFILE,bundle_ref=seal('Bundle',b),source=copy.deepcopy(b['source']),target=copy.deepcopy(b['target']),status=status,spatial_candidates=spatial,clock_candidates=clock,work=dict(rotation_trials=24,rate_trials=len(b['rates_ppm'])),physical_validation='Unknown')
    c['digest']=seal('Certificate',c);return c

def projection(b,certificate,carrier,last_raw=None):
    result=dict(profile=PROFILE,status='Unknown',reason='registration_pending',facticity='Simulated' if carrier['origin']=='synthetic' or b['origin']=='synthetic' else 'Recorded',physical_validation='Unknown',temporal_scope='historical_file',target=copy.deepcopy(b['target']),query=copy.deepcopy(b['query']),value=None,values=[],position_um=None,reference_time_ns=None,orientation='Unknown',certificate_ref=certificate['digest'] if certificate else None,carrier_ref=carrier['head'],rows=[],witnesses={})
    if certificate is None:return result
    require(certificate['bundle_ref']==seal('Bundle',b),'projection_bundle_binding')
    if certificate['status']!='PASS':result['reason']=certificate['status'];return result
    if carrier['epoch']!=b['source']['epoch'] or carrier['reference_space']!=b['source']['reference_space']:result['reason']='reference_scope_changed';return result
    last=carrier['latest']
    if not last or last['pose'] is None:result['reason']='pose_unavailable';return result
    if last_raw is None:result['reason']='explicit_scope_missing';return result
    raw=read_line(last_raw)
    if raw.get('source_epoch')!=carrier['epoch'] or raw.get('reference_space')!=carrier['reference_space']:result['reason']='explicit_scope_missing';return result
    t=ns(last['source_time_ns']);lo,hi=timebox(b['valid_source_ns'])
    if not lo<=t<=hi:result['reason']='source_horizon';return result
    times=[]
    for c in certificate['clock_candidates']:
        a=F(c['rate_ppm'],1000000);times.append([a*t+unfrac(x) for x in c['offset_ns']])
    lower=min(x[0] for x in times);upper=max(x[1] for x in times);vlo,vhi=timebox(b['valid_reference_ns'])
    result['reference_time_ns']=[frac(lower),frac(upper)]
    if lower<vlo or upper>vhi:result['reason']='reference_horizon';return result
    local=[[x[0]-e,x[1]+e] for x,e in zip(last['pose']['position_um'],b['sensor_error_um'])];rows=[];witnesses={};values=set();axis=b['query']['axis'];threshold=b['query']['threshold_um']
    for c in certificate['spatial_candidates']:
        r=c['rotation'];trans=c['translation_um'];world=add(rotate_box(local,r),trans);possible=([False] if world[axis][1]<=threshold else [True] if world[axis][0]>threshold else [False,True]);values.update(possible);rows.append(dict(rotation_id=c['rotation_id'],position_um=world,values=possible))
        for value in possible:
            key=str(value).lower()
            if key in witnesses:continue
            k=1 if value else 0;point=[x[0] for x in local];j=abs(r[axis])-1;point[j]=local[j][k if r[axis]>0 else 1-k];translation=[x[0] for x in trans];translation[axis]=trans[axis][k];mapped=[x+y for x,y in zip(rotate_point(point,r),translation)];assert (mapped[axis]>threshold)==value
            witnesses[key]=dict(rotation_id=c['rotation_id'],local_um=point,translation_um=translation,reference_um=mapped,value=value)
    union=[[min(x['position_um'][j][0] for x in rows),max(x['position_um'][j][1] for x in rows)] for j in range(3)];vs=sorted(values);result.update(status='Known' if len(vs)==1 else 'Ambiguous',reason='universal_registered_query' if len(vs)==1 else 'registered_query_ambiguous',value=vs[0] if len(vs)==1 else None,values=vs,position_um=union,rows=rows,witnesses=witnesses)
    return result

def load_bundle(path,carrier):
    with Path(path).open('rb') as f:raw=f.read(MAX_BYTES+1)
    require(0<len(raw)<=MAX_BYTES,'bundle_size');b=loads(raw);validate(b,carrier);return b
