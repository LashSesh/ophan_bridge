"""Historical XR plus a continuous registered 3-D target, with existing live geometry."""
import argparse,json,subprocess,sys,threading,time,webbrowser
from pathlib import Path
from grfps_l2 import canon,loads,require
from carrier_contract import preflight,load as load_trace
from carrier_bank import config as carrier_config
from carrier_runtime import CarrierService,sources
from uncertain3d import compile_certificate
from epoch3d_fixtures import dataset,CASES
from epoch3d_bank import config
from epoch3d_segments import SegmentJournal,replay
from adapters import MonotonicClock
from live import server_for
from epoch_registration import load_plan,validate_plan
from source_runtime import SourceService

def worker_certificate(bundle,carrier):
    data=canon(dict(bundle=bundle,carrier=carrier));r=subprocess.run([sys.executable,str(Path(__file__).with_name('uncertain3d_worker.py'))],input=data,capture_output=True,timeout=30,check=True);c=loads(r.stdout);require(c==compile_certificate(bundle,carrier),'worker_certificate');return c

def html(data):return Path(__file__).with_name('epoch3d_viewer.html').read_text().replace('__EPOCH3D_DATA__',json.dumps(data,ensure_ascii=True).replace('<','\\u003c'))
def export(directory,target):
    r=replay(directory,collect=True);Path(target).write_text(html(dict(mode='replay',views=r['views'],events=r['events'],head=r['head'])));m=r['machine'];return dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,requests=m.request_count,nodes_spent=m.nodes_spent,head=r['head'],state_digest=m.snapshot()['state_digest'])
def admission_event(entry,certificate,at):return dict(kind='epoch_registration_result',at=at,epoch=entry['bundle']['source']['epoch'],after_record=entry['after_record'],activation_ref=entry['activation_ref'],certificate=certificate)
class EpochService(CarrierService):
    def cycle(self):
        m=self.engine.machine
        if m.phase=='RUNNING' and not m.active.paused and not self.stop_reason and not self.at_capacity():
            entry=m.pending_admission()
            if entry is not None:
                cert=worker_certificate(entry['bundle'],m.contract['carrier']);self.commit(admission_event(entry,cert,self.now()))
                # Keep admission and the first new frame as distinct visible transitions.
                return SourceService.cycle(self)
        return super().cycle()
def initialize(d,raw,mf,plan):
    cc,lines,_=preflight(raw,mf);validate_plan(plan,cc,lines);first=plan['entries'][0];cert=worker_certificate(first['bundle'],cc)
    d.mkdir(parents=True,exist_ok=False);(d/'carrier.jsonl').write_bytes(raw);(d/'carrier_manifest.json').write_bytes(canon(mf));(d/'registration_plan.json').write_bytes(canon(plan));base=carrier_config(sources(d),cc);base.update(segment_records=32,calibration_refresh=500);j=SegmentJournal(d/'journal',config(base,plan));j.commit(admission_event(first,cert,0));return j,lines

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',default='epoch3d_run');p.add_argument('--case',choices=CASES,default='baseline');p.add_argument('--trace');p.add_argument('--manifest');p.add_argument('--registration');p.add_argument('--resume',action='store_true');p.add_argument('--duration',type=float,default=3);p.add_argument('--open',action='store_true');a=p.parse_args();require(0<a.duration<=3600,'duration');d=Path(a.out).resolve()
    if a.resume:
        r=replay(d/'journal');cc,lines,_=load_trace(d/'carrier.jsonl',r['machine'].contract['carrier']['manifest']);require(cc==r['machine'].contract['carrier'],'carrier_source_changed');plan=load_plan(d/'registration_plan.json',cc,lines);require(plan==r['machine'].contract['registration_schedule'],'registration_source_changed');j=SegmentJournal.reopen(d/'journal');offset=j.machine.mapper.at+6000;j.commit(dict(kind='resume',at=offset));clock=MonotonicClock(offset)
    else:
        if a.trace or a.manifest or a.registration:
            require(a.trace and a.manifest and a.registration,'three_inputs_required');mf=loads(Path(a.manifest).read_bytes());cc,lines,_=load_trace(a.trace,mf);raw=''.join(lines).encode('ascii');bundle=load_plan(a.registration,cc,lines)
        else:raw,mf,bundle=dataset(a.case)
        j,lines=initialize(d,raw,mf,bundle);clock=MonotonicClock()
    s=EpochService(j,clock,lines=lines);server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));th=threading.Thread(target=server.serve_forever,daemon=True);th.start();url=f'http://127.0.0.1:{server.server_port}/';print(url,flush=True)
    if a.open:webbrowser.open(url)
    end=time.monotonic()+a.duration
    try:
        while True:
            if time.monotonic()>=end:s.stop_reason='duration'
            if not s.cycle():break
            time.sleep(.025)
    except KeyboardInterrupt:
        s.stop_reason='user'
        while s.cycle():time.sleep(.025)
    finally:server.shutdown();server.server_close();th.join();s.close()
    print(json.dumps(export(d/'journal',d/'replay.html'),indent=2))
if __name__=='__main__':main()
