"""Complete finite C4 box geometry. A resource stop is never a proof of consensus.

Conditioned on one shared calibration and one pose per window, each landmark
has the intersection of its transformed integer boxes as its exact domain.
Landmarks have independent domains: this profile imposes no distinctness or
distance constraints. Poses are enumerated, never fitted to chosen centers.
"""
import copy
import hashlib
import itertools
from mapping import rot, transform
from grfps_l2 import canon


def box(center, radius):
    return [[v-radius for v in center], [v+radius for v in center]]


def move(b, t):
    corners=[transform(p,t) for p in itertools.product(*zip(*b))]
    return [[min(p[i] for p in corners) for i in range(2)],
            [max(p[i] for p in corners) for i in range(2)]]


def intersect(a, b):
    c=[[max(a[0][i],b[0][i]) for i in range(2)],
       [min(a[1][i],b[1][i]) for i in range(2)]]
    return c if all(c[0][i]<=c[1][i] for i in range(2)) else None


def choices(local, global_box, bound):
    """All poses that can match this anchor; other anchors are checked in DFS."""
    for q in range(4):
        b=move(local,[q,0,0])
        lo=[max(-bound,global_box[0][i]-b[1][i]) for i in range(2)]
        hi=[min(bound,global_box[1][i]-b[0][i]) for i in range(2)]
        for x,y in itertools.product(range(lo[0],hi[0]+1),range(lo[1],hi[1]+1)):
            yield [q,x,y]


def query_values(domains, query):
    a,b=domains[query['a']],domains[query['b']]
    # Distinct identifiers required by the import contract.
    out=[]
    if b[0][0]<=a[1][0]:out.append(False)
    if b[1][0]>a[0][0]:out.append(True)
    return out


def witness(domains, poses, calibration, query, value):
    points={k:list(v[0]) for k,v in domains.items()}
    a,b=query['a'],query['b']
    points[a][0]=domains[a][0 if value else 1][0]
    points[b][0]=domains[b][1 if value else 0][0]
    return dict(calibration=list(calibration),poses=copy.deepcopy(poses),points=points,value=value)


class Exhausted(Exception):pass


def solve(windows, candidates, query, limit=50000, pose_bound=8):
    """Exhaustive feasible pose tuples; root is the lexicographically first window.

    node count = one root or proposed non-root pose. The limit spans all
    calibration candidates. Partial summaries on LIMIT are diagnostic only.
    """
    names=sorted(windows)
    out=dict(status='GAP',complete=True,reason='no_windows',root=names[0] if names else None,
             nodes=0,solutions=0,support=[],values=[],witnesses={},bounds={},solution_digest=None)
    if not names or not candidates:return out
    all_ids=set().union(*(set(windows[n]) for n in names))
    if query['a'] not in all_ids or query['b'] not in all_ids:
        out['reason']='missing_query_landmark';return out
    reached={names[0]};ids=set(windows[names[0]])
    while True:
        added={n for n in names if n not in reached and ids&set(windows[n])}
        if not added:break
        reached|=added
        for n in added:ids.update(windows[n])
    if len(reached)!=len(names):out['reason']='disconnected_windows';return out
    hasher=hashlib.sha256();values=set()
    def charge():
        if out['nodes']>=limit:raise Exhausted()
        out['nodes']+=1
    try:
        for calibration in candidates:
            local={n:{k:move(box(p['center'],p['radius']),calibration) for k,p in windows[n].items()} for n in names}
            support=dict(calibration=list(calibration),solutions=0,complete=False)
            out['support'].append(support)
            def visit(domains, poses, remaining):
                if not remaining:
                    support['solutions']+=1;out['solutions']+=1
                    hasher.update(canon(dict(calibration=calibration,poses=poses,domains=domains)))
                    hasher.update(b'\n')
                    for k,b in domains.items():
                        if k not in out['bounds']:out['bounds'][k]=copy.deepcopy(b)
                        else:
                            old=out['bounds'][k]
                            out['bounds'][k]=[[min(old[0][i],b[0][i]) for i in range(2)],
                                              [max(old[1][i],b[1][i]) for i in range(2)]]
                    for value in query_values(domains,query):
                        values.add(value)
                        out['witnesses'].setdefault(str(value).lower(),witness(domains,poses,calibration,query,value))
                    return
                # Connectedness ensures at least one frontier window.
                n=min(remaining,key=lambda n:(-len(set(local[n])&set(domains)),n))
                shared=sorted(set(local[n])&set(domains));anchor=shared[0]
                for pose in choices(local[n][anchor],domains[anchor],pose_bound):
                    charge();merged=dict(domains)
                    for k,b in local[n].items():
                        projected=move(b,pose)
                        merged[k]=intersect(domains[k],projected) if k in domains else projected
                        if merged[k] is None:break
                    else:visit(merged,{**poses,n:pose},[v for v in remaining if v!=n])
            charge();visit(local[names[0]],{names[0]:[0,0,0]},names[1:]);support['complete']=True
    except Exhausted:
        out.update(status='LIMIT',complete=False,reason='search_budget_exhausted')
    else:
        if not out['solutions']:out.update(status='CONFLICT',reason='no_joint_geometry')
        elif any(s['solutions']==0 for s in out['support']):out.update(status='GAP',reason='calibration_scope_gap')
        else:out.update(status='FEASIBLE',reason='all_calibrations_covered')
    out['values']=sorted(values);out['solution_digest']=hasher.hexdigest()
    return out


def verify_witness(windows, candidates, query, w, pose_bound=8):
    """Independent membership check for a displayed constructive witness."""
    if w['calibration'] not in candidates or set(w['poses'])!=set(windows):return False
    if w['poses'][min(windows)]!=[0,0,0]:return False
    if set(w['points'])!=set().union(*(set(ps) for ps in windows.values())):return False
    for n,points in windows.items():
        t=w['poses'][n]
        if len(t)!=3 or any(type(v) is not int for v in t) or not 0<=t[0]<4 or any(abs(v)>pose_bound for v in t[1:]):return False
        for k,p in points.items():
            b=move(move(box(p['center'],p['radius']),w['calibration']),t)
            if any(type(v) is not int for v in w['points'][k]) or not all(b[0][i]<=w['points'][k][i]<=b[1][i] for i in range(2)):return False
    return (w['points'][query['b']][0]>w['points'][query['a']][0]) is w['value']
