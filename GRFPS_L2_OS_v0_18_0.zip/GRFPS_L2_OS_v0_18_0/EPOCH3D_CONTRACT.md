# Uncertain anchors and epoch admission contract 0.18.0

Executable definitions: `uncertain3d.validate`, `compile_certificate`, `projection`; `epoch_registration.validate_plan`; `Epoch3DBank._registered`. Earlier profiles retain their separate semantics.

| Interface | Profile |
|---|---|
| Registration bundle | `grfps-uncertain3d/0.18.0` |
| Bound plan | `grfps-epoch-registration/0.18.0` |
| Owner bank | `grfps-epoch3d-bank/0.18.0` |
| Observation port | `grfps-observation-port/4` |

## Bundle

The continuous bundle fields remain unchanged, except the profile and the interpretation of local fit anchors. `spatial_fit[*].local_um` is a bounded integer box and may be nondegenerate. There must exist one shared R,t and, for each anchor, a point xi in Li such that Rxi+t lies in Wi. No further cross-anchor correlation is encoded. Controls remain universal over their local boxes and cannot remove fit candidates.

Source epoch is an exact integer from 0 through 128. Epoch zero uses the manifest's initial reference; subsequent source references are bound to their actual reset during plan preflight and admission. Source hash, session, carrier and timebase are unchanged. Target and query are common across the entire plan. All input boxes, horizons, rate family, proper chart bases, canonical rational endpoints and search bounds retain their previous bounded formats.

Input bundle loader bound: 65536 bytes. Plan loader bound: 262144 bytes. A plan contains one to four complete bundles within the combined plan size limit; embedded bundles are schema-validated, not separately serialized through the standalone loader. One to four charts and one to five declared affine clock rates remain supported. Search permits at most 127 cell evaluations and depth eight. These bounds do not promise a wall-clock service time.

## Joint feasibility and witnesses

For each rotation cell, the outer translation intersection is derived from all uncertain local boxes and corresponding reference boxes. Every feasible common transformation is enclosed. Only an empty outer translation intersection can discard a rotation cell.

For fixed exact R,t, each anchor feasibility problem has twelve linear inequalities in three variables. Two fast point candidates precede enumeration of all 220 triples of active planes. A nonsingular triple is solved exactly, then checked against all inequalities. A nonempty bounded polyhedron has an extreme point with three independent active planes, including lower-dimensional cases; therefore this fixed-transform anchor procedure is complete.

Global feasibility search remains incomplete. At a tested rotation parameter it tries up to three distinct translations: the midpoint and the all-lower/all-upper corners of the exact-rotation outer translation box. The cell midpoint is tried first; a feasible parent rotation parameter is retained in any child containing it and retried when needed. Failure to find a witness cannot discard a cell or prove global infeasibility.

A `fit_witness` holds rational parameter `u`, one rational `translation_um` point and an `anchors` list containing each original ID, a feasible local point and its transformed reference point. It is not an outer translation box. Direct checks must use every original correspondence and the same R,t for every anchor.

Projection witnesses additionally hold a current local point, its transformed reference point and the resulting query value. The current local point must lie in the carrier's declared position interval expanded by the bound sensor error. Known requires a singleton answer over the complete outer cover and a PASS certificate. Ambiguous requires two original-constraint witnesses with opposite answers. Overlap without two such witnesses remains Unknown/enclosure_overlap. Witnesses are model states, not physical measurements.

Compiler reason priority remains SPATIAL_FIT_EMPTY; unresolved spatial control/existence (SEARCH_LIMIT if further required refinement is cell-budget blocked, otherwise CONTROL_UNPROVEN or FIT_EXISTENCE_UNPROVEN); CLOCK_FIT_EMPTY; CLOCK_CHECK_REJECTED; PASS. Detailed checks remain in the certificate.

Logical work counters: cell_evaluations, splits, retained_cells, discarded_cells, rate_trials, translation_trials, anchor_checks, plane_triples. Parent/owner/replay recomputation adds uncounted execution work. Snapshot and plan reads do not compile. Direct witness assertions are verification helpers; owner acceptance uses full certificate recomputation and canonical comparison.

## Plan

A plan has exactly `profile` and `entries`. Each entry has exactly `after_record`, `activation_ref`, `bundle`. Entry zero uses source epoch zero, cursor zero and activation null. Later entries have strictly increasing cursors and epochs. Gaps are permitted. Their cursor must be less than the bound record count and immediately follow a real `reference_reset`; activation must be the raw hash of that reset record. Bundle reference name and epoch must equal the resulting observed source scope.

Preflight checks all bound raw line hashes and replays the carrier state to validate reset positions. All ID and evidence_ref values across all fit/check groups and epochs are disjoint. This checks identity reuse, not physical independence. All plans share the same exact target and query.

Later clock fits start no earlier than the reset source timestamp. Clock checks follow fits, and the source validity horizon begins no earlier than the final check; the entire affine target time hull must fit its bound horizon. Spatial anchors contain no independent acquisition timestamps, so their temporal origin is not established by this check.

Plans are prebound historical calibration data. Later compilation is deferred until its reset barrier. New, previously unknown evidence intake and in-epoch certificate revisions are outside this profile.

## Admission state machine

`epoch_registration_result` has exactly kind, at, epoch, after_record, activation_ref, certificate. It is permitted only in RUNNING, unpaused state with a pending plan entry at the exact observed initial/reset barrier. Epoch and cursor must be exact integers and match the observed state. The reset hash, reference name and clock-evidence lower bound must match. The owner recomputes and compares the complete certificate before mutation.

An epoch admits at most one result, including non-PASS results. There is no implicit retry or fallback. Admission after importing any frame in that epoch is rejected. A new PASS certificate alone does not restore the previous pose; a subsequent explicitly scoped frame within both horizons is needed.

A reset clears the current certificate, active bundle and last frame, and records the new activation cursor/hash/time. It preserves registration_history and aggregate registration_work. Missing planned epochs yield Unknown/epoch_unbound. Planned pending epochs yield Unknown/epoch_registration_pending. Reusing a reference name in a later epoch cannot revive an old certificate.

History records each admission's source epoch/reference, activation cursor/hash, admission time, bundle/certificate references, status and work. Full certificates remain in their journal events. The observation port identifies the current source epoch and preserves Unknown joining to room_grid and an empty external effect list.

Initial compiler validation precedes run directory creation. Later compiler workers run at the actual barrier with a subprocess timeout; a failed worker does not commit a certificate. Resume fully replays the original journal and validates the original source and plan before reopening for new commits. The interrupted reset/admission gap survives checkpoint and process restart. Full semantic replay reexecutes every admission and carrier transition; checkpoint data does not bypass it.

Declared scope: synthetic demonstration inputs, historical source semantics, proper continuous position transforms, bounded independent anchor boxes, fixed affine rate family, prebound plans with at most four admissions. Physical authentication, independently measured controls, live calibration acquisition, arbitrary clock drift, registered orientation, room_grid joining and confirmed external effects require additional contracts and evidence.
