"""One bounded sensor read or joint geometry solve per subprocess invocation."""
import sys,time
from pathlib import Path
from grfps_l2 import canon,require
from trace_import import strict_load
from geometry_sensor import capture
from geometry_bank import seal
from trace_geometry import solve

def main():
    v=strict_load(sys.stdin.buffer.read(262145));r=v['request']
    if r['organ']=='geometry_window':
        with Path(sys.argv[1]).open('rb') as stream:w=strict_load(stream.read(262145))
        data=capture(w,r)
    else:
        require(r['organ']=='geometry_solver','organ');p=r['payload'];i=p['inputs']
        data=solve(i['windows'],i['candidates'],i['query'],p['node_limit'],i['pose_bound'])
    at=v['offset']+(time.monotonic_ns()-v['start_ns'])//1000000
    out=dict(data=data,sampled_at=at,exposure=r['exposure'],sample_ref=seal('WorkerSample',dict(exposure=r['exposure'],data=data,sampled_at=at)))
    sys.stdout.buffer.write(canon(out))

if __name__=='__main__':main()
