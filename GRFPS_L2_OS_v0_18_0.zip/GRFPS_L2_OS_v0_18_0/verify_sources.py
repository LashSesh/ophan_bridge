"""Full semantic history and archived source checks, including every Known state."""
import json
from pathlib import Path
from source_segments import replay
from source_registration import capture
from source_runtime import html,export
from noisy_certificate import observation,seal as chart_seal
from source_geometry import verify_witness

from run_source_demo import CASES
def verify(directory,export_views=True):
    root=Path(directory);out={};gallery=[]
    for name in CASES:
        d=root/name;r=replay(d/'journal',collect=True);m=r['machine'];s=m.snapshot();expected=json.loads((d/'report.json').read_text());counts=dict(window=0,solver=0,calibration=0,witnesses=0,known_states=0)
        for k,value in dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,requests=m.request_count,nodes_spent=m.nodes_spent,head=r['head'],state_digest=s['state_digest']).items():assert expected[k]==value,(name,k)
        for before,e,after in zip(r['views'],r['events'],r['views'][1:]):
            pending=before['pending']
            if e['kind']=='geometry_result' and e['outcome']=='OK':
                if pending['organ']=='geometry_window':
                    source=json.loads((d/'samples'/(e['data']['source_ref']+'.json')).read_text())
                    o=e['data'];clock=o['clock'];times=[sum(clock['fit']['host'])//2,sum(clock['check']['host'])//2,clock['sampled_local']-source['clock_offset']]
                    assert capture(source,pending,times)==o;counts['window']+=1
                else:
                    counts['solver']+=1;i=pending['payload']['inputs']
                    for w in e['data']['witnesses'].values():assert verify_witness(i,w);counts['witnesses']+=1
            if e['kind']=='calibration_result' and e['outcome']=='OK':
                o=e['observation'];source=json.loads((d/'samples'/(o['series_ref']+'.json')).read_text())
                assert observation(source,pending['payload']['stage'])==o;counts['calibration']+=1
            assert after['search_budget']['spent']+after['search_budget']['reserved']<=after['search_budget']['total']
            if after['geometry_answer']['epistemic']=='Known':
                result=after['geometry_solution']['result'];assert after['drift']['status']=='VALID' and result['complete'] and result['status']=='FEASIBLE'
                assert all(x['complete'] and x['solutions']>0 for x in result['support'])
                assert result['values']==[after['geometry_answer']['value']]
                assert name=='moving_sources' and after['geometry_answer']['value'] is True
                assert after['temporal_status']=='PASS' and after['reference']=='room_grid'
                assert all(v['clock_registration']['status']=='PASS' and v['spatial_registration']['status']=='PASS' and v['observation']['epoch']==after['source_epochs'][n] for n,v in after['box_windows'].items())
                counts['known_states']+=1
            if e['kind']=='source_reset':
                assert after['geometry_answer']['epistemic']=='Unknown' and e['window'] not in after['box_windows']
            if e['kind']=='resume':
                assert after['source_epochs']==before['source_epochs']
                assert after['spent']==before['spent'] and after['search_budget']['spent']==before['search_budget']['spent'] and after['calibration']==before['calibration']
                assert after['geometry_answer']['epistemic']=='Unknown' and after['box_windows']=={}
        if name=='moving_sources':
            labels=[x['stage'] for x in expected['stages']]
            assert labels==['coarse_ambiguous','fine_known','motion_revokes_old_proof','rotated_window_fixed_answer','clock_epoch_revokes_old_proof','new_clock_registered_known','duplicate_reset_rejected']
            assert m.source_epochs==dict(left=1,right=1) and any(x['status']=='STALE_SOURCE_EPOCH' for x in expected['command_results'])
            refs={x['answer']['registration_ref'] for x in expected['stages']};assert len(refs)==1
        else:assert counts['known_states']==0
        out[name]=dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,requests=m.request_count,nodes_spent=m.nodes_spent,head=r['head'],state_digest=s['state_digest'],http_checks=expected['http_checks'],verified=counts)
        gallery.append(dict(name=name,views=r['views'],events=r['events'],head=r['head']))
        if export_views:export(d/'journal',d/'replay.html')
    if export_views:(root.parent/'source_demo.html').write_text(html(dict(mode='replay',cases=gallery)))
    return dict(cases=out,transitions=sum(x['transitions'] for x in out.values()),http_checks=sum(x['http_checks'] for x in out.values()),requests=sum(x['requests'] for x in out.values()),nodes_spent=sum(x['nodes_spent'] for x in out.values()),synthetic_sources_only=True,full_semantic_replay=True)

if __name__=='__main__':print(json.dumps(verify(Path(__file__).parent/'source_evidence_run'),indent=2))
