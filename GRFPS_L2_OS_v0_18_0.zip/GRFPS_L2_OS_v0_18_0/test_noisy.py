import copy,itertools,json,tempfile,unittest
from pathlib import Path
from noisy_certificate import fixture,observation,fit_candidates,max_residual,evaluate,assess,validate_fixture,seal,point_bounds
from noisy_bridge import NoisyBank,config
from noisy_segments import SegmentJournal,replay,header
from test_uncertain import answer as uncertain_answer

W=lambda broad=False:fixture([0,0,0],broad)
def machine(scope_gap=False):
    c=config('/tmp/w','/tmp/f','/tmp/o','/tmp/c')
    if scope_gap:c['registrations'][0]['hypotheses']=c['registrations'][0]['hypotheses'][:1]
    return NoisyBank(c)
def dispatch(m):return m.reduce(dict(kind='dispatch',at=m.mapper.at,proposal=m.plan()))[0]
def answer(m,w=None,consensus=False,sectors=None):
    r=m.pending
    if r['organ']=='calibration_probe':
        o=observation(W() if w is None else w,r['payload']['stage']);return dict(kind='calibration_result',at=m.mapper.at+1,request=r['id'],exposure=r['exposure'],outcome='OK',observation=o,sampled_at=m.mapper.at+1,sample_ref=seal('Observation',o))
    e=uncertain_answer(m,[0,1,2,3] if sectors is None else sectors)
    if consensus and e['kind']=='scoped_boolean' and r['organ']=='ray_clear':e['event']['value']=True
    return dict(kind='noisy_result',at=e['at'],calibration_ref=m.pending_calibration,event=e)
def sample(m,w):
    at=max(m.mapper.at,m.calibration_attempt+m.contract['calibration_refresh']);m=m.reduce(dict(kind='tick',at=at))[0];
    while m.plan()['organ']!='calibration_probe':
        m=dispatch(m);m=m.reduce(answer(m,w))[0]
    m=dispatch(m);return m.reduce(answer(m,w))[0]
def completed(w=None,scope_gap=False):
    w=W() if w is None else w;m=machine(scope_gap)
    for _ in range(3):m=sample(m,w)
    return m
def adopt(m):return m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=m.recalibration_proposal()))[0]
def projected(broad=False,consensus=False,scope_gap=False):
    w=W(broad);m=sample(adopt(completed(w,scope_gap)),w)
    for _ in range(20):
        p=m.projections()[0]
        if p['epistemic'] in ['Known','Ambiguous'] or p['reason']=='calibration_scope_gap':return m
        m=dispatch(m);m=m.reduce(answer(m,w,consensus))[0]
    raise AssertionError('missing projection')
def fresh_fit(m,w):
    while m.next_stage()!='fit':m=sample(m,W())
    return sample(m,w)
def campaign(w):return dict(fit=dict(observation=observation(w,'fit')),checks={k:dict(observation=observation(w,k)) for k in ['check0','check1']})

class BoundedFitTests(unittest.TestCase):
    def test_complete_against_grid_oracle(self):
        for broad in [False,True]:
            for q in range(4):
                w=fixture([q,0,0],broad);ps=w['samples']['fit'];actual=fit_candidates(ps)
                oracle=[list(t) for t in itertools.product(range(4),range(-4,5),range(-4,5)) if max_residual(ps,t)<=1];self.assertEqual(actual,oracle)
    def test_ground_truth_retained_under_declared_noise(self):
        for q in range(4):self.assertIn([q,3,-2],fit_candidates(fixture([q,3,-2])['samples']['fit']))
    def test_multiple_rotations_retained(self):
        r=evaluate(campaign(W(True)));self.assertEqual(r['status'],'PASS');self.assertEqual(len(r['candidates']),14);self.assertEqual({t[0] for t in r['candidates']},{0,1,2,3})
    def test_translation_uncertainty_retained(self):self.assertEqual(len(evaluate(campaign(W()))['candidates']),9)
    def test_check_never_prunes_set(self):
        w=W();before=fit_candidates(w['samples']['fit']);w['samples']['check1'][0]['raw'][0]+=5;r=evaluate(campaign(w));self.assertEqual(r['status'],'CHECK_REJECTED');self.assertEqual(r['candidates'],before);self.assertIsNone(r['certificate'])
    def test_partial_check_rejects_whole_candidate_set(self):
        w=W();w['samples']['check1'][0]['raw'][0]+=5;r=evaluate(campaign(w));self.assertEqual(r['checks']['check1']['status'],'UNCERTAIN');self.assertEqual(r['status'],'CHECK_REJECTED')
    def test_invalid_fit(self):
        w=W();w['samples']['fit'][1]['raw'][0]+=8;self.assertEqual(evaluate(campaign(w))['status'],'FIT_REJECTED')
    def test_protocol_cannot_be_relaxed(self):
        w=W();w['protocol']['fit_error']=2
        with self.assertRaises(ValueError):validate_fixture(w)
    def test_boolean_coordinate_rejected(self):
        w=W();w['samples']['fit'][0]['raw'][0]=True
        with self.assertRaises(ValueError):validate_fixture(w)
    def test_fit_check_identity_leak(self):
        w=W();w['samples']['check0'][0]['id']='fit0'
        with self.assertRaises(ValueError):validate_fixture(w)
    def test_repeated_checks_use_same_targets(self):
        w=W();w['samples']['check1'][0]['reference'][0]+=1
        with self.assertRaises(ValueError):validate_fixture(w)
    def test_coincident_raws_allowed_under_quantization(self):
        w=W(True);w['samples']['fit'][1]['raw']=[0,0];validate_fixture(w);self.assertTrue(fit_candidates(w['samples']['fit']))
    def test_order_invariance(self):
        ps=W()['samples']['fit'];self.assertEqual(fit_candidates(ps),fit_candidates(list(reversed(ps))))
    def test_bounds_contain_each_candidate(self):
        cert=evaluate(campaign(W(True)))['certificate'];p=[3,-2];b=point_bounds(p,cert)
        from mapping import transform,inverse
        raw=transform(p,inverse(cert['representative']))
        for t in cert['candidates']:
            v=transform(raw,t);self.assertTrue(all(b['min'][i]<=v[i]<=b['max'][i] for i in range(2)))

class NoisyRuntimeTests(unittest.TestCase):
    def test_three_separate_observations_required(self):
        m=sample(machine(),W());self.assertIsNone(m.recalibration_proposal());self.assertEqual(m.next_stage(),'check0');m=sample(m,W());self.assertIsNone(m.recalibration_proposal());self.assertEqual(m.next_stage(),'check1');m=sample(m,W());self.assertIsNotNone(m.recalibration_proposal());self.assertEqual(m.request_count,3)
    def test_adoption_preserves_cost_and_resets_evidence(self):
        m=completed();spent=m.spent;m=adopt(m);self.assertEqual(m.spent,spent);self.assertEqual(m.mapper.frame,1);self.assertEqual(m.monitor()['status'],'UNKNOWN');self.assertIsNone(m.fresh_campaign())
    def test_mixed_answers_under_all_rotations_stay_ambiguous(self):
        m=projected(True);p=m.projections()[0];self.assertEqual(p['epistemic'],'Ambiguous');self.assertIsNone(p['value']);self.assertEqual(len(p['rotation_support']),4)
    def test_universal_true_with_uncertain_rotation(self):
        m=projected(True,True);self.assertIs(m.projections()[0]['value'],True);self.assertEqual(m.projections()[0]['registration_status'],'Ambiguous')
    def test_universal_false_with_uncertain_rotation(self):
        m=projected(True)
        for key,e in m.boolean.items():
            if key.startswith('ray_clear.'):e['value']=False
        self.assertIs(m.projections()[0]['value'],False)
    def test_narrow_rotation_known_translation_uncertain(self):
        m=projected();self.assertIs(m.projections()[0]['value'],True);self.assertEqual(len(m.calibration['certificate']['candidates']),9)
    def test_scope_gap_must_not_drop_transformations(self):
        m=projected(True,False,True);self.assertEqual(m.projections()[0]['reason'],'calibration_scope_gap');self.assertIsNone(m.projections()[0]['value'])
    def test_orientation_probe_must_not_silently_shrink_calibration(self):
        m=dispatch(projected(True));self.assertEqual(m.pending['organ'],'registration_probe');m=m.reduce(answer(m,W(True),sectors=[0]))[0];self.assertEqual(m.projections()[0]['reason'],'calibration_scope_gap');self.assertEqual(len(m.calibration['certificate']['candidates']),14)
    def test_partial_monitor_is_unknown_not_drift_or_valid(self):
        m=projected();w=W();
        for p in w['samples']['fit']:p['raw'][0]+=3
        m=fresh_fit(m,w);self.assertEqual(m.monitor()['sample_class'],'UNCERTAIN');self.assertEqual(m.monitor()['status'],'UNKNOWN');self.assertFalse(m.revoked)
    def test_all_candidates_fail_latches_drift(self):
        m=projected();w=W()
        for ps in w['samples'].values():
            for p in ps:p['raw'][0]+=10
        m=fresh_fit(m,w);self.assertTrue(m.revoked);self.assertEqual(m.breaches,1);m=sample(m,w);self.assertEqual(m.breaches,1)
    def test_missing_checks_cannot_be_replayed_as_other_stage(self):
        m=sample(machine(),W());m=m.reduce(dict(kind='tick',at=200))[0];m=dispatch(m);e=answer(m);e['observation']['stage']='check1';e['sample_ref']=seal('Observation',e['observation'])
        with self.assertRaises(ValueError):m.reduce(e)
    def test_mixed_source_campaign_rejected(self):
        m=sample(machine(),W());m=m.reduce(dict(kind='tick',at=200))[0];m=dispatch(m);w=W();w['dataset']='different'
        with self.assertRaises(ValueError):m.reduce(answer(m,w))
    def test_expiry_invalidates_whole_campaign(self):
        m=completed();p=m.recalibration_proposal()
        with self.assertRaises(ValueError):m.reduce(dict(kind='recalibrate',at=2001,proposal=p))
    def test_mutated_certificate_rejected(self):
        m=completed();p=m.recalibration_proposal();p['certificate']['candidates'].pop()
        with self.assertRaises(ValueError):m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=p))
    def test_late_result_cost_retained(self):
        m=dispatch(machine());e=answer(m);e['at']=m.pending['deadline']+1;m=m.reduce(e)[0];self.assertEqual(m.spent,1);self.assertIsNone(m.campaign)
    def test_failure_restarts_campaign(self):
        m=sample(machine(),W());m=m.reduce(dict(kind='tick',at=200))[0];m=dispatch(m);e=answer(m);e.update(outcome='ERROR',observation=None,sampled_at=None,sample_ref=None);m=m.reduce(e)[0];self.assertEqual(m.next_stage(),'fit');self.assertEqual(m.spent,2)
    def test_old_frame_does_not_rebuild_campaign(self):
        m=dispatch(machine());e=answer(m);m=m.reduce(dict(kind='frame',at=0))[0];m=m.reduce(e)[0];self.assertEqual(m.last['status'],'SUPERSEDED');self.assertIsNone(m.campaign)
    def test_pending_adoption_forbidden(self):
        m=projected()
        while evaluate(m.fresh_campaign())['status']!='PASS':m=sample(m,W())
        p=m.recalibration_proposal();m=dispatch(m)
        with self.assertRaises(ValueError):m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=p))
    def test_completed_candidate_waits_for_adoption_or_expiry(self):
        m=completed();m=m.reduce(dict(kind='tick',at=1000))[0];self.assertIsNone(m.plan());self.assertIsNotNone(m.recalibration_proposal());m=m.reduce(dict(kind='tick',at=2001))[0];self.assertEqual(m.plan()['payload']['stage'],'fit')
    def test_resume_keeps_set_and_budget(self):
        m=projected();old=copy.deepcopy(m.calibration);spent=m.spent;m=m.reduce(dict(kind='stop',at=m.mapper.at,reason='user'))[0];m=m.reduce(dict(kind='resume',at=3000))[0];self.assertEqual(m.calibration,old);self.assertEqual(m.spent,spent);self.assertEqual(m.monitor()['status'],'UNKNOWN')
    def test_due_calibration_yields_one_ordinary_request(self):
        m=sample(adopt(completed()),W());m=m.reduce(dict(kind='tick',at=m.mapper.at+200))[0]
        self.assertNotEqual(m.plan()['organ'],'calibration_probe');m=dispatch(m);m=m.reduce(answer(m,W()))[0];self.assertEqual(m.plan()['organ'],'calibration_probe')
    def test_pending_across_segment(self):
        with tempfile.TemporaryDirectory(dir='/tmp') as t:
            c=config('/tmp/w','/tmp/f','/tmp/o','/tmp/c');c['segment_records']=16;j=SegmentJournal(Path(t)/'j',c)
            for _ in range(15):j.commit(dict(kind='tick',at=0))
            j.commit(dict(kind='dispatch',at=0,proposal=j.machine.plan()));j.commit(answer(j.machine));s=j.machine.snapshot();j.close();self.assertEqual(replay(Path(t)/'j')['machine'].snapshot(),s)
if __name__=='__main__':unittest.main()
