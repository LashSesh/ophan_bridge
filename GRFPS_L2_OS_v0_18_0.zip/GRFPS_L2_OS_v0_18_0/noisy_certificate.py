"""Bounded integer calibration errors; complete candidate set, held-out universal checks.
No stochastic confidence or continuous-angle coverage is asserted.
"""
import copy,itertools
from grfps_l2 import canon,fields,ident,require
from mapping import rot,transform,inverse,hashof,validate_patch
from calibration_certificate import point,pose
PROFILE='grfps-bounded-calibration/1'
PROTOCOL=dict(algorithm='c4-box-enumeration/1',raw_frame='sensor_local',reference_frame='window_local',units='model_grid_step',coordinate_limit=64,translation_limit=128,fit_error=1,check_error=3,monitor_error=3,check_stages=['check0','check1'],max_points_per_stage=16,max_candidates=36,window_error=0)
def seal(kind,x):return hashof(kind,dict(profile=PROFILE,value=x))
def hash64(s):return type(s) is str and len(s)==64 and all(c in '0123456789abcdef' for c in s)
def validate_points(ps,minimum):
    require(type(ps) is list and minimum<=len(ps)<=16,'point_count')
    for p in ps:
        fields(p,'id raw reference');require(ident(p['id']) and point(p['raw']) and point(p['reference']),'point')
    require(len({p['id'] for p in ps})==len(ps) and len({tuple(p['reference']) for p in ps})==len(ps),'point_identity');return ps

def fixture(t=None,broad=False):
    t=[1,3,-2] if t is None else t;require(pose(t),'pose')
    fit=[[0,0],[1,0],[0,1]] if broad else [[0,0],[6,0],[0,6]]
    check=[[-1,0],[0,-1]] if broad else [[4,3],[-3,4]]
    def points(refs,prefix,noise):return [dict(id=prefix+str(i),reference=list(p),raw=[a+b for a,b in zip(transform(p,inverse(t)),noise)]) for i,p in enumerate(refs)]
    return dict(profile='grfps-noisy-fixture/1',protocol=copy.deepcopy(PROTOCOL),dataset='broad' if broad else 'spread',samples=dict(fit=points(fit,'fit',[0,0] if broad else [1,0]),check0=points(check,'test',[0,0]),check1=points(check,'test',[0,0] if broad else [-1,0])))
def validate_fixture(w):
    fields(w,'profile protocol dataset samples');require(w['profile']=='grfps-noisy-fixture/1' and canon(w['protocol'])==canon(PROTOCOL) and ident(w['dataset']),'fixture_protocol');fields(w['samples'],'fit check0 check1')
    for stage,ps in w['samples'].items():validate_points(ps,3 if stage=='fit' else 2)
    validate_partition(w['samples']);return w

def validate_partition(samples):
    fit=samples['fit'];a=fit[0]['reference'];require(any((b['reference'][0]-a[0])*(c['reference'][1]-a[1])!=(b['reference'][1]-a[1])*(c['reference'][0]-a[0]) for b in fit[1:] for c in fit[1:]),'degenerate_reference')
    for stage in ['check0','check1']:
        if stage not in samples:continue
        ps=samples[stage];require(not ({p['id'] for p in fit}&{p['id'] for p in ps}) and not ({tuple(p['reference']) for p in fit}&{tuple(p['reference']) for p in ps}),'partition_leak')
    if 'check0' in samples and 'check1' in samples:require({p['id']:p['reference'] for p in samples['check0']}=={p['id']:p['reference'] for p in samples['check1']},'check_target_change')

def observation(w,stage):
    validate_fixture(w);require(stage in ['fit','check0','check1'],'stage')
    return dict(profile='grfps-noisy-observation/1',protocol_ref=seal('Protocol',PROTOCOL),series_ref=seal('Series',w),dataset=w['dataset'],stage=stage,points=copy.deepcopy(w['samples'][stage]))
def validate_observation(o):
    fields(o,'profile protocol_ref series_ref dataset stage points');require(o['profile']=='grfps-noisy-observation/1' and o['protocol_ref']==seal('Protocol',PROTOCOL) and hash64(o['series_ref']) and ident(o['dataset']) and o['stage'] in ['fit','check0','check1'],'observation_protocol');validate_points(o['points'],3 if o['stage']=='fit' else 2)
    if o['stage']=='fit':validate_partition(dict(fit=o['points']))
    return o

def fit_candidates(ps):
    validate_points(ps,3);validate_partition(dict(fit=ps));out=[];a=sorted(ps,key=lambda p:p['id'])[0]
    for q in range(4):
        center=[v-u for v,u in zip(a['reference'],rot(a['raw'],q))]
        for dx,dy in itertools.product(range(-1,2),repeat=2):
            t=[q,center[0]+dx,center[1]+dy]
            if pose(t) and max_residual(ps,t)<=1:out.append(t)
    return sorted(out)
def max_residual(ps,t):return max(max(abs(a-b) for a,b in zip(transform(p['raw'],t),p['reference'])) for p in ps)
def assess(ps,candidates,limit):
    rs=[max_residual(ps,t) for t in candidates];n=sum(r<=limit for r in rs)
    return dict(compatible=n,total=len(rs),best=min(rs) if rs else None,worst=max(rs) if rs else None,residuals=rs,status='WITHIN' if rs and n==len(rs) else 'DRIFT' if rs and n==0 else 'UNCERTAIN' if rs else 'UNKNOWN')
def evaluate(campaign):
    if not campaign:return dict(status='WAITING_FIT',candidates=[],checks={},certificate=None)
    fit=campaign['fit']['observation'];candidates=fit_candidates(fit['points']);checks={};samples=dict(fit=fit['points'])
    for stage in ['check0','check1']:
        if stage in campaign['checks']:
            o=campaign['checks'][stage]['observation'];require(o['series_ref']==fit['series_ref'] and o['dataset']==fit['dataset'] and o['stage']==stage,'campaign_binding');samples[stage]=o['points'];checks[stage]=assess(o['points'],candidates,3)
    validate_partition(samples);status='FIT_REJECTED' if not candidates else 'CHECK_REJECTED' if any(c['status']!='WITHIN' for c in checks.values()) else 'PASS' if len(checks)==2 else 'WAITING_CHECKS'
    cert=None
    if status=='PASS':
        cert=dict(profile=PROFILE,protocol=copy.deepcopy(PROTOCOL),series_ref=fit['series_ref'],fit_ref=seal('Observation',fit),check_refs={k:seal('Observation',campaign['checks'][k]['observation']) for k in ['check0','check1']},candidates=candidates,representative=candidates[0],checks=checks)
    return dict(status=status,candidates=candidates,checks=checks,certificate=cert)

def corrected_patch(raw,cert,calibration_ref):
    validate_patch(raw);require(all(point(v) for v in raw['points'].values()),'raw_domain');out=copy.deepcopy(raw);out['points']={k:list(transform(v,cert['representative'])) for k,v in raw['points'].items()}
    out['sample_ref']=seal('RepresentativeSample',dict(raw_sample_ref=raw['sample_ref'],raw_patch_ref=hashof('Patch',raw),calibration_ref=calibration_ref,certificate_ref=seal('Certificate',cert)));validate_patch(out);return out

def point_bounds(p,cert):
    raw=transform(p,inverse(cert['representative']));ps=[transform(raw,t) for t in cert['candidates']]
    return dict(min=[min(v[i] for v in ps) for i in range(2)],max=[max(v[i] for v in ps) for i in range(2)])
