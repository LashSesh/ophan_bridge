import copy,json,tempfile,unittest
from decimal import Decimal
from pathlib import Path
from carrier_contract import CarrierState,manifest,preflight,interval,pose,read_line,MAX_BYTES
from carrier_bank import CarrierBank,config,checkpoint
from carrier_segments import SegmentJournal,replay
from carrier_fixtures import dataset
from test_sources import machine
from grfps_l2 import canon

def frame():return json.loads(dataset('rehearsal')[0].splitlines()[0])
def raw(x):return json.dumps(x)+'\n'
def bank(lines=None):
    cc,ls,_=preflight(lines or (raw(frame()).encode()),manifest());return CarrierBank(config(machine().contract,cc)),ls
class CarrierTests(unittest.TestCase):
    def test_original_rehearsal_retains_origin(self):
        _,_,s=preflight(*dataset('rehearsal'));self.assertEqual((s['frames'],s['events'],s['facticity'],s['physical_validation']),(180,5,'Simulated','Unknown'))
    def test_missing_tracking_is_unknown(self):
        f=frame();f.pop('tracking_state');s=CarrierState(manifest()).apply(raw(f));self.assertIsNone(s['latest']['pose']);self.assertEqual(s['counts']['unavailable'],1)
    def test_partial_validity_has_no_full_pose(self):
        f=frame();f['tracking_state']='POSITION_VALID';self.assertIsNone(CarrierState(manifest()).apply(raw(f))['latest']['pose'])
    def test_missing_metrics_are_not_zero(self):
        f=frame();f.pop('application_frame_ms');f.pop('registration_error_m');s=CarrierState(manifest()).apply(raw(f));self.assertEqual(s['application_us'],dict(count=0,missing=1,max=None));self.assertEqual(s['registration_um']['max'],None)
    def test_reported_origin_is_not_physical_validation(self):
        f=frame();f['source_api']='OpenXR';s=CarrierState(manifest('recorded','OpenXR')).apply(raw(f));self.assertEqual(s['facticity'],'Recorded');self.assertEqual(s['physical_validation'],'Unknown')
    def test_dry_run_cannot_claim_recorded(self):
        with self.assertRaisesRegex(ValueError,'origin_promotion'):CarrierState(manifest('recorded'))
    def test_api_identity_bound_to_manifest(self):
        f=frame();f['source_api']='OpenXR'
        with self.assertRaisesRegex(ValueError,'api_binding'):CarrierState(manifest()).apply(raw(f))
    def test_session_override_rejected(self):
        f=frame();f['session_id']='intruder'
        with self.assertRaisesRegex(ValueError,'identity_override'):CarrierState(manifest()).apply(raw(f))
    def test_exact_decimal_enclosure(self):
        self.assertEqual(interval(Decimal('-0.0000001')),[-1,0]);self.assertEqual(interval(Decimal('0.0000001')),[0,1]);self.assertEqual(interval(Decimal('0.032')),[32000,32000])
    def test_nan_and_infinity_rejected(self):
        for value in ['NaN','Infinity','-Infinity']:
            with self.subTest(value=value),self.assertRaises(ValueError):read_line('{"x":'+value+'}')
    def test_boolean_coordinate_rejected(self):
        f=frame();f['head_pose']['position_m'][0]=True
        with self.assertRaises(ValueError):CarrierState(manifest()).apply(raw(f))
    def test_wrong_vector_dimensions_rejected(self):
        f=frame();f['head_pose']['orientation_xyzw']=[1]
        with self.assertRaisesRegex(ValueError,'dimensions'):CarrierState(manifest()).apply(raw(f))
    def test_nonunit_quaternion_rejected(self):
        f=frame();f['head_pose']['orientation_xyzw']=[0,0,0,0]
        with self.assertRaisesRegex(ValueError,'quaternion_norm'):CarrierState(manifest()).apply(raw(f))
    def test_duplicate_json_key_rejected(self):
        with self.assertRaisesRegex(ValueError,'duplicate_key'):read_line('{"x":1,"x":2}')
    def test_extreme_decimal_exponent_rejected(self):
        with self.assertRaisesRegex(ValueError,'numeric_bounds'):interval(Decimal('0e-999999'))
    def test_fractional_frame_index_rejected(self):
        f=frame();f['frame_index']=0.0
        with self.assertRaisesRegex(ValueError,'frame_sequence'):CarrierState(manifest()).apply(raw(f))
    def test_frame_gap_rejected(self):
        f=frame();f['frame_index']=1
        with self.assertRaisesRegex(ValueError,'frame_sequence'):CarrierState(manifest()).apply(raw(f))
    def test_frame_time_must_increase(self):
        s=CarrierState(manifest());f=frame();s.apply(raw(f));f['frame_index']=1
        with self.assertRaisesRegex(ValueError,'frame_time'):s.apply(raw(f))
    def test_large_time_stays_exact(self):
        f=frame();f['monotonic_time_ns']=2**53+13;s=CarrierState(manifest()).apply(raw(f));self.assertEqual(s['latest']['source_time_ns'],'9007199254741005');canon(s)
    def test_timestamp_bool_rejected(self):
        f=frame();f['monotonic_time_ns']=True
        with self.assertRaisesRegex(ValueError,'timestamp'):CarrierState(manifest()).apply(raw(f))
    def test_reset_clears_pose_and_binds_next_epoch(self):
        s=CarrierState(manifest());f=frame();s.apply(raw(f));e=dict(record_kind='event',kind='reference_reset',previous=0,epoch=1,reference_space='STAGE',monotonic_time_ns=f['monotonic_time_ns']);self.assertIsNone(s.apply(raw(e))['latest']);f.update(frame_index=1,monotonic_time_ns=f['monotonic_time_ns']+1,source_epoch=0)
        with self.assertRaisesRegex(ValueError,'epoch_binding'):s.apply(raw(f))
    def test_duplicate_reset_rejected(self):
        s=CarrierState(manifest());e=dict(record_kind='event',kind='reference_reset',previous=0,epoch=1,reference_space='STAGE',monotonic_time_ns=0);s.apply(raw(e))
        with self.assertRaisesRegex(ValueError,'reference_reset'):s.apply(raw(e))
    def test_visibility_loss_clears_pose(self):
        s=CarrierState(manifest());f=frame();s.apply(raw(f));e=dict(record_kind='event',kind='visibility',visibility_state='hidden',monotonic_time_ns=f['monotonic_time_ns']);self.assertIsNone(s.apply(raw(e))['latest'])
    def test_input_echo_never_reconciles_effect(self):
        s=CarrierState(manifest());e=dict(record_kind='event',kind='interaction',action='select',roundtrip_ok=True,monotonic_time_ns=1);v=s.apply(raw(e));self.assertEqual(v['last_event']['effect_status'],'Unknown');self.assertIsNone(v['last_event']['receipt'])
    def test_event_time_regression_rejected(self):
        s=CarrierState(manifest());s.apply(raw(frame()))
        with self.assertRaisesRegex(ValueError,'time_regression'):s.apply(raw(dict(record_kind='event',kind='interaction',action='select',monotonic_time_ns=0)))
    def test_native_valid_flags_do_not_establish_tracking(self):
        f=frame();f['head_location_flags']=3;s=CarrierState(manifest()).apply(raw(f));self.assertIsNone(s['latest']['pose']);self.assertEqual(s['latest']['tracking'],'PARTIAL')
    def test_native_flags_cannot_upgrade_missing_tracking(self):
        f=frame();f.pop('tracking_state');f['head_location_flags']=15;self.assertIsNone(CarrierState(manifest()).apply(raw(f))['latest']['pose'])
    def test_failed_native_capture_discards_pose(self):
        f=frame();f['capture_status']=dict(xrLocateSpace=-1,xrLocateViews=-1);s=CarrierState(manifest()).apply(raw(f));self.assertIsNone(s['latest']['pose']);self.assertEqual(s['latest']['views'],[])
    def test_emulated_position_cannot_be_full_tracking(self):
        f=frame();f['emulated_position']=True;f['head_location_flags']=15;self.assertIsNone(CarrierState(manifest()).apply(raw(f))['latest']['pose'])
    def test_empty_and_oversize_input_rejected(self):
        for data in [b'',b' '*(MAX_BYTES+1)]:
            with self.subTest(size=len(data)),self.assertRaises(ValueError):preflight(data,manifest())
    def test_content_hash_is_byte_exact(self):
        f=frame();a,_,_=preflight(raw(f).encode(),manifest());b,_,_=preflight(json.dumps(f,indent=None,separators=(',',':')).encode(),manifest());self.assertNotEqual(a['raw_sha256'],b['raw_sha256'])
    def test_bank_rejects_changed_record_atomically(self):
        m,ls=bank();before=m.snapshot();f=frame();f['head_pose']['position_m'][0]=1
        with self.assertRaisesRegex(ValueError,'raw_binding'):m.reduce(dict(kind='carrier_record',at=0,index=0,raw=raw(f)))
        self.assertEqual(m.snapshot(),before)
    def test_bank_rejects_duplicate_cursor(self):
        m,ls=bank();e=dict(kind='carrier_record',at=0,index=0,raw=ls[0]);m=m.reduce(e)[0]
        with self.assertRaisesRegex(ValueError,'cursor'):m.reduce(e)
    def test_pause_blocks_ingestion(self):
        m,ls=bank();m=m.reduce(dict(kind='pause',at=0,paused=True))[0]
        with self.assertRaises(ValueError):m.reduce(dict(kind='carrier_record',at=0,index=0,raw=ls[0]))
    def test_port_keeps_spatial_and_clock_join_unknown(self):
        m,ls=bank();m=m.reduce(dict(kind='carrier_record',at=0,index=0,raw=ls[0]))[0];p=m.snapshot()['observation_port'];self.assertEqual(p['joining'],dict(spatial='Unknown',clock='Unknown'));self.assertEqual(p['external_effects'],[]);self.assertTrue(all(x['effect']=='local_view' for x in p['affordances']))
    def test_resume_retains_history_without_freshness_promotion(self):
        m,ls=bank();m=m.reduce(dict(kind='carrier_record',at=0,index=0,raw=ls[0]))[0];old=m.snapshot()['carrier'];m=m.reduce(dict(kind='stop',at=0,reason='user'))[0];m=m.reduce(dict(kind='resume',at=6000))[0];self.assertEqual(m.snapshot()['carrier'],old);self.assertEqual(old['temporal_scope'],'historical_file')
    def test_carrier_rollover_full_replay(self):
        data,mf=dataset('rehearsal');cc,ls,_=preflight(data,mf);c=config(machine().contract,cc);c['segment_records']=16
        with tempfile.TemporaryDirectory(dir='/tmp') as tmp:
            j=SegmentJournal(Path(tmp)/'j',c)
            for i,line in enumerate(ls[:20]):j.commit(dict(kind='carrier_record',at=i,index=i,raw=line))
            expected=j.machine.snapshot();j.close();r=replay(Path(tmp)/'j');self.assertEqual(r['machine'].snapshot(),expected);self.assertEqual(r['index'],1)
    def test_checkpoint_tamper_rejected(self):
        m,ls=bank()
        with tempfile.TemporaryDirectory(dir='/tmp') as tmp:
            j=SegmentJournal(Path(tmp)/'j',m.contract);j.close();p=Path(tmp)/'j/segment-000000.jsonl';x=json.loads(p.read_text());x['checkpoint']['bank']['carrier_state']['epoch']=1;p.write_bytes(canon(x)+b'\n')
            with self.assertRaisesRegex(ValueError,'checkpoint_or_link'):replay(Path(tmp)/'j')
class CarrierIntegrationTests(unittest.TestCase):
    def test_supplied_evaluator_counterexamples(self):
        from audit_carrier_intake import report
        r=report();self.assertTrue(all(r['reproduced_boundary_failures'].values()));self.assertTrue(r['negative_control_missing_registration_is_unknown'])
    def test_actual_javascript_encoder_is_accepted(self):
        import subprocess,shutil
        if not shutil.which('node'):self.skipTest('Node unavailable')
        r=subprocess.run(['node','test_webxr_probe.cjs','--fixture'],cwd=Path(__file__).parent,capture_output=True,check=True)
        _,_,s=preflight(r.stdout,manifest('recorded','WebXR','local'));self.assertEqual(s['facticity'],'Recorded');self.assertIsNone(s['latest']['pose']);self.assertEqual(s['physical_validation'],'Unknown')
if __name__=='__main__':unittest.main()
