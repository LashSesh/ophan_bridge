import copy,tempfile,unittest
from pathlib import Path
from uncertain_bridge import UncertainBank,config,scope_ref,seal,probe_fixture
from uncertain_segments import SegmentJournal,replay
from uncertain_runtime import UncertainService
from test_registered import answer as old_answer,field

def answer(m,sectors=None):
    if m.pending['organ']=='registration_probe':
        r=m.pending;return dict(kind='probe_result',at=m.mapper.at+1,request=r['id'],exposure=r['exposure'],outcome='OK',sectors=[0] if sectors is None else sectors,sampled_at=m.mapper.at+1,sample_ref=seal('OrientationWorld',probe_fixture()))
    w=field();w['cells'][1][0]['solid']=True
    e=old_answer(m,w if m.pending['organ']!='window' else None)
    if e['kind']=='scoped_boolean':e['scope_ref']=scope_ref(m.contract)
    return e

def ambiguous():
    m=UncertainBank(config('/tmp/w','/tmp/f','/tmp/o'))
    for _ in range(16):
        if m.projections()[0]['epistemic']=='Ambiguous':return m
        m=m.reduce(dict(kind='dispatch',at=m.mapper.at,proposal=m.plan()))[0];m=m.reduce(answer(m))[0]
    raise AssertionError('no ambiguity')
def pending():
    m=ambiguous();return m.reduce(dict(kind='dispatch',at=m.mapper.at,proposal=m.plan()))[0]

class UncertainTests(unittest.TestCase):
    def test_initial(self):self.assertEqual(UncertainBank(config('/tmp/w','/tmp/f','/tmp/o')).projections()[0]['reason'],'unobserved_geometry')
    def test_disagreement(self):
        p=ambiguous().projections()[0];self.assertEqual(p['gate'],'HOLD');self.assertIsNone(p['value']);self.assertEqual(len(p['hypotheses']),2)
    def test_probe_selected(self):self.assertEqual(ambiguous().plan()['organ'],'registration_probe')
    def test_east(self):
        m=pending();m=m.reduce(answer(m))[0];self.assertIs(m.projections()[0]['value'],True);self.assertEqual(m.projections()[0]['registration_status'],'Known')
    def test_north_false(self):
        m=pending();m=m.reduce(answer(m,[1]))[0];self.assertIs(m.projections()[0]['value'],False)
    def test_unanimity(self):
        m=ambiguous();m.boolean['ray_clear.s1']['value']=True;p=m.projections()[0];self.assertEqual(p['registration_status'],'Ambiguous');self.assertIs(p['value'],True);self.assertNotEqual(m.plan()['organ'],'registration_probe')
    def test_unanimous_false(self):
        m=ambiguous();m.boolean['ray_clear.s0']['value']=False;self.assertIs(m.projections()[0]['value'],False)
    def test_missing(self):
        m=ambiguous();del m.boolean['ray_clear.s1'];self.assertEqual(m.projections()[0]['epistemic'],'Unknown')
    def test_empty_intersection(self):
        m=pending();m=m.reduce(answer(m,[3]))[0];self.assertEqual(m.projections()[0]['reason'],'geometry_counterevidence');self.assertIsNone(m.projections()[0]['value'])
    def test_uninformative(self):
        m=pending();m=m.reduce(answer(m,[0,1]))[0];self.assertEqual(m.projections()[0]['epistemic'],'Ambiguous');self.assertNotEqual(m.plan()['organ'],'registration_probe')
    def test_error_cost(self):
        m=pending();cost=m.spent;e=answer(m);e.update(outcome='ERROR',sectors=None,sampled_at=None,sample_ref=None);m=m.reduce(e)[0];self.assertEqual(m.spent,cost);self.assertFalse(m.probes)
    def test_budget(self):
        m=ambiguous();m.spent=m.config['budget'];self.assertIsNone(m.plan());self.assertEqual(m.projections()[0]['gate'],'HOLD')
    def test_frame(self):
        m=pending();e=answer(m);m=m.reduce(dict(kind='frame',at=m.mapper.at))[0];m=m.reduce(e)[0];self.assertEqual(m.last['status'],'SUPERSEDED');self.assertFalse(m.probes)
    def test_timeout(self):
        m=pending();e=answer(m);e['at']=m.pending['deadline']+1;m=m.reduce(e)[0];self.assertEqual(m.last['status'],'TIMEOUT');self.assertFalse(m.probes)
    def test_invalid_results(self):
        m=pending()
        for sectors in [[],[True],[0,0],[4],[1,0]]:
            with self.subTest(sectors=sectors),self.assertRaises(ValueError):m.reduce(answer(m,sectors))
        e=answer(m);e['exposure']='0'*64
        with self.assertRaises(ValueError):m.reduce(e)
    def test_invalid_config(self):
        c=config('/tmp/w','/tmp/f','/tmp/o');c['registrations'][0]['error_bound']=-1
        with self.assertRaises(ValueError):UncertainBank(c)
        c=config('/tmp/w','/tmp/f','/tmp/o');c['registrations'][0]['hypotheses'][1]['sector']=0
        with self.assertRaises(ValueError):UncertainBank(c)
    def test_exact_error_bound(self):
        m=ambiguous();m.contract['registrations'][0]['error_bound']=0;self.assertEqual(m.projections()[0]['registration_status'],'Known')
    def test_expiry(self):
        m=pending();m=m.reduce(answer(m))[0];m=m.reduce(dict(kind='tick',at=2000))[0];self.assertEqual(m.projections()[0]['epistemic'],'Unknown');self.assertIsNone(m.projections()[0]['probe_ref'])
    def test_support_change(self):
        m=pending();m=m.reduce(answer(m))[0];next(iter(m.mapper.patches.values()))['sampled_at']+=1;self.assertIsNone(m.context(m.contract['registrations'][0])['probe'])
    def test_segment_pending(self):
        with tempfile.TemporaryDirectory() as t:
            c=config('/tmp/w','/tmp/f','/tmp/o');c['segment_records']=16;j=SegmentJournal(Path(t)/'j',c)
            while j.machine.projections()[0]['epistemic']!='Ambiguous':
                j.commit(dict(kind='dispatch',at=j.machine.mapper.at,proposal=j.machine.plan()));j.commit(answer(j.machine))
            while j.count<15:j.commit(dict(kind='tick',at=j.machine.mapper.at))
            j.commit(dict(kind='dispatch',at=j.machine.mapper.at,proposal=j.machine.plan()));cost=j.machine.spent;j.commit(answer(j.machine));s=j.machine.snapshot();j.close();r=replay(Path(t)/'j');self.assertEqual(r['machine'].snapshot(),s);self.assertEqual(r['machine'].spent,cost)
    def test_invalid_worker(self):
        with tempfile.TemporaryDirectory() as t:
            d=Path(t);o=d/'o';o.write_text('{}');j=SegmentJournal(d/'j',config(d/'w',d/'f',o));j.machine=pending();j.machine.contract['probe_world']=str(o);s=UncertainService(j)
            try:self.assertEqual(s.measure(j.machine.pending)['outcome'],'ERROR')
            finally:s.close()
if __name__=='__main__':unittest.main()
