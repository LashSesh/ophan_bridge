"""Synthetic continuous rotation fixtures; exact local fit anchors are assumptions."""
import copy,math
from fractions import Fraction as F
from registration3d_fixtures import dataset as finite_dataset,T
from carrier_contract import preflight
from continuous3d import PROFILE,encode,exact_matrix,exact_transform
CASES=['baseline','refinement','search_limit','control_unproven','enclosure_overlap','two_witnesses','fit_empty','clock_rejection','reference_reset','horizon','tracking_loss']
BASE=[1,2,3];U=[F(0),F(0),F(1,5)]
def box(v,r):return [[math.floor(x)-r,math.ceil(x)+r] for x in v]
def dataset(case='baseline'):
    raw,m,b=finite_dataset(case if case in ['reference_reset','horizon','tracking_loss','clock_rejection'] else 'baseline');b['profile']=PROFILE
    b['target']['reference_space']='continuous_lab3d'
    b['charts']=[dict(id='rotation_chart',base=BASE,u=encode([[x-F(1,100000),x+F(1,100000)] for x in U]))]
    b['search']=dict(min_depth=0,max_depth=5,max_cells=63)
    rotation=exact_matrix(U,BASE)
    fits=[[0,0,0],[1000000,0,0],[0,1000000,0]];checks=[[0,0,1000000],[-500000,500000,500000]]
    for group,points,radius in [('spatial_fit',fits,40),('spatial_check',checks,250)]:
        for row,v in zip(b[group],points):row['local_um']=[[x,x] for x in v];row['reference_um']=box([a+z for a,z in zip(exact_transform(rotation,v),T)],radius)
    if case in ['refinement','search_limit','control_unproven']:
        b['charts'][0]['u']=encode([[F(0),F(0)],[F(0),F(0)],[F(19,100),F(21,100)]])
        # Strong fit at long anchors; subdivisions remove incompatible rotation cells.
        b['search']=dict(min_depth=0,max_depth=8,max_cells=63)
        for row in b['spatial_check']:row['reference_um']=box([a+z for a,z in zip(exact_transform(rotation,[x for x,y in row['local_um']]),T)],1000)
        if case=='search_limit':b['search']['max_cells']=1
        if case=='control_unproven':b['spatial_check'][0]['reference_um'][0]=[x+10000 for x in b['spatial_check'][0]['reference_um'][0]]
    if case in ['enclosure_overlap','two_witnesses']:
        # A broad chart with origin-only references passes controls yet encloses
        # correlated rotations. Midpoint witnesses cannot settle every query.
        for row in b['spatial_fit']+b['spatial_check']:row['local_um']=[[0,0]]*3;row['reference_um']=[[x,x] for x in T]
        b['charts'][0]['u']=encode([[F(0),F(0)],[F(0),F(0)],[F(0),F(1)]])
        b['sensor_error_um']=[0,0,0];b['query']['threshold_um']=100001
        if case=='two_witnesses':b['search']=dict(min_depth=1,max_depth=1,max_cells=3);b['charts'][0]['u']=encode([[F(0),F(0)],[F(0),F(0)],[F(-1),F(1)]]);b['query'].update(axis=1,threshold_um=200000)
    if case=='fit_empty':b['translation_bound_um']=0
    return raw,m,b
