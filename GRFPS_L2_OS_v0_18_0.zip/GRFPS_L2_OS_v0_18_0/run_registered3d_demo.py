"""Eight actual owner/worker/HTTP runs on synthetic 3-D registration inputs."""
import argparse,json,shutil,tempfile,threading,time,urllib.request
from pathlib import Path
from registration3d_fixtures import CASES,dataset
from registered3d_runtime import initialize,export,html
from registered3d_segments import SegmentJournal,replay
from carrier_runtime import CarrierService
from live import server_for

def run_case(d,name):
    raw,m,b=dataset(name);j,lines=initialize(d,raw,m,b);s=CarrierService(j,lines=lines);server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));th=threading.Thread(target=server.serve_forever,daemon=True);th.start();url=f'http://127.0.0.1:{server.server_port}';checks=0;end=time.monotonic()+25
    try:
        while time.monotonic()<end:
            assert s.cycle();st=s.current
            with urllib.request.urlopen(url+'/api/updates') as response:got=json.load(response)['snapshot']
            assert got['state_digest']==st['state_digest'] and got['registered3d']==st['registered3d'];checks+=1
            if st['carrier']['cursor']==len(lines) and st['geometry_answer']['epistemic']=='Known':break
            time.sleep(.02)
        else:raise AssertionError('timeout '+name)
        s.stop_reason='user'
        while s.cycle():time.sleep(.02)
    finally:server.shutdown();server.server_close();th.join();s.close()
    old=replay(d/'journal')['machine'];j=SegmentJournal.reopen(d/'journal');j.commit(dict(kind='resume',at=old.mapper.at+6000));assert j.machine.registered3d==old.registered3d and j.machine.registration_certificate==old.registration_certificate and j.machine.registration_work==old.registration_work and j.machine.spent==old.spent;j.commit(dict(kind='stop',at=j.machine.mapper.at,reason='user'));j.close()
    report=export(d/'journal',d/'replay.html');report.update(case=name,http_checks=checks,compiler_subprocess=True,source_records=len(lines),synthetic_input=True,resume_preserved=True);(d/'report.json').write_text(json.dumps(report,indent=2));return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='registered3d_evidence_run');a=p.parse_args();target=Path(a.out).resolve();assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps016_',dir='/tmp') as tmp:
        work=Path(tmp)/'proof';work.mkdir()
        for name in CASES:
            r=run_case(work/name,name);print(json.dumps({name:{k:r[k] for k in ['transitions','spent','requests','nodes_spent','http_checks']}}),flush=True)
        from verify_registered3d import verify
        report=verify(work,export_views=False);(work/'integration_report.json').write_text(json.dumps(report,indent=2));shutil.copytree(work,target)
if __name__=='__main__':main()
