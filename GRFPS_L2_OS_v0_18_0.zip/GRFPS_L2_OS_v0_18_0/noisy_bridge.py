"""Proof-carrying model calibration, actual raw-coordinate correction and latch."""
import copy
from pathlib import Path
from grfps_l2 import canon,fields,uint,require
from uncertain_bridge import UncertainBank,config as uncertain_config,checkpoint
from mapping import hashof
from noisy_certificate import evaluate,validate_observation,assess,corrected_patch,point_bounds,seal as certificate_seal,PROTOCOL
from uncertain_bridge import seal as uncertain_seal,scope_ref
from mapping import rot
PROFILE='grfps-noisy-bank/0.11.0'
def seal(kind,x):return hashof(kind,dict(profile=PROFILE,value=x))
def config(world,field,orientation,calibration):
    c=uncertain_config(world,field,orientation);c.update(profile=PROFILE,calibration_world=str(Path(calibration).resolve()),calibration_cost=1,calibration_refresh=200,calibration_ttl=2000)
    c['registrations'][0].update(error_bound=0,hypotheses=[dict(id=name,sector=i) for i,name in enumerate(['east','north','west','south'])]);return c

class NoisyBank(UncertainBank):
    def __init__(self,c):
        extra=['calibration_world','calibration_cost','calibration_refresh','calibration_ttl'];fields(c,'profile bank segment_records max_segments scope_cells registrations probe_world probe_cost '+' '.join(extra));canon(c)
        require(c['profile']==PROFILE and type(c['calibration_world']) is str and 0<len(c['calibration_world'])<=1024,'calibration_path')
        require(uint(c['calibration_cost']) and 1<=c['calibration_cost']<=16,'calibration_cost')
        require(uint(c['calibration_refresh']) and uint(c['calibration_ttl']) and 10<=c['calibration_refresh']<c['calibration_ttl']<=1000000,'calibration_time')
        base={k:v for k,v in c.items() if k not in extra};base['profile']='grfps-uncertain-bank/0.8.0';super().__init__(base);self.contract=copy.deepcopy(c)
        self.calibration=dict(revision=0,certificate=None,activated_at=0)
        self.calibration_yield=False;self.campaign=None;self.calibration_sample=None;self.calibration_attempt=-c['calibration_refresh'];self.revoked=False;self.breaches=0;self.pending_calibration=None
    def calibration_ref(self):return seal('Calibration',self.calibration)
    def fresh_sample(self):
        e=self.calibration_sample
        return e if e is not None and e['calibration_ref']==self.calibration_ref() and e['frame']==self.mapper.frame and self.mapper.at<e['sampled_at']+self.contract['calibration_ttl'] else None
    def fresh_campaign(self):
        c=self.campaign
        if c is None:return None
        samples=[c['fit'],*c['checks'].values()]
        return c if all(e['frame']==self.mapper.frame and e['calibration_ref']==self.calibration_ref() and self.mapper.at<e['sampled_at']+self.contract['calibration_ttl'] for e in samples) else None
    def next_stage(self):
        c=self.fresh_campaign()
        if c is None or evaluate(c)['status'] in ['FIT_REJECTED','CHECK_REJECTED','PASS']:return 'fit'
        return 'check0' if 'check0' not in c['checks'] else 'check1'
    def monitor(self):
        e=self.fresh_sample();cert=self.calibration['certificate'];a=assess(e['observation']['points'],cert['candidates'],3) if e and cert else dict(status='UNKNOWN',best=None,worst=None,compatible=0,total=0,residuals=[])
        cls=a['status'];status='REVOKED' if self.revoked else 'VALID' if cls=='WITHIN' else 'UNKNOWN';candidate=evaluate(self.fresh_campaign())
        return dict(status=status,flag=True if self.revoked else False if status=='VALID' else None,sample_class=cls,breach_count=self.breaches,residual=a['worst'],best_residual=a['best'],compatible=a['compatible'],total=a['total'],calibration_ref=self.calibration_ref(),revision=self.calibration['revision'],transform=copy.deepcopy(cert['representative']) if cert else None,limit=3,sample=copy.deepcopy(e),candidate=candidate)
    def recalibration_proposal(self):
        c=self.fresh_campaign();v=evaluate(c)
        if self.phase!='RUNNING' or self.active.paused or self.pending or v['status']!='PASS' or self.calibration['revision']>=128:return None
        return dict(previous=self.calibration_ref(),revision=self.calibration['revision']+1,certificate=v['certificate'],sample_ref=seal('Campaign',c))
    def context(self,r):
        state=self.mapper.snapshot();ps=[p for p in state['patches'] if self.patch_windows.get(p['id'])==r['window'] and r['a'] in p['points'] and r['b'] in p['points']]
        refs=sorted(hashof('Patch',p) for p in ps);cert=self.calibration['certificate'];n=self.contract['scope_cells'];vectors=[[n,0],[0,n],[-n,0],[0,-n]]
        qs=sorted(set(t[0] for t in cert['candidates'])) if cert else [];representative=cert['representative'][0] if cert else 0
        by_rotation={q:[h for h in r['hypotheses'] if ps and all(max(abs(a-b) for a,b in zip(rot([p['points'][r['b']][i]-p['points'][r['a']][i] for i in range(2)],q-representative),vectors[h['sector']]))<=r['error_bound'] for p in ps)] for q in qs}
        binding=seal('SetGeometrySupport',dict(registration=r,patches=refs,frame=self.mapper.frame,scope_ref=scope_ref(self.contract),calibration_ref=self.calibration_ref()))
        e=self.probes.get(r['id']);valid=e is not None and e['binding']==binding and e['frame']==self.mapper.frame and self.mapper.at<e['sampled_at']+self.config['ttl']
        if valid:by_rotation={q:[h for h in hs if h['sector'] in e['sectors']] for q,hs in by_rotation.items()}
        covered=bool(qs) and all(by_rotation[q] for q in qs);sectors={h['sector'] for hs in by_rotation.values() for h in hs};hs=[h for h in r['hypotheses'] if h['sector'] in sectors]
        quarantined=any(c['quarantined'] and any(p['id'] in c['patches'] for p in ps) for c in state['atlas']['components'])
        return dict(hypotheses=hs if covered else [],patch_refs=refs,binding=binding,probe=e if valid else None,quarantined=quarantined,rotation_support=[dict(rotation=q,sectors=[h['sector'] for h in by_rotation[q]]) for q in qs],set_covered=covered)
    def projections(self):
        out=super().projections();m=self.monitor()
        for b in out:
            b['calibration_ref']=self.calibration_ref();b['calibration_status']=m['status'];c=self.context(self.registration(b['id']));b['rotation_support']=c['rotation_support'];b['calibration_set_covered']=c['set_covered']
            if c['patch_refs'] and not c['set_covered']:b['reason']='calibration_scope_gap'
            if m['status']!='VALID':b.update(gate='HOLD',epistemic='Unknown',value=None,reason='calibration_'+m['status'].lower())
        return out
    def plan(self):
        if self.phase!='RUNNING' or self.active.paused or self.pending:return None
        ordinary=super().plan() if self.monitor()['status']=='VALID' else None
        if self.calibration_yield and ordinary:return ordinary
        if evaluate(self.fresh_campaign())['status']=='PASS' and self.monitor()['status']!='VALID':return None
        if self.mapper.at-self.calibration_attempt>=self.contract['calibration_refresh'] and self.spent+self.contract['calibration_cost']<=self.config['budget']:
            return dict(organ='calibration_probe',cost=self.contract['calibration_cost'],frame=self.mapper.frame,payload=dict(calibration_ref=self.calibration_ref(),protocol_ref=certificate_seal('Protocol',PROTOCOL),stage=self.next_stage(),fit_ref=seal('AcceptedFit',self.fresh_campaign()['fit']) if self.next_stage()!='fit' else None,series_ref=self.fresh_campaign()['fit']['observation']['series_ref'] if self.next_stage()!='fit' else None))
        return ordinary
    def snapshot(self):
        s=super().snapshot();s.update(profile=PROFILE,calibration=copy.deepcopy(self.calibration),drift=self.monitor(),pending_calibration=self.pending_calibration,recalibration_proposal=self.recalibration_proposal(),contract_ref=seal('Contract',self.contract),calibration_yield=self.calibration_yield)
        cert=self.calibration['certificate'];s['geometry_uncertainty']=dict(mode='representative_gauge',candidates=copy.deepcopy(cert['candidates']) if cert else [],point_bounds={p['id']:{k:point_bounds(v,cert) for k,v in p['points'].items()} for p in s['patches']} if cert else {})
        s['bank'].append(dict(id='calibration_probe',type='BoundedCalibration',cost=self.contract['calibration_cost'],last_dispatch=None));s['state_digest']=seal('State',{k:v for k,v in s.items() if k!='state_digest'});return s
    def _registered(self,e):
        k=e.get('kind')
        if k=='dispatch' and e.get('proposal',{}).get('organ')=='calibration_probe':
            fields(e,'kind at proposal');require(self.phase=='RUNNING','stopped');self._active(dict(kind='tick',at=e['at']));p=self.plan();require(p is not None and canon(p)==canon(e['proposal']),'proposal_binding')
            self.spent+=p['cost'];self.request_count+=1;r=dict(id='bank'+str(self.request_count),organ=p['organ'],cost=p['cost'],frame=self.mapper.frame,issued_at=e['at'],deadline=e['at']+self.config['timeout'],payload=p['payload']);r['exposure']=seal('CalibrationExposure',r);self.pending=r;self.calibration_attempt=e['at'];self.last=dict(kind=k,request=r)
        elif k=='calibration_result':
            fields(e,'kind at request exposure outcome observation sampled_at sample_ref');r=self.pending
            require(self.phase=='RUNNING' and r and r['organ']=='calibration_probe' and e['request']==r['id'] and e['exposure']==r['exposure'],'calibration_binding')
            require(e['outcome'] in ['OK','ERROR','TIMEOUT'],'calibration_outcome');require(e['outcome']!='TIMEOUT' or e['at']>=r['deadline'],'early_timeout')
            if e['outcome']=='OK':
                validate_observation(e['observation']);require(e['observation']['stage']==r['payload']['stage'],'observation_stage');require(uint(e['sampled_at']) and r['issued_at']<=e['sampled_at']<=e['at'],'calibration_sample');require(e['sample_ref']==certificate_seal('Observation',e['observation']),'chart_ref')
            else:require(e['observation'] is None and e['sampled_at'] is None and e['sample_ref'] is None,'failure_payload')
            self._active(dict(kind='tick',at=e['at']));status='SUPERSEDED' if r['frame']!=self.mapper.frame or r['payload']['calibration_ref']!=self.calibration_ref() else 'TIMEOUT' if e['at']>r['deadline'] else e['outcome']
            if status=='OK':
                o=e['observation'];sample=dict(observation=o,sampled_at=e['sampled_at'],sample_ref=e['sample_ref'],frame=r['frame'],calibration_ref=r['payload']['calibration_ref'],request=r['id'])
                self.calibration_sample=sample
                if o['stage']=='fit':self.campaign=dict(fit=sample,checks={})
                else:
                    c=self.fresh_campaign();require(c is not None and r['payload']['fit_ref']==seal('AcceptedFit',c['fit']) and o['series_ref']==r['payload']['series_ref'],'campaign_binding')
                    require(o['stage'] not in c['checks'] and (o['stage']=='check0' or 'check0' in c['checks']),'check_order');self.campaign['checks'][o['stage']]=sample;evaluate(self.campaign)
                if self.monitor()['sample_class']=='DRIFT' and not self.revoked:self.breaches+=1;self.revoked=True
            elif status in ['ERROR','TIMEOUT']:self.campaign=None
            self.pending=None;self.calibration_yield=True;self.last=dict(kind=k,status=status,drift=self.monitor())
        elif k=='recalibrate':
            fields(e,'kind at proposal');require(self.phase=='RUNNING','stopped');self._active(dict(kind='tick',at=e['at']));p=self.recalibration_proposal();require(p is not None and canon(p)==canon(e['proposal']),'calibration_certificate_witness')
            previous=copy.deepcopy(self.calibration);self.calibration=dict(revision=p['revision'],certificate=p['certificate'],activated_at=e['at'])
            self.revoked=False;self.calibration_yield=False;self.campaign=None;self.calibration_sample=None;self.calibration_attempt=-self.contract['calibration_refresh'];self._active(dict(kind='frame',at=e['at']));self.last=dict(kind=k,previous=previous,calibration=copy.deepcopy(self.calibration),witness=p)
        elif k=='noisy_result':
            fields(e,'kind at calibration_ref event');require(self.pending is not None and e['calibration_ref']==self.pending_calibration and e['calibration_ref']==self.calibration_ref(),'result_calibration')
            inner=copy.deepcopy(e['event']);require(type(inner) is dict and inner.get('kind') in ['window_result','scoped_boolean','probe_result'] and inner.get('at')==e['at'],'noisy_type')
            raw=None
            if inner['kind']=='window_result' and inner['event'].get('kind')=='patch':
                raw=copy.deepcopy(inner['event']['patch']);cert=self.calibration['certificate'];require(cert is not None,'certificate_missing')
                inner['event']['patch']=corrected_patch(raw,cert,self.calibration_ref())
            super()._registered(inner);self.pending_calibration=None;self.last=dict(kind=k,calibration_ref=e['calibration_ref'],raw_patch=raw,result=self.last)
        elif k in ['window_result','scoped_boolean','probe_result']:raise ValueError('unnoisy_result_forbidden')
        else:
            super()._registered(e)
            if k=='dispatch':self.pending_calibration=self.calibration_ref();self.calibration_yield=False
            if k in ['resume','frame']:self.campaign=None
            if k=='resume':self.pending_calibration=None
