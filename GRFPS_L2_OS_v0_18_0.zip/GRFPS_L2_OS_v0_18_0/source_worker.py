"""One source adapter per process, separate files and local recording clocks.
The supplied adapter simulates two unit-rate clocks. No physical clock claim.
"""
import sys,time
from pathlib import Path
from grfps_l2 import canon,require
from trace_import import strict_load
from source_registration import capture
from source_bank import seal
from source_geometry import solve

def main():
    v=strict_load(sys.stdin.buffer.read(262145));r=v['request']
    def now():return v['offset']+(time.monotonic_ns()-v['start_ns'])//1000000
    if r['organ']=='geometry_window':
        with Path(sys.argv[1]).open('rb') as stream:w=strict_load(stream.read(262145))
        f=now();time.sleep(.006);c=now();time.sleep(.004);s=now();data=capture(w,r,[f,c,s]);time.sleep(.003)
    else:
        require(r['organ']=='geometry_solver','organ');p=r['payload'];data=solve(p['inputs'],p['node_limit'])
    at=now();out=dict(data=data,sampled_at=at,exposure=r['exposure'],sample_ref=seal('WorkerSample',dict(exposure=r['exposure'],data=data,sampled_at=at)))
    sys.stdout.buffer.write(canon(out))
if __name__=='__main__':main()
