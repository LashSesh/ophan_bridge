"""Separate real-process cases: rejection/refinement/drift, consensus and scope gap."""
import argparse,copy,json,shutil,tempfile,threading,time,urllib.request
from pathlib import Path
from noisy_bridge import config
from noisy_runtime import NoisyService,fixture as world_fixture,html,export
from noisy_segments import SegmentJournal,replay
from noisy_certificate import fixture,seal
from uncertain_bridge import seal as uncertain_seal
from test_registered import field
from mapping import hashof
from field_world import world_ref
from live import server_for

def run_case(d,case):
    d.mkdir();samples=d/'samples';samples.mkdir()
    def write(name,w,ref):
        tmp=d/(name+'.next');tmp.write_text(json.dumps(w));tmp.replace(d/(name+'.json'));(samples/(ref+'.json')).write_text(json.dumps(w))
    def chart(w):write('calibration',w,seal('Series',w))
    w=dict(world_fixture(),sensor_transform=[0,0,0]);f=field()
    if case!='consensus':f['cells'][1][0]['solid']=True
    o=dict(profile='grfps-orientation-fixture/1',registrations=dict(AB_ray=[0,1,2,3]));write('world',w,hashof('SampleWorld',w));write('field',f,world_ref(f));write('orientation',o,uncertain_seal('OrientationWorld',o))
    broad=fixture([0,0,0],True);narrow=fixture([0,0,0]);bad=copy.deepcopy(narrow);bad['samples']['check1'][0]['raw'][0]+=5;chart(bad if case=='refinement' else broad)
    c=config(d/'world.json',d/'field.json',d/'orientation.json',d/'calibration.json');c.update(segment_records=16,calibration_refresh=150,calibration_ttl=3000);c['bank'].update(budget=256,ttl=5000,refresh=1000,timeout=2000);c['bank']['atlas']['atlas']['ttl']=5000
    if case=='scope_gap':c['registrations'][0]['hypotheses']=c['registrations'][0]['hypotheses'][:1]
    j=SegmentJournal(d/'journal',c);s=NoisyService(j);stages=[];step=0;checks=0;rejected=False;partial_seen=False;original=s.commit
    def stage(name):stages.append(dict(stage=name,sequence=s.current['sequence'],spent=s.current['spent'],drift=s.current['drift'],projection=s.current['bridges'][0],geometry_uncertainty=s.current['geometry_uncertainty']))
    def capture(e):
        original(e)
        if e['kind']=='recalibrate':stage('adopted_v'+str(s.current['calibration']['revision'])+'_requires_evidence')
    s.commit=capture
    server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));th=threading.Thread(target=server.serve_forever,daemon=True);th.start();url=f'http://127.0.0.1:{server.server_port}'
    def control():
        req=urllib.request.Request(url+'/api/control',data=b'{"kind":"recalibrate"}',headers={'Content-Type':'application/json','Origin':url},method='POST')
        with urllib.request.urlopen(req) as response:assert response.status==202
    end=time.monotonic()+35
    try:
        while time.monotonic()<end:
            assert s.cycle();m=s.current['drift'];p=s.current['bridges'][0];candidate=m['candidate'];ts=s.current['geometry_uncertainty']['candidates']
            with urllib.request.urlopen(url+'/api/updates') as response:res=json.load(response)
            assert res['snapshot']['state_digest']==s.current['state_digest'];checks+=1
            if case=='consensus' and p['epistemic']=='Known':assert len(ts)==14 and p['value'] is True;stage('consensus_known_with_14_candidates');break
            if case=='scope_gap' and p['reason']=='calibration_scope_gap':assert p['value'] is None and len(ts)==14;stage('uncovered_rotations_hold');break
            if case=='refinement':
                if step==0 and candidate['status']=='CHECK_REJECTED':stage('held_out_check_rejects_entire_set');control();step=1
                elif step==1 and any(x['status']=='NO_VALID_CERTIFICATE' for x in s.command_results):
                    with urllib.request.urlopen(url+'/api/status') as response:status=json.load(response)
                    assert 'NO_VALID_CERTIFICATE' in json.dumps(status);rejected=True;stage('invalid_adoption_rejected');chart(broad);step=2
                elif step==2 and p['epistemic']=='Ambiguous':assert len(ts)==14;stage('four_rotations_disagree');chart(narrow);step=3
                elif step==3:
                    if m['sample_class']=='UNCERTAIN' and not partial_seen:stage('partial_compatibility_holds');partial_seen=True
                    if candidate['status']=='PASS' and len(candidate['candidates'])==9:assert partial_seen;stage('new_fit_and_two_checks_complete');control();step=4
                elif step==4 and m['revision']==2 and p['epistemic']=='Known':
                    assert len(ts)==9 and p['value'] is True;stage('one_rotation_known_with_translation_uncertainty');drift=copy.deepcopy(narrow)
                    for ps in drift['samples'].values():
                        for v in ps:v['raw'][0]+=10
                    chart(drift);step=5
                elif step==5 and m['status']=='REVOKED':stage('all_candidates_fail_drift');chart(narrow);step=6
                elif step==6 and m['sample_class']=='WITHIN' and m['status']=='REVOKED':stage('return_does_not_repair');break
            time.sleep(.02)
        else:raise AssertionError(json.dumps(dict(case=case,step=step,sequence=s.current['sequence'],spent=s.current['spent'],pending=s.current['pending'],candidate=s.current['drift']['candidate'],calibration=s.current['calibration'],projection=s.current['bridges'][0],last=s.current['control_result'])))
        s.stop_reason='user'
        while s.cycle():time.sleep(.02)
    finally:server.shutdown();server.server_close();th.join();s.close()
    old=replay(d/'journal')['machine'];j=SegmentJournal.reopen(d/'journal');j.commit(dict(kind='resume',at=old.mapper.at+6000));ss=j.machine.snapshot();assert ss['spent']==old.spent and ss['calibration']==old.calibration and ss['drift']['breach_count']==old.breaches and ss['bridges'][0]['epistemic']=='Unknown';j.commit(dict(kind='stop',at=j.machine.mapper.at,reason='user'));j.close()
    report=export(d/'journal',d/'replay.html');report.update(case=case,stages=stages,http_checks=checks,rejected_control_verified=rejected if case=='refinement' else None,restart_preserved_spent=old.spent,restart_preserved_certificate=True);(d/'report.json').write_text(json.dumps(report,indent=2));return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='noisy_evidence_run');a=p.parse_args();target=Path(a.out).resolve();assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps011-',dir='/tmp') as tmp:
        d=Path(tmp)/'proof';d.mkdir();reports={case:run_case(d/case,case) for case in ['refinement','consensus','scope_gap']};shutil.copytree(d,target)
    print(json.dumps({case:{k:v for k,v in r.items() if k!='stages'} for case,r in reports.items()},indent=2))
if __name__=='__main__':main()
