"""Separate bounded acquisition for fit, check0 and check1. No candidate input."""
import sys,time
from pathlib import Path
from grfps_l2 import loads,canon,fields,require
from noisy_certificate import validate_fixture,observation,seal
try:
    with Path(sys.argv[1]).open('rb') as f:raw=f.read(65537)
    require(len(raw)<=65536,'source_size');w=validate_fixture(loads(raw));q=loads(sys.stdin.buffer.read(8193));fields(q,'start_ns offset exposure stage series_ref')
    o=observation(w,q['stage']);require(q['series_ref'] is None or q['series_ref']==o['series_ref'],'series_changed')
    at=q['offset']+(time.monotonic_ns()-q['start_ns'])//1000000
    sys.stdout.buffer.write(canon(dict(observation=o,sampled_at=at,sample_ref=seal('Observation',o),exposure=q['exposure'])))
except Exception:sys.exit(2)
