"""Reexecute every transition and recompute all accepted sources and set corrections."""
import json
from noisy_segments import replay
from noisy_runtime import export
from noisy_certificate import observation,seal,corrected_patch,fit_candidates
from calibration_certificate import raw_sample
from uncertain_bridge import seal as uncertain_seal,validate_probe
from map_worker import sample as ideal_sample
from mapping import transform
from field_world import measure,world_ref

def verify(root):
    out={}
    for case in ['refinement','consensus','scope_gap']:
        d=root/'noisy_evidence_run'/case;r=replay(d/'journal',collect=True);m=r['machine'];expected=json.loads((d/'report.json').read_text());counts=dict(window=0,field=0,orientation=0,fit=0,check0=0,check1=0);known=0
        for k,v in [('transitions',m.seq),('segments',r['index']+1),('spent',m.spent),('head',r['head']),('state_digest',m.snapshot()['state_digest']),('revision',m.calibration['revision']),('breaches',m.breaches)]:assert expected[k]==v,k
        fw=json.loads((d/'field.json').read_text());truth=measure(fw,'ray_clear',0)['value']
        for s in r['views']:
            if s['bridges'][0]['epistemic']=='Known':assert s['bridges'][0]['value']==truth;known+=1
        for i,(before,event) in enumerate(zip(r['views'],r['events'])):
            req=before['pending'];e=event
            if e['kind']=='noisy_result':
                assert e['calibration_ref']==before['pending_calibration'];ref=e['calibration_ref'];e=e['event']
                if e['kind']=='window_result' and e['event']['kind']=='patch':
                    raw=e['event']['patch'];w=json.loads((d/'samples'/(raw['sample_ref']+'.json')).read_text());assert raw_sample(w,req['inner'],raw['sampled_at'])==raw;cert=before['calibration']['certificate'];corrected=corrected_patch(raw,cert,ref);assert corrected in r['views'][i+1]['patches'];ideal=ideal_sample(w,req['inner'],raw['sampled_at'])
                    assert any(all(list(transform(raw['points'][k],t))==v for k,v in ideal['points'].items()) for t in cert['candidates']);counts['window']+=1
                elif e['kind']=='scoped_boolean' and e['event']['outcome'] in ['OK','OCCLUDED']:
                    v=e['event'];w=json.loads((d/'samples'/(v['sample_ref']+'.json')).read_text());a=measure(w,req['organ'],req['payload']['sector']);assert world_ref(w)==v['sample_ref'] and w['depth']==m.contract['scope_cells'];assert (a['outcome'],a['value'])==(v['outcome'],v['value']);counts['field']+=1
                elif e['kind']=='probe_result' and e['outcome']=='OK':
                    w=validate_probe(json.loads((d/'samples'/(e['sample_ref']+'.json')).read_text()));assert uncertain_seal('OrientationWorld',w)==e['sample_ref'];assert w['registrations'][req['payload']['registration']]==e['sectors'];counts['orientation']+=1
            elif e['kind']=='calibration_result' and e['outcome']=='OK':
                o=e['observation'];w=json.loads((d/'samples'/(o['series_ref']+'.json')).read_text());assert observation(w,req['payload']['stage'])==o and seal('Observation',o)==e['sample_ref'];counts[o['stage']]+=1
            elif e['kind']=='recalibrate':
                cert=e['proposal']['certificate'];w=json.loads((d/'samples'/(cert['series_ref']+'.json')).read_text());assert cert['candidates']==fit_candidates(w['samples']['fit']);assert [0,0,0] in cert['candidates'];assert all(cert['check_refs'][k]==seal('Observation',observation(w,k)) for k in ['check0','check1'])
        for st in expected['stages']:
            s=next(v for v in r['views'] if v['sequence']==st['sequence']);assert s['spent']==st['spent'] and s['bridges'][0]==st['projection'] and s['drift']==st['drift'] and s['geometry_uncertainty']==st['geometry_uncertainty']
        assert m.spent==expected['restart_preserved_spent'] and expected['restart_preserved_certificate'];assert m.revoked==(case=='refinement')
        export(d/'journal',d/'replay.html')
        if case=='refinement':assert expected['rejected_control_verified'];export(d/'journal',root/'noisy_demo.html')
        out[case]=dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,requests=m.request_count,verified_samples=counts,original_http_checks=expected['http_checks'],known_states_checked=known,false_known_states=0,revision=m.calibration['revision'],breaches=m.breaches,head=r['head'])
    return out
