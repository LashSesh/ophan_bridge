"""Explicitly synthetic recorded inputs; these are not physical sensor recordings."""
import copy
from trace_import import PROFILE,CONTRACT
from noisy_certificate import fixture,observation


def points(coords,radius=0):return {k:dict(center=list(v),radius=radius) for k,v in coords.items()}
def window(at,name,coords=None,radius=0,frame=0,outcome='OK',sampled_at=None):
    return dict(kind='window',at=at,sampled_at=at if sampled_at is None else sampled_at,frame=frame,
                window=name,outcome=outcome,points=points(coords,radius) if outcome=='OK' else None)
def monitor(at,shift=0,frame=0):
    o=observation(fixture([0,0,0]),'check0')
    for p in o['points']:p['raw'][0]+=shift
    return dict(kind='monitor',at=at,sampled_at=at,frame=frame,observation=o)
def base(records,broad=False,limit=50000,budget=64):
    return dict(profile=PROFILE,contract=copy.deepcopy(CONTRACT),
        provenance=dict(kind='synthetic',device='fixture_grid',description='Deterministic synthetic trace; no physical sensor capture.'),
        query=dict(kind='x_greater',a='A',b='B'),
        calibration=dict(series=fixture([0,0,0],broad),sampled_at=dict(fit=0,check0=1,check1=2)),
        solver_node_limit=limit,budget=budget,records=records)


def cases():
    triangle=dict(A=[0,0],B=[6,0],C=[0,6])
    return {
        'joint_consensus':base([
            window(10,'left',triangle,1),window(20,'right',triangle,1),
            window(30,'left',outcome='OCCLUDED'),window(40,'right',outcome='OCCLUDED'),
            window(50,'left',triangle,1),dict(kind='tick',at=150),dict(kind='frame',at=151),
            window(152,'left',triangle,1),monitor(153,frame=1),window(154,'left',triangle,1,frame=1),
            monitor(155,shift=10,frame=1),monitor(156,frame=1)]),
        'refinement':base([window(10,'left',dict(A=[0,0],B=[1,0]),1),
                            window(20,'left',dict(A=[0,0],B=[2,0]))]),
        'cycle_conflict':base([window(10,'left',dict(A=[0,0],B=[2,0])),
                              window(20,'middle',dict(B=[0,0],C=[2,0])),
                              window(30,'right',dict(A=[0,0],C=[6,0]))]),
        'search_limit':base([window(10,'left',triangle,1)],limit=1),
        'disconnected':base([window(10,'left',triangle,1),
                             window(20,'island',dict(D=[0,0],E=[2,0]),1)]),
        'calibration_ambiguity':base([window(10,'left',dict(A=[0,0],B=[6,0]),1)],broad=True),
        'negative_consensus':base([window(10,'left',dict(A=[0,0],B=[-6,0]),1)]),
        'measurement_budget':base([window(10,'left',triangle,1)],budget=1),
    }


EXPECTED={
    'joint_consensus':['Known','Known','Known','Unknown','Known','Unknown','Unknown','Unknown','Unknown','Known','Unknown','Unknown'],
    'refinement':['Ambiguous','Known'],
    'cycle_conflict':['Known','Known','Unknown'],
    'search_limit':['Unknown'],
    'disconnected':['Known','Unknown'],
    'calibration_ambiguity':['Ambiguous'],
    'negative_consensus':['Known'],
    'measurement_budget':['Unknown'],
}
