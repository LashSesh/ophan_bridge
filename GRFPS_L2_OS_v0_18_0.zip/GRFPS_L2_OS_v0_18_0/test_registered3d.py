import copy,itertools,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from fractions import Fraction as F
from carrier_contract import preflight,CarrierState,manifest
from carrier_bank import config as carrier_config
from registration3d import ROTATIONS,compile_certificate,projection,rotate_point,unfrac,seal,validate
from registration3d_fixtures import dataset,R,T
from registered3d_bank import Registered3DBank,config
from registered3d_segments import SegmentJournal,replay
from registered3d_runtime import worker_certificate
from test_sources import machine
from grfps_l2 import canon

def inputs(case='baseline'):
    raw,m,b=dataset(case);cc,ls,_=preflight(raw,m);return cc,ls,b
def state(case='baseline',index=3):
    cc,ls,b=inputs(case);c=compile_certificate(b,cc);s=CarrierState(cc['manifest']);raw=None
    for line in ls[:index+1]:
        s.apply(line)
        if json.loads(line)['record_kind']=='frame':raw=line
    return b,c,s.snapshot(),raw

def bank(case='baseline'):
    cc,ls,b=inputs(case);m=Registered3DBank(config(carrier_config(machine().contract,cc),b));return m,ls,b
class RotationTests(unittest.TestCase):
    def test_all_rotations_are_unique_and_proper(self):
        self.assertEqual(len(set(map(tuple,ROTATIONS))),24)
        for r in ROTATIONS:
            basis=[rotate_point(x,r) for x in [[1,0,0],[0,1,0],[0,0,1]]];a,b,c=basis;cross=[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];self.assertEqual(sum(x*y for x,y in zip(cross,c)),1)
    def test_group_composition_closes(self):
        signatures={tuple(rotate_point([1,2,3],r)) for r in ROTATIONS}
        for a,b in itertools.product(ROTATIONS,repeat=2):self.assertIn(tuple(rotate_point(rotate_point([1,2,3],b),a)),signatures)
    def test_fit_boxes_equal_exhaustive_small_integer_model(self):
        cc,ls,b=inputs();b['translation_bound_um']=2
        points=[[0,0,0],[1,0,0],[0,1,0]]
        for obs,v in zip(b['spatial_fit'],points):
            obs['local_um']=[[x-1,x+1] for x in v];w=[x+y for x,y in zip(rotate_point(v,R),[1,0,-1])];obs['reference_um']=[[x-1,x+1] for x in w]
        cert=compile_certificate(b,cc);model={}
        for ri,r in enumerate(ROTATIONS):
            ts=[]
            for t in itertools.product(range(-2,3),repeat=3):
                good=True
                for row in b['spatial_fit']:
                    found=False
                    for x in itertools.product(*(range(a[0],a[1]+1) for a in row['local_um'])):
                        w=[u+v for u,v in zip(rotate_point(x,r),t)]
                        if all(a[0]<=v<=a[1] for a,v in zip(row['reference_um'],w)):found=True;break
                    if not found:good=False;break
                if good:ts.append(t)
            if ts:model[ri]=set(ts)
        actual={x['rotation_id']:set(itertools.product(*(range(a[0],a[1]+1) for a in x['translation_um']))) for x in cert['spatial_candidates']};self.assertEqual(actual,model)

class RegistrationContractTests(unittest.TestCase):
    def test_source_hash_binding(self):
        cc,ls,b=inputs();b['source']['trace_sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'source_binding'):compile_certificate(b,cc)
    def test_epoch_type_is_exact(self):
        cc,ls,b=inputs();b['source']['epoch']=False
        with self.assertRaisesRegex(ValueError,'source_epoch'):compile_certificate(b,cc)
    def test_future_epoch_cannot_silently_reactivate_certificate(self):
        cc,ls,b=inputs();b['source']['epoch']=1
        with self.assertRaisesRegex(ValueError,'source_epoch'):compile_certificate(b,cc)
    def test_reused_evidence_is_rejected(self):
        cc,ls,b=inputs();b['spatial_check'][0]['evidence_ref']=b['spatial_fit'][0]['evidence_ref']
        with self.assertRaisesRegex(ValueError,'disjoint_evidence'):compile_certificate(b,cc)
    def test_boolean_coordinate_rejected(self):
        cc,ls,b=inputs();b['spatial_fit'][0]['local_um'][0][0]=False
        with self.assertRaises(ValueError):compile_certificate(b,cc)
    def test_float_coordinate_rejected(self):
        cc,ls,b=inputs();b['spatial_fit'][0]['local_um'][0][0]=-10.0
        with self.assertRaises(ValueError):compile_certificate(b,cc)
    def test_inverted_interval_rejected(self):
        cc,ls,b=inputs();b['spatial_fit'][0]['local_um'][0]=[2,1]
        with self.assertRaises(ValueError):compile_certificate(b,cc)
    def test_unknown_extra_field_rejected(self):
        cc,ls,b=inputs();b['confidence']=1
        with self.assertRaises(ValueError):compile_certificate(b,cc)
    def test_wrong_units_rejected(self):
        cc,ls,b=inputs();b['target']['unit']='mm'
        with self.assertRaisesRegex(ValueError,'units'):compile_certificate(b,cc)
    def test_rate_family_must_be_sorted_and_bounded(self):
        for rates in [[1000000,999999],[1000000]*2,[1001001],list(range(1000000,1000006))]:
            cc,ls,b=inputs();b['rates_ppm']=rates
            with self.subTest(rates=rates),self.assertRaises(ValueError):compile_certificate(b,cc)
    def test_clock_check_is_separate_and_later(self):
        cc,ls,b=inputs();b['clock_check'][0]['local_ns']=b['clock_fit'][1]['local_ns']
        with self.assertRaisesRegex(ValueError,'clock_observation_order'):compile_certificate(b,cc)
    def test_certificate_cannot_extrapolate_back_before_controls(self):
        cc,ls,b=inputs();b['valid_source_ns'][0]='1'
        with self.assertRaisesRegex(ValueError,'clock_observation_order'):compile_certificate(b,cc)
    def test_noncanonical_time_string_rejected(self):
        cc,ls,b=inputs();b['clock_fit'][0]['local_ns']='01000000'
        with self.assertRaisesRegex(ValueError,'ns_string'):compile_certificate(b,cc)
    def test_wrong_box_dimension_rejected(self):
        cc,ls,b=inputs();b['spatial_fit'][0]['local_um'].pop()
        with self.assertRaisesRegex(ValueError,'box_dimension'):compile_certificate(b,cc)
    def test_sensor_error_bound_rejected(self):
        cc,ls,b=inputs();b['sensor_error_um']=[-1,0,0]
        with self.assertRaisesRegex(ValueError,'sensor_error'):compile_certificate(b,cc)

class CertificateTests(unittest.TestCase):
    def test_noisy_fit_retains_translation_interval(self):
        cc,ls,b=inputs();c=compile_certificate(b,cc);self.assertEqual(c['status'],'PASS');self.assertEqual(len(c['spatial_candidates']),1);row=c['spatial_candidates'][0];self.assertEqual(row['rotation'],R);self.assertEqual(row['translation_um'],[[x-30,x+30] for x in T])
    def test_all_three_clock_rates_are_retained(self):
        cc,ls,b=inputs();c=compile_certificate(b,cc);self.assertEqual([x['rate_ppm'] for x in c['clock_candidates']],[999999,1000000,1000001]);self.assertEqual(c['work'],dict(rotation_trials=24,rate_trials=3))
    def test_partial_spatial_control_never_prunes_to_passing_subset(self):
        cc,ls,b=inputs('partial_holdout');c=compile_certificate(b,cc);self.assertEqual(c['status'],'SPATIAL_CHECK_REJECTED');self.assertEqual(len(c['spatial_candidates']),24);self.assertGreater(sum(x['passed'] for x in c['spatial_candidates']),0);self.assertLess(sum(x['passed'] for x in c['spatial_candidates']),24)
    def test_partial_clock_control_never_prunes_rate_candidates(self):
        cc,ls,b=inputs()
        for row in b['clock_check']:
            t=int(row['local_ns'])+1000000;row['reference_ns']=[str(t-50),str(t+50)]
        c=compile_certificate(b,cc);self.assertEqual(c['status'],'CLOCK_CHECK_REJECTED');self.assertEqual(len(c['clock_candidates']),3);self.assertEqual(sum(x['passed'] for x in c['clock_candidates']),1)
    def test_spatial_fit_empty_is_not_vacuous_pass(self):
        cc,ls,b=inputs();b['translation_bound_um']=0;c=compile_certificate(b,cc);self.assertEqual(c['status'],'SPATIAL_FIT_EMPTY')
    def test_clock_fit_empty_is_not_vacuous_pass(self):
        cc,ls,b=inputs();b['clock_fit'][1]['reference_ns']=[str(int(x)+10000) for x in b['clock_fit'][1]['reference_ns']];self.assertEqual(compile_certificate(b,cc)['status'],'CLOCK_FIT_EMPTY')
    def test_actual_compiler_process_matches_parent(self):
        cc,ls,b=inputs();self.assertEqual(worker_certificate(b,cc),compile_certificate(b,cc))
    def test_fractional_clock_offsets_are_exact(self):
        cc,ls,b=inputs();b['clock_fit'][0]['local_ns']='1000001';c=compile_certificate(b,cc);self.assertTrue(any(int(v[1])!=1 for row in c['clock_candidates'] for v in row['offset_ns']));canon(c)

class ProjectionTests(unittest.TestCase):
    def test_changed_query_requires_a_new_bound_certificate(self):
        b,c,s,r=state();b['query']['threshold_um']+=1
        with self.assertRaisesRegex(ValueError,'projection_bundle_binding'):projection(b,c,s,r)
    def test_negative_ambiguous_positive_sequence(self):
        for i,status,value in [(0,'Known',False),(2,'Ambiguous',None),(3,'Known',True)]:
            b,c,s,r=state(index=i);g=projection(b,c,s,r);self.assertEqual((g['status'],g['value']),(status,value))
    def test_unknown_is_not_false(self):
        b,c,s,r=state('spatial_rejection');g=projection(b,c,s,r);self.assertEqual(g['status'],'Unknown');self.assertIsNone(g['value'])
    def test_ambiguous_rotations_retain_both_witnesses(self):
        b,c,s,r=state('ambiguous_registration');g=projection(b,c,s,r);self.assertEqual(g['values'],[False,True]);self.assertEqual(set(g['witnesses']),{'false','true'});self.assertEqual(len(g['rows']),24)
    def test_pose_uncertainty_is_added_to_representation(self):
        from decimal import Decimal
        from carrier_contract import interval
        with self.assertRaisesRegex(ValueError,'numeric_bounds'):interval(Decimal('10000.000000000000000000000000000001'))
        b,c,s,r=state();g=projection(b,c,s,r);self.assertGreaterEqual(g['position_um'][0][1]-g['position_um'][0][0],80)
    def test_increasing_declared_error_can_remove_known(self):
        b,c,s,r=state();b['sensor_error_um']=[100000]*3;c=compile_certificate(b,inputs()[0]);g=projection(b,c,s,r);self.assertEqual(g['status'],'Ambiguous')
    def test_reference_reset_removes_registered_answer(self):
        b,c,s,r=state('reference_reset',5);g=projection(b,c,s,r);self.assertEqual(g['reason'],'reference_scope_changed');self.assertIsNone(g['position_um'])
    def test_horizon_end_is_inclusive_and_next_frame_expires(self):
        b,c,s,r=state('horizon',4);self.assertEqual(projection(b,c,s,r)['status'],'Known');b,c,s,r=state('horizon',5);self.assertEqual(projection(b,c,s,r)['reason'],'source_horizon')
    def test_reference_horizon_uses_all_rate_endpoints(self):
        b,c,s,r=state();g=projection(b,c,s,r);lower=unfrac(g['reference_time_ns'][0]);b['valid_reference_ns'][0]=str(lower.numerator//lower.denominator+1);c=compile_certificate(b,inputs()[0]);self.assertEqual(projection(b,c,s,r)['reason'],'reference_horizon')
    def test_missing_explicit_epoch_is_unknown(self):
        b,c,s,r=state();x=json.loads(r);x.pop('source_epoch');self.assertEqual(projection(b,c,s,json.dumps(x))['reason'],'explicit_scope_missing')
    def test_tracking_loss_removes_position(self):
        b,c,s,r=state('tracking_loss',5);g=projection(b,c,s,r);self.assertEqual(g['reason'],'pose_unavailable');self.assertIsNone(g['position_um'])
    def test_orientation_and_physical_validation_stay_unknown(self):
        b,c,s,r=state();g=projection(b,c,s,r);self.assertEqual(g['orientation'],'Unknown');self.assertEqual(g['physical_validation'],'Unknown');self.assertEqual(g['facticity'],'Simulated')
    def test_large_reference_times_remain_exact(self):
        cc,ls,b=inputs();shift=2**53+17
        for group in ['clock_fit','clock_check']:
            for row in b[group]:row['reference_ns']=[str(int(x)+shift) for x in row['reference_ns']]
        b['valid_reference_ns']=[str(int(x)+shift) for x in b['valid_reference_ns']];c=compile_certificate(b,cc);s=CarrierState(cc['manifest'])
        for r in ls[:4]:s.apply(r)
        g=projection(b,c,s.snapshot(),r);self.assertEqual(g['status'],'Known');self.assertGreater(unfrac(g['reference_time_ns'][0]),2**53);canon(g)

class RegisteredBankTests(unittest.TestCase):
    def test_rehashed_pruned_certificate_is_rejected_atomically(self):
        m,ls,b=bank('partial_holdout');c=compile_certificate(b,m.contract['carrier']);c['spatial_candidates']=[x for x in c['spatial_candidates'] if x['passed']];c['status']='PASS';c['digest']=seal('Certificate',{k:v for k,v in c.items() if k!='digest'});before=m.snapshot()
        with self.assertRaisesRegex(ValueError,'registration_semantics'):m.reduce(dict(kind='registration3d_result',at=0,certificate=c))
        self.assertEqual(m.snapshot(),before)
    def test_certificate_cannot_be_replaced(self):
        m,ls,b=bank();e=dict(kind='registration3d_result',at=0,certificate=compile_certificate(b,m.contract['carrier']));m=m.reduce(e)[0]
        with self.assertRaisesRegex(ValueError,'registration_lifecycle'):m.reduce(e)
    def test_late_certificate_is_rejected(self):
        m,ls,b=bank();m=m.reduce(dict(kind='carrier_record',at=0,index=0,raw=ls[0]))[0]
        with self.assertRaisesRegex(ValueError,'registration_lifecycle'):m.reduce(dict(kind='registration3d_result',at=0,certificate=compile_certificate(b,m.contract['carrier'])))
    def test_snapshot_does_not_compile_or_search(self):
        m,ls,b=bank()
        with patch('registered3d_bank.compile_certificate',side_effect=AssertionError('hidden_search')):m.snapshot();m.plan()
    def test_port_keeps_room_grid_join_separate(self):
        m,ls,b=bank();s=m.snapshot();self.assertEqual(s['observation_port']['joining'],dict(spatial='Unknown',clock='Unknown'));self.assertEqual(s['observation_port']['registered_target']['reference_space'],'lab3d');self.assertFalse(s['observation_port']['external_effects'])
    def test_resume_keeps_historical_registration(self):
        m,ls,b=bank();m=m.reduce(dict(kind='registration3d_result',at=0,certificate=compile_certificate(b,m.contract['carrier'])))[0]
        for i,r in enumerate(ls[:4]):m=m.reduce(dict(kind='carrier_record',at=i,index=i,raw=r))[0]
        old=m.snapshot();m=m.reduce(dict(kind='stop',at=m.mapper.at,reason='user'))[0];m=m.reduce(dict(kind='resume',at=m.mapper.at+6000))[0];self.assertEqual(m.snapshot()['registered3d'],old['registered3d']);self.assertEqual(m.snapshot()['registration_work'],old['registration_work'])
    def test_rollover_replays_certificate_and_reference_revocation(self):
        m,ls,b=bank('reference_reset');c=m.contract;c['segment_records']=16
        with tempfile.TemporaryDirectory(dir='/tmp') as tmp:
            j=SegmentJournal(Path(tmp)/'j',c);j.commit(dict(kind='registration3d_result',at=0,certificate=compile_certificate(b,c['carrier'])))
            for i,r in enumerate(ls):j.commit(dict(kind='carrier_record',at=i,index=i,raw=r));j.commit(dict(kind='tick',at=i))
            expected=j.machine.snapshot();j.close();result=replay(Path(tmp)/'j');self.assertEqual(result['machine'].snapshot(),expected);self.assertGreater(result['index'],0)
if __name__=='__main__':unittest.main()
