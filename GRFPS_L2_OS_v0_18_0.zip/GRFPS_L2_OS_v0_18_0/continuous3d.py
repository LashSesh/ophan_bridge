"""Bounded exact interval cover of continuous quaternion charts.
No floating-point decision arithmetic. Fit points are exact declared anchors.
An outer enclosure proves Known; Ambiguous requires two concrete model witnesses.
"""
import copy,itertools
from fractions import Fraction as F
from pathlib import Path
from grfps_l2 import require,fields,canon,loads
import registration3d as old
from carrier_contract import read_line
PROFILE='grfps-continuous3d/0.17.0'
MAX_BYTES=65536
frac=old.frac;unfrac=old.unfrac
def seal(kind,value):return old.sha(canon(dict(profile=PROFILE,kind=kind,value=value)))
def encode(x):
    if isinstance(x,F):return frac(x)
    if isinstance(x,(tuple,list)):return [encode(v) for v in x]
    return x
def decode_box(x):return [[unfrac(v) for v in a] for a in x]
def scalar(x):return [F(x),F(x)]
def add(a,b):return [a[0]+b[0],a[1]+b[1]]
def neg(a):return [-a[1],-a[0]]
def sub(a,b):return add(a,neg(b))
def mul(a,b):
    v=[x*y for x in a for y in b];return [min(v),max(v)]
def square(a):return [F(0) if a[0]<=0<=a[1] else min(x*x for x in a),max(x*x for x in a)]
def divide_positive(a,b):
    require(b[0]>0,'positive_interval_denominator');return mul(a,[1/b[1],1/b[0]])
def sum_interval(xs):
    r=scalar(0)
    for x in xs:r=add(r,x)
    return r
def matrix(u,base):
    """R_base * R(1,u), normalized quaternion written without a square root."""
    s=sum_interval([square(x) for x in u]);den=add(scalar(1),s)
    cross=[[scalar(0),neg(u[2]),u[1]],[u[2],scalar(0),neg(u[0])],[neg(u[1]),u[0],scalar(0)]]
    m=[]
    for i in range(3):
        row=[]
        for j in range(3):
            # Diagonal u_i^2 is kept as a square, with a nonnegative lower bound.
            v=mul(scalar(2),square(u[i]) if i==j else mul(u[i],u[j]));v=add(v,mul(scalar(2),cross[i][j]))
            if i==j:v=add(v,sub(scalar(1),s))
            row.append(divide_positive(v,den))
        m.append(row)
    return [[a if v>0 else neg(a) for a in m[abs(v)-1]] for v in base]
def exact_matrix(u,base):return [[x[0] for x in row] for row in matrix([scalar(v) for v in u],base)]
def transform(m,box):return [sum_interval([mul(a,x) for a,x in zip(row,box)]) for row in m]
def exact_transform(m,p):return [sum(a*x for a,x in zip(row,p)) for row in m]
def translate(a,t):return [add(x,y) for x,y in zip(a,t)]
def intersection(a,b):return [[max(x[0],y[0]),min(x[1],y[1])] for x,y in zip(a,b)]
def nonempty(a):return all(x<=y for x,y in a)
def inside(a,b):return all(y[0]<=x[0] and x[1]<=y[1] for x,y in zip(a,b))
def parameter(x):
    require(type(x) is list and len(x)==2 and all(type(v) is str and len(v)<=11 for v in x),'parameter_fraction')
    try:r=F(int(x[0]),int(x[1]))
    except (ValueError,ZeroDivisionError):raise ValueError('parameter_fraction')
    require(frac(r)==x and abs(r.numerator)<=10**9 and r.denominator<=10**9 and abs(r)<=1,'parameter_canonical_bound');return r
def validate(b,carrier):
    fields(b,'profile origin source target valid_source_ns valid_reference_ns sensor_error_um translation_bound_um rates_ppm spatial_fit spatial_check clock_fit clock_check query charts search')
    require(b['profile']==PROFILE,'continuous_profile')
    legacy={k:copy.deepcopy(v) for k,v in b.items() if k not in ['charts','search']};legacy['profile']=old.PROFILE;old.validate(legacy,carrier)
    require(all(all(a==z for a,z in row['local_um']) for row in b['spatial_fit']),'fit_requires_exact_local_anchors')
    require(type(b['charts']) is list and 1<=len(b['charts'])<=4,'chart_count');seen=set()
    for c in b['charts']:
        fields(c,'id base u');old.label(c['id']);require(c['id'] not in seen,'chart_identity');seen.add(c['id'])
        require(type(c['base']) is list and all(type(x) is int for x in c['base']) and c['base'] in old.ROTATIONS,'proper_chart_base')
        require(type(c['u']) is list and len(c['u'])==3,'parameter_box')
        for x in c['u']:require(type(x) is list and len(x)==2 and parameter(x[0])<=parameter(x[1]),'parameter_interval')
    s=b['search'];fields(s,'min_depth max_depth max_cells');require(all(type(v) is int for v in s.values()) and 0<=s['min_depth']<=3 and s['min_depth']<=s['max_depth']<=8 and len(b['charts'])<=s['max_cells']<=127,'search_bound');canon(b);return b
def fit_translation(b,m):
    bound=b['translation_bound_um'];t=[[F(-bound),F(bound)] for _ in range(3)]
    for row in b['spatial_fit']:
        a=transform(m,row['local_um']);w=row['reference_um'];t=intersection(t,[[F(w[j][0])-a[j][1],F(w[j][1])-a[j][0]] for j in range(3)])
    return t
def concrete_fit(b,u,base):return fit_translation(b,matrix([scalar(v) for v in u],base))
def clock_candidates(b):
    out=[]
    for ppm in b['rates_ppm']:
        a=F(ppm,1000000);lo=None;hi=None
        for row in b['clock_fit']:
            t=old.ns(row['local_ns']);w=old.timebox(row['reference_ns']);x,y=F(w[0])-a*t,F(w[1])-a*t;lo=x if lo is None else max(lo,x);hi=y if hi is None else min(hi,y)
        if lo>hi:continue
        checks=[]
        for row in b['clock_check']:
            t=old.ns(row['local_ns']);w=old.timebox(row['reference_ns']);x,y=a*t+lo,a*t+hi;checks.append(dict(id=row['id'],predicted_ns=encode([x,y]),passed=w[0]<=x and y<=w[1]))
        out.append(dict(rate_ppm=ppm,offset_ns=encode([lo,hi]),checks=checks,passed=all(x['passed'] for x in checks)))
    return out
def compile_certificate(b,carrier):
    validate(b,carrier);s=b['search'];pending=[dict(chart=c,u=decode_box(c['u']),depth=0,path='') for c in b['charts']];leaves=[];discarded=[];nodes=0;splits=0;budget_blocked=False
    while pending:
        cell=pending.pop(0);c=cell['chart'];u=cell['u'];m=matrix(u,c['base']);t=fit_translation(b,m);nodes+=1
        record=dict(chart_id=c['id'],path=cell['path'],depth=cell['depth'],base=c['base'],u=encode(u))
        if not nonempty(t):discarded.append(dict(record,reason='fit_interval_empty'));continue
        checks=[]
        for row in b['spatial_check']:
            predicted=translate(transform(m,row['local_um']),t);checks.append(dict(id=row['id'],predicted_um=encode(predicted),passed=inside(predicted,row['reference_um'])))
        midpoint=[(a+z)/2 for a,z in u];witness_point=midpoint;exact=concrete_fit(b,witness_point,c['base']);has_witness=nonempty(exact)
        if not has_witness and cell.get('inherited_witness') is not None:
            witness_point=cell['inherited_witness'];exact=concrete_fit(b,witness_point,c['base']);has_witness=nonempty(exact)
        passed=all(x['passed'] for x in checks);widths=[z-a for a,z in u];split_axis=max(range(3),key=lambda j:widths[j]);want_split=cell['depth']<s['min_depth'] or not passed or not has_witness
        if want_split and widths[split_axis]>0 and cell['depth']<s['max_depth']:
            if nodes+len(pending)+2<=s['max_cells']:
                middle=midpoint[split_axis]
                for side in range(2):
                    v=copy.deepcopy(u);v[split_axis][1-side]=middle;inherited=witness_point if has_witness and all(a<=x<=z for x,(a,z) in zip(witness_point,v)) else None;pending.append(dict(chart=c,u=v,depth=cell['depth']+1,path=cell['path']+str(side),inherited_witness=inherited))
                splits+=1;continue
            budget_blocked=True
        leaves.append(dict(record,rotation_interval=encode(m),translation_um=encode(t),checks=checks,passed=passed,fit_witness=dict(u=encode(witness_point),translation_um=encode(exact)) if has_witness else None))
    clocks=clock_candidates(b);exists=any(x['fit_witness'] is not None for x in leaves)
    if not leaves:status='SPATIAL_FIT_EMPTY'
    elif not all(x['passed'] for x in leaves) or not exists:status='SEARCH_LIMIT' if budget_blocked else 'CONTROL_UNPROVEN' if not all(x['passed'] for x in leaves) else 'FIT_EXISTENCE_UNPROVEN'
    elif not clocks:status='CLOCK_FIT_EMPTY'
    elif not all(x['passed'] for x in clocks):status='CLOCK_CHECK_REJECTED'
    else:status='PASS'
    cert=dict(profile=PROFILE,bundle_ref=seal('Bundle',b),source=copy.deepcopy(b['source']),target=copy.deepcopy(b['target']),status=status,spatial_candidates=leaves,discarded_cells=discarded,clock_candidates=clocks,fit_existence_witnessed=exists,work=dict(cell_evaluations=nodes,splits=splits,retained_cells=len(leaves),discarded_cells=len(discarded),rate_trials=len(b['rates_ppm'])),physical_validation='Unknown')
    cert['digest']=seal('Certificate',cert);return cert
def query_witnesses(b,cert,local):
    witnesses={};axis=b['query']['axis'];threshold=b['query']['threshold_um']
    for c in cert['spatial_candidates']:
        w=c['fit_witness']
        if w is None:continue
        u=[unfrac(x) for x in w['u']];t=decode_box(w['translation_um']);m=exact_matrix(u,c['base'])
        for high in [False,True]:
            p=[F(x[int(high) if coefficient>=0 else int(not high)]) for x,coefficient in zip(local,m[axis])];shift=[x[0] for x in t];shift[axis]=t[axis][int(high)];mapped=[a+z for a,z in zip(exact_transform(m,p),shift)];value=mapped[axis]>threshold
            witnesses.setdefault(str(value).lower(),dict(chart_id=c['chart_id'],path=c['path'],base=c['base'],u=encode(u),local_um=encode(p),translation_um=encode(shift),reference_um=encode(mapped),value=value))
    return witnesses
def verify_witness(b,w,local):
    """Check a concrete model witness directly against original fit constraints."""
    chart=next(x for x in b['charts'] if x['id']==w['chart_id']);u=[unfrac(x) for x in w['u']];assert w['base']==chart['base'] and all(a<=x<=z for x,(a,z) in zip(u,decode_box(chart['u'])))
    m=exact_matrix(u,chart['base']);t=[unfrac(x) for x in w['translation_um']];p=[unfrac(x) for x in w['local_um']];bound=b['translation_bound_um'];assert all(abs(x)<=bound for x in t) and all(a<=x<=z for x,(a,z) in zip(p,local))
    for row in b['spatial_fit']:
        out=[x+y for x,y in zip(exact_transform(m,[F(a) for a,z in row['local_um']]),t)];assert all(a<=x<=z for x,(a,z) in zip(out,row['reference_um']))
    out=[x+y for x,y in zip(exact_transform(m,p),t)];assert encode(out)==w['reference_um'] and (out[b['query']['axis']]>b['query']['threshold_um'])==w['value'];return True
def projection(b,certificate,carrier,last_raw=None):
    g=dict(profile=PROFILE,status='Unknown',reason='registration_pending',facticity='Simulated' if carrier['origin']=='synthetic' or b['origin']=='synthetic' else 'Recorded',physical_validation='Unknown',temporal_scope='historical_file',target=copy.deepcopy(b['target']),query=copy.deepcopy(b['query']),value=None,values=[],enclosure_values=[],position_um=None,reference_time_ns=None,orientation='Unknown',certificate_ref=certificate['digest'] if certificate else None,carrier_ref=carrier['head'],rows=[],witnesses={})
    if certificate is None:return g
    require(certificate['bundle_ref']==seal('Bundle',b),'projection_bundle_binding')
    if certificate['status']!='PASS':g['reason']=certificate['status'];return g
    if carrier['epoch']!=b['source']['epoch'] or carrier['reference_space']!=b['source']['reference_space']:g['reason']='reference_scope_changed';return g
    last=carrier['latest']
    if not last or last['pose'] is None:g['reason']='pose_unavailable';return g
    raw=read_line(last_raw) if last_raw is not None else {}
    if type(raw.get('source_epoch')) is not int or raw.get('source_epoch')!=carrier['epoch'] or raw.get('reference_space')!=carrier['reference_space']:g['reason']='explicit_scope_missing';return g
    t=old.ns(last['source_time_ns']);lo,hi=old.timebox(b['valid_source_ns'])
    if not lo<=t<=hi:g['reason']='source_horizon';return g
    times=[[F(x['rate_ppm'],1000000)*t+unfrac(v) for v in x['offset_ns']] for x in certificate['clock_candidates']];lower=min(x[0] for x in times);upper=max(x[1] for x in times);g['reference_time_ns']=encode([lower,upper]);vlo,vhi=old.timebox(b['valid_reference_ns'])
    if lower<vlo or upper>vhi:g['reason']='reference_horizon';return g
    local=[[F(a-e),F(z+e)] for (a,z),e in zip(last['pose']['position_um'],b['sensor_error_um'])];rows=[];hulls=[];possible=set();axis=b['query']['axis'];threshold=b['query']['threshold_um']
    for c in certificate['spatial_candidates']:
        m=[decode_box(row) for row in c['rotation_interval']];world=translate(transform(m,local),decode_box(c['translation_um']));a,z=world[axis];vs=[False] if z<=threshold else [True] if a>threshold else [False,True];possible.update(vs);hulls.append(world);rows.append(dict(chart_id=c['chart_id'],path=c['path'],position_um=encode(world),enclosure_values=vs))
    w=query_witnesses(b,certificate,local);actual=sorted(x['value'] for x in w.values());hull=[[min(x[j][0] for x in hulls),max(x[j][1] for x in hulls)] for j in range(3)]
    status='Known' if len(possible)==1 else 'Ambiguous' if len(actual)==2 else 'Unknown';reason='universal_continuous_query' if status=='Known' else 'two_feasible_model_witnesses' if status=='Ambiguous' else 'enclosure_overlap'
    g.update(status=status,reason=reason,value=next(iter(possible)) if status=='Known' else None,values=actual,enclosure_values=sorted(possible),position_um=encode(hull),rows=rows,witnesses=w);return g
def load_bundle(path,carrier):
    with Path(path).open('rb') as f:raw=f.read(MAX_BYTES+1)
    require(0<len(raw)<=MAX_BYTES,'bundle_size');b=loads(raw);validate(b,carrier);return b
