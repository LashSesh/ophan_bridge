import copy,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from source_bank import SourceBank,config,seal
from source_registration import fixture,capture,clock_certificate,spatial_certificate,TARGETS,validate_source
from source_geometry import solve,verify_witness
from source_segments import SegmentJournal,replay
from test_noisy import answer as calibration_answer
from noisy_certificate import fixture as calibration_fixture
from test_geometry import dispatch,tick

def machine(**changes):
    c=config('/tmp/world','/tmp/field','/tmp/orientation','/tmp/calibration','/tmp/sensor');c['geometry'].update(changes);return SourceBank(c)
def event(m,source=None):
    r=m.pending
    if r['organ']=='calibration_probe':return calibration_answer(m,calibration_fixture([0,0,0]))
    p=r['payload'];at=m.mapper.at+20
    if r['organ']=='geometry_window':data=capture(source or fixture(p['window'],p['source_epoch']),r,[at-15,at-10,at-5])
    else:data=solve(p['inputs'],p['node_limit'])
    return dict(kind='geometry_result',at=at,request=r['id'],exposure=r['exposure'],calibration_ref=p['calibration_ref'],outcome='OK',data=data,sampled_at=at,sample_ref=seal('WorkerSample',dict(exposure=r['exposure'],data=data,sampled_at=at)))
def rehash(e):e['sample_ref']=seal('WorkerSample',dict(exposure=e['exposure'],data=e['data'],sampled_at=e['sampled_at']));return e
def advance(m,sources=None):
    p=m.recalibration_proposal()
    if p and m.calibration['revision']==0:return m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=p))[0]
    if m.plan() is None:return tick(m,m.mapper.at+100)
    m=dispatch(m);src=sources.get(m.pending['payload'].get('window')) if sources else None;return m.reduce(event(m,src))[0]
def until(m,predicate,sources=None,n=120):
    for _ in range(n):
        if predicate(m):return m
        m=advance(m,sources)
    raise AssertionError(str(m.answer()))
def ready():return until(machine(),lambda m:m.answer()['epistemic']=='Known')
def window_pending():return dispatch(until(machine(),lambda m:m.plan() and m.plan()['organ']=='geometry_window'))
def solver_pending():return dispatch(until(machine(),lambda m:m.plan() and m.plan()['organ']=='geometry_solver'))
def clock():return dict(rate=[1,1],fit=dict(local=800,host=[99,101]),check=dict(local=810,host=[109,111]),sampled_local=820)

class RegistrationTests(unittest.TestCase):
    def test_three_offsets_retained(self):
        c=clock_certificate(clock(),90,130,100);self.assertEqual(c['offsets'],[699,700,701]);self.assertEqual(c['interval'],[119,121]);self.assertEqual(c['status'],'PASS')
    def test_check_does_not_prune_offset(self):
        x=clock();x['check']['local']+=1;c=clock_certificate(x,90,130,100);self.assertEqual(c['status'],'CHECK_REJECTED');self.assertEqual(c['offsets'],[699,700,701])
    def test_expiry_uses_earliest_possible_capture(self):self.assertEqual(clock_certificate(clock(),90,219,100)['status'],'EXPIRED')
    def test_upper_endpoint_cannot_be_future(self):self.assertEqual(clock_certificate(clock(),90,120,100)['status'],'CAPTURE_OUTSIDE_BRACKET')
    def test_unwitnessed_rate_rejected(self):
        x=clock();x['rate']=[2,1]
        with self.assertRaisesRegex(ValueError,'rate'):clock_certificate(x,90,130,100)
    def test_bool_rate_rejected(self):
        x=clock();x['rate']=[True,True]
        with self.assertRaises(ValueError):clock_certificate(x,90,130,100)
    def test_overlapping_fit_and_check_rejected(self):
        x=clock();x['check']['host']=[100,102]
        with self.assertRaisesRegex(ValueError,'order'):clock_certificate(x,90,130,100)
    def test_outside_exchange_bracket_rejected(self):
        with self.assertRaisesRegex(ValueError,'bracket'):clock_certificate(clock(),100,130,100)
    def test_all_four_moving_orientations_register(self):
        for q in range(4):
            x=fixture('left',pose=[q,3,-2]);c=spatial_certificate(x['beacons'],[[0,0,0],[1,1,-1]])
            self.assertEqual(c['status'],'PASS');self.assertEqual(len(c['rows']),2)
    def test_heldout_spatial_mismatch_rejects(self):
        x=fixture('left');x['beacons']['H0'][0]+=1;c=spatial_certificate(x['beacons'],[[0,0,0]])
        self.assertEqual(c['status'],'REJECTED');self.assertEqual(c['rows'][0]['status'],'CHECK_REJECTED')
    def test_fit_mismatch_rejects(self):
        x=fixture('left');x['beacons']['R2'][0]+=1;self.assertEqual(spatial_certificate(x['beacons'],[[0,0,0]])['status'],'REJECTED')
    def test_query_cannot_use_fit_or_heldout_ids(self):
        x=fixture('left');x['channels']['coarse']['points']['H0']=dict(center=[0,0],radius=0)
        with self.assertRaisesRegex(ValueError,'heldout'):validate_source(x)

class MultiSourceTests(unittest.TestCase):
    def test_active_refinement_and_separate_clocks(self):
        m=ready();self.assertTrue(m.answer()['value']);self.assertEqual(m.answer()['reference'],'room_grid')
        self.assertEqual(m.box_windows['left']['clock_registration']['offsets'],[699,700,701]);self.assertEqual(m.box_windows['right']['clock_registration']['offsets'],[-401,-400,-399])
    def test_witness_membership(self):
        m=ready()
        for w in m.solution['result']['witnesses'].values():self.assertTrue(verify_witness(m.inputs(),w))
    def test_rotated_left_preserves_fixed_query(self):
        m=ready();ref=m.answer()['registration_ref'];m=m.reduce(dict(kind='source_reset',at=m.mapper.at,window='left',previous=0,epoch=1))[0]
        self.assertEqual(m.answer()['epistemic'],'Unknown');self.assertIn('right',m.live_windows())
        m=until(m,lambda m:m.answer()['epistemic']=='Known',{'left':fixture('left',1,[2,3,-2])});self.assertIs(m.answer()['value'],True);self.assertEqual(m.answer()['registration_ref'],ref)
    def test_clock_epoch_reset_discards_window(self):
        m=ready();m=m.reduce(dict(kind='source_reset',at=m.mapper.at,window='right',previous=0,epoch=1))[0];self.assertNotIn('right',m.live_windows());self.assertEqual(m.answer()['epistemic'],'Unknown')
    def test_pending_old_source_is_superseded(self):
        m=window_pending();e=event(m);n=m.pending['payload']['window'];m=m.reduce(dict(kind='source_reset',at=m.mapper.at,window=n,previous=0,epoch=1))[0];m=m.reduce(e)[0]
        self.assertEqual(m.last['status'],'SUPERSEDED');self.assertNotIn(n,m.live_windows())
    def test_pending_solver_is_stale_after_source_reset(self):
        m=solver_pending();e=event(m);m=m.reduce(dict(kind='source_reset',at=m.mapper.at,window='left',previous=0,epoch=1))[0];m=m.reduce(e)[0]
        self.assertEqual(m.last['status'],'STALE_INPUTS');self.assertGreater(m.nodes_spent,0);self.assertEqual(m.nodes_reserved,0)
    def test_wrong_device_rejected_even_rehashed(self):
        m=window_pending();e=event(m);e['data']['provenance']['device']='camera_intruder'
        with self.assertRaisesRegex(ValueError,'source_binding'):m.reduce(rehash(e))
    def test_wrong_epoch_rejected_even_rehashed(self):
        m=window_pending();e=event(m);e['data']['epoch']=1
        with self.assertRaisesRegex(ValueError,'source_binding'):m.reduce(rehash(e))
    def test_clock_drift_cannot_admit(self):
        m=window_pending();x=fixture(m.pending['payload']['window']);x['clock_check_shift']=1;m=m.reduce(event(m,x))[0]
        self.assertEqual(m.last['status'],'CLOCK_CHECK_REJECTED');self.assertFalse(m.live_windows())
    def test_capture_cannot_postdate_worker_completion(self):
        m=window_pending();e=event(m);e['data']['clock']['sampled_local']+=5;e['sampled_at']-=2
        m=m.reduce(rehash(e))[0];self.assertEqual(m.last['status'],'CLOCK_CAPTURE_OUTSIDE_BRACKET');self.assertFalse(m.live_windows())
    def test_beacon_drift_cannot_admit(self):
        m=window_pending();x=fixture(m.pending['payload']['window']);x['beacons']['H1'][0]+=1;m=m.reduce(event(m,x))[0]
        self.assertEqual(m.last['status'],'SPATIAL_REJECTED');self.assertFalse(m.live_windows())
    def test_skew_compares_all_interval_endpoints(self):
        c=machine().contract;c['geometry']['max_skew']=10;m=SourceBank(c)
        m=until(m,lambda m:len(m.live_windows())==2);self.assertEqual(m.temporal_status(),'temporal_scope_gap');self.assertIsNone(m.inputs());self.assertEqual(m.ordinary_plan()['payload']['reason'],'temporal_refresh')
    def test_earliest_ttl_expires_existing_proof(self):
        m=ready();t=min(v['clock_registration']['interval'][0] for v in m.live_windows().values())+m.geometry_contract['ttl'];m=tick(m,t);self.assertEqual(m.answer()['epistemic'],'Unknown')
    def test_disjoint_windows_can_register_through_reference(self):
        xs={n:fixture(n) for n in ['left','right']}
        for c in xs['left']['channels'].values():c['points']={k:v for k,v in c['points'].items() if k=='A'}
        for c in xs['right']['channels'].values():c['points']={k:v for k,v in c['points'].items() if k=='B'}
        m=until(machine(),lambda m:m.answer()['epistemic']=='Known',xs);self.assertTrue(m.answer()['value'])
    def test_conflict_is_not_resolved_by_moving_root(self):
        xs={n:fixture(n) for n in ['left','right']}
        for c in xs['right']['channels'].values():c['points']['A']['center']=[8,0]
        m=until(machine(),lambda m:m.solution is not None,xs);self.assertEqual(m.solution['result']['status'],'CONFLICT');self.assertEqual(m.answer()['epistemic'],'Unknown')
    def test_partial_solver_never_known(self):
        m=until(machine(node_limit=1,node_budget=2),lambda m:m.solution is not None);self.assertEqual(m.solution['result']['status'],'LIMIT');self.assertEqual(m.answer()['epistemic'],'Unknown')
    def test_rehashed_forged_proof_rejected(self):
        m=solver_pending();e=event(m);e['data']['values']=[True]
        with self.assertRaisesRegex(ValueError,'solver_semantics'):m.reduce(rehash(e))
    def test_read_paths_do_not_search(self):
        m=ready()
        with patch('source_bank.solve',side_effect=AssertionError('search')):m.snapshot();m.plan();m.answer()
    def test_restart_retains_epochs_budget_and_certificate(self):
        m=ready();m=m.reduce(dict(kind='source_reset',at=m.mapper.at,window='left',previous=0,epoch=1))[0];old=copy.deepcopy(m);m=m.reduce(dict(kind='stop',at=m.mapper.at,reason='user'))[0];m=m.reduce(dict(kind='resume',at=m.mapper.at+6000))[0]
        self.assertEqual((m.source_epochs,m.spent,m.nodes_spent,m.calibration),(old.source_epochs,old.spent,old.nodes_spent,old.calibration));self.assertEqual(m.answer()['epistemic'],'Unknown')
    def test_duplicate_reset_is_rejected(self):
        m=ready();e=dict(kind='source_reset',at=m.mapper.at,window='left',previous=0,epoch=1);m=m.reduce(e)[0]
        with self.assertRaisesRegex(ValueError,'epoch'):m.reduce(e)
    def test_segment_boundary_replays_pending_epoch_reset(self):
        with tempfile.TemporaryDirectory(dir='/tmp') as tmp:
            c=machine().contract;c['segment_records']=16;j=SegmentJournal(Path(tmp)/'journal',c)
            for _ in range(100):
                m=j.machine;p=m.recalibration_proposal()
                if p and m.calibration['revision']==0:e=dict(kind='recalibrate',at=m.mapper.at,proposal=p)
                elif m.pending:
                    if m.pending['organ']=='geometry_solver':break
                    e=event(m)
                elif m.plan():e=dict(kind='dispatch',at=m.mapper.at,proposal=m.plan())
                else:e=dict(kind='tick',at=m.mapper.at+100)
                j.commit(e)
            e=event(j.machine)
            while j.count<16:j.commit(dict(kind='tick',at=j.machine.mapper.at))
            j.commit(dict(kind='source_reset',at=j.machine.mapper.at,window='left',previous=0,epoch=1));j.commit(e);expected=j.machine.snapshot();j.close()
            self.assertEqual(replay(Path(tmp)/'journal')['machine'].snapshot(),expected)
if __name__=='__main__':unittest.main()
