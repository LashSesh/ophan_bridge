"""Finite witnessed registrations. All times are integer ms; rate is exactly one.
Host brackets are trusted adapter evidence, not device authentication.
"""
import copy
from grfps_l2 import fields,require,uint,ident,canon
from mapping import hashof,rot,transform
from geometry_sensor import validate_points
from noisy_certificate import hash64
PROFILE='grfps-registered-source/1'
TARGETS={'R0':[0,0],'R1':[6,0],'R2':[0,6],'H0':[4,3],'H1':[-3,4]}
FIT=['R0','R1','R2'];CHECK=['H0','H1']
def seal(kind,x):return hashof(kind,dict(profile=PROFILE,value=x))
def integer(x,b=1000000000):return type(x) is int and abs(x)<=b

def clock_certificate(clock,issued,received,ttl):
    fields(clock,'rate fit check sampled_local');require(type(clock['rate']) is list and all(type(v) is int for v in clock['rate']) and clock['rate']==[1,1],'clock_rate')
    for k in ['fit','check']:
        x=clock[k];fields(x,'local host');require(integer(x['local']) and type(x['host']) is list and len(x['host'])==2 and all(uint(v) for v in x['host']),'clock_shape')
        require(issued<=x['host'][0]<=x['host'][1]<=received and x['host'][1]-x['host'][0]<=8,'clock_bracket')
    f,c=clock['fit'],clock['check'];require(f['host'][1]<c['host'][0] and f['local']<c['local'],'clock_order')
    require(integer(clock['sampled_local']) and clock['sampled_local']>=c['local'],'clock_sample')
    offsets=list(range(max(-10000,f['local']-f['host'][1]),min(10000,f['local']-f['host'][0])+1))
    status='PASS' if offsets else 'FIT_REJECTED'
    if offsets and not all(c['host'][0]<=c['local']-o<=c['host'][1] for o in offsets):status='CHECK_REJECTED'
    interval=[clock['sampled_local']-max(offsets),clock['sampled_local']-min(offsets)] if offsets else None
    if status=='PASS' and not (issued<=interval[0]<=interval[1]<=received):status='CAPTURE_OUTSIDE_BRACKET'
    if status=='PASS' and received>=interval[0]+ttl:status='EXPIRED'
    return dict(status=status,offsets=offsets,interval=interval,rate=[1,1],evidence_ref=seal('ClockEvidence',clock))

def spatial_certificate(beacons,calibrations,targets=TARGETS):
    require(type(beacons) is dict and set(beacons)==set(targets),'beacon_partition')
    require(all(type(p) is list and len(p)==2 and all(integer(v,64) for v in p) for p in beacons.values()),'beacon_coordinates')
    rows=[]
    for calibration in calibrations:
        raw={k:transform(v,calibration) for k,v in beacons.items()};poses=[]
        for q in range(4):
            a=rot(raw[FIT[0]],q);b=targets[FIT[0]];t=[q,b[0]-a[0],b[1]-a[1]]
            if all(abs(v)<=128 for v in t[1:]) and all(list(transform(raw[k],t))==targets[k] for k in FIT):poses.append(t)
        status='PASS' if len(poses)==1 else 'FIT_REJECTED'
        if status=='PASS' and not all(list(transform(raw[k],poses[0]))==targets[k] for k in CHECK):status='CHECK_REJECTED'
        rows.append(dict(calibration=copy.deepcopy(calibration),status=status,poses=poses if status=='PASS' else []))
    return dict(status='PASS' if rows and all(r['status']=='PASS' for r in rows) else 'REJECTED',rows=rows,
                evidence_ref=seal('SpatialEvidence',dict(beacons=beacons,targets=targets,calibrations=calibrations)))

def validate_source(w):
    fields(w,'profile provenance epoch clock_offset clock_check_shift channels beacons')
    require(w['profile']==PROFILE,'source_profile');fields(w['provenance'],'kind device');require(w['provenance']['kind']=='synthetic' and ident(w['provenance']['device']),'synthetic_source')
    require(uint(w['epoch']) and w['epoch']<=128 and integer(w['clock_offset'],10000) and integer(w['clock_check_shift'],16),'source_clock')
    spatial_certificate(w['beacons'],[[0,0,0]])
    fields(w['channels'],'coarse fine')
    for c in w['channels'].values():
        fields(c,'outcome points');require(c['outcome'] in ['OK','OCCLUDED','ERROR'],'channel_outcome')
        if c['outcome']=='OK':validate_points(c['points']);require(not set(c['points'])&set(TARGETS),'heldout_landmarks')
        else:require(c['points'] is None,'failed_points')
    return w

def capture(w,r,times):
    validate_source(w);p=r['payload'];f,c,s=times;offset=w['clock_offset'];channel=w['channels'][p['mode']]
    return dict(profile=PROFILE,source_ref=seal('Source',w),provenance=copy.deepcopy(w['provenance']),epoch=w['epoch'],window=p['window'],mode=p['mode'],
                outcome=channel['outcome'],points=copy.deepcopy(channel['points']),beacons=copy.deepcopy(w['beacons']),
                clock=dict(rate=[1,1],fit=dict(local=f+offset,host=[f-1,f+1]),check=dict(local=c+offset+w['clock_check_shift'],host=[c-1,c+1]),sampled_local=s+offset))

def validate_capture(o,r):
    fields(o,'profile source_ref provenance epoch window mode outcome points beacons clock')
    require(o['profile']==PROFILE and hash64(o['source_ref']),'source_profile');fields(o['provenance'],'kind device');p=r['payload']
    require(o['provenance']['kind']=='synthetic' and o['provenance']['device']==p['source_id'] and o['epoch']==p['source_epoch'] and uint(o['epoch']),'source_binding')
    require(o['window']==p['window'] and o['mode']==p['mode'],'capture_channel')
    require(o['outcome'] in ['OK','OCCLUDED','ERROR'],'capture_outcome')
    if o['outcome']=='OK':validate_points(o['points']);require(not set(o['points'])&set(TARGETS),'heldout_landmarks')
    else:require(o['points'] is None,'failed_points')
    spatial_certificate(o['beacons'],[[0,0,0]])
    return o

def inverse(p,t):return list(rot([p[0]-t[1],p[1]-t[2]],(-t[0])%4))
def fixture(name,epoch=0,pose=None,offset=None):
    pose=pose or [0,0,0];offset=(700 if name=='left' else -400) if offset is None else offset
    coarse={'A':[0,0],'B':[1,0],'C':[0,6]};fine={'A':[0,0],'B':[2,0],'C':[0,6]}
    return dict(profile=PROFILE,provenance=dict(kind='synthetic',device='camera_'+name),epoch=epoch,clock_offset=offset,clock_check_shift=0,
        channels={mode:dict(outcome='OK',points={k:dict(center=inverse(v,pose),radius=radius) for k,v in ps.items()}) for mode,ps,radius in [('coarse',coarse,1),('fine',fine,0)]},
        beacons={k:inverse(v,pose) for k,v in TARGETS.items()})
