import copy
import hashlib
import itertools
import json
import unittest
from trace_examples import cases,EXPECTED,base,window,points,monitor
from trace_import import validate,import_bytes,new_session,advance,replay,seal,strict_load
from trace_geometry import solve,move,box,intersect,verify_witness
from mapping import transform


def encoded(t):return json.dumps(t).encode()
def machine(t):return import_bytes(encoded(t))
def finished(t):return replay(advance(new_session(encoded(t))))


class GeometryTests(unittest.TestCase):
    def test_rotation_boxes_equal_explicit_grid(self):
        b=box([2,-1],1)
        for q in range(4):
            t=[q,-2,3];got=move(b,t)
            ps=[transform(p,t) for p in itertools.product(range(1,4),range(-2,1))]
            self.assertEqual(got,[[min(p[i] for p in ps) for i in range(2)],[max(p[i] for p in ps) for i in range(2)]])

    def test_pair_solver_matches_independent_pose_and_point_oracle(self):
        # Brute force every pose and enumerate lattice points, independent of box intersections.
        for radius in [0,1]:
            ws=dict(left=points(dict(A=[0,0],B=[2,0]),radius),right=points(dict(A=[0,0],B=[1,0]),radius))
            query=dict(a='A',b='B');count=0;values=set()
            def grid(p,t):
                x,y=p['center'];r=p['radius']
                return {tuple(transform(z,t)) for z in itertools.product(range(x-r,x+r+1),range(y-r,y+r+1))}
            for q,tx,ty in itertools.product(range(4),range(-1,2),range(-1,2)):
                domains={k:grid(ws['left'][k],[0,0,0])&grid(ws['right'][k],[q,tx,ty]) for k in ['A','B']}
                if all(domains.values()):
                    count+=1
                    values.update(b[0]>a[0] for a,b in itertools.product(domains['A'],domains['B']))
            got=solve(ws,[[0,0,0]],query,10000,1)
            self.assertEqual(got['solutions'],count);self.assertEqual(got['values'],sorted(values))

    def test_pairwise_compatible_cycle_is_globally_impossible(self):
        t=cases()['cycle_conflict'];m=machine(t)
        for _ in t['records']:m.step()
        ws=m.live_windows()
        for a,b in itertools.combinations(ws,2):
            r=solve({a:ws[a],b:ws[b]},m.cert['candidates'],t['query'])
            self.assertEqual(r['status'],'FEASIBLE')
        self.assertEqual(m.snapshot()['geometry']['status'],'CONFLICT')

    def test_limit_after_feasible_solution_cannot_admit(self):
        s=finished(cases()['search_limit'])['views'][-1]
        self.assertGreater(s['geometry']['solutions'],0)
        self.assertFalse(s['geometry']['complete']);self.assertEqual(s['answer']['epistemic'],'Unknown')

    def test_all_synthetic_constructive_witnesses_verify(self):
        for trace in cases().values():
            rr=finished(trace)
            for s in rr['views']:
                for w in s['geometry']['witnesses'].values():
                    self.assertTrue(verify_witness(s['live_windows'],s['calibration']['candidates'],trace['query'],w))

    def test_all_calibration_candidates_accounted_for(self):
        s=finished(cases()['calibration_ambiguity'])['views'][-1]
        self.assertEqual(len(s['calibration']['candidates']),14)
        self.assertEqual([r['calibration'] for r in s['geometry']['support']],s['calibration']['candidates'])
        self.assertEqual(s['answer']['epistemic'],'Ambiguous')

    def test_marginal_boxes_do_not_replace_joint_witnesses(self):
        s=finished(cases()['refinement'])['views'][1]
        self.assertEqual(set(s['geometry']['witnesses']),{'true','false'})
        self.assertNotEqual(s['geometry']['witnesses']['true']['points'],s['geometry']['witnesses']['false']['points'])

    def test_tampered_witness_fails(self):
        t=cases()['negative_consensus'];s=finished(t)['views'][-1];w=copy.deepcopy(s['geometry']['witnesses']['false'])
        w['points']['B'][0]=100
        self.assertFalse(verify_witness(s['live_windows'],s['calibration']['candidates'],t['query'],w))

    def test_calibration_without_geometric_support_is_not_pruned(self):
        ws=dict(left=points(dict(A=[0,0],B=[2,0])),right=points(dict(A=[0,0],B=[0,2])))
        r=solve(ws,[[0,0,0],[0,128,0]],dict(a='A',b='B'))
        self.assertEqual(r['status'],'GAP');self.assertEqual(r['reason'],'calibration_scope_gap')
        self.assertEqual([x['solutions'] for x in r['support']],[1,0])

    def test_consistent_three_window_cycle(self):
        ws=dict(left=points(dict(A=[0,0],B=[2,0])),middle=points(dict(B=[0,0],C=[2,0])),right=points(dict(A=[0,0],C=[4,0])))
        r=solve(ws,[[0,0,0]],dict(a='A',b='B'))
        self.assertEqual(r['status'],'FEASIBLE');self.assertEqual(r['solutions'],1)


class ImportTests(unittest.TestCase):
    def invalid(self,mutator):
        t=cases()['refinement'];mutator(t)
        with self.assertRaises(ValueError):validate(t)
    def test_supported_cases(self):
        for name,t in cases().items():
            ss=finished(t)['views'][1:]
            self.assertEqual([s['answer']['epistemic'] for s in ss],EXPECTED[name],name)
    def test_unknown_version(self):self.invalid(lambda t:t.update(profile='grfps-sensor-trace/2'))
    def test_unknown_field(self):self.invalid(lambda t:t.update(extra=1))
    def test_units_not_silently_converted(self):self.invalid(lambda t:t['contract'].update(units='metre'))
    def test_radius_not_silently_clamped(self):self.invalid(lambda t:t['records'][0]['points']['A'].update(radius=2))
    def test_boolean_coordinates(self):self.invalid(lambda t:t['records'][0]['points']['A'].update(center=[True,0]))
    def test_float_coordinates(self):self.invalid(lambda t:t['records'][0]['points']['A'].update(center=[0.0,0]))
    def test_clock_order(self):self.invalid(lambda t:t['records'][1].update(at=3,sampled_at=3))
    def test_future_sample(self):self.invalid(lambda t:t['records'][0].update(sampled_at=11))
    def test_duplicate_keys(self):
        with self.assertRaisesRegex(ValueError,'duplicate'):strict_load(b'{"a":1,"a":2}')
    def test_nonfinite(self):
        with self.assertRaises(ValueError):strict_load(b'{"a":NaN}')
    def test_oversized_input(self):
        with self.assertRaisesRegex(ValueError,'file_size'):strict_load(b' '*262145)
    def test_calibration_holdout_rejects_import(self):
        self.invalid(lambda t:t['calibration']['series']['samples']['check1'][0].update(raw=[16,16]))
    def test_calibration_stage_clock(self):self.invalid(lambda t:t['calibration']['sampled_at'].update(check1=1))
    def test_landmark_budget(self):
        self.invalid(lambda t:t['records'][0].update(points=points({f'L{i}':[i,0] for i in range(9)})))
    def test_same_query_id_not_independent(self):self.invalid(lambda t:t['query'].update(b='A'))
    def test_failed_measurement_cannot_carry_points(self):self.invalid(lambda t:t['records'][0].update(outcome='ERROR'))


class ReplayTests(unittest.TestCase):
    def test_chunked_resume_equals_whole_execution(self):
        t=cases()['joint_consensus'];j=new_session(encoded(t));whole=advance(j)
        chunked=advance(advance(advance(j,2),3),64)
        self.assertEqual(whole,chunked);self.assertEqual(replay(whole)['head'],replay(chunked)['head'])
    def test_recomputed_hash_does_not_hide_semantic_tamper(self):
        j=advance(new_session(encoded(cases()['refinement'])),1)
        r=j['records'][0];r['output']['cost']=0;r['digest']=seal('Transition',{k:v for k,v in r.items() if k!='digest'})
        with self.assertRaisesRegex(ValueError,'semantic_replay'):replay(j)
    def test_source_content_is_bound(self):
        j=advance(new_session(encoded(cases()['refinement'])),1);j['trace']['records'][1]['points']['B']['center'][0]=3
        with self.assertRaisesRegex(ValueError,'initial_state'):replay(j)
    def test_expiry_at_exact_boundary(self):
        t=base([window(10,'left',dict(A=[0,0],B=[6,0]),1),dict(kind='tick',at=109),dict(kind='tick',at=110)])
        ss=finished(t)['views'];self.assertEqual(ss[2]['answer']['epistemic'],'Known');self.assertEqual(ss[3]['answer']['epistemic'],'Unknown')
    def test_calibration_expiry_blocks_fresh_window(self):
        t=base([window(1002,'left',dict(A=[0,0],B=[6,0]),1)])
        s=finished(t)['views'][-1];self.assertEqual(s['geometry']['status'],'FEASIBLE');self.assertEqual(s['answer']['reason'],'calibration_unknown')
    def test_old_sample_cannot_replace_newer_window(self):
        t=base([window(20,'left',dict(A=[0,0],B=[6,0])),window(21,'left',dict(A=[0,0],B=[-6,0]),sampled_at=10)])
        s=finished(t)['views'][-1];self.assertEqual(s['last']['status'],'OLDER_SAMPLE');self.assertIs(s['answer']['value'],True);self.assertEqual(s['spent'],4)
    def test_frame_invalidates_windows_and_monitor(self):
        ss=finished(cases()['joint_consensus'])['views'];self.assertEqual(ss[7]['frame'],1)
        self.assertEqual(ss[7]['live_windows'],{});self.assertEqual(ss[8]['last']['status'],'OLD_FRAME')
    def test_drift_return_does_not_clear_latch(self):
        s=finished(cases()['joint_consensus'])['views'][-1]
        self.assertEqual(s['last']['status'],'WITHIN');self.assertEqual(s['calibration']['monitor'],'REVOKED');self.assertEqual(s['calibration']['breaches'],1)
    def test_measurement_budget_no_reset(self):
        s=finished(cases()['measurement_budget'])['views'][-1]
        self.assertEqual(s['spent'],0);self.assertEqual(s['last']['status'],'BUDGET_EXHAUSTED')
    def test_distinct_bytes_same_decoded_data_remain_distinguishable(self):
        t=cases()['refinement'];a=new_session(encoded(t));b=new_session(json.dumps(t,indent=2).encode())
        self.assertNotEqual(a['source_bytes_ref'],b['source_bytes_ref']);self.assertEqual(a['trace'],b['trace'])


if __name__=='__main__':unittest.main()
