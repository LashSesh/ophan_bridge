import copy,itertools,json,tempfile,unittest
from pathlib import Path
from fractions import Fraction as F
from unittest.mock import patch
import uncertain3d as u
from epoch3d_fixtures import dataset,BASE,U,T
from epoch_registration import validate_plan,load_plan,MAX_BYTES
from epoch3d_bank import Epoch3DBank,config
from epoch3d_segments import SegmentJournal,replay
from epoch3d_runtime import worker_certificate,admission_event,initialize
from carrier_contract import preflight
from carrier_bank import config as carrier_config
from test_sources import machine
def inputs(name='baseline'):
    raw,m,p=dataset(name);cc,ls,_=preflight(raw,m);return cc,ls,p
def bank(name='baseline'):
    cc,ls,p=inputs(name);return Epoch3DBank(config(carrier_config(machine().contract,cc),p)),ls,p
def admit(m):
    entry=m.pending_admission();return m.reduce(admission_event(entry,u.compile_certificate(entry['bundle'],m.contract['carrier']),m.mapper.at))[0]
def advance(m,ls,n,auto=True):
    while m.carrier_state.cursor<n:
        if auto and m.pending_admission():m=admit(m)
        i=m.carrier_state.cursor;m=m.reduce(dict(kind='carrier_record',at=m.mapper.at+1,index=i,raw=ls[i]))[0]
    return m
def work():return dict(anchor_checks=0,plane_triples=0,translation_trials=0)

class ExactAnchorPolytope(unittest.TestCase):
    def test_solver_finds_exact_rational_solution(self):
        a=[[F(2),F(1),F(-1)],[F(1),F(-2),F(1)],[F(3),F(1),F(2)]];b=[F(1),F(2),F(3)];x=u.solve3(a,b);self.assertEqual([sum(c*v for c,v in zip(row,x)) for row in a],b)
    def test_singular_planes_are_not_inverted(self):self.assertIsNone(u.solve3([[F(1),F(0),F(0)]]*3,[F(1)]*3))
    def test_axis_hull_overlap_can_have_empty_true_intersection(self):
        m=u.exact_matrix(U,BASE);local=[[-13,13],[-13,13],[0,0]];ref=[[17,17],[17,17],[0,0]];h=u.transform([[u.scalar(x) for x in row] for row in m],local);self.assertTrue(u.inside(ref,h));w=work();self.assertIsNone(u.anchor_point(m,[F(0)]*3,local,ref,w));self.assertEqual(w['plane_triples'],220)
    def test_degenerate_point_polytope_remains_feasible(self):
        m=u.exact_matrix(U,BASE);p=[F(13),F(0),F(0)];ref=[[x,x] for x in u.exact_transform(m,p)];self.assertEqual(u.anchor_point(m,[F(0)]*3,[[x,x] for x in p],ref,work()),p)
    def test_lower_dimensional_line_is_preserved(self):
        m=u.exact_matrix(U,BASE);p=u.anchor_point(m,[F(0)]*3,[[0,13],[0,0],[0,0]],[[6,6],[F(5,2),F(5,2)],[0,0]],work());self.assertEqual(p,[F(13,2),F(0),F(0)])
    def test_fixed_transform_matches_independent_axis_interval_intersection(self):
        m=u.exact_matrix([F(0)]*3,BASE)
        for a,b in itertools.product(range(-3,4),repeat=2):
            local=[[a,a+1],[-1,1],[-1,1]];ref=[[b,b+1],[0,1],[0,1]];point=u.anchor_point(m,[F(0)]*3,local,ref,work());self.assertEqual(point is not None,max(a,b)<=min(a+1,b+1))
    def test_nonzero_shared_translation_is_checked(self):
        m=u.exact_matrix(U,BASE);p=[F(1),F(2),F(3)];t=[F(4),F(-5),F(6)];mapped=[x+y for x,y in zip(u.exact_transform(m,p),t)];self.assertEqual(u.anchor_point(m,t,[[x,x] for x in p],[[x,x] for x in mapped],work()),p)
    def test_plane_enumeration_finds_a_nonheuristic_feasible_vertex(self):
        m=u.exact_matrix([F(1,5),F(-1,7),F(1,3)],BASE);local=[[-3,4],[-3,2],[-3,5]];ref=[[-7,7],[3,5],[3,7]];w=work();point=u.anchor_point(m,[F(0)]*3,local,ref,w);self.assertEqual(point,[F(4),F(2),F(365,273)]);self.assertEqual(w['plane_triples'],30);mapped=u.exact_transform(m,point);self.assertTrue(all(a<=x<=z for x,(a,z) in zip(mapped,ref)))

class UncertainFit(unittest.TestCase):
    def test_real_local_boxes_are_accepted_without_center_substitution(self):
        cc,ls,p=inputs('noncentral_anchors');b=p['entries'][0]['bundle'];cert=u.compile_certificate(b,cc);self.assertEqual(cert['status'],'PASS');self.assertTrue(all(a<z for row in b['spatial_fit'] for a,z in row['local_um']));w=cert['spatial_candidates'][0]['fit_witness'];self.assertTrue(u.verify_fit_witness(b,w,BASE));self.assertTrue(any([u.unfrac(x) for x in a['local_um']]!=[F(x+z,2) for x,z in row['local_um']] for a,row in zip(w['anchors'],b['spatial_fit'])))
    def test_using_all_anchor_centers_can_destroy_a_valid_fit(self):
        cc,ls,p=inputs('noncentral_anchors');b=p['entries'][0]['bundle'];self.assertEqual(u.compile_certificate(b,cc)['status'],'PASS');mid=copy.deepcopy(b)
        for row in mid['spatial_fit']:row['local_um']=[[(a+z)//2]*2 for a,z in row['local_um']]
        self.assertEqual(u.compile_certificate(mid,cc)['status'],'SPATIAL_FIT_EMPTY')
    def test_correlated_outer_box_does_not_create_existence(self):
        cc,ls,p=inputs('correlated_empty');c=u.compile_certificate(p['entries'][0]['bundle'],cc);self.assertEqual(c['status'],'FIT_EXISTENCE_UNPROVEN');self.assertTrue(c['spatial_candidates']);self.assertFalse(c['fit_existence_witnessed']);self.assertEqual(c['work']['plane_triples'],220)
    def test_all_anchor_witnesses_use_one_shared_transform(self):
        cc,ls,p=inputs();b=p['entries'][0]['bundle'];c=u.compile_certificate(b,cc);w=c['spatial_candidates'][0]['fit_witness'];self.assertEqual(len(w['anchors']),len(b['spatial_fit']));self.assertTrue(u.verify_fit_witness(b,w,BASE))
    def test_changed_anchor_cannot_pass_direct_verification(self):
        cc,ls,p=inputs();b=p['entries'][0]['bundle'];w=u.compile_certificate(b,cc)['spatial_candidates'][0]['fit_witness'];w=copy.deepcopy(w);w['anchors'][0]['local_um'][0]=['99999999','1']
        with self.assertRaises(AssertionError):u.verify_fit_witness(b,w,BASE)
    def test_changed_common_translation_cannot_borrow_other_anchors(self):
        cc,ls,p=inputs();b=p['entries'][0]['bundle'];w=copy.deepcopy(u.compile_certificate(b,cc)['spatial_candidates'][0]['fit_witness']);w['translation_um'][0]=['0','1']
        with self.assertRaises(AssertionError):u.verify_fit_witness(b,w,BASE)
    def test_budget_limit_keeps_unresolved_cells(self):
        cc,ls,p=inputs('search_limit');b=p['entries'][0]['bundle'];c=u.compile_certificate(b,cc);self.assertEqual(c['status'],'SEARCH_LIMIT');self.assertEqual(c['work']['cell_evaluations'],1);self.assertTrue(c['spatial_candidates'])
    def test_direct_query_witnesses_include_all_original_anchors(self):
        m,ls,p=bank('two_witnesses');m=advance(m,ls,4);g=m.registered3d;self.assertEqual(g['status'],'Ambiguous');local=[[F(a-e),F(z+e)] for (a,z),e in zip(m.carrier_state.latest['pose']['position_um'],p['entries'][0]['bundle']['sensor_error_um'])]
        for w in g['witnesses'].values():self.assertTrue(u.verify_witness(p['entries'][0]['bundle'],w,local));self.assertEqual(len(w['anchors']),3)
    def test_actual_worker_preserves_certificate_and_counts(self):
        cc,ls,p=inputs('correlated_empty');b=p['entries'][0]['bundle'];self.assertEqual(worker_certificate(b,cc),u.compile_certificate(b,cc))

class EpochPlan(unittest.TestCase):
    def test_plan_binds_real_reset_record(self):
        cc,ls,p=inputs('epoch_rebind');self.assertIs(validate_plan(p,cc,ls),p);self.assertEqual(p['entries'][1]['activation_ref'],cc['record_refs'][5])
    def test_same_epoch_cannot_be_scheduled_twice(self):
        cc,ls,p=inputs('epoch_rebind');p['entries'][1]['bundle']['source'].update(epoch=0,reference_space='LOCAL')
        with self.assertRaisesRegex(ValueError,'epoch_order'):validate_plan(p,cc,ls)
    def test_evidence_cannot_be_reused_across_epochs(self):
        cc,ls,p=inputs('epoch_rebind');p['entries'][1]['bundle']['spatial_fit'][0]['evidence_ref']=p['entries'][0]['bundle']['spatial_fit'][0]['evidence_ref']
        with self.assertRaisesRegex(ValueError,'epoch_evidence_reuse'):validate_plan(p,cc,ls)
    def test_activation_on_a_frame_is_rejected(self):
        cc,ls,p=inputs('epoch_rebind');p['entries'][1]['after_record']=7;p['entries'][1]['activation_ref']=cc['record_refs'][6]
        with self.assertRaisesRegex(ValueError,'activation_requires_reset'):validate_plan(p,cc,ls)
    def test_wrong_reference_label_is_rejected(self):
        cc,ls,p=inputs('epoch_rebind');p['entries'][1]['bundle']['source']['reference_space']='LOCAL'
        with self.assertRaisesRegex(ValueError,'activation_scope'):validate_plan(p,cc,ls)
    def test_pre_reset_clock_evidence_is_not_new_epoch_evidence(self):
        cc,ls,p=inputs('epoch_rebind');p['entries'][1]['bundle']['clock_fit'][0]['local_ns']='1000000'
        with self.assertRaisesRegex(ValueError,'epoch_clock_evidence'):validate_plan(p,cc,ls)
    def test_query_cannot_change_implicitly_between_epochs(self):
        cc,ls,p=inputs('epoch_rebind');p['entries'][1]['bundle']['query']['threshold_um']+=1
        with self.assertRaisesRegex(ValueError,'common_target_query'):validate_plan(p,cc,ls)
    def test_bounded_plan_file_rejected_before_parse(self):
        cc,ls,p=inputs()
        with tempfile.TemporaryDirectory(dir='/tmp') as d:
            f=Path(d)/'plan';f.write_bytes(b' '*(MAX_BYTES+1))
            with self.assertRaisesRegex(ValueError,'plan_size'):load_plan(f,cc,ls)

class EpochLifecycle(unittest.TestCase):
    def test_reset_invalidates_before_any_new_admission(self):
        m,ls,p=bank('epoch_rebind');m=advance(m,ls,5);old=copy.deepcopy(m.registration_history);m=advance(m,ls,6);self.assertIsNone(m.registration_certificate);self.assertEqual(m.registered3d['reason'],'epoch_registration_pending');self.assertEqual(m.registration_history,old);self.assertIsNotNone(m.pending_admission())
    def test_rebinding_requires_new_certificate_and_new_frame(self):
        m,ls,p=bank('epoch_rebind');m=advance(m,ls,6);m=admit(m);self.assertEqual(m.registered3d['reason'],'pose_unavailable');self.assertEqual(len(m.registration_history),2);m=advance(m,ls,8);self.assertEqual(m.registered3d['status'],'Known');self.assertFalse(m.registered3d['value']);self.assertEqual(m.registered3d['source_epoch'],1)
    def test_missing_epoch_evidence_stays_unknown(self):
        m,ls,p=bank('epoch_missing');m=advance(m,ls,len(ls));self.assertEqual(m.registered3d['reason'],'epoch_unbound');self.assertEqual(len(m.registration_history),1)
    def test_return_to_old_name_cannot_reactivate_old_epoch(self):
        m,ls,p=bank('epoch_return');m=advance(m,ls,len(ls));self.assertEqual(m.carrier_state.reference,'LOCAL');self.assertEqual(m.carrier_state.epoch,2);self.assertEqual(m.registered3d['reason'],'epoch_unbound');self.assertIsNone(m.registration_certificate)
    def test_failed_new_epoch_never_falls_back_to_old_cert(self):
        m,ls,p=bank('epoch_bad_control');m=advance(m,ls,len(ls));self.assertEqual(m.registered3d['reason'],'CONTROL_UNPROVEN');self.assertEqual(m.registration_certificate['source']['epoch'],1);self.assertEqual(len(m.registration_history),2)
    def test_stale_prior_certificate_rejected_atomically(self):
        m,ls,p=bank('epoch_rebind');m=admit(m);old=copy.deepcopy(m.registration_certificate);m=advance(m,ls,6);before=m.snapshot();event=admission_event(p['entries'][1],old,m.mapper.at)
        with self.assertRaisesRegex(ValueError,'epoch_certificate_semantics'):m.reduce(event)
        self.assertEqual(m.snapshot(),before)
    def test_early_future_admission_rejected(self):
        m,ls,p=bank('epoch_rebind');m=admit(m);entry=p['entries'][1];event=admission_event(entry,u.compile_certificate(entry['bundle'],m.contract['carrier']),m.mapper.at)
        with self.assertRaisesRegex(ValueError,'epoch_admission_lifecycle'):m.reduce(event)
    def test_late_admission_cannot_relabel_imported_frames(self):
        m,ls,p=bank('epoch_rebind');m=advance(m,ls,6);m=advance(m,ls,7,auto=False);entry=p['entries'][1]
        with self.assertRaisesRegex(ValueError,'epoch_admission_lifecycle'):m.reduce(admission_event(entry,u.compile_certificate(entry['bundle'],m.contract['carrier']),m.mapper.at))
    def test_duplicate_admission_rejected(self):
        m,ls,p=bank();m=admit(m)
        with self.assertRaisesRegex(ValueError,'epoch_admission_lifecycle'):m.reduce(admission_event(p['entries'][0],m.registration_certificate,m.mapper.at))
    def test_wrong_activation_hash_rejected(self):
        m,ls,p=bank('epoch_rebind');m=advance(m,ls,6);event=admission_event(p['entries'][1],u.compile_certificate(p['entries'][1]['bundle'],m.contract['carrier']),m.mapper.at);event['activation_ref']='0'*64
        with self.assertRaisesRegex(ValueError,'epoch_admission_binding'):m.reduce(event)
    def test_boolean_epoch_rejected(self):
        m,ls,p=bank();event=admission_event(p['entries'][0],u.compile_certificate(p['entries'][0]['bundle'],m.contract['carrier']),0);event['epoch']=False
        with self.assertRaisesRegex(ValueError,'epoch_admission_binding'):m.reduce(event)
    def test_reading_and_planning_do_not_compile_or_search(self):
        m,ls,p=bank('epoch_rebind');m=advance(m,ls,6)
        with patch('epoch3d_bank.compile_certificate',side_effect=AssertionError('hidden_work')):m.snapshot();m.plan();m.pending_admission()
    def test_aggregate_work_and_previous_admissions_are_preserved(self):
        m,ls,p=bank('epoch_rebind');m=advance(m,ls,6);before=copy.deepcopy(m.registration_history[0]);work0=copy.deepcopy(m.registration_work);m=admit(m);self.assertEqual(m.registration_history[0],before)
        for k,v in m.registration_certificate['work'].items():self.assertEqual(m.registration_work[k],work0[k]+v)
    def test_port_has_explicit_epoch_without_implicit_geometry_join(self):
        m,ls,p=bank('epoch_rebind');m=advance(m,ls,8);port=m.snapshot()['observation_port'];self.assertEqual(port['profile'],'grfps-observation-port/4');self.assertEqual(port['registered_target']['source_epoch'],1);self.assertEqual(port['joining'],dict(spatial='Unknown',clock='Unknown'));self.assertEqual(port['external_effects'],[])
    def test_checkpoint_resume_at_reset_keeps_admission_pending(self):
        m,ls,p=bank('epoch_rebind');contract=m.contract;contract['segment_records']=16
        with tempfile.TemporaryDirectory(dir='/tmp') as d:
            j=SegmentJournal(Path(d)/'j',contract);j.commit(admission_event(p['entries'][0],u.compile_certificate(p['entries'][0]['bundle'],contract['carrier']),0))
            for i in range(6):j.commit(dict(kind='carrier_record',at=i+1,index=i,raw=ls[i]));j.commit(dict(kind='tick',at=i+1))
            j.commit(dict(kind='stop',at=6,reason='user'));old=j.machine.snapshot();j.close();j=SegmentJournal.reopen(Path(d)/'j');j.commit(dict(kind='resume',at=6006));self.assertEqual(j.machine.registered3d,old['registered3d']);self.assertIsNotNone(j.machine.pending_admission());j.commit(admission_event(p['entries'][1],u.compile_certificate(p['entries'][1]['bundle'],contract['carrier']),6006));expected=j.machine.snapshot();j.close();self.assertEqual(replay(Path(d)/'j')['machine'].snapshot(),expected)
if __name__=='__main__':unittest.main()
