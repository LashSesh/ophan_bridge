"""Full transition replay plus independent source recomputation for every sensor family."""
import json
from calibrated_segments import replay
from calibrated_runtime import export
from calibrated_bridge import seal,validate_fixture
from uncertain_bridge import seal as uncertain_seal,validate_probe
from map_worker import sample
from field_world import measure,world_ref

def verify(root):
    d=root/'calibrated_evidence_run';r=replay(d/'journal',collect=True);m=r['machine'];expected=json.loads((d/'report.json').read_text());counts=dict(window=0,field=0,orientation=0,calibration=0)
    for k,v in [('transitions',m.seq),('spent',m.spent),('head',r['head']),('state_digest',m.snapshot()['state_digest']),('revision',m.calibration['revision']),('breaches',m.breaches)]:assert expected[k]==v,k
    for before,e in zip(r['views'],r['events']):
        req=before['pending']
        if e['kind']=='calibrated_result':
            assert e['calibration_ref']==before['pending_calibration'];e=e['event']
            if e['kind']=='window_result' and e['event']['kind']=='patch':
                p=e['event']['patch'];w=json.loads((d/'samples'/(p['sample_ref']+'.json')).read_text());assert sample(w,req['inner'],p['sampled_at'])==p;counts['window']+=1
            elif e['kind']=='scoped_boolean' and e['event']['outcome'] in ['OK','OCCLUDED']:
                v=e['event'];w=json.loads((d/'samples'/(v['sample_ref']+'.json')).read_text());a=measure(w,req['organ'],req['payload']['sector']);assert world_ref(w)==v['sample_ref'] and w['depth']==m.contract['scope_cells'];assert (a['outcome'],a['value'])==(v['outcome'],v['value']);counts['field']+=1
            elif e['kind']=='probe_result' and e['outcome']=='OK':
                w=validate_probe(json.loads((d/'samples'/(e['sample_ref']+'.json')).read_text()));assert uncertain_seal('OrientationWorld',w)==e['sample_ref'];assert w['registrations'][req['payload']['registration']]==e['sectors'];counts['orientation']+=1
        elif e['kind']=='calibration_result' and e['outcome']=='OK':
            w=validate_fixture(json.loads((d/'samples'/(e['sample_ref']+'.json')).read_text()));assert seal('ReferenceWorld',w)==e['sample_ref'] and w['offset']==e['offset'];counts['calibration']+=1
    for stage in expected['stages']:
        s=next(s for s in r['views'] if s['sequence']==stage['sequence']);assert s['bridges'][0]==stage['projection'] and s['drift']==stage['drift'] and s['spent']==stage['spent']
    assert m.revoked and m.breaches==2 and m.spent==expected['restart_preserved_spent']
    export(d/'journal',d/'replay.html');export(d/'journal',root/'calibrated_demo.html')
    return dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,verified_samples=counts,original_http_checks=expected['http_checks'],revision=m.calibration['revision'],breaches=m.breaches,head=r['head'])
