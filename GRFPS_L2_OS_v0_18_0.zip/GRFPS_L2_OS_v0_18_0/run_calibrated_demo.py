"""Real process/HTTP drift experiment, explicit reanchoring, verified restart."""
import argparse,json,shutil,tempfile,threading,time,urllib.request
from pathlib import Path
from calibrated_bridge import config,calibration_fixture,seal
from calibrated_runtime import CalibratedService,fixture,html,export
from calibrated_segments import SegmentJournal,replay
from uncertain_bridge import probe_fixture,seal as uncertain_seal
from test_registered import field
from mapping import hashof
from field_world import world_ref
from live import server_for

def run(d):
    d.mkdir();samples=d/'samples';samples.mkdir()
    def write(name,w,ref):
        temp=d/(name+'.next');temp.write_text(json.dumps(w));temp.replace(d/(name+'.json'));(samples/(ref+'.json')).write_text(json.dumps(w))
    w=fixture();f=field();f['cells'][1][0]['solid']=True;o=probe_fixture()
    write('world',w,hashof('SampleWorld',w));write('field',f,world_ref(f));write('orientation',o,uncertain_seal('OrientationWorld',o))
    def offset(v):
        w=calibration_fixture(v);write('calibration',w,seal('ReferenceWorld',w))
    offset([0,0]);c=config(d/'world.json',d/'field.json',d/'orientation.json',d/'calibration.json');c['segment_records']=16;c['bank'].update(budget=256,ttl=5000,refresh=1000,timeout=2000);c['bank']['atlas']['atlas']['ttl']=5000
    j=SegmentJournal(d/'journal',c);s=CalibratedService(j);stages=[];step=0;original=s.commit
    def capture(e):
        original(e);p=s.current['bridges'][0];m=s.current['drift'];label=None
        if e['kind']=='recalibrate':label='new_version_requires_evidence'
        if label:stages.append(dict(stage=label,sequence=s.current['sequence'],spent=s.current['spent'],drift=m,projection=p))
    s.commit=capture
    server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();url=f'http://127.0.0.1:{server.server_port}';checks=0;end=time.monotonic()+15
    def stage(name):stages.append(dict(stage=name,sequence=s.current['sequence'],spent=s.current['spent'],drift=s.current['drift'],projection=s.current['bridges'][0]))
    try:
        while time.monotonic()<end:
            assert s.cycle();m=s.current['drift'];p=s.current['bridges'][0]
            with urllib.request.urlopen(url+'/api/updates') as response:r=json.load(response)
            assert r['snapshot']['state_digest']==s.current['state_digest'];checks+=1
            if step==0 and p['epistemic']=='Known':stage('known_v1');offset([1,0]);step=1
            elif step==1 and m['sample'] and m['sample']['offset']==[1,0] and m['status']=='VALID':stage('boundary_within');offset([2,0]);step=2
            elif step==2 and m['status']=='REVOKED':stage('drift_revokes_v1');offset([0,0]);step=3
            elif step==3 and m['status']=='REVOKED' and m['sample_class']=='WITHIN':stage('return_does_not_repair');offset([2,0]);step=4
            elif step==4 and m['sample_class']=='DRIFT':
                stage('drift_still_same_breach');req=urllib.request.Request(url+'/api/control',data=b'{"kind":"recalibrate"}',headers={'Content-Type':'application/json','Origin':url},method='POST')
                with urllib.request.urlopen(req) as response:assert response.status==202
                step=5
            elif step==5 and m['revision']==2 and p['epistemic']=='Known':stage('known_v2');offset([4,0]);step=6
            elif step==6 and m['breach_count']==2:stage('second_version_breach');s.stop_reason='user';break
            time.sleep(.02)
        else:raise AssertionError('scenario timeout: '+str(step))
        while s.cycle():time.sleep(.02)
    finally:server.shutdown();server.server_close();thread.join();s.close()
    first=replay(d/'journal');old=first['machine'];j=SegmentJournal.reopen(d/'journal');j.commit(dict(kind='resume',at=old.mapper.at+6000));resumed=j.machine.snapshot();assert resumed['spent']==old.spent and resumed['drift']['breach_count']==2 and resumed['drift']['status']=='REVOKED';j.commit(dict(kind='stop',at=j.machine.mapper.at,reason='user'));j.close()
    report=export(d/'journal',d/'replay.html');report.update(stages=stages,http_checks=checks,restart_preserved_spent=old.spent,restart_preserved_breaches=2);(d/'report.json').write_text(json.dumps(report,indent=2));return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='calibrated_evidence_run');a=p.parse_args();target=Path(a.out).resolve();assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps09-',dir='/tmp') as tmp:
        d=Path(tmp)/'proof';r=run(d);shutil.copytree(d,target)
    print(json.dumps({k:v for k,v in r.items() if k!='stages'},indent=2))
if __name__=='__main__':main()
