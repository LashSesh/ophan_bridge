"""Actual asynchronous workers + HTTP; preserve immutable fixtures and semantic replay."""
import argparse,json,shutil,tempfile,threading,time,urllib.request
from pathlib import Path
from uncertain_bridge import config,probe_fixture,seal
from uncertain_segments import SegmentJournal,replay
from uncertain_runtime import UncertainService,fixture,html,export
from test_registered import field
from live import server_for
from mapping import hashof
from field_world import world_ref

def run(d,sectors,unanimous=False):
    d.mkdir();samples=d/'samples';samples.mkdir();w=fixture();f=field();f['cells'][1][0]['solid']=not unanimous;o=probe_fixture();o['registrations']['AB_ray']=sectors
    for name,value,ref in [('world',w,hashof('SampleWorld',w)),('field',f,world_ref(f)),('orientation',o,seal('OrientationWorld',o))]:
        (d/(name+'.json')).write_text(json.dumps(value));(samples/(ref+'.json')).write_text(json.dumps(value))
    c=config(d/'world.json',d/'field.json',d/'orientation.json');c['segment_records']=16;c['bank'].update(ttl=5000,refresh=1000,timeout=2000);c['bank']['atlas']['atlas']['ttl']=5000
    j=SegmentJournal(d/'journal',c);s=UncertainService(j);stages=[];commits=s.commit
    def capture(e):
        commits(e);p=s.current['bridges'][0]
        label='ambiguous' if p['epistemic']=='Ambiguous' else 'unanimous' if p['epistemic']=='Known' and p['registration_status']=='Ambiguous' else 'resolved' if p['epistemic']=='Known' else 'counterevidence' if p['reason']=='geometry_counterevidence' else None
        if label and label not in [v['stage'] for v in stages]:stages.append(dict(stage=label,sequence=s.current['sequence'],spent=s.current['spent'],projection=p))
    s.commit=capture;server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();checks=0;end=time.monotonic()+8
    try:
        while time.monotonic()<end:
            if not s.cycle():break
            with urllib.request.urlopen(f'http://127.0.0.1:{server.server_port}/api/updates') as response:received=json.load(response)
            # The endpoint serves the exact state-owner reset snapshot.
            snapshot=received.get('snapshot',received)
            assert snapshot['state_digest']==s.current['state_digest'];checks+=1
            if any(x['stage']==('unanimous' if unanimous else 'counterevidence' if sectors==[3] else 'resolved') for x in stages):
                s.stop_reason='user'
                while s.cycle():time.sleep(.01)
                break
            time.sleep(.01)
        else:raise AssertionError('scenario timeout')
    finally:server.shutdown();server.server_close();thread.join();s.close()
    report=export(d/'journal',d/'replay.html');r=replay(d/'journal',collect=True);probes=[e for e in r['events'] if e['kind']=='probe_result'];report.update(stages=stages,http_checks=checks,probe_results=len(probes),probe_cost=c['probe_cost'])
    assert (len(probes)==0 if unanimous else len(probes)>=1)
    (d/'report.json').write_text(json.dumps(report,indent=2));return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='uncertain_evidence_run');a=p.parse_args();target=Path(a.out).resolve();assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps08-',dir='/tmp') as temp:
        d=Path(temp);reports={}
        for name,sectors,unanimous in [('east',[0],False),('north',[1],False),('consensus',[0],True),('outside',[3],False)]:reports[name]=run(d/name,sectors,unanimous)
        (d/'report.json').write_text(json.dumps(reports,indent=2));shutil.copytree(d,target)
    print(json.dumps({k:{x:v[x] for x in ['transitions','spent','requests','probe_results','http_checks']} for k,v in reports.items()},indent=2))
if __name__=='__main__':main()
