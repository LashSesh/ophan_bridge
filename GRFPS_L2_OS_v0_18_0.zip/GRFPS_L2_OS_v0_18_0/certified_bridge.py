"""Proof-carrying model calibration, actual raw-coordinate correction and latch."""
import copy
from pathlib import Path
from grfps_l2 import canon,fields,uint,require
from uncertain_bridge import UncertainBank,config as uncertain_config,checkpoint
from mapping import hashof
from calibration_certificate import evaluate,validate_chart,residuals,corrected_patch,seal as certificate_seal,PROTOCOL
PROFILE='grfps-certified-bank/0.10.0'
def seal(kind,x):return hashof(kind,dict(profile=PROFILE,value=x))
def config(world,field,orientation,calibration):
    c=uncertain_config(world,field,orientation);c.update(profile=PROFILE,calibration_world=str(Path(calibration).resolve()),calibration_cost=1,calibration_refresh=200,calibration_ttl=800)
    return c

class CertifiedBank(UncertainBank):
    def __init__(self,c):
        extra=['calibration_world','calibration_cost','calibration_refresh','calibration_ttl'];fields(c,'profile bank segment_records max_segments scope_cells registrations probe_world probe_cost '+' '.join(extra));canon(c)
        require(c['profile']==PROFILE and type(c['calibration_world']) is str and 0<len(c['calibration_world'])<=1024,'calibration_path')
        require(uint(c['calibration_cost']) and 1<=c['calibration_cost']<=16,'calibration_cost')
        require(uint(c['calibration_refresh']) and uint(c['calibration_ttl']) and 10<=c['calibration_refresh']<c['calibration_ttl']<=1000000,'calibration_time')
        base={k:v for k,v in c.items() if k not in extra};base['profile']='grfps-uncertain-bank/0.8.0';super().__init__(base);self.contract=copy.deepcopy(c)
        self.calibration=dict(revision=0,certificate=None,activated_at=0)
        self.calibration_sample=None;self.calibration_attempt=-c['calibration_refresh'];self.revoked=False;self.breaches=0;self.pending_calibration=None
    def calibration_ref(self):return seal('Calibration',self.calibration)
    def fresh_sample(self):
        e=self.calibration_sample
        return e if e is not None and e['calibration_ref']==self.calibration_ref() and e['frame']==self.mapper.frame and self.mapper.at<e['sampled_at']+self.contract['calibration_ttl'] else None
    def monitor(self):
        e=self.fresh_sample();cert=self.calibration['certificate'];rs=residuals(e['chart']['points'],cert['transform']) if e and cert else []
        residual=max(p['residual'] for p in rs) if rs else None;cls='UNKNOWN' if residual is None else 'WITHIN' if residual==0 else 'DRIFT'
        status='REVOKED' if self.revoked else 'VALID' if cls=='WITHIN' else 'UNKNOWN'
        return dict(status=status,flag=True if self.revoked else False if status=='VALID' else None,sample_class=cls,breach_count=self.breaches,residual=residual,calibration_ref=self.calibration_ref(),revision=self.calibration['revision'],transform=copy.deepcopy(cert['transform']) if cert else None,limit=0,sample=copy.deepcopy(e),candidate=copy.deepcopy(e['evaluation']) if e else None)
    def recalibration_proposal(self):
        e=self.fresh_sample()
        if self.phase!='RUNNING' or self.active.paused or self.pending or not e or e['evaluation']['status']!='PASS' or self.calibration['revision']>=128:return None
        return dict(previous=self.calibration_ref(),revision=self.calibration['revision']+1,certificate=e['evaluation']['certificate'],sample_ref=seal('CalibrationSample',e))
    def projections(self):
        out=super().projections();m=self.monitor()
        for b in out:
            b['calibration_ref']=self.calibration_ref();b['calibration_status']=m['status']
            if m['status']!='VALID':b.update(gate='HOLD',epistemic='Unknown',value=None,reason='calibration_'+m['status'].lower())
        return out
    def plan(self):
        if self.phase!='RUNNING' or self.active.paused or self.pending:return None
        if self.mapper.at-self.calibration_attempt>=self.contract['calibration_refresh'] and self.spent+self.contract['calibration_cost']<=self.config['budget']:
            return dict(organ='calibration_probe',cost=self.contract['calibration_cost'],frame=self.mapper.frame,payload=dict(calibration_ref=self.calibration_ref(),protocol_ref=certificate_seal('Protocol',PROTOCOL)))
        return super().plan() if self.monitor()['status']=='VALID' else None
    def snapshot(self):
        s=super().snapshot();s.update(profile=PROFILE,calibration=copy.deepcopy(self.calibration),drift=self.monitor(),pending_calibration=self.pending_calibration,recalibration_proposal=self.recalibration_proposal(),contract_ref=seal('Contract',self.contract))
        s['bank'].append(dict(id='calibration_probe',type='CalibrationChart',cost=self.contract['calibration_cost'],last_dispatch=None));s['state_digest']=seal('State',{k:v for k,v in s.items() if k!='state_digest'});return s
    def _registered(self,e):
        k=e.get('kind')
        if k=='dispatch' and e.get('proposal',{}).get('organ')=='calibration_probe':
            fields(e,'kind at proposal');require(self.phase=='RUNNING','stopped');self._active(dict(kind='tick',at=e['at']));p=self.plan();require(p is not None and canon(p)==canon(e['proposal']),'proposal_binding')
            self.spent+=p['cost'];self.request_count+=1;r=dict(id='bank'+str(self.request_count),organ=p['organ'],cost=p['cost'],frame=self.mapper.frame,issued_at=e['at'],deadline=e['at']+self.config['timeout'],payload=p['payload']);r['exposure']=seal('CalibrationExposure',r);self.pending=r;self.calibration_attempt=e['at'];self.last=dict(kind=k,request=r)
        elif k=='calibration_result':
            fields(e,'kind at request exposure outcome chart sampled_at sample_ref');r=self.pending
            require(self.phase=='RUNNING' and r and r['organ']=='calibration_probe' and e['request']==r['id'] and e['exposure']==r['exposure'],'calibration_binding')
            require(e['outcome'] in ['OK','ERROR','TIMEOUT'],'calibration_outcome');require(e['outcome']!='TIMEOUT' or e['at']>=r['deadline'],'early_timeout')
            if e['outcome']=='OK':
                validate_chart(e['chart']);require(uint(e['sampled_at']) and r['issued_at']<=e['sampled_at']<=e['at'],'calibration_sample');require(e['sample_ref']==certificate_seal('Chart',e['chart']),'chart_ref')
            else:require(e['chart'] is None and e['sampled_at'] is None and e['sample_ref'] is None,'failure_payload')
            self._active(dict(kind='tick',at=e['at']));status='SUPERSEDED' if r['frame']!=self.mapper.frame or r['payload']['calibration_ref']!=self.calibration_ref() else 'TIMEOUT' if e['at']>r['deadline'] else e['outcome']
            if status=='OK':
                self.calibration_sample=dict(chart=e['chart'],evaluation=evaluate(e['chart']),sampled_at=e['sampled_at'],sample_ref=e['sample_ref'],frame=r['frame'],calibration_ref=r['payload']['calibration_ref'],request=r['id'])
                if self.monitor()['sample_class']=='DRIFT' and not self.revoked:self.breaches+=1;self.revoked=True
            self.pending=None;self.last=dict(kind=k,status=status,drift=self.monitor())
        elif k=='recalibrate':
            fields(e,'kind at proposal');require(self.phase=='RUNNING','stopped');self._active(dict(kind='tick',at=e['at']));p=self.recalibration_proposal();require(p is not None and canon(p)==canon(e['proposal']),'calibration_certificate_witness')
            previous=copy.deepcopy(self.calibration);self.calibration=dict(revision=p['revision'],certificate=p['certificate'],activated_at=e['at'])
            self.revoked=False;self.calibration_sample=None;self.calibration_attempt=-self.contract['calibration_refresh'];self._active(dict(kind='frame',at=e['at']));self.last=dict(kind=k,previous=previous,calibration=copy.deepcopy(self.calibration),witness=p)
        elif k=='certified_result':
            fields(e,'kind at calibration_ref event');require(self.pending is not None and e['calibration_ref']==self.pending_calibration and e['calibration_ref']==self.calibration_ref(),'result_calibration')
            inner=copy.deepcopy(e['event']);require(type(inner) is dict and inner.get('kind') in ['window_result','scoped_boolean','probe_result'] and inner.get('at')==e['at'],'certified_type')
            raw=None
            if inner['kind']=='window_result' and inner['event'].get('kind')=='patch':
                raw=copy.deepcopy(inner['event']['patch']);cert=self.calibration['certificate'];require(cert is not None,'certificate_missing')
                inner['event']['patch']=corrected_patch(raw,cert,self.calibration_ref())
            super()._registered(inner);self.pending_calibration=None;self.last=dict(kind=k,calibration_ref=e['calibration_ref'],raw_patch=raw,result=self.last)
        elif k in ['window_result','scoped_boolean','probe_result']:raise ValueError('uncertified_result_forbidden')
        else:
            super()._registered(e)
            if k=='dispatch':self.pending_calibration=self.calibration_ref()
            if k=='resume':self.pending_calibration=None
