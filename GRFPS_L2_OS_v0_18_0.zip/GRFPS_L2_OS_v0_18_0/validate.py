"""Reexecute release contracts, recorded experiments, and actual CLI restart."""
from pathlib import Path
import io
import json
import platform
import shutil
import subprocess
import sys
import tempfile
import unittest
from grfps_l2 import digest
from journal import recover,verify_checkpoint
from live import export_replay as export_files
from segments import recover_segments,verify_segment_checkpoint
from organ_runtime import export_replay
from field_world import truth
from organs import fact_id

ROOT=Path(__file__).resolve().parent


def main():
    report={"version":"0.18.0","python":platform.python_version(),"platform":platform.system(),
            "visual_browser_review":False}
    log=[];passed=False
    def run(args):
        r=subprocess.run(args,cwd=ROOT,capture_output=True,text=True,encoding="utf-8",
                         errors="replace",timeout=90)
        log.extend(["COMMAND "+repr(args),r.stdout,r.stderr])
        if r.returncode:raise RuntimeError("Command failed: "+repr(args))
        return r.stdout
    try:
        stream=io.StringIO()
        suite=unittest.defaultTestLoader.discover(str(ROOT),pattern="test_*.py")
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
        log.append(stream.getvalue())
        report["python_tests"]={"run":result.testsRun,"failures":len(result.failures),
            "errors":len(result.errors),"skipped":len(result.skipped)}
        if not result.wasSuccessful():raise RuntimeError("Contract tests failed")
        run([sys.executable,"build_demo.py"])
        filejournal=ROOT/"evidence_run/session.jsonl"
        fileproof=export_files(filejournal,ROOT/"closed_loop_demo.html")
        verify_checkpoint(filejournal,filejournal.with_name(filejournal.name+".checkpoint.json"))
        report["file_profile_replay"]=fileproof
        organjournal=ROOT/"organ_evidence_run/journal"
        proof=export_replay(organjournal,ROOT/"organ_demo.html")
        verify_segment_checkpoint(organjournal)
        original=json.loads((ROOT/"organ_evidence_run/integration_report.json").read_text())
        for k in ["transitions","requests","segments","state_digest","head"]:
            if proof[k]!=original[k]:raise RuntimeError("Organ evidence mismatch: "+k)
        report["organ_integration"]={**proof,"checkpoint_verified":True,
            "original_http_projection_checks":original["http_projection_checks"],
            "note":"Reexecution of recorded inputs; original process/HTTP integration is not repeated."}
        bench=ROOT/"benchmark_run"
        protocol=json.loads((bench/"protocol.json").read_text())
        br=json.loads((bench/"benchmark_report.json").read_text())
        if br["protocol_digest"]!=digest("BenchmarkProtocol",protocol):
            raise RuntimeError("Benchmark protocol mismatch")
        for row in br["cases"]:
            directory=bench/f"{row['world_seed']:02d}-{row['policy']}"
            r=recover_segments(directory);m=r["machine"];state=m.snapshot()
            if state["state_digest"]!=row["state_digest"] or r["head"]!=row["head"]:
                raise RuntimeError("Benchmark replay mismatch")
            world=json.loads((bench/f"world-{row['world_seed']:02d}.json").read_text())
            known=wrong=0
            for o in m.config["organs"]:
                for s in range(m.config["sectors"]):
                    p=state["kernel"]["percepts"][fact_id(o["id"],s)]
                    if p["epistemic"]=="Known":
                        known+=1;wrong+=p["value"]!=truth(world,o["query"],s)
            if (known!=row["known_questions"] or wrong!=row["false_known_count"]
                    or len(m.attempts)!=row["distinct_questions"] or m.spent!=16):
                raise RuntimeError("Benchmark metric mismatch")
        report["benchmark"]={"replayed_runs":len(br["cases"]),"measurements":br["measurements"],
                            "aggregate":br["aggregate"],"protocol_digest":br["protocol_digest"]}
        from map_runtime import export as export_map, replay as replay_map
        from mapping import hashof
        from map_worker import sample as sample_map
        from run_map_demo import metrics
        mapping_dir=ROOT/"mapping_run"
        mp=export_map(mapping_dir/"map.jsonl",ROOT/"map_demo.html")
        mr=json.loads((mapping_dir/"mapping_report.json").read_text())
        for k in ["transitions","spent","head","state_digest"]:
            if mp[k]!=mr[k]:raise RuntimeError("Map replay mismatch")
        rr=replay_map(mapping_dir/"map.jsonl")
        for before,event in zip(rr["views"],rr["events"]):
            if event["kind"]=="patch":
                fixture=json.loads((mapping_dir/"samples"/(event["patch"]["sample_ref"]+".json")).read_text())
                if sample_map(fixture,before["pending"],event["patch"]["sampled_at"])!=event["patch"]:
                    raise RuntimeError("Map sample provenance mismatch")
        protocol=json.loads((mapping_dir/"protocol.json").read_text())
        if hashof("Protocol",protocol)!=mr["protocol_digest"]:raise RuntimeError("Map protocol mismatch")
        baseline=rr["views"][6]
        initial=json.loads((mapping_dir/"world_initial.json").read_text())
        map_truth=[e[:2] for e in initial["relations"] if e[2]]
        predicted=[[e["a"],e["b"]] for e in baseline["atlas"]["relations"] if e["status"]=="Known" and e["value"]]
        expected=dict(declared=metrics(protocol["declared"],map_truth),measured=metrics(predicted,map_truth),budget_spent=baseline["spent"])
        if expected!=mr["comparison"]:raise RuntimeError("Map metrics mismatch")
        report["mapping"]={**mp,"comparison":expected,"sample_provenance_verified":True}
        from active_runtime import export as export_active
        from active_atlas import replay as replay_active
        ar=export_active(ROOT/"active_evidence_run/active.jsonl",ROOT/"active_demo.html")
        expected=json.loads((ROOT/"active_evidence_run/report.json").read_text())
        for k in ["transitions","spent","head","state_digest"]:
            if ar[k]!=expected[k]:raise RuntimeError("Active replay mismatch")
        active_replay=replay_active(ROOT/"active_evidence_run/active.jsonl")
        active_world=json.loads((ROOT/"active_evidence_run/world.json").read_text())
        for before,event in zip(active_replay["views"],active_replay["events"]):
            if event["kind"]=="patch" and sample_map(active_world,before["pending"],event["patch"]["sampled_at"])!=event["patch"]:
                raise RuntimeError("Active sample provenance mismatch")
        report["active_atlas"]={**ar,"sample_provenance_verified":True,"original_http_checks":expected["http_checks"],"restart_preserved_spent":expected["restart_preserved_spent"]}
        from bank_journal import replay as replay_bank
        from bank_runtime import export as export_bank
        from field_world import measure as measure_field, world_ref
        bank_report={}
        for case in ["live","archive"]:
            directory=ROOT/"bank_evidence_run"/case
            rr=replay_bank(directory/"bank.jsonl",collect=True)
            expected=json.loads((directory/"report.json").read_text())
            state=rr["machine"].snapshot()
            for k,val in [("transitions",rr["machine"].seq),("spent",rr["machine"].spent),("head",rr["head"]),("state_digest",state["state_digest"])]:
                if expected[k]!=val:raise RuntimeError("Bank replay mismatch")
            ww=json.loads((directory/"world.json").read_text());fw=json.loads((directory/"field.json").read_text());verified=0
            for before,event in zip(rr["views"],rr["events"]):
                request=before["pending"]
                if event["kind"]=="window_result" and event["event"]["kind"]=="patch":
                    patch=event["event"]["patch"]
                    if sample_map(ww,request["inner"],patch["sampled_at"])!=patch:raise RuntimeError("Bank window provenance")
                    verified+=1
                if event["kind"]=="boolean_result" and event["outcome"] in ["OK","OCCLUDED"]:
                    sample=measure_field(fw,request["organ"],request["payload"]["sector"])
                    if sample["outcome"]!=event["outcome"] or sample["value"]!=event["value"] or world_ref(fw)!=event["sample_ref"]:raise RuntimeError("Bank field provenance")
                    verified+=1
            if case=="archive":
                if max(v["resident"]["patches"] for v in rr["views"])!=4 or state["archive"]["count"]!=108:raise RuntimeError("Retirement bound")
                if len(replay_bank(directory/"bank.jsonl",resolve=expected["resolve_ref"])["resolved"])!=1:raise RuntimeError("Archive resolution")
                export_bank(directory/"bank.jsonl",ROOT/"bank_demo.html")
            bank_report[case]={"transitions":state["sequence"],"spent":state["spent"],"verified_samples":verified,"archive":state["archive"],"head":rr["head"]}
        report["organ_bank"]=bank_report
        from registered_segments import replay as replay_registered
        from registered_runtime import export as export_registered
        registered_report={}
        for case in ["live","continuity"]:
            directory=ROOT/"registered_evidence_run"/case
            rr=replay_registered(directory/"journal",collect=True)
            expected=json.loads((directory/"report.json").read_text());m=rr["machine"]
            for k,val in [("transitions",m.seq),("spent",m.spent),("segments",rr["index"]+1),("head",rr["head"]),("state_digest",m.snapshot()["state_digest"])]:
                if expected[k]!=val:raise RuntimeError("Registered replay mismatch")
            verified=0
            for before,event in zip(rr["views"],rr["events"]):
                request=before["pending"]
                if event["kind"]=="window_result" and event["event"]["kind"]=="patch":
                    p=event["event"]["patch"];ww=json.loads((directory/"samples"/(p["sample_ref"]+".json")).read_text())
                    if sample_map(ww,request["inner"],p["sampled_at"])!=p:raise RuntimeError("Registered window provenance")
                    verified+=1
                if event["kind"]=="scoped_boolean" and event["event"]["outcome"] in ["OK","OCCLUDED"]:
                    e=event["event"];fw=json.loads((directory/"samples"/(e["sample_ref"]+".json")).read_text())
                    sample=measure_field(fw,request["organ"],request["payload"]["sector"])
                    if fw["depth"]!=m.contract["scope_cells"] or world_ref(fw)!=e["sample_ref"] or sample["outcome"]!=e["outcome"] or sample["value"]!=e["value"]:raise RuntimeError("Registered scoped provenance")
                    verified+=1
            if case=="live":export_registered(directory/"journal",ROOT/"registered_demo.html")
            else:
                if m.seq<=2000 or m.spent!=expected["preserved_spent"]:raise RuntimeError("Continuous budget preservation")
            registered_report[case]={"transitions":m.seq,"segments":rr["index"]+1,"spent":m.spent,"verified_samples":verified,"head":rr["head"]}
        report["registered_bank"]=registered_report
        from verify_uncertain import verify
        report["uncertain_bank"]=verify(ROOT)
        from verify_calibrated import verify as verify_calibrated
        report["calibrated_bank"]=verify_calibrated(ROOT)
        from verify_certified import verify as verify_certified
        report["certified_bank"]=verify_certified(ROOT)
        from verify_noisy import verify as verify_noisy
        report["noisy_bank"]=verify_noisy(ROOT)
        from run_trace_demo import verify as verify_trace
        from trace_runtime import export_gallery
        report["trace_import"]=verify_trace(ROOT/"trace_evidence_run")
        export_gallery(ROOT/"trace_evidence_run",ROOT/"trace_demo.html")
        from verify_geometry import verify as verify_geometry
        report["live_geometry"]=verify_geometry(ROOT/"geometry_evidence_run")
        from verify_sources import verify as verify_sources
        report["multisource"]=verify_sources(ROOT/"source_evidence_run")
        from verify_carrier import verify as verify_carrier
        report['carrier_integration']=verify_carrier(ROOT/'carrier_evidence_run')
        from verify_registered3d import verify as verify_registered3d
        report['registered3d_integration']=verify_registered3d(ROOT/'registered3d_evidence_run')
        from verify_continuous3d import verify as verify_continuous3d
        report['continuous3d_integration']=verify_continuous3d(ROOT/'continuous3d_evidence_run')
        from verify_epoch3d import verify as verify_epoch3d
        report['epoch3d_integration']=verify_epoch3d(ROOT/'epoch3d_evidence_run')
        from audit_carrier_intake import report as audit_carrier
        report['carrier_intake_audit']=audit_carrier()
        from wfb_audit import report as audit_wfb
        report["wfb_audit"]=audit_wfb()
        if shutil.which("node"):
            report["javascript"]={name:json.loads(run(["node",filename])) for name,filename in [
                ("legacy","test_viewer.cjs"),("files","test_live_viewer.cjs"),
                ("organs","test_organ_viewer.cjs"),("mapping","test_map_viewer.cjs"),("active","test_active_viewer.cjs"),("bank","test_bank_viewer.cjs"),("registered","test_registered_viewer.cjs"),("uncertain","test_uncertain_viewer.cjs"),("calibrated","test_calibrated_viewer.cjs"),("certified","test_certified_viewer.cjs"),("noisy","test_noisy_viewer.cjs"),("trace","test_trace_viewer.cjs"),("geometry","test_geometry_viewer.cjs"),("sources","test_source_viewer.cjs"),("carrier","test_carrier_viewer.cjs"),("webxr_probe","test_webxr_probe.cjs"),("registered3d","test_registered3d_viewer.cjs"),("continuous3d","test_continuous3d_viewer.cjs"),("epoch3d","test_epoch3d_viewer.cjs")]}
        else:report["javascript"]={"status":"SKIPPED","reason":"Node.js unavailable"}
        with tempfile.TemporaryDirectory(prefix="grfps_organ_cli_") as tmp:
            field=Path(tmp)/"field.json";shutil.copyfile(ROOT/"organ_evidence_run/field.json",field)
            directory=Path(tmp)/"journal"
            run([sys.executable,"organ_runtime.py","watch","--world",str(field),
                 "--out",str(directory),"--duration","0.6","--budget","4"])
            first=recover_segments(directory);seq=first["machine"].seq;spent=first["machine"].spent
            if first["machine"].phase!="STOPPED":raise RuntimeError("First CLI stop absent")
            run([sys.executable,"organ_runtime.py","watch","--out",str(directory),
                 "--resume","--duration","0.6","--budget","6"])
            second=recover_segments(directory,collect_views=True)
            state=second["views"][seq]
            if second["records"][seq]["event"]["kind"]!="resume":
                raise RuntimeError("Resume event absent")
            if any(p["active_refs"] for p in state["kernel"]["percepts"].values()):
                raise RuntimeError("Resume retained old evidence")
            if state["budget"]["spent"]!=spent:
                raise RuntimeError("Resume reset spent budget")
            if second["machine"].phase!="STOPPED":raise RuntimeError("Second CLI stop absent")
            cli=json.loads(run([sys.executable,"organ_runtime.py","replay",str(directory)]))
            if cli["state_digest"]!=second["machine"].snapshot()["state_digest"]:
                raise RuntimeError("CLI replay mismatch")
            verify_segment_checkpoint(directory)
            report["cli_restart"]={"passed":True,"first_transitions":seq,
                "final_transitions":second["machine"].seq,"preserved_spent_budget":spent,
                "old_evidence_expired":True,"checkpoint_verified":True}
        from uncertain_segments import replay as replay_uncertain
        with tempfile.TemporaryDirectory(prefix="grfps08_cli_",dir="/tmp") as tmp:
            directory=Path(tmp)/"run"
            run([sys.executable,"uncertain_runtime.py","--out",str(directory),"--duration","0.4"])
            first=replay_uncertain(directory/"journal");spent=first["machine"].spent;seq=first["machine"].seq
            run([sys.executable,"uncertain_runtime.py","--out",str(directory),"--resume","--duration","0.4"])
            second=replay_uncertain(directory/"journal",collect=True)
            resumed=next(s for s in second["views"] if s["sequence"]==seq+1)
            assert resumed["spent"]==spent and all(b["epistemic"]=="Unknown" for b in resumed["bridges"])
            assert second["machine"].phase=="STOPPED"
            report["uncertain_cli_restart"]={"passed":True,"preserved_spent":spent,"final_spent":second["machine"].spent,"transitions":second["machine"].seq}
        from calibrated_segments import replay as replay_calibrated
        with tempfile.TemporaryDirectory(prefix="grfps09_cli_",dir="/tmp") as tmp:
            directory=Path(tmp)/"run"
            run([sys.executable,"calibrated_runtime.py","--out",str(directory),"--duration","0.5"])
            first=replay_calibrated(directory/"journal");spent=first["machine"].spent;seq=first["machine"].seq
            run([sys.executable,"calibrated_runtime.py","--out",str(directory),"--resume","--duration","0.5"])
            second=replay_calibrated(directory/"journal",collect=True);resumed=next(s for s in second["views"] if s["sequence"]==seq+1)
            assert resumed["spent"]==spent and resumed["drift"]["status"]=="UNKNOWN"
            assert second["machine"].phase=="STOPPED"
            report["calibrated_cli_restart"]={"passed":True,"preserved_spent":spent,"final_spent":second["machine"].spent,"transitions":second["machine"].seq}
        from certified_segments import replay as replay_certified
        with tempfile.TemporaryDirectory(prefix="grfps010_cli_",dir="/tmp") as tmp:
            directory=Path(tmp)/"run"
            run([sys.executable,"certified_runtime.py","--out",str(directory),"--duration","0.6"])
            first=replay_certified(directory/"journal");spent=first["machine"].spent;seq=first["machine"].seq;cert=first["machine"].calibration
            assert cert['revision']==1 and cert['certificate']['transform']==[1,3,-2]
            run([sys.executable,"certified_runtime.py","--out",str(directory),"--resume","--duration","0.6"])
            second=replay_certified(directory/"journal",collect=True);resumed=next(s for s in second["views"] if s["sequence"]==seq+1)
            assert resumed["spent"]==spent and resumed["calibration"]==cert and resumed["drift"]["status"]=="UNKNOWN"
            assert second["machine"].phase=="STOPPED"
            report["certified_cli_restart"]={"passed":True,"preserved_spent":spent,"certificate_preserved":True,"final_spent":second["machine"].spent,"transitions":second["machine"].seq}
        from noisy_segments import replay as replay_noisy
        with tempfile.TemporaryDirectory(prefix="grfps011_cli_",dir="/tmp") as tmp:
            directory=Path(tmp)/"run"
            run([sys.executable,"noisy_runtime.py","--out",str(directory),"--duration","1.0"])
            first=replay_noisy(directory/"journal");spent=first["machine"].spent;seq=first["machine"].seq;cert=first["machine"].calibration
            assert cert['revision']==1 and [1,3,-2] in cert['certificate']['candidates']
            run([sys.executable,"noisy_runtime.py","--out",str(directory),"--resume","--duration","0.5"])
            second=replay_noisy(directory/"journal",collect=True);resumed=next(s for s in second["views"] if s["sequence"]==seq+1)
            assert resumed["spent"]==spent and resumed["calibration"]==cert and resumed["drift"]["status"]=="UNKNOWN"
            assert second["machine"].phase=="STOPPED"
            report["noisy_cli_restart"]={"passed":True,"preserved_spent":spent,"certificate_preserved":True,"final_spent":second["machine"].spent,"transitions":second["machine"].seq}
        from geometry_segments import replay as replay_geometry
        with tempfile.TemporaryDirectory(prefix="grfps013_cli_",dir="/tmp") as tmp:
            directory=Path(tmp)/"run"
            run([sys.executable,"geometry_runtime.py","--out",str(directory),"--duration","2.0"])
            first=replay_geometry(directory/"journal");spent=first["machine"].spent;seq=first["machine"].seq;nodes=first["machine"].nodes_spent;cert=first["machine"].calibration
            assert cert['revision']==1
            run([sys.executable,"geometry_runtime.py","--out",str(directory),"--resume","--duration","1.0"])
            second=replay_geometry(directory/"journal",collect=True);resumed=next(s for s in second["views"] if s["sequence"]==seq+1)
            assert resumed["spent"]==spent and resumed["search_budget"]["spent"]==nodes and resumed["calibration"]==cert and resumed["geometry_answer"]["epistemic"]=="Unknown"
            assert second["machine"].phase=="STOPPED"
            report["geometry_cli_restart"]={"passed":True,"preserved_spent":spent,"preserved_nodes":nodes,"certificate_preserved":True,"final_spent":second["machine"].spent,"transitions":second["machine"].seq}
        from source_segments import replay as replay_sources
        with tempfile.TemporaryDirectory(prefix="grfps014_cli_",dir="/tmp") as tmp:
            directory=Path(tmp)/"run"
            run([sys.executable,"source_runtime.py","--out",str(directory),"--duration","2.0"])
            first=replay_sources(directory/"journal");old=first['machine'];assert old.calibration['revision']==1
            run([sys.executable,"source_runtime.py","--out",str(directory),"--resume","--duration","1.0"])
            second=replay_sources(directory/"journal",collect=True)
            resumed=next(after for before,e,after in zip(second['views'],second['events'],second['views'][1:]) if e['kind']=='resume')
            assert resumed['spent']==old.spent and resumed['search_budget']['spent']==old.nodes_spent and resumed['source_epochs']==old.source_epochs and resumed['calibration']==old.calibration and resumed['geometry_answer']['epistemic']=='Unknown'
            assert second['machine'].phase=='STOPPED'
            report['source_cli_restart']=dict(passed=True,preserved_spent=old.spent,preserved_nodes=old.nodes_spent,preserved_epochs=old.source_epochs,transitions=second['machine'].seq)
        from carrier_segments import replay as replay_carrier
        with tempfile.TemporaryDirectory(prefix='grfps015_cli_',dir='/tmp') as tmp:
            directory=Path(tmp)/'run'
            run([sys.executable,'carrier_runtime.py','--out',str(directory),'--trace',str(ROOT/'sources/carrier_rehearsal.jsonl'),'--manifest',str(ROOT/'sources/carrier_manifest.json'),'--duration','1.0'])
            first=replay_carrier(directory/'journal');old=first['machine'];cursor=old.carrier_state.cursor
            run([sys.executable,'carrier_runtime.py','--out',str(directory),'--resume','--duration','1.0'])
            second=replay_carrier(directory/'journal',collect=True)
            resumed=next(after for before,e,after in zip(second['views'],second['events'],second['views'][1:]) if e['kind']=='resume')
            assert resumed['carrier']==old.snapshot()['carrier'] and resumed['spent']==old.spent and resumed['search_budget']['spent']==old.nodes_spent and second['machine'].carrier_state.cursor>cursor
            assert second['machine'].phase=='STOPPED'
            before={x.name:x.read_bytes() for x in (directory/'journal').glob('*.jsonl')}
            (directory/'carrier.jsonl').write_bytes(b'{}\n')
            failed=subprocess.run([sys.executable,'carrier_runtime.py','--out',str(directory),'--resume','--duration','.1'],cwd=ROOT,capture_output=True,text=True)
            assert failed.returncode!=0 and before=={x.name:x.read_bytes() for x in (directory/'journal').glob('*.jsonl')}
            bad=Path(tmp)/'bad';invalid=subprocess.run([sys.executable,'carrier_runtime.py','--out',str(bad),'--trace',str(directory/'carrier.jsonl'),'--manifest',str(ROOT/'sources/carrier_manifest.json'),'--duration','.1'],cwd=ROOT,capture_output=True,text=True);assert invalid.returncode!=0 and not bad.exists()
            report['carrier_cli_restart']=dict(passed=True,preserved_spent=old.spent,preserved_nodes=old.nodes_spent,first_cursor=cursor,final_cursor=second['machine'].carrier_state.cursor,transitions=second['machine'].seq,invalid_resume_no_mutation=True,invalid_preflight_no_output=True)
        from registered3d_segments import replay as replay_registered3d
        with tempfile.TemporaryDirectory(prefix='grfps016_cli_',dir='/tmp') as tmp:
            directory=Path(tmp)/'run'
            run([sys.executable,'registered3d_runtime.py','--out',str(directory),'--duration','.35'])
            first=replay_registered3d(directory/'journal');old=first['machine'];cursor=old.carrier_state.cursor
            run([sys.executable,'registered3d_runtime.py','--out',str(directory),'--resume','--duration','.5'])
            second=replay_registered3d(directory/'journal',collect=True);resumed=next(after for before,e,after in zip(second['views'],second['events'],second['views'][1:]) if e['kind']=='resume')
            assert resumed['registered3d']==old.registered3d and resumed['registration_certificate']==old.registration_certificate and resumed['registration_work']==old.registration_work and resumed['spent']==old.spent and second['machine'].carrier_state.cursor>=cursor
            assert second['machine'].phase=='STOPPED'
            before={x.name:x.read_bytes() for x in (directory/'journal').glob('*.jsonl')};b=json.loads((directory/'registration3d.json').read_text());b['query']['threshold_um']+=1;(directory/'registration3d.json').write_text(json.dumps(b))
            bad=subprocess.run([sys.executable,'registered3d_runtime.py','--out',str(directory),'--resume','--duration','.1'],cwd=ROOT,capture_output=True,text=True);assert bad.returncode!=0 and before=={x.name:x.read_bytes() for x in (directory/'journal').glob('*.jsonl')}
            report['registered3d_cli_restart']=dict(passed=True,first_cursor=cursor,final_cursor=second['machine'].carrier_state.cursor,preserved_spent=old.spent,certificate_preserved=True,work_preserved=True,invalid_resume_no_mutation=True,transitions=second['machine'].seq)
        from continuous3d_segments import replay as replay_continuous3d
        with tempfile.TemporaryDirectory(prefix='grfps017_cli_',dir='/tmp') as tmp:
            directory=Path(tmp)/'run'
            run([sys.executable,'continuous3d_runtime.py','--out',str(directory),'--duration','.35'])
            first=replay_continuous3d(directory/'journal');old=first['machine'];cursor=old.carrier_state.cursor
            run([sys.executable,'continuous3d_runtime.py','--out',str(directory),'--resume','--duration','.5'])
            second=replay_continuous3d(directory/'journal',collect=True);resumed=next(after for before,e,after in zip(second['views'],second['events'],second['views'][1:]) if e['kind']=='resume')
            assert resumed['registered3d']==old.registered3d and resumed['registration_certificate']==old.registration_certificate and resumed['registration_work']==old.registration_work and resumed['spent']==old.spent and second['machine'].carrier_state.cursor>=cursor
            assert second['machine'].phase=='STOPPED'
            before={x.name:x.read_bytes() for x in (directory/'journal').glob('*.jsonl')};b=json.loads((directory/'registration3d.json').read_text());b['query']['threshold_um']+=1;(directory/'registration3d.json').write_text(json.dumps(b))
            bad=subprocess.run([sys.executable,'continuous3d_runtime.py','--out',str(directory),'--resume','--duration','.1'],cwd=ROOT,capture_output=True,text=True);assert bad.returncode!=0 and before=={x.name:x.read_bytes() for x in (directory/'journal').glob('*.jsonl')}
            report['continuous3d_cli_restart']=dict(passed=True,first_cursor=cursor,final_cursor=second['machine'].carrier_state.cursor,preserved_spent=old.spent,certificate_preserved=True,work_preserved=True,invalid_resume_no_mutation=True,transitions=second['machine'].seq)
        from epoch3d_segments import replay as replay_epoch3d
        with tempfile.TemporaryDirectory(prefix='grfps018_cli_',dir='/tmp') as tmp:
            directory=Path(tmp)/'run'
            run([sys.executable,'epoch3d_runtime.py','--out',str(directory),'--case','epoch_rebind','--duration','.25'])
            first=replay_epoch3d(directory/'journal');old=first['machine'];cursor=old.carrier_state.cursor
            run([sys.executable,'epoch3d_runtime.py','--out',str(directory),'--resume','--duration','.9'])
            second=replay_epoch3d(directory/'journal',collect=True);resumed=next(after for before,e,after in zip(second['views'],second['events'],second['views'][1:]) if e['kind']=='resume')
            assert resumed['registered3d']==old.registered3d and resumed['registration_certificate']==old.registration_certificate and resumed['registration_work']==old.registration_work and resumed['spent']==old.spent and second['machine'].carrier_state.cursor>=cursor
            assert second['machine'].phase=='STOPPED'
            before={x.name:x.read_bytes() for x in (directory/'journal').glob('*.jsonl')};b=json.loads((directory/'registration_plan.json').read_text());b['entries'][0]['bundle']['sensor_error_um'][0]+=1;(directory/'registration_plan.json').write_text(json.dumps(b))
            bad=subprocess.run([sys.executable,'epoch3d_runtime.py','--out',str(directory),'--resume','--duration','.1'],cwd=ROOT,capture_output=True,text=True);assert bad.returncode!=0 and before=={x.name:x.read_bytes() for x in (directory/'journal').glob('*.jsonl')}
            assert len(second['machine'].registration_history)==2 and second['machine'].carrier_state.epoch==1
            report['epoch3d_cli_restart']=dict(passed=True,first_cursor=cursor,final_cursor=second['machine'].carrier_state.cursor,preserved_spent=old.spent,certificate_preserved=True,work_preserved=True,invalid_resume_no_mutation=True,transitions=second['machine'].seq,admissions=len(second['machine'].registration_history),final_epoch=second['machine'].carrier_state.epoch)
        passed=True
    except Exception as err:
        report["error"]=type(err).__name__+": "+str(err);log.append(report["error"])
    finally:
        report["passed"]=passed
        (ROOT/"validation.json").write_text(json.dumps(report,indent=2)+"\n")
        (ROOT/"validation.log").write_text("\n".join(log))
        print(json.dumps(report,indent=2))
    if not passed:raise SystemExit(1)


if __name__=="__main__":
    main()
