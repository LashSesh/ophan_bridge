# GRFPS — 2nd-Layer Synthetic Perception OS, 0.15.0

Diese Phase ergänzt einen **XR-Dateieingang mit bytegenauer Herkunftsbindung** und einen **Beobachtungsport für die zweite Wahrnehmungsschicht**. Die bestehende aktive Mehrquellengeometrie bleibt ausführbar. Aufgezeichnete Trägerpose, geometrische Ableitung und bestätigte Wirkung besitzen getrennte Zustände.

Die beiden neuen Ressourcen wurden verwertet: Das Physical-Carrier-Paket liefert Format und Probelauf; OPERATORIUM die Idee schmaler Ports und gebundener Darstellungen. Acht ausführbare Gegenversuche begrenzen die Übernahme des ursprünglichen physischen Evaluators. Die Bewertung steht in `INTAKE_ASSESSMENT.md`, die Reproduktion in `audit_carrier_intake.py` und `intake_audit.json`.

## Start

Python 3.10 oder neuer, Standardbibliothek; Node.js für die Browserlogikprüfungen. Im entpackten Projektordner:

```sh
python carrier_runtime.py --out mein_traegerraum --trace sources/carrier_rehearsal.jsonl --manifest sources/carrier_manifest.json --open
python carrier_runtime.py --out mein_traegerraum --resume --open
python run_carrier_demo.py --out neue_traegerversuche
python audit_carrier_intake.py
python validate.py
```

Der neue Ausgabeordner muss fehlen. Standardlaufzeit: 15 Sekunden, anpassbar mit `--duration`. Die lokale HTTP-Ansicht zeigt den laufenden Ownerzustand; die XR-Datei bleibt historisch. Nach Ende liegt `replay.html` im Ausgabeordner. Unterbrochene Imports lassen sich über `--resume` mit erhaltenem Cursor und Budget fortsetzen. Veränderte Rohdaten werden vor dem Resume-Commit abgewiesen. Neue Imports prüfen die vollständige Datei vor dem Anlegen des Ausgabeordners.

`GRFPS_Second_Layer_Demo.html` ist eine eigenständige Offline-Datei mit sechs auswählbaren Versuchsverläufen. Die Steuerknöpfe sind darin gesperrt. `source_demo.html` bewahrt die sechs Mehrquellenversuche aus 0.14.0; deren Bedienung steht in `README_v0_14_0.md`.

## Eine XR-Aufnahme vorbereiten

`webxr_probe.html` ist ein neuer, begrenzter WebXR-Recorder. Auf dem Gerätehost:

```sh
python -m http.server 8000 --bind 127.0.0.1
```

Im WebXR-Browser desselben Hosts `http://localhost:8000/webxr_probe.html` öffnen und die Sitzung starten. Die Seite benötigt eine verfügbare XR-Runtime und einen geeigneten sicheren Kontext. Sie gibt höchstens 512 Records und 2 MiB aus, mit separaten Downloads für `carrier.jsonl` und `carrier_manifest.json`. Diese Dateien können anschließend mit `--trace` und `--manifest` eingelesen werden. Die Browserdeklaration `recorded` authentisiert kein physisches Gerät.

Der Recorder wurde hier anhand seiner JavaScript-Ausgabe und deren Python-Import geprüft. **Es wurde keine reale XR-Sitzung ausgeführt.** Die native OpenXR-Datei im Originalarchiv ist ein Hostfragment; sie wurde weder als Anwendung übernommen noch kompiliert. Für native Produzenten sind erfolgreiche API-Rückgaben, VALID-/TRACKED-Bits, gewählter Referenzraum und Epochengrenzen explizit zu liefern. Fehlen solche Belege, ist ein gemeldeter Trackingtext keine unabhängig bestätigte Gerätefähigkeit.

## Vertrag

| Bestandteil | Verhalten |
|---|---|
| Rohdaten | Unveränderte ASCII-JSONL-Bytes, Dateihash und Hash jeder Zeile |
| Zahlen | Endliche Dezimalzahlen; keine booleschen Zahlen, NaN oder Infinity; doppelte Schlüssel verboten |
| Begrenzung | 2 MiB, 512 Records, 32768 Bytes je Zeile; 64 Dezimalziffern, Exponent −48 bis 6 |
| Pose | Drei Positions-, vier Quaternionkomponenten; Normprüfung als Formkontrolle |
| Position | µm-Intervalle durch Abrunden/Aufrunden; ausschließlich Darstellungsfehler |
| Zeit | Integer-Nanosekunden bis 2^63−1; im kanonischen Zustand als exakter Dezimalstring |
| Tracking | Fehlend → UNAVAILABLE; partiell oder ausgefallen → keine vollständige projizierte Pose |
| Native Flags | Vorhandene Flags können einschränken; sie dürfen fehlendes Tracking nicht hochstufen |
| Referenzreset | Alte Pose entziehen, monotone Epoche; ausdrücklich veraltete Folgeframes abweisen |
| Kennzahlen | Fehlend bleibt null; vorhandene Werte und Fehlstellen werden getrennt gezählt |
| Herkunft | Simulated oder Recorded nach Manifest; physische Validierung bleibt Unknown |
| Aufnahmezeit | historical_file; Einlesezeit oder Resume erneuern keine Sensorbelege |
| Wirkungen | Eingabe oder roundtrip_ok ist keine bestätigte externe Wirkung |
| Raum-/Uhranschluss | XR ↔ bestehende Geometrie bleibt in beiden Dimensionen Unknown |

Die Quaternionnormprüfung ist kein Orientierungsfehlernachweis. Die µm-Hülle beweist keine Sensorgenauigkeit. Ein als Registrierung gemeldeter Wert ist eine Produzentenangabe; keine unabhängig kontrollierte Registrierung. Der Host-Millisekundentakt wird nicht mit der XR-Nanosekundendomäne gleichgesetzt. Fehlende Referenz- und Epochennummern werden als aktuelle Importreferenz und -epoche gelesen. Neue Produzenten sollten diese Felder explizit liefern; die Runtime kann eine nicht gemeldete Ursprungsänderung nicht erkennen. Eine vollständig neu erfundene Herkunft lässt sich durch Inhalts-Hashes allein nicht erkennen.

`operator_port.py` projiziert Referent, Wert, Bestimmtheit, Faktizität, Scope und Evidenz. Affordances beschränken sich auf lokales Inspizieren und Replay. Die Liste externer Effekte ist leer. Dies ist das eigene Teilprofil `grfps-observation-port/1`, keine vollständige Implementierung der 39 OPERATORIUM-Records oder des dortigen Compilers.

## Ausgeführte Prüfung

**432 Python-Tests und 255 JavaScript-Prüfungen bestehen.** Die 46 Tests des unveränderten Originalarchivs wurden separat ausgeführt und bestehen ebenfalls. Acht Gegenversuche reproduzieren trotzdem die in der Bewertung dokumentierten Prüfgrenzen.

| Versuch | Übergänge | XR-Records | Aufträge | Messkosten | Suchknoten | HTTP |
|---|---:|---:|---:|---:|---:|---:|
| rehearsal | 543 | 185 | 68 | 88 | 297 | 185 |
| tracking_loss | 82 | 9 | 11 | 13 | 54 | 42 |
| reference_reset | 83 | 10 | 11 | 13 | 54 | 42 |
| missing_metrics | 82 | 9 | 11 | 13 | 54 | 42 |
| native_flags | 82 | 9 | 11 | 13 | 54 | 42 |
| emulated_webxr | 82 | 9 | 11 | 13 | 54 | 42 |
| **Gesamt** | **954** | **231** | **123** | **153** | **567** | **395** |

Jeder neue Versuch nutzt tatsächliche Workerprozesse und einen tatsächlichen lokalen HTTP-Server. Alle XR-Daten dieser Versuche sind synthetisch. Jeder Verlauf wird vollständig semantisch wiedergegeben, jedes XR-Rohrecord erneut eingelesen und jeder Beobachtungsport rekonstruiert. Die ursprünglichen 180 Frames plus fünf Ereignisse sind vollständig erhalten. Die fünf zusätzlichen Fälle prüfen Trackingverlust, Referenzreset, fehlende Werte und große Zeitstempel, native Statusflags und geschätzte WebXR-Positionen.

Der zusätzliche CLI-Start importierte 15 Records; Resume führte den Cursor auf 30 fort und erhielt Verbrauch und historischen Zustand. Ein veränderter Rohdatenbestand erzeugte beim erneuten Resume keine Journalmutation. Übergangszahlen können bei einer neuen Durchführung wegen realer Prozessplanung abweichen; die archivierten Nachweise sind exakt replaybar.

Browserlogik wurde ausgeführt. Ein visueller Browserdurchlauf war mangels installiertem Browser nicht möglich. Die 118-seitige PDF wurde eigenständig kompiliert und visuell geprüft. Headsetbetrieb, Displaylatenz, Geräteauthentizität und physische Referenzmessung wurden nicht geprüft.

## Nächster Nachweis

Ein echter dreidimensionaler Raum- und Uhranschluss benötigt unveränderte Geräteaufnahmen, unabhängig kontrollierte Referenzmessungen und explizite Fehlerintervalle. Die bisherige 2D-Vierteldrehungsgeometrie wird dafür nicht stillschweigend erweitert. Erst ein solcher Anschluss kann Aussagen aus dem Modellraum begründet auf einen realen Trägerraum beziehen. Externe Aktionen benötigen zusätzlich Autorisierung und einen belegten Wirkungsabgleich.

## Dateien

- `GRFPS_2nd_Layer_OS.pdf` / `.tex`: vollständiger Gesamtentwurf mit neuen Abschnitten 83–89 sowie Bedien- und Formatanhang.
- `carrier_contract.py`, `carrier_bank.py`, `carrier_segments.py`: Import, Zustandsmaschine und vollständiges Replay.
- `carrier_runtime.py`, `carrier_viewer.html`, `operator_port.py`: lokaler Lauf und Beobachtungsansicht.
- `webxr_probe.html`: neuer begrenzter Recorder.
- `carrier_evidence_run`: sechs unveränderte Prozessverläufe, Rohdateien und Berichte.
- `sources`: beide neuen Originalressourcen, ursprünglicher Probelauf und Bericht über die Originaltests.
- `validation.json`, `validation.log`, `intake_audit.json`: ausgeführte Prüfungen und reproduzierte Grenzen.
- `MANIFEST.sha256`: Inhaltsprüfsummen der Paketdateien.

Die Vorprofile und bisherigen WFB-Bewertungen bleiben erhalten. Alle neuen Laufzeitzustände sind durch eigene Profile versioniert.
