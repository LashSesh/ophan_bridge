import copy,tempfile,unittest
from pathlib import Path
from calibrated_bridge import CalibratedBank,config,seal,calibration_fixture
from calibrated_segments import SegmentJournal,replay
from test_uncertain import answer as uncertain_answer

def machine():return CalibratedBank(config('/tmp/w','/tmp/f','/tmp/o','/tmp/c'))
def dispatch(m):return m.reduce(dict(kind='dispatch',at=m.mapper.at,proposal=m.plan()))[0]
def answer(m,offset=None):
    if m.pending['organ']=='calibration_probe':
        r=m.pending;v=[0,0] if offset is None else offset;return dict(kind='calibration_result',at=m.mapper.at+1,request=r['id'],exposure=r['exposure'],outcome='OK',offset=v,sampled_at=m.mapper.at+1,sample_ref=seal('ReferenceWorld',calibration_fixture(v)))
    e=uncertain_answer(m);return dict(kind='calibrated_result',at=e['at'],calibration_ref=m.pending_calibration,event=e)
def sampled(offset=None):
    m=dispatch(machine());return m.reduce(answer(m,offset))[0]
def known():
    m=sampled()
    for _ in range(16):
        if m.projections()[0]['epistemic']=='Known':return m
        m=dispatch(m);m=m.reduce(answer(m))[0]
    raise AssertionError('not known')
def refresh(m,offset):
    m=m.reduce(dict(kind='tick',at=m.mapper.at+m.contract['calibration_refresh']))[0];m=dispatch(m);return m.reduce(answer(m,offset))[0]

class CalibratedTests(unittest.TestCase):
    def test_initial_hold_and_monitor_first(self):
        m=machine();self.assertEqual(m.monitor()['status'],'UNKNOWN');self.assertEqual(m.plan()['organ'],'calibration_probe')
    def test_within(self):self.assertEqual(sampled([1,-1]).monitor()['status'],'VALID')
    def test_known_after_calibration(self):self.assertIs(known().projections()[0]['value'],True)
    def test_drift_revokes(self):
        m=refresh(known(),[2,0]);self.assertEqual(m.monitor()['status'],'REVOKED');self.assertEqual(m.breaches,1);self.assertIsNone(m.projections()[0]['value'])
    def test_latched_return(self):
        m=refresh(sampled([2,0]),[0,0]);self.assertEqual(m.monitor()['sample_class'],'WITHIN');self.assertEqual(m.monitor()['status'],'REVOKED')
    def test_repeat_drift_count(self):self.assertEqual(refresh(sampled([2,0]),[3,0]).breaches,1)
    def test_recalibration_new_version_no_old_known(self):
        m=sampled([2,0]);old=m.calibration_ref();cost=m.spent;m=m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=m.recalibration_proposal()))[0]
        self.assertEqual(m.calibration['revision'],2);self.assertNotEqual(m.calibration_ref(),old);self.assertEqual(m.spent,cost);self.assertEqual(m.monitor()['status'],'UNKNOWN');self.assertEqual(m.projections()[0]['epistemic'],'Unknown')
    def test_new_reference_requires_new_monitor(self):
        m=sampled([2,0]);m=m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=m.recalibration_proposal()))[0];m=dispatch(m);m=m.reduce(answer(m,[2,0]))[0];self.assertEqual(m.monitor()['status'],'VALID')
    def test_two_version_breaches(self):
        m=sampled([2,0]);m=m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=m.recalibration_proposal()))[0];m=dispatch(m);m=m.reduce(answer(m,[4,0]))[0];self.assertEqual(m.breaches,2)
    def test_expiry(self):
        m=known();m=m.reduce(dict(kind='tick',at=801))[0];self.assertEqual(m.monitor()['status'],'UNKNOWN');self.assertIsNone(m.projections()[0]['value'])
    def test_frame_revokes_freshness(self):
        m=known();m=m.reduce(dict(kind='frame',at=m.mapper.at))[0];self.assertEqual(m.monitor()['status'],'UNKNOWN')
    def test_old_frame_result(self):
        m=dispatch(machine());e=answer(m);m=m.reduce(dict(kind='frame',at=m.mapper.at))[0];m=m.reduce(e)[0];self.assertEqual(m.last['status'],'SUPERSEDED');self.assertIsNone(m.calibration_sample)
    def test_timeout(self):
        m=dispatch(machine());e=answer(m);e['at']=m.pending['deadline']+1;m=m.reduce(e)[0];self.assertEqual(m.last['status'],'TIMEOUT')
    def test_error_retains_cost(self):
        m=dispatch(machine());cost=m.spent;e=answer(m);e.update(outcome='ERROR',offset=None,sampled_at=None,sample_ref=None);m=m.reduce(e)[0];self.assertEqual(m.spent,cost);self.assertEqual(m.monitor()['status'],'UNKNOWN')
    def test_exposure_and_boolean_type(self):
        m=dispatch(machine());e=answer(m);e['exposure']='0'*64
        with self.assertRaises(ValueError):m.reduce(e)
        e=answer(m,[True,0])
        with self.assertRaises(ValueError):m.reduce(e)
    def test_unknown_cannot_reanchor(self):self.assertIsNone(machine().recalibration_proposal())
    def test_reanchor_expired_proposal(self):
        m=sampled();p=m.recalibration_proposal()
        with self.assertRaises(ValueError):m.reduce(dict(kind='recalibrate',at=801,proposal=p))
    def test_reanchor_pending_rejected(self):
        m=sampled();p=m.recalibration_proposal();m=dispatch(m)
        with self.assertRaises(ValueError):m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=p))
    def test_no_silent_tolerance_increase(self):
        m=sampled([2,0]);p=m.recalibration_proposal();p['limit']=2
        with self.assertRaises(ValueError):m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=p))
    def test_uncalibrated_result_rejected(self):
        m=dispatch(sampled());e=answer(m)
        with self.assertRaises(ValueError):m.reduce(e['event'])
        e['calibration_ref']='0'*64
        with self.assertRaises(ValueError):m.reduce(e)
    def test_budget_hold(self):
        m=known();m.spent=m.config['budget'];m=m.reduce(dict(kind='tick',at=801))[0];self.assertIsNone(m.plan());self.assertEqual(m.projections()[0]['gate'],'HOLD')
    def test_pending_across_segment(self):
        with tempfile.TemporaryDirectory() as t:
            c=config('/tmp/w','/tmp/f','/tmp/o','/tmp/c');c['segment_records']=16;j=SegmentJournal(Path(t)/'j',c)
            for _ in range(15):j.commit(dict(kind='tick',at=0))
            j.commit(dict(kind='dispatch',at=0,proposal=j.machine.plan()));j.commit(answer(j.machine));s=j.machine.snapshot();j.close();self.assertEqual(replay(Path(t)/'j')['machine'].snapshot(),s)
    def test_resume_preserves_latch_and_counter(self):
        m=sampled([2,0]);m=m.reduce(dict(kind='stop',at=m.mapper.at,reason='user'))[0];m=m.reduce(dict(kind='resume',at=900))[0];self.assertTrue(m.revoked);self.assertEqual(m.breaches,1);self.assertEqual(m.spent,1)
if __name__=='__main__':unittest.main()
