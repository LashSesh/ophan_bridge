const fs=require('fs'),vm=require('vm'),assert=require('assert');let checks=0,network=0;
const els={},ctx={document:{getElementById:id=>els[id]||(els[id]={events:{},addEventListener(k,v){this.events[k]=v;}})},fetch(){network++;throw Error('offline')},AbortController,setTimeout,clearTimeout};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('source_demo.html','utf8').match(/<script>([\s\S]*?)<\/script>/)[1],ctx);
const t=ctx.sourceTest,check=f=>{f();checks++;};
check(()=>assert.equal(t.CASES.length,6));check(()=>assert.equal(network,0));
for(const id of ['pause','frame','recalibrate','stop'])check(()=>assert(els[id].disabled));
const V=t.CASES[0].views;let i=V.findIndex(s=>s.geometry_answer.epistemic==='Ambiguous');t.render(i);
check(()=>assert(i>=0));check(()=>assert(els.proof.textContent.includes('"false"')&&els.proof.textContent.includes('"true"')));
i=V.findIndex(s=>s.geometry_answer.epistemic==='Known');t.render(i);check(()=>assert.equal(els.answer.textContent,'Known · Ja'));
check(()=>assert(els.question.textContent.includes('room_grid')));check(()=>assert(els.sources.innerHTML.includes('PASS / PASS')));check(()=>assert(els.proof.textContent.includes('clock_registration')));check(()=>assert(els.proof.textContent.includes('spatial_registration')));
i=V.findIndex(s=>s.source_epochs.left===1);t.render(i);check(()=>assert.equal(els.answer.textContent,'Unknown'));check(()=>assert(els.sources.innerHTML.includes('Kein aktueller Beleg')));
i=V.findIndex(s=>s.source_epochs.left===1&&s.geometry_answer.epistemic==='Known');t.render(i);check(()=>assert.equal(els.answer.textContent,'Known · Ja'));check(()=>assert(els.question.textContent.includes('room_grid')));
i=V.findIndex(s=>s.source_epochs.right===1&&s.geometry_answer.epistemic==='Known');t.render(i);check(()=>assert.equal(els.answer.textContent,'Known · Ja'));check(()=>assert(els.scene.innerHTML.includes('<circle')));
for(let c=1;c<t.CASES.length;c++){t.chooseCase(c);check(()=>assert(t.CASES[c].views.every(s=>s.geometry_answer.epistemic!=='Known')));}
t.chooseCase(3);i=t.CASES[3].views.findIndex(s=>s.temporal_status==='temporal_scope_gap');t.render(i);check(()=>assert(els.timegate.textContent.includes('temporal_scope_gap')));
for(let c=0;c<t.CASES.length;c++){t.chooseCase(c);for(let j=0;j<t.CASES[c].views.length;j++)t.render(j);}checks++;
check(()=>assert.equal(network,0));check(()=>assert.equal(t.esc('<img>'),'&lt;img&gt;'));
t.chooseCase(0);t.accept(V.at(-1));check(()=>assert.throws(()=>t.accept(V[0]),/stale_sequence/));check(()=>assert.throws(()=>t.accept({...V.at(-1),state_digest:'bad'}),/conflicting_sequence/));
(async()=>{await t.poll();check(()=>assert(els.answer.textContent.includes('Verbindung unterbrochen')));console.log(JSON.stringify({checks,passed:true,visual_browser_review:false}));})().catch(e=>{console.error(e);process.exitCode=1;});
