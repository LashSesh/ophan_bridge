"""Twelve actual owner/compiler/worker/HTTP runs with uncertain local anchors."""
import argparse,json,shutil,tempfile,threading,time,urllib.request
from pathlib import Path
from epoch3d_fixtures import CASES,dataset
from epoch3d_runtime import initialize,export,html,EpochService
from epoch3d_segments import SegmentJournal,replay
from live import server_for
from adapters import MonotonicClock

def phase(j,lines,barrier=False):
    s=EpochService(j,MonotonicClock(j.machine.mapper.at),lines=lines);server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));th=threading.Thread(target=server.serve_forever,daemon=True);th.start();url=f'http://127.0.0.1:{server.server_port}';checks=0;end=time.monotonic()+40
    try:
        while time.monotonic()<end:
            assert s.cycle();st=s.current
            with urllib.request.urlopen(url+'/api/updates') as response:got=json.load(response)['snapshot']
            assert got['state_digest']==st['state_digest'] and got['registration_history']==st['registration_history'] and got['registered3d']==st['registered3d'];checks+=1
            if barrier and st['carrier']['cursor']==6 and st['registration_certificate'] is None:break
            if not barrier and st['carrier']['cursor']==len(lines) and st['geometry_answer']['epistemic']=='Known':break
            time.sleep(.02)
        else:raise AssertionError('phase timeout')
        s.stop_reason='user'
        while s.cycle():time.sleep(.02)
    finally:server.shutdown();server.server_close();th.join();s.close()
    return checks
def run_case(d,name):
    raw,m,p=dataset(name);j,lines=initialize(d,raw,m,p);checks=phase(j,lines,barrier=name=='resume_barrier');barrier_preserved=False
    if name=='resume_barrier':
        old=replay(d/'journal')['machine'];assert old.carrier_state.cursor==6 and old.pending_admission() is not None;j=SegmentJournal.reopen(d/'journal');j.commit(dict(kind='resume',at=old.mapper.at+6000));assert j.machine.registered3d==old.registered3d and j.machine.registration_history==old.registration_history;barrier_preserved=True;checks+=phase(j,lines)
    old=replay(d/'journal')['machine'];j=SegmentJournal.reopen(d/'journal');j.commit(dict(kind='resume',at=old.mapper.at+6000));assert j.machine.registered3d==old.registered3d and j.machine.registration_certificate==old.registration_certificate and j.machine.registration_history==old.registration_history and j.machine.registration_work==old.registration_work and j.machine.spent==old.spent;j.commit(dict(kind='stop',at=j.machine.mapper.at,reason='user'));j.close()
    report=export(d/'journal',d/'replay.html');report.update(case=name,http_checks=checks,compiler_subprocesses=len(old.registration_history),source_records=len(lines),synthetic_input=True,resume_preserved=True,barrier_preserved=barrier_preserved);(d/'report.json').write_text(json.dumps(report,indent=2));return report
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='epoch3d_evidence_run');a=p.parse_args();target=Path(a.out).resolve();assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps018_',dir='/tmp') as tmp:
        work=Path(tmp)/'proof';work.mkdir()
        for name in CASES:
            r=run_case(work/name,name);print(json.dumps({name:{k:r[k] for k in ['transitions','spent','requests','http_checks','compiler_subprocesses','barrier_preserved']}}),flush=True)
        from verify_epoch3d import verify
        report=verify(work,export_views=False);(work/'integration_report.json').write_text(json.dumps(report,indent=2));shutil.copytree(work,target)
if __name__=='__main__':main()
