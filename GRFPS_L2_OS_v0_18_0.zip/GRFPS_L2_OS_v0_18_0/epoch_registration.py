"""Prebound historical calibration schedule; each epoch requires its own admission."""
import copy
from pathlib import Path
from grfps_l2 import fields,require,canon,loads
from carrier_contract import CarrierState,read_line,sha
from uncertain3d import validate,seal,ns
PROFILE='grfps-epoch-registration/0.18.0';MAX_BYTES=262144
def validate_plan(plan,carrier,lines=None):
    fields(plan,'profile entries');require(plan['profile']==PROFILE and type(plan['entries']) is list and 1<=len(plan['entries'])<=4,'epoch_plan');seen=set();last_cursor=-1;last_epoch=-1;target=None;query=None
    for i,entry in enumerate(plan['entries']):
        fields(entry,'after_record activation_ref bundle');n=entry['after_record'];b=entry['bundle'];validate(b,carrier);epoch=b['source']['epoch']
        require(type(n) is int and 0<=n<carrier['record_count'] and n>last_cursor and epoch>last_epoch,'epoch_order')
        require((i!=0 or (epoch==0 and n==0)) and (epoch!=0 or n==0),'initial_epoch')
        expected=None if n==0 else carrier['record_refs'][n-1];require(entry['activation_ref']==expected,'activation_binding')
        if target is None:target=b['target'];query=b['query']
        require(b['target']==target and b['query']==query,'common_target_query')
        for group in ['spatial_fit','spatial_check','clock_fit','clock_check']:
            for row in b[group]:
                for key in ['id','evidence_ref']:require(row[key] not in seen,'epoch_evidence_reuse');seen.add(row[key])
        last_cursor=n;last_epoch=epoch
    if lines is not None:
        require(len(lines)==carrier['record_count'] and all(sha(x.encode('ascii'))==h for x,h in zip(lines,carrier['record_refs'])),'plan_trace_binding');scopes={0:(0,carrier['manifest']['reference_space'],None)};cs=CarrierState(carrier['manifest'])
        for i,line in enumerate(lines):
            row=read_line(line);cs.apply(line)
            if row.get('kind')=='reference_reset':scopes[i+1]=(cs.epoch,cs.reference,int(row['monotonic_time_ns']))
        for entry in plan['entries']:
            n=entry['after_record'];b=entry['bundle'];require(n in scopes,'activation_requires_reset');epoch,reference,t=scopes[n];require((b['source']['epoch'],b['source']['reference_space'])==(epoch,reference),'activation_scope')
            if t is not None:require(min(ns(x['local_ns']) for x in b['clock_fit'])>=t and ns(b['valid_source_ns'][0])>=t,'epoch_clock_evidence')
    require(len(canon(plan))<=MAX_BYTES,'plan_size');return plan
def load_plan(path,carrier,lines=None):
    with Path(path).open('rb') as f:raw=f.read(MAX_BYTES+1)
    require(0<len(raw)<=MAX_BYTES,'plan_size');return validate_plan(loads(raw),carrier,lines)

