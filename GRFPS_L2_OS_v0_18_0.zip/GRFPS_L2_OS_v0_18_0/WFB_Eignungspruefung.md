# WFB: Eignung für das 2nd-Layer Synthetic Perception OS

Bewertete Quelle: *The Wavefield-Rupture Framework*, Second Edition, 24. August 2026, bereitgestellte PDF mit 27 Seiten. Bezugssystem: GRFPS-Referenz 0.8.0; umgesetzte Fortsetzung: 0.9.0. Die Seitenangaben unten meinen PDF-Seiten, nicht die interne Buchpaginierung.

## Entscheidung

**Das Dokument ist als Quelle einzelner Strukturideen geeignet. Die Übernahme als geschlossenes, bereits bewiesenes Fundament ist nicht gerechtfertigt.** Der größte unmittelbare Nutzen liegt im expliziten Referenzvergleich, in der Trennung verschiedener Detektorausgaben und in der Prüfung von Informationsverlust durch Projektionen. Diese Elemente passen zur Kalibrierungs- und Driftphase der bestehenden Runtime.

Die Auswertung umfasst alle 27 PDF-Seiten. Die mathematisch entscheidenden Formulierungen wurden zusätzlich im gerenderten Dokument geprüft. Die Datei enthält keine eingebetteten Experimentskripte. Die erwähnten `experiments_*.py`, Eingabedaten und vollständigen Protokolle wurden nicht mitgeliefert. Zahlen in E11–E111 sind deshalb zunächst Ergebnisbehauptungen der Quelle. Unsere eigenen Prüfungen ersetzen diese Versuche nicht.

## Verwertung nach Funktion

| WFB-Baustein | Fundstelle | Nutzen im OS | Umsetzung bzw. Grenze |
|---|---|---|---|
| Verankerter Vergleich gegen eine Referenz | I.3–I.4, S. 6 | Gültigkeit einer Interpretation kontrollieren | Versionierte Referenz, Residuum, feste Grenze und aktueller Messbeleg |
| Getrennte Anzeige von Flag, Klasse und Zähler | I.3–I.4, S. 6; Darstellung S. 19 | Verhindert, dass ein Zähler oder eine grobe Klasse als vollständiger Gültigkeitsnachweis gilt | Widerrufsflag, aktuelle Residuumsklasse und Zahl widerrufener Versionen bleiben separate Felder |
| Bezugssystem und kanonische Differenzen | IV.1, S. 11; V.12, S. 16 | Absolute Interpretation benötigt eine gebundene Referenz | Jede Messannahme trägt die aktuelle Kalibrierungsreferenz; Referenzwechsel erzeugen neue Versionen |
| Projektionsblindheit | II.3–II.4, S. 8; V.4, S. 14 | Eine Anzeige kann entscheidende Unterschiede verlieren | Q8-Beispiel unabhängig endlich geprüft; operative Anzeige erhält Klasse, Flag, Zähler und Evidenzreferenzen |
| Vorab festgelegte Diskriminatoren und Fehlerbudget | VIII.2, S. 22 | Nachvollziehbare Abnahmekriterien | Grenzwertkontakt, Drift, Rückkehr, Versionswechsel und erneute Evidenzaufnahme als getrennte Versuchsstufen |
| Kanonische Inversion und Adjunktion | VI.6–VI.7, S. 18 | Potenziell für spätere Abstraktions- und Rekonstruktionsoperatoren | VI.6 benötigt zusätzliche Voraussetzungen; keine ungeprüfte Übernahme |
| Q8-, SU(2)- und Holonomiestrukturen | Teile I–V | Denkbarer eigener Adapter für orientierungs- oder phasensensitive Sensorik | Kein Nachweis, dass die gegenwärtige viersektorige Kartenruntime diese Zustandsräume benötigt |
| Primanker, 13 Knoten, Sternfiguren und AES-Zuordnungen | Teile V, VI, IX | Für diese Phase keine erforderliche Funktion | Keine künstliche Festlegung von Organ-, Speicher- oder Knotenzahl auf 13 |
| Gemessene Zeitreihen und Interferometrie | Teile VII–VIII | Mögliche spätere Prüfdomänen | Ohne mitgelieferte Daten und Adapterverträge kein übertragener empirischer Nachweis |

Die neue Detektorstruktur ist eine **technische Adaption**. Ihr Ereigniszähler ist weder spektraler Fluss noch Windungszahl. Ihre Klasse ist keine Holonomieklasse. Eine Gleichung wie `Klasse = (-1)^Zähler` wird nicht eingeführt.

## Konkrete mathematische Grenzen

### 1. Normalteiler von Q8

II.3 behauptet, jeder Normalteiler enthalte −1. Der triviale Normalteiler `{+1}` ist ein unmittelbares Gegenbeispiel. Die passende eingeschränkte Aussage lautet: Jeder **nichttriviale** Normalteiler von Q8 enthält −1.

`wfb_audit.py` enumeriert die sechs Normalteiler exakt, bestätigt Zentrum und Kommutatoruntergruppe `{+1,−1}` sowie fünf Konjugationsklassen. Damit bleibt der nützliche Projektionsbefund erhalten: Im Quotienten nach dem Zentrum werden +1 und −1 identifiziert. Ein Fehler in der universellen Formulierung hebt diesen konkreten Befund nicht auf.

### 2. Die Voraussetzungen von VI.6 reichen nicht aus

Setze `S1 = S2 = {0,1}`, `F = G = Identität`, `Can1(x) = 0` und `Can2(x) = x`. Beide Kanonisierungen sind idempotent. Die im Dokument genannten Bedingungen gelten:

```
Can1 ◦ G ◦ F = Can1
Can2 ◦ F ◦ G = Can2
```

Trotzdem hat der erste kanonische Quotient ein Element und der zweite zwei. Sie können nicht bijektiv sein. Es fehlt die Verträglichkeit von F und G mit den jeweiligen Äquivalenzrelationen: Gleiche kanonische Klasse muss unter F beziehungsweise G wieder gleiche Zielklasse ergeben. Erst mit wohldefinierten induzierten Abbildungen liefern die Kompositionsbedingungen deren gegenseitige Invertierbarkeit.

Das ist ein exakt nachgerechnetes Gegenbeispiel zur angegebenen Allgemeinheit. Ein erfolgreiches einzelnes Beispiel E92 kann es nicht ausschließen. Die stärkere Adjunktionsstruktur in VI.7 wird dadurch nicht automatisch widerlegt; sie hat zusätzliche Voraussetzungen.

### 3. Nicht jede Nullstelle erzeugt einen Vorzeichen- oder π-Phasensprung

VI.1(a), S. 17, formuliert die Aussage für reelles m allgemein. Bei `m(t)=t²` liegt eine Nullstelle ohne Vorzeichenwechsel vor. Links und rechts davon bleibt der reelle Faktor positiv. Eine Phasensprungregel benötigt unter anderem eine passende Art der Nullstelle und einen festgelegten Signal- und Phasenvertrag.

Diese Grenze ist direkt für Drift relevant: Ein Berühren einer Grenze, ihr Überschreiten und das Ausbleiben eines Messbelegs dürfen nicht als derselbe Vorgang gezählt werden. Der neue Monitor setzt `Residuum ≤ Grenze` auf WITHIN und `Residuum > Grenze` auf DRIFT. Er behauptet keine lückenlose Beobachtung des kontinuierlichen Übergangs.

### 4. Operatorbereiche dürfen nicht stillschweigend verallgemeinert werden

Die Defizienzfälle in I.5 benötigen einen konkreten Operator und dessen Definitionsbereich. Schon eindimensionale Schrödingeroperatoren auf einem endlichen Intervall können Defizienzindizes `(2,2)` und durch U(2) parametrisierte Erweiterungen besitzen. Die drei genannten Paare sind deshalb keine allgemeine Klassifikation aller symmetrischen Operatoren. Das Standardkriterium verlangt die Gleichheit der beiden Defizienzindizes. Siehe Higuchi und Serrano Blanco, Theorem 2 und Abschnitt III: [Self-Adjoint extensions of the one-dimensional Schrödinger operator with symmetric potential](https://arxiv.org/abs/2005.10774).

Diese Operatorentheorie wird nicht in eine Behauptung über den Softwarezustandsraum umgedeutet.

## Umgesetzte Phase 0.9.0

Die Runtime besitzt nun einen zusätzlichen Modellsensor für einen zweikomponentigen Referenzoffset. Er verwendet denselben einzelnen asynchronen Workerplatz und dasselbe Messbudget wie Fenster-, Feld- und Orientierungsmessungen.

Eine Kalibrierungsversion enthält Referenz, Aktivierungszeit, Einheit und eine feste Fehlergrenze. Ein aktueller Messbeleg wird über die Maximumsnorm mit dieser Referenz verglichen. Im Standard gilt Grenze 1 Modellgitterschritt, Refresh 200 ms und TTL 800 ms. Zeitangaben sind Annahmeverträge, keine garantierten Pollinglatenzen.

- Ohne gültigen Kalibrierungsbeleg bleibt die Kartenantwort Unknown/HOLD.
- Ein frischer Beleg innerhalb der Grenze erlaubt die übrigen vorhandenen Gateprüfungen.
- Der erste akzeptierte Grenzverstoß widerruft diese Kalibrierungsversion. Wiederholte Verstöße zählen sie nicht mehrfach.
- Eine Rückkehr in den bisherigen Bereich hebt den Widerruf nicht auf.
- Die explizite Bedienaktion „Aktuellen Referenzwert übernehmen“ wartet einen offenen Auftrag ab und bindet einen frischen Referenzmesswert an Version n+1.
- Der Fehlergrenzwert wird dabei nicht erhöht. Die Aktion setzt einen neuen Frame und fordert neue Kalibrierungs- und Wahrnehmungsbelege.
- Globale Kosten und die Zahl widerrufener Versionen bleiben bei Segmentwechsel und Neustart erhalten.

**Eine neue Referenz ist keine nachgewiesene Reparatur des Sensors.** Der neue Modellsensor stellt diagnostische Offsetwerte bereit; er schätzt keine physische Geometrie, korrigiert keine Kameramatrix und authentifiziert keine Messhardware. Eine reale Neukalibrierung benötigt weiterhin einen eigenen empirischen Nachweis. Die Benutzeraktion bestätigt einen neuen Modellbezug und ist im Journal explizit sichtbar.

## Nachgewiesener Ablauf

Der vollständige Versuch verwendet echte Worker-Prozesse, atomar geänderte eigene Fixturedateien und die lokale HTTP-Steuerung. Er durchläuft:

| Stufe | Sequenz | Version | Ergebnis |
|---|---:|---:|---|
| Frische Wahrnehmung | 36 | 1 | Known |
| Kontakt mit der zulässigen Grenze | 40 | 1 | VALID, weiterhin Known |
| Überschreitung | 47 | 1 | REVOKED, Unknown |
| Rückkehr zur alten Referenz | 55 | 1 | Messklasse WITHIN, Widerruf bleibt |
| Erneute Überschreitung | 63 | 1 | Weiterhin genau eine widerrufene Version |
| Explizite Referenzübernahme | 64 | 2 | UNKNOWN, neue Belege erforderlich |
| Erneute Wahrnehmung | 93 | 2 | Known |
| Zweiter Versionsverstoß | 96 | 2 | REVOKED, Zähler 2 |

Gesamt: **100 Transitionen, 7 Segmente, 20 Messaufträge, 24 Kosteneinheiten und 49 HTTP-Projektionsvergleiche**. Das abschließende Replay einschließlich Wiederaufnahme erhält Kosten und beide Widerrufe. Jede erfolgreiche Sensorantwort wird außerdem gegen ihre archivierte Quelldatei nachgerechnet. Eine neue Ausführung kann andere Tickzahlen und Zeitstempel erzeugen.

Die Releaseprüfung enthält **230 Python-Tests und 94 JavaScript-Prüfungen**. Darin enthalten sind 23 neue Kalibrierungstests, vier unabhängige WFB-Prüfungen und zwölf neue Ansichtsprüfungen. Eine visuelle Browserprüfung ist nicht enthalten.

## Ergebnis der Verwertung

WFB liefert eine brauchbare Richtung für die **Kontrolle von Referenzabhängigkeit und Beobachtungsgrenzen**. Version 0.9.0 setzt daraus einen konkret prüfbaren Betriebsschritt um. Die breiteren physikalischen, topologischen und kryptografischen Zuordnungen bleiben außerhalb des übernommenen Vertrags. Für eine weitere WFB-Prüfung wären als nächster Quellenschritt die tatsächlichen Experimentskripte samt Daten und Parametern erforderlich; für die OS-Entwicklung bleibt der nächste Schritt ein verifizierbarer Kalibrierungsadapter mit eigenem Nachweisprotokoll.
