import unittest
from wfb_audit import report
class WFBAuditTests(unittest.TestCase):
    def test_retained_projection_loss(self):self.assertTrue(report()['q8']['projection_identifies_opposite_centre'])
    def test_normal_subgroup_counterexample(self):self.assertFalse(report()['counterexamples']['II_3']['contains_minus_one'])
    def test_canonical_counterexample(self):self.assertEqual(report()['counterexamples']['VI_6']['quotient_sizes'],[1,2])
    def test_zero_touch_counterexample(self):self.assertFalse(report()['counterexamples']['VI_1_a']['sign_reversal'])
if __name__=='__main__':unittest.main()
