# GRFPS — 2nd-Layer Synthetic Perception OS, 0.14.0

Diese Phase verbindet **getrennte Quellen, eigene Aufnahmeuhren und bewegte Sensorfenster** mit einem festen Bezugsraum. Jeder Messauftrag bindet Quellenkennung und Generation. Jede Aufnahme erhält einen eigenen Zeitnachweis und einen räumlichen Anschluss mit separaten Kontrollpunkten. Die Geometrie wird erst nach diesen Prüfungen gemeinsam ausgewertet.

`GRFPS_Second_Layer_Demo.html` enthält sechs auswählbare Prozessreplays. Der Monolith `GRFPS_2nd_Layer_OS.pdf` und seine eigenständig kompilierbare TEX-Datei integrieren die neuen Verträge, Beweise, Grenzen und Versuchsergebnisse. Die WFB-Eignungsprüfung bleibt unverändert erhalten.

## Ausführen

Python 3.10 oder neuer, Standardbibliothek; Node.js für die zusätzliche Prüfung der Browserlogik. Im entpackten Projektordner:

```sh
python source_runtime.py --out mein_quellenraum --open
python source_runtime.py --out mein_quellenraum --resume --open
python run_source_demo.py --out neue_quellenversuche
python validate.py
```

Der neue Ausgabeordner muss zunächst fehlen. Standardlaufzeit: 15 Sekunden; `--duration` passt sie an. Die Laufzeit startet einen lokalen Loopbackserver. `replay.html` enthält danach die historische Sitzung. Resume prüft den vollständigen Verlauf und erhält Generationen, Kalibrierung und Verbrauch; neue Aufnahmen sind nötig.

`left.json` und `right.json` sind getrennte synthetische Quellen. Jede enthält grobe und feine Objektmessungen, aktuelle Referenzpunkte und die Parameter ihrer simulierten Aufnahmeuhr. `calibration.json` enthält die vorhandenen Kalibrierungsserien. Die erste bestandene Kalibrierung wird automatisch übernommen; spätere Übernahmen brauchen den vorgesehenen Steuerbefehl.

## Zeit und Raum

| Bestandteil | Vertrag dieser Phase |
|---|---|
| Quellen | Bis vier Pflichtquellen; jeweils eigene Kennung, Datei und Generation 0 bis 128 |
| Referenz | Fester Modellraum `room_grid`; Referenzpunkte sind im Profil festgelegt |
| Lokale Uhr | Ganzzahlige Millisekunden, Rate exakt 1, Versatz zwischen −10000 und +10000 |
| Uhrfit | Lokaler Zeitstempel und vertrauenswürdiges Hostintervall, Breite höchstens 8 ms |
| Uhrkontrolle | Spätere getrennte Messung muss **alle** Fitkandidaten bestätigen; keine Kandidatenreduktion |
| Aufnahmezeit | Gesamtes auf die Laufzeituhr abgebildete Intervall muss zwischen Auftrag und Worker-Abschluss liegen |
| Ablauf | Frühester möglicher Aufnahmezeitpunkt plus TTL; Gleichheit gilt als abgelaufen |
| Zeitlicher Anschluss | Größtes oberes minus kleinstes unteres Aufnahmeende höchstens `max_skew` |
| Raumfit | Drei nicht kollineare Referenzpunkte; vollständige Prüfung aller vier Vierteldrehungen |
| Raumkontrolle | Zwei weitere Referenzpunkte; Objektpunkte werden dafür nicht benutzt |
| Kalibrierung | Ein geprüfter räumlicher Anschluss für **jede** erhaltene Kalibrierung |
| Objektgeometrie | Zentren in [−16,16]², Radius 0 oder 1; bis acht aktive Landmarken |
| Referenzmessungen | Exakte Ganzzahlen in [−64,64]²; Anschlussverschiebungen in [−128,128]² |
| Standardzeiten | Fenster-TTL 5000 ms, Refresh 2000 ms, Retry 200 ms, `max_skew` 1000 ms |
| Verbrauch | Messkosten: grob 2, fein 3, Kalibrierung 1; Budget 128. Suchbudget 65536, pro Auftrag 4096 |

Für den Uhrfit `(local=800, host=[99,101])` bleiben die drei Versätze `[699,700,701]` erhalten. Bei lokaler Aufnahmezeit 820 entsteht das Intervall `[119,121]`. Bei TTL 100 ist die Aufnahme ab Laufzeit 219 ungültig. Eine Kontrolle, die nur zwei dieser drei Versätze bestätigt, erlaubt keine Freigabe.

Die Raumfitpunkte sind R0=(0,0), R1=(6,0), R2=(0,6); die getrennten Kontrollen H0=(4,3), H1=(−3,4). Die aktuellen Rohkoordinaten stammen aus der Quelle. Jeder Anschluss wird nach jeder beibehaltenen Kalibrierung neu geprüft. Ein um 180 Grad gedrehtes Fenster mit passender Neuaufnahme kann deshalb dieselbe Antwort im festen Raum tragen. Das erste Fenster definiert dessen Achse nicht mehr.

Der gemeinsame Solver schneidet die registrierten Boxen jeder Landmarke. Ohne weitere Kopplungen sind nicht leere ganzzahlige Boxdurchschnitte notwendig und hinreichend für eine gemeinsame Geometrie. Known benötigt vollständige Bearbeitung, Unterstützung jeder Kalibrierung und denselben Wahrheitswert in allen zulässigen Geometrien. Beide möglichen Antworten ergeben Ambiguous; vollständige Zeugen bleiben sichtbar.

## Quellenwechsel und offene Aufträge

Ein beobachteter Neustart, Uhrenwechsel oder eine bekannte Fensterbewegung kann über `POST /api/control` gemeldet werden:

```json
{"kind":"source_reset","window":"left","previous":0,"epoch":1}
```

Der Adapter muss dazu passende Rohdaten der neuen Generation liefern. Im Versuch wird die Quelldatei atomar ersetzt und der Lebenszykluswechsel über HTTP gemeldet. Der Server verändert keine Sensorinhalte. Der Owner prüft die bisherige Generation beim Commit erneut. HTTP 202 bestätigt nur die Einreihung. Doppelte oder veraltete Meldungen ergeben `STALE_SOURCE_EPOCH`, ohne die Laufzeit anzuhalten.

| Ereignis | Wirkung |
|---|---|
| Neue Quellengeneration | Betroffenes Fenster wird sofort entzogen; gemeinsame Antwort Unknown |
| Ergebnis eines alten Quellenauftrags | `SUPERSEDED` |
| Alte Solvereingaben nach Quellenwechsel | `STALE_INPUTS`; nachgewiesene Suchkosten bleiben verbraucht |
| Fehlerhafte Uhrkontrolle | `CLOCK_CHECK_REJECTED`; kein aktueller Fensterbeleg |
| Fehlerhafte Raumkontrolle | `SPATIAL_REJECTED`; kein aktueller Fensterbeleg |
| Zu große mögliche Zeitspreizung | `temporal_scope_gap`; älteste Aufnahme gezielt erneuern |
| Neue gültige Aufnahme | Neue Bindung; eigener Solverauftrag erforderlich |
| Vollständiger neuer Konsens | Known unter unverändertem Raumbezug |

Sucharbeit entsteht in beauftragten Prozessen. Lesen, Planen und Anzeigen starten keine versteckte Suche. Ein Suchknoten zählt hier einen Kalibrierungsstart oder eine projizierte Quelle. Bei zwei Quellen und neun Kalibrierungen sind es 27 Knoten. Registrierung, Ergebnisverifikation und Replay verbrauchen zusätzliche, nicht in diesem Zähler gemessene CPU-Arbeit. Reservierung, Abrechnung fehlerhafter Aufträge und Wiederanlauf folgen dem vorherigen Live-Vertrag.

## Tatsächlich ausgeführte Nachweise

| Versuch | Records | Segmente | Aufträge | Messkosten | Suchknoten | HTTP-Vergleiche |
|---|---:|---:|---:|---:|---:|---:|
| Fensterbewegung und neue Uhr | 138 | 9 | 29 | 33 | 162 | 66 |
| Fehlerhafte Uhrkontrolle | 38 | 3 | 6 | 8 | 0 | 20 |
| Fehlerhafte Raumkontrolle | 38 | 3 | 6 | 8 | 0 | 20 |
| Fehlender zeitlicher Anschluss | 42 | 3 | 7 | 9 | 0 | 22 |
| Widerspruch im festen Raum | 56 | 4 | 10 | 11 | 27 | 29 |
| Unvollständige Suche | 67 | 5 | 13 | 15 | 2 | 33 |
| Gesamt | 379 | 27 | 71 | 84 | 191 | 190 |

Der Hauptversuch erreicht Ambiguous, misst autonom feiner und erhält Known. Dann wird das linke Fenster um 180 Grad gedreht und um (3,−2) versetzt. Die Generation entzieht den alten Nachweis; neu registrierte Daten erlauben wieder Known mit derselben Antwort. Anschließend wechselt die rechte Uhr von Versatz −400 auf +900. Auch hier wird die Antwort zuerst entzogen und erst nach neuen Zeit-, Raum- und Geometriebelegen freigegeben. Ein doppelter Reset wird kontrolliert abgelehnt.

Alle 18 Fensterresultate, 44 Kalibrierungsresultate und neun Solverresultate werden semantisch wiedergegeben und gegen archivierte Quellen geprüft. Neun konstruktive Zeugen werden zusätzlich auf Mitgliedschaft geprüft. Alle zwölf Known-Zustände gehören zum Hauptversuch; die fünf Gegenversuche geben keinen Known-Zustand aus. Jeder Verlauf wird neu geöffnet, ohne Generationen oder Verbrauch zurückzusetzen.

**392 Python-Tests und 210 JavaScript-Prüfungen bestehen**, einschließlich 33 beziehungsweise 31 neuer Prüfungen. Die Browserlogik wird in einem minimalen DOM ausgeführt; eine visuelle Prüfung in einem echten Browser ist nicht enthalten. Die PDF wird eigenständig kompiliert, vollständig gerendert und visuell geprüft. Ein zusätzlicher echter CLI-Start und CLI-Resume prüft die Bedienroute.

## Aussagegrenzen und nächste Phase

Die Quellen sind **synthetisch**. Ihre Dateien und Adapterprozesse sind getrennt, ihre lokalen Uhren werden jedoch aus der Laufzeituhr mit unterschiedlichen Versätzen erzeugt. Die Tests belegen weder unabhängige Hardwareuhren noch physische Sensorgenauigkeit. Hostintervalle sind vertrauenswürdige Adapterbelege. Hashes sichern Inhaltsbindung, keine Geräteauthentizität.

Der Modellraum und seine korrekt identifizierten, exakten, ruhenden Referenzpunkte sind Voraussetzungen. Gemeinsam falsche Referenzen können die Kontrollen gemeinsam passieren. Für gemeinsam ausgewertete Objektmessungen werden **stationäre Landmarken** vorausgesetzt. Ein kleiner Zeitabstand beweist keine Gleichzeitigkeit und kompensiert keine Objektbewegung. Eine ungemeldete externe Änderung wird erst durch neue Messdaten, ein Lebenszyklusereignis oder normalen Evidenzablauf wirksam.

Der nächste Anschluss ist ein physischer Adapter mit unveränderter Rohaufnahme, dokumentiertem Uhrursprung und nachprüfbaren Referenzmessungen. Driftende Uhrenraten, verrauschte Referenzpunkte und bewegte Objektlandmarken benötigen zusätzliche Mengenverträge; sie sind in dieser Phase noch nicht implementiert.

Neue Module: `source_registration.py`, `source_geometry.py`, `source_bank.py`, `source_worker.py`, `source_runtime.py`, `source_segments.py`, `run_source_demo.py`, `verify_sources.py`. Die vollständigen Nachweise liegen in `source_evidence_run`. `geometry_demo.html` bewahrt das vorherige Live-Profil.

---

## Erhaltenes Live-Geometrieprofil 0.13.0

# GRFPS — 2nd-Layer Synthetic Perception OS, 0.13.0

Die gemeinsame Geometrieprüfung arbeitet jetzt im **Live-Messplan**. Die vorhandene Organbank beauftragt unsichere Fensteraufnahmen und Geometriesuchen als separate Prozesse. Eine mehrdeutige Geometrie löst eine feinere Aufnahme aus. Jeder Nachweis bleibt an Auftrag, Exposure, Kalibrierung, Frame und frische Eingabebelege gebunden.

**geometry_demo.html** enthält vier auswählbare Prozessreplays. **GRFPS_2nd_Layer_OS.pdf** und die eigenständig kompilierbare TEX-Datei integrieren die neuen Verträge und Nachweise in den Monolithen.

## Start

Python 3.10+, Standardbibliothek. Im entpackten Projektordner:

```sh
python geometry_runtime.py --out mein_live_raum --open
python geometry_runtime.py --out mein_live_raum --resume --open
python run_geometry_demo.py --out neue_liveversuche
python validate.py
```

Der neue Ausgabeordner darf noch nicht existieren. Standardlaufzeit 15 Sekunden; mit `--duration` anpassbar. Der Server bindet nur an Loopback. Nach dem Lauf steht `replay.html` im Ausgabeordner. Stoppen beendet offene Aufträge geordnet. Resume prüft alle Journalsegmente, erhält Mess- und Suchverbrauch sowie Kalibrierung und verlangt neue Belege in einem neuen Frame.

`sensor.json` bietet grobe und feine Kanäle der benannten Fenster. `calibration.json` enthält Fit und beide Prüfserien. Die erste vollständig geprüfte Kalibrierung wird automatisch übernommen. Weitere Übernahmen erfolgen mit **Geprüfte Kalibrierung übernehmen** und benötigen erneut Kontrollbelege, Fenster und Suche.

## Live-Vertrag

Profil `grfps-live-geometry-bank/0.13.0`; Sensorprofil `grfps-live-box-sensor/1`. Die vollständigen Grenzen stehen in `geometry_bank.py` und `geometry_sensor.py`.

| Größe | Standard und Grenze |
|---|---|
| Rohpunkte | Ganzzahlige Zentren in [-16,16]²; Radius null oder eins je Punkt |
| Umfang | Bis vier vorgeschriebene Fenster und acht gleichzeitig aktive Landmarken |
| Fensterlagen | Vierteldrehungen und ganzzahlige Translationen in [-8,8]² |
| Abfrage | `x_B > x_A` im benannten Ankerfenster; alle Pflichtfenster müssen frisch sein |
| Anker | Festes erstes Fenster der sortierten vertraglichen Fensterliste; kein automatischer Wechsel |
| Fenster | TTL 5000 ms, Refresh 2000 ms, Wiederholabstand 200 ms |
| Kalibrierung | TTL 5000 ms, Refresh 400 ms, Fit und zwei separate Prüfaufnahmen |
| Aufträge | Deadline standardmäßig 3000 ms; ein asynchroner Worker gleichzeitig |
| Messkosten | Grober Kanal 2, feiner Kanal 3, Kalibrierungsaufnahme 1; gemeinsames Budget 128 |
| Sucharbeit | Pro Auftrag maximal 4096 Knoten; Gesamtbudget 65536; konfigurierbar bis 100000 bzw. 1000000 |

Ein Fenster speichert die gelieferten Rohboxen. Der Solver prüft gemeinsam alle Pflichtfenster und die gesamte Kalibrierungsmenge. Der Worker erhält keine gewünschte Antwort. Ein als fein bezeichneter Kanal garantiert keine Verbesserung; nur seine tatsächlichen Daten zählen. OCCLUDED und ERROR entziehen dem betroffenen Fenster seinen aktuellen Beleg.

Die Messkanäle der mitgelieferten Quelle sind **synthetisch**. Ihre Landmarkenidentität, Einheit und Fehlerschranke gehören zum Modellvertrag. Die Quellenhashes authentifizieren kein physisches Gerät. Der feste Bezug auf eine Fenster-ID belegt keine unveränderliche Weltorientierung bei Bewegung dieses Sensors.

## Aktiver Ablauf

1. Fehlende oder abgelaufene Pflichtfenster werden aufgenommen.
2. Neue gemeinsame Eingaben veranlassen einen Solverauftrag.
3. Ambiguous, LIMIT, GAP oder CONFLICT können die älteste geeignete grobe Aufnahme über deren feinen Kanal herausfordern.
4. Eine neue Aufnahme entzieht dem alten Solvernachweis sofort seine aktuelle Bindung.
5. Known benötigt einen neuen vollständigen Nachweis, Unterstützung jeder Kalibrierung, Antwortkonsens und einen gültigen Monitor.

Es gibt keine Geometriesuche beim Lesen eines Snapshots oder beim Berechnen des Plans. Sucharbeit entsteht ausschließlich über beauftragte Solverausführungen und deren explizite Verifikation. Der zuvor geprüfte Fehlervertrag und die vollständige Kalibrierungsmenge bleiben erhalten.

Nach einer Kalibrierungsaufnahme bekommt bei gültigem Monitor ein gewöhnlicher Auftrag eine Gelegenheit. Die Regel begrenzt Verdrängung durch Kalibrierungen. Sie garantiert weder Echtzeit noch, dass beliebig kurz gültige Fenster gleichzeitig aufgenommen werden können.

## Suchbudget und veraltete Ergebnisse

Vor Dispatch werden Knoten reserviert: `spent + reserved <= total`. Ein vollständig verifiziertes Ergebnis verbucht die tatsächlich verwendeten Knoten und gibt den ungenutzten Anteil frei. Ein ERROR- oder TIMEOUT-Record ohne verifizierbares Resultat verbraucht die volle Reservierung. Suchabbruch erzeugt Unknown. Derselbe Eingabebeleg wird nach einem Versuch nicht unmittelbar erneut berechnet.

Gezählt werden logische Suchknoten beauftragter Ausführungen. Reducer-Verifikation und Replay benötigen zusätzliche Rechenarbeit; der Zähler ist keine Messung des gesamten CPU-Verbrauchs. Ein erschöpftes Suchbudget verhindert weitere geometrische Mess- und Suchaufträge. Ein schon gültiger Nachweis behält seine normale zeitliche Gültigkeit.

| Ereignis | Wirkung auf die Antwort |
|---|---|
| Fester Anker fehlt | Unknown / `fixed_anchor_missing`; ein anderes Fenster übernimmt die Achse nicht |
| Weiteres Pflichtfenster fehlt | Unknown / `required_window_missing` |
| Neue Aufnahme, noch keine neue Suche | Unknown / `awaiting_geometry` |
| Suchbelege während Übertragung abgelaufen | Ergebnis `STALE_INPUTS`; verifizierte Suchknoten bleiben verbraucht |
| Ergebnis aus altem Frame | `SUPERSEDED`; kein aktueller Beleg |
| Deadline überschritten | `TIMEOUT`; keine Antwortfreigabe |
| Vollständiger Konsens | Known / true oder false |
| Beide Antworten zulässig | Ambiguous mit zwei konstruktiven Zeugen |
| Drift und anschließende Rückkehr | Alte Kalibrierung bleibt widerrufen; frische geprüfte Neuübernahme erforderlich |

## Ausgeführte Prozessnachweise

| Fall | Records | Segmente | Aufträge | Messkosten | Suchknoten | HTTP-Vergleiche |
|---|---:|---:|---:|---:|---:|---:|
| Autonome Verfeinerung und Drift | 171 | 11 | 36 | 42 | 2817 | 82 |
| Widersprüchlicher Kartenzyklus | 60 | 4 | 12 | 14 | 189 | 29 |
| Erschöpftes Suchbudget | 69 | 5 | 14 | 16 | 2 | 33 |
| Ablauf während Übertragung | 88 | 6 | 10 | 11 | 909 | 59 |
| Gesamt | 388 | 26 | 72 | 83 | 3917 | 203 |

Der Hauptlauf erreicht Ambiguous mit groben Daten, beauftragt autonom eine feinere Aufnahme und erreicht Known. Über HTTP werden Pause und Fortsetzung gesteuert. Anschließend fällt nur das linke Ankerfenster aus, während das rechte vorhanden bleibt. Nach Wiederaufnahme, Drift, erfolgloser Rückkehr und expliziter Kalibrierungsadoption erreicht die neue Revision Known mit frischen Belegen.

Der Ablaufgegenfall verzögert den Transport eines tatsächlich berechneten Solverresultats um 1600 ms bei einer Fenster-TTL von 1200 ms. Das Ergebnis wird als `STALE_INPUTS` behandelt. Die drei Gegenversuche erzeugen keinen Known-Zustand.

Verifiziert sind 16 erfolgreiche Fensterantworten, 46 Kalibrierungsbeobachtungen, neun Solverresultate, neun konstruktive Geometriezeugen und alle 13 Known-Zustände des Hauptlaufs. Jeder Fall wird vollständig semantisch wiedergegeben und mit erhaltenem Verbrauch neu gestartet. Die unveränderten Quellen und Prozessjournale liegen in `geometry_evidence_run`.

**359 Python-Tests und 179 JavaScript-Prüfungen bestehen**, darunter 26 beziehungsweise 25 neue Prüfungen. Eine weitere tatsächliche CLI-Ausführung mit CLI-Resume bestätigt die Bedienroute. Die JavaScript-Logik wird in einem minimalen DOM ausgeführt; eine visuelle Prüfung in einem echten Browser ist nicht enthalten. Die PDF wird getrennt gerendert und visuell geprüft.

## Oberfläche und nächste Grenze

Die Live-Ansicht trennt Antwort, gemeinsamen Geometrienachweis, Kalibrierung, Messverbrauch und reservierte Suchknoten. Pause, Framewechsel, Kalibrierungsübernahme und Stoppen werden als Befehle eingereiht; ihre Wirkung wird im nachfolgenden Zustand sichtbar. Offline-Replays deaktivieren die Steuerknöpfe. Ältere oder widersprüchliche Sequenzstände werden verworfen. Verbindungsfehler zeigen Unknown; hängende Statusabfragen werden nach 1500 ms abgebrochen.

Der nächste Ausbau betrifft unabhängig fortschreitende Messquellen, unterschiedliche Aufnahmeuhren und bewegte Referenzfenster. Dafür müssen Zeitabbildung, Quellenidentität und räumliche Registrierung eigenständig bezeugt werden. Kontinuierliche Winkel, physische Sensorgenauigkeit und statistische Fehler bleiben separate Vertragsänderungen.

Erhaltene Profile: `trace_runtime.py` und `trace_demo.html` für Offline-Import 0.12.0; `noisy_runtime.py` und `noisy_demo.html` für das vorherige Kalibrierungsprofil. Die WFB-Eignungsprüfung und ihre mathematischen Übernahmegrenzen bleiben enthalten.

---

## Erhaltenes Importprofil 0.12.0


Unsichere Fensterpunkte und aufgezeichnete Messdaten haben jetzt einen ausführbaren Vertrag. Der neue Importadapter sucht **gemeinsame Geometrien aller aktiven Fenster** und berücksichtigt dabei die vollständige Kalibrierungsmenge. Sichere Antworten entstehen nur bei vollständig geprüfter Unterstützung und Antwortkonsens.

**trace_demo.html** enthält acht auswählbare Offline-Replays. Der Monolith **GRFPS_2nd_Layer_OS.pdf** integriert Vertrag, Beweis, Bedienung, Gegenbeispiele und die erhaltenen Vorprofile. Seine TEX-Datei kompiliert eigenständig mit `pdflatex`.

## Start der neuen Phase

Python 3.10+, Standardbibliothek. Im entpackten Projektordner:

```sh
python trace_runtime.py import --trace trace_evidence_run/fixtures/joint_consensus.json --out meine_aufnahme --steps 2
python trace_runtime.py resume --out meine_aufnahme
python trace_runtime.py replay --out meine_aufnahme
python run_trace_demo.py --out neue_traceversuche
python validate.py
```

Der neue Ausgabeordner darf noch nicht existieren. `--steps` begrenzt die Quellenrecords für diesen Aufruf; ohne Option läuft der Import bis zum Ende. Die Ausgabe enthält unveränderte `source.json`, semantisch überprüfbare `session.json`, `report.json` und `replay.html`. Resume prüft Originalbytes und sämtliche Übergänge vor der Fortsetzung. Eine Sitzung hat genau einen Schreiber. Ein nach einem Absturz verbliebener `session.lock` wird nicht automatisch entfernt.

Der neue Adapter verarbeitet **Aufnahmezeit**. Eine echte Unterbrechung verschiebt den historischen Zeitpunkt nicht. Die bestehende Live-Organruntime wird weiterhin mit `python noisy_runtime.py --out mein_raum --open` gestartet. Der neue Geometriesolver ist in dieser Phase noch nicht mit ihrem Scheduler verbunden.

## Eingabevertrag

Profil `grfps-sensor-trace/1`. Ein vollständiges Beispiel steht in `trace_evidence_run/fixtures/refinement.json`; der Parser und alle Grenzen stehen in `trace_import.py`.

| Größe | Vertrag |
|---|---|
| Rohpunkte | Ganzzahlige Zentren in [-16,16]²; Radius 0 oder 1 je Punkt in der Maximumsnorm |
| Kalibrierung | Vollständige 0.11-Fitserie und zwei getrennte Prüfdatensätze mit strikt steigenden Aufnahmezeiten; Zertifikat wird neu berechnet |
| Fensterlagen | Vierteldrehungen und Translationen in [-8,8]² relativ zum benannten Rootfenster |
| Umfang | Maximal 4 Fenster, 8 Landmarken, 64 Ereignisse, 262144 Dateibytes |
| Zeit | Monotone `at`-Werte bis 3600000 ms; `sampled_at <= at`; Fenster-TTL 100 ms, Monitor-TTL 1000 ms |
| Sucharbeit | Quellengebundenes Limit von 1 bis 100000 Knoten je Snapshot, Standard 50000 |
| Verarbeitung | Fenster 2, Monitor 1 Einheit; Budget maximal 256; vorhandene Importkalibrierung kostet keine neue Aufnahme |
| Ereignisse | `window`, `monitor`, `tick`, `frame`; explizite Outcomes OK, OCCLUDED und ERROR für Fenster |

Keine stille Rundung, Einheitenumrechnung oder Toleranzanpassung. Doppelte JSON-Schlüssel, unbekannte Felder und Versionen, ungültige Zeiten sowie nicht bestandene Kalibrierungsprüfungen verwerfen den Import vor dem Anlegen der Sitzung. Teilweise Dateien werden nicht repariert.

Ein Fensterereignis enthält beispielsweise:

```json
{"kind":"window","at":10,"sampled_at":10,"frame":0,"window":"left","outcome":"OK","points":{"A":{"center":[0,0],"radius":1},"B":{"center":[6,0],"radius":1}}}
```

Alle Punktfehler sind innerhalb ihrer Boxen frei kombinierbar, während **derselbe Kalibrierungskandidat für alle Punkte** gilt. Landmarken-IDs werden als korrekte Zuordnung vorausgesetzt. Das Modell fordert keine Nichtkoinzidenz verschiedener Landmarken und enthält keine zusätzlichen Abstandsgleichungen. OCCLUDED/ERROR entfernen den bisherigen Fensterbeleg; ausgelassene Landmarken werden nicht aus dem Vorgänger ergänzt. Ältere oder abgelaufene Samples ersetzen keine aktuellen. Bei gleicher Samplezeit entscheidet die Quellenreihenfolge.

## Gemeinsame Geometrie und Antworten

Der Solver enumeriert für jede Kalibrierung alle erlaubten Fensterlagen. Ein Anker begrenzt die zu prüfenden Translationen; jeder Kandidat wird anschließend gegen **sämtliche gemeinsamen Landmarken** geprüft. Nichtleere Schnitte der transformierten Boxen ergeben gemeinsame ganzzahlige Landmarkenpositionen. Der Monolith enthält den Vollständigkeitsbeweis für diesen endlichen Vertrag.

Die Frage lautet `x_B > x_A` **im kalibrierten Bezug des benannten Rootfensters**. Dieses ist das lexikographisch erste aktive Fenster. Ein Rootwechsel wird ausgewiesen und behauptet keine unveränderte globale Weltachse.

| Ergebnis | Bedeutung |
|---|---|
| Known / true oder false | Vollständige Suche; jede Kalibrierung unterstützt; alle Punktlagen stimmen überein |
| Ambiguous | Wahre und falsche Antwort haben jeweils einen konstruktiven gemeinsamen Zeugen |
| GAP / Unknown | Fehlende Landmarke, getrennte Fenster oder Kalibrierung ohne Unterstützung |
| CONFLICT / Unknown | Vollständig geprüfter gemeinsamer Lösungsraum ist leer |
| LIMIT / Unknown | Suchlimit erreicht; vorhandene Treffer reichen nicht zum Freigeben |
| Ungültiger Monitor / Unknown | Veraltete Kontrolle, teilweise unpassende Kalibrierungsmenge oder dauerhafter Widerruf |

Jede Kalibrierung bleibt erhalten; fehlende Unterstützung darf sie nicht stillschweigend entfernen. Die marginalen Punktgrenzen sind Projektionen der Lösungsmenge, keine frei kombinierbaren gemeinsamen Boxen und keine Konfidenzintervalle. Die Demo zeichnet einen geprüften Zeugen und zeigt beide Antwortzeugen sowie Abdeckung und Hashes im Nachweis.

## Ausgeführte Nachweise

| Fall | Records | Kosten | Ergebnis |
|---|---:|---:|---|
| Gemeinsame Geometrie und Drift | 12 | 17 | Verdeckung, Ablauf, Framewechsel, Drift und dauerhafte Sperre bei Rückkehr |
| Engere neue Messung | 2 | 4 | Ambiguous → Known |
| Kartenzyklus | 3 | 6 | Drei kompatible Paare; keine gemeinsame Geometrie |
| Suchlimit | 1 | 2 | Treffer vorhanden, Antwort bleibt Unknown |
| Getrennte Fenster | 2 | 4 | GAP |
| Vier Kalibrierungsrichtungen | 1 | 2 | 14 Kandidaten, beide Antworten möglich |
| Negativer Konsens | 1 | 2 | Known / false |
| Messbudget | 1 | 0 | Eintrag ohne Messwirkung |

**18 echte CLI-Aufrufe, 23 Übergänge und 17 nachgeprüfte Geometriezeugen.** Der Hauptfall wird in drei Prozessen fortgesetzt. Die Prozessdaten und unveränderten Quellen sind unter `trace_evidence_run` enthalten. Der Zyklusgegenfall enthält AB=2, BC=2, AC=6 entlang lokaler Achsen: Jedes Paar hat 36 zulässige Lagentupel über neun Kalibrierungen, die Gesamtsuche endet nach 189 Knoten ohne Lösung.

37 neue Python-Tests prüfen außerdem eine unabhängige kleine Gitteroracle, einen konsistenten Dreifensterzyklus, fehlende Kalibrierungsunterstützung, manipulierte Zeugen und semantisch neu gehashte Falschrecords. Zusammen mit den Vorprofilen bestehen **333 Python-Tests und 154 JavaScript-Prüfungen**. JavaScript wird in einem minimalen DOM ausgeführt; eine visuelle Prüfung in einem echten Browser ist nicht enthalten. Die PDF wird separat kompiliert und visuell geprüft.

## Aussagegrenzen und nächster Anschluss

Alle mitgelieferten Quellen sind **synthetisch**. Das Herkunftsfeld erlaubt auch `recorded`; diese Angabe authentifiziert kein Gerät. Originalbytehash, Referenzserie und Recordhashes sichern die Zuordnung der gelieferten Daten, beweisen aber keine physische Aufnahmequalität. Eine Übertragung auf reale Sensoren benötigt separat begründete Landmarkenidentitäten, Einheiten und Fehlerschranken.

Die nächste Phase ist der Live-Anschluss desselben Geometrievertrags: beauftragte Sensorantworten, Exposurebindung, gemeinsames Rechenbudget, aktiver Messplan bei Mehrdeutigkeit und eine dauerhafte registrierte Abfragereferenz. Kontinuierliche Winkel und statistische Fehler bleiben ein eigener Vertragswechsel. Die WFB-Eignungsprüfung und ihre mathematischen Übernahmegrenzen bleiben enthalten.

---

## Erhaltenes Live-Profil 0.11.0


Kalibrierungsmessungen dürfen jetzt begrenzt rauschen. Die Fitdaten liefern eine vollständige Menge zulässiger Transformationen. Zwei anschließend getrennt aufgenommene Prüfserien müssen die unveränderte Menge bestätigen. Die Kartenantwort berücksichtigt alle verbleibenden Möglichkeiten.

## Start

Python 3.10+, Standardbibliothek. Im entpackten Projektordner:

```sh
python noisy_runtime.py --out mein_raum --open
python noisy_runtime.py --out mein_raum --resume --open
python run_noisy_demo.py --out neue_rauschversuche
python validate.py
```

Der neue Ordner darf noch nicht existieren. Standardlaufzeit 15 Sekunden, mit `--duration` anpassbar. Der Server läuft lokal auf Loopback. Das erste vollständig geprüfte Zertifikat wird automatisch übernommen. Spätere Änderungen erfolgen mit **Geprüfte Kalibrierung übernehmen**. Eine neue Version setzt einen neuen Frame und verlangt frische Wahrnehmungsbelege.

`calibration.json` enthält die vorab festgelegten Aufnahmen `fit`, `check0`, `check1`. Jede Stufe wird separat beauftragt und durch einen eigenen Prozess gelesen. Quellenänderungen während einer Kampagne verletzen die Serienbindung und führen zu einem neuen Fit. Die Versuchsskripte ersetzen Quelldateien atomisch. `world.json` definiert den synthetischen Rohsensor. Sein Fensterfehler bleibt in diesem Profil exakt null.

**noisy_demo.html** zeigt den Hauptversuch aus Profil 0.11 offline. Die weiteren Replays liegen unter `noisy_evidence_run/consensus` und `noisy_evidence_run/scope_gap`. `certified_demo.html` erhält den Versuch aus Version 0.10.0.

## Fehlervertrag und Kandidaten

- Ganzzahlige Koordinaten in [-64,64], Vierteldrehungen und ganzzahlige Translationen in [-128,128].
- Mindestens 3 Fitreferenzen, die nicht sämtlich kollinear sind; mindestens 2 getrennte Prüfobjekte, jeweils in zwei nachfolgenden Aufnahmen. Höchstens 16 Punkte je Stufe.
- Feste Maximumsnormgrenzen: Fit 1, Prüfung und Monitor 3. Keine während der Übernahme veränderbare Toleranz.
- Der erste Fitpunkt begrenzt jede Drehung auf neun mögliche Translationen. Alle vier Drehungen werden vollständig enumeriert; sämtliche Fitbedingungen werden geprüft. Höchstens 36 Kandidaten.
- Die Prüfdaten dürfen keine Kandidaten auswählen oder entfernen. Schon ein unpassender Kandidat verwirft den gesamten Vorschlag; beide Prüfaufnahmen müssen die ganze Menge bestätigen.
- Zertifikat: Protokoll, Quellserie, Fitreferenz, beide Prüfreferenzen, vollständige Kandidaten und Residuen. Adoption bindet zusätzlich die zeitlich angenommenen Samples und die vorige Version.
- Default: Refresh 200 ms, Sample-TTL 2000 ms; jede Kalibrierungsaufnahme kostet 1 Einheit. Die ganze Kampagne muss frisch bleiben.

## Wirkung auf Wahrnehmung und Messplan

Die Atlaszeichnung verwendet einen zulässigen Vertreter als Darstellungsbezug. Diese Auswahl behauptet keine eindeutige Lage. Der Snapshot enthält die volle Transformationsmenge und lokale Punktgrenzen. Für relative Landmarkenvektoren heben sich gemeinsame Translationen auf; jede verbliebene Drehung wird weiter geprüft.

| Beobachtung | Operative Antwort |
|---|---|
| Alle Zuordnungen vollständig, alle Feldantworten aktuell und gleich | Known, auch bei mehrdeutiger Kalibrierung |
| Vollständige Zuordnungen liefern verschiedene bekannte Antworten | Ambiguous |
| Für eine mögliche Drehung fehlt eine räumliche Zuordnung | Unknown / calibration_scope_gap |
| Neue Kontrollmessung passt nur zu einem Teil des aktiven Zertifikats | Unknown / UNCERTAIN; Kandidaten bleiben unverändert |
| Neue Kontrollmessung passt zu keinem Kandidaten | Dauerhafter Widerruf / DRIFT |
| Kein frischer Kontrollbeleg | Unknown / UNKNOWN |

Der erste vollständige Widerruf erhöht den Zähler. Eine spätere Rückkehr repariert die gesperrte Version nicht. Ein Orientierungsbeleg darf das Kalibrierungszertifikat nicht stillschweigend verkleinern.

Der Prozessversuch deckte zwei Probleme im Messplan auf. Die Runtime gewährt jetzt nach einer Kalibrierungsaufnahme bei gültigem Monitor einer bezahlbaren normalen Messung Vorrang. Außerdem bleibt ein abgeschlossener PASS-Vorschlag bei aktuell ungültiger Kalibrierung bis zur Adoption oder zum Ablauf verfügbar. Diese Zustände sind Teil des Journals und Replay. Die Regeln garantieren keine Echtzeitlatenz.

## Nachweise

| Prozessfall | Transitionen | Segmente | Messaufträge | Kosten | HTTP-Vergleiche |
|---|---:|---:|---:|---:|---:|
| Verfeinerung und Drift | 147 | 10 | 30 | 32 | 72 |
| Konsens bei 14 Kandidaten | 76 | 5 | 16 | 17 | 36 |
| Fehlende räumliche Abdeckung | 51 | 4 | 10 | 11 | 24 |

Im Hauptlauf werden fehlerhafte Prüfdaten abgelehnt. Vier mögliche Drehungen erzeugen unterschiedliche Antworten. Eine neue Kalibrierung mit weiter verteilten Fitreferenzen reduziert die Menge von 14 auf 9 Kandidaten mit einer einzigen Drehung. Trotz verbleibender Translationsunsicherheit wird die relative Kartenfrage Known. Drift und Rückkehr prüfen anschließend die dauerhafte Sperre.

Jeder erfolgreiche Sample und jede Koordinatenableitung wird aus archivierten Quellen nachgerechnet. Alle Known-Zustände der drei Läufe stimmen mit der synthetischen Referenzantwort überein. Das sind neun geprüfte Zustände aus diesen konkreten Läufen, keine allgemeine Fehlerrate. Jeder Lauf wird beendet und wieder aufgenommen; Zertifikat, Kosten und Widerruf bleiben erhalten, alte Belege laufen ab.

**296 Python-Tests und 129 JavaScript-Prüfungen bestanden**, einschließlich 36 neuer Vertragstests, 20 neuer Projektionsprüfungen und der Vorprofile. Zusätzlich wurde die neue CLI gestartet und wieder aufgenommen. Die JavaScript-Prüfung verwendet eine minimale DOM-Umgebung; eine visuelle Browserprüfung wurde nicht durchgeführt. Neue Läufe dürfen andere Zeitstempel und Tickzahlen erzeugen.

Die bedingte Abdeckung gilt nur, wenn die wahre Transformation und die Fitfehler den deklarierten Vertrag erfüllen. Die zwei Prüfaufnahmen stammen aus einer synthetischen Quelle; getrennte Prozesse beweisen keine statistische Unabhängigkeit. Die dargestellten Punktgrenzen sind achsenweise Spannweiten, keine unabhängigen Freiheitsgrade. Kontinuierliche Winkel, Rauschen einzelner Fensterpunkte und physische Sensorvalidierung bleiben offen.

Neue Module: `noisy_certificate.py`, `noisy_bridge.py`, `noisy_segments.py`, `noisy_runtime.py`, `noisy_chart_worker.py`, `noisy_window_worker.py`, `noisy_viewer.html`, `verify_noisy.py`.

Nächste Phase: versionierter Vertrag für externe Aufnahmespuren und unsichere Fenstergeometrie. Der vorhandene exakte Atlas darf dabei keine beliebig gewählte Lage als eindeutige Messung behandeln. WFB-Prüfung, Gegenbeispiele und Quellenkopie bleiben im Paket erhalten.

---

## Historischer Stand 0.10.0

# GRFPS — 2nd-Layer Synthetic Perception OS, 0.10.0

Diese Phase ergänzt eine tatsächlich angewendete Kalibrierung: Fitpunkte bestimmen eine endliche Transformation; getrennte Prüfpunkte müssen sie bestätigen. Erst ein bestandenes Zertifikat darf die Runtime übernehmen. Der Reducer korrigiert damit die Rohkoordinaten der Fenster, bevor sie in den Atlas eingehen.

## Start

Python 3.10+, Standardbibliothek. Im entpackten Projektordner:

```sh
python certified_runtime.py --out mein_raum --open
python certified_runtime.py --out mein_raum --resume --open
python run_certified_demo.py --out neuer_kalibrierlauf
python validate.py
```

Der neue Ausgabeordner darf noch nicht existieren. Standardlaufzeit 15 Sekunden, mit `--duration` anpassbar. Der Server läuft lokal auf Loopback. Das erste bestandene Zertifikat wird automatisch übernommen. Spätere Änderungen erfolgen mit **Geprüfte Kalibrierung übernehmen**. Der Befehl wartet einen offenen Auftrag ab, verlangt einen frischen PASS-Kandidaten und erzeugt eine neue Version mit neuem Frame. Danach sind neue Messungen erforderlich.

`calibration.json` enthält die Korrespondenzen mit ihren Fit-/Prüfrollen. `world.json` enthält die synthetische Welt und deren `sensor_transform`; der Rohsensor erzeugt daraus verzerrte Koordinaten. Die Runtime liest die Korrektur nicht aus diesem Wert, sondern bestimmt sie aus dem Chart. Änderungen der Quelldateien erfolgen im Versuch per atomischem Dateiaustausch. `journal` enthält die vollständige Historie; `replay.html` wird beim Ende exportiert.

**GRFPS_Second_Layer_Demo.html** zeigt den aufgezeichneten Kalibrierungsversuch vollständig offline. Die Ansicht zeigt aktive Version, Transformation, Widerruf und Kandidatenbericht getrennt. `calibrated_demo.html` erhält den Driftversuch der Version 0.9.0.

## Fester Kalibrierungsvertrag

- Zwei ganzzahlige Koordinaten in [-64,64]; 5 bis 16 Korrespondenzen.
- Mindestens 3 nicht kollineare Fitpunkte und 2 getrennte Prüfpunkte. IDs, Rohpositionen und Referenzpositionen dürfen nicht doppelt auftreten.
- Transformation `T(u) = R_q u + t`: vier Vierteldrehungen, ganzzahlige Translation in [-128,128] je Achse.
- Der nach ID erste Fitpunkt legt für jede Drehung die Translation fest. Alle Fitpunkte müssen exakt passen; genau ein Kandidat muss verbleiben.
- Prüfpunkte bestätigen oder verwerfen diesen Kandidaten. Sie verändern weder Parameter noch Kandidatenauswahl. Beide Fehlergrenzen sind fest 0.
- Zertifikat: Verfahren, Protokoll, Charthash, Fit-/Prüf-IDs, Transformation und Einzelresiduen. Die Adoption bindet zusätzlich Sample, Zeit, Frame und vorige Version.
- Die Rohpatches bleiben im Journal. Die korrigierte Sample-Referenz bindet Rohquelle, Rohpatch, Zertifikat und Versionsreferenz.
- Neue normale Messaufträge benötigen gültige Kalibrierung. Der Monitor prüft die aktive Transformation an allen Punkten des neuen Charts.
- Frischer Nullfehler: WITHIN. Positiver Fehler: DRIFT. Ohne frischen Nachweis: UNKNOWN. Default Refresh 200 ms, TTL 800 ms; Chartmessung kostet 1 Einheit.
- Ein DRIFT widerruft die Version dauerhaft. Ein späteres WITHIN repariert sie nicht. Ein neuer PASS-Kandidat kann eine andere Transformation belegen, hebt die Sperre aber erst durch explizite Adoption auf.
- Segmentwechsel und Wiederanlauf erhalten Kosten, Zertifikat und Widerrufszähler. Der Replay prüft die gesamte Historie.

## Nachweis und Reichweite

Der aufgezeichnete Lauf enthält **130 Transitionen, 9 Segmente, 25 Messaufträge, 29 Kosteneinheiten und 66 HTTP-Projektionsvergleiche**. Er zeigt: Fit abgelehnt → Prüfpunkt abgelehnt → zertifizierte Korrektur/Known → fehlerhafter Prüfpunkt/Widerruf → Übernahme abgelehnt → Rückkehr ohne Reparatur → zweite geprüfte Transformation → neue Belege/Known. Der Neustart erhält Revision 2, das Zertifikat und 29 Kosten; alte Belege sind abgelaufen.

Die Korrekturen sind `[1,3,-2]` und `[2,1,0]`, geschrieben als `[Vierteldrehung, x, y]`. Für die erste wird der Rohvektor A→B `[0,-2]` zu `[2,0]`. Jeder Rohpatch wird aus seiner archivierten Quelle nachgerechnet; die korrigierten Punkte werden außerdem gegen die unverzerrte Modellgeometrie geprüft. Jede Chartantwort wird erneut ausgewertet. Die abgelehnte HTTP-Übernahme wird auch über den Statusendpunkt geprüft.

**260 Python-Tests und 109 JavaScript-Prüfungen bestanden**, einschließlich Vorprofilen, 30 neuen Vertragstests und 15 neuen Projektionsprüfungen. Zusätzlich werden reale CLI-Prozesse gestartet und wieder aufgenommen. JavaScript-Prüfungen verwenden eine minimale DOM-Umgebung; eine visuelle Browserprüfung wurde nicht durchgeführt. Zeitstempel und Tickzahlen neuer Läufe können abweichen. Die Versuchszahlen sind kein Leistungsbenchmark.

Das Zertifikat beweist die angegebenen endlichen Korrespondenzen. Die Roh- und Referenzdaten sind synthetisch. Die zurückgehaltenen Prüfpunkte sind beim Fit unbenutzt, aber keine statistisch unabhängige Stichprobe. Starrheit der Verzerrung, korrekte Landmarken-IDs und vertrauenswürdige Referenzen sind Modellannahmen. Die Domänengrenze beweist keine Abdeckung zwischen den Prüfpunkten. Hashes authentifizieren keine Hardware.

Neue Module: `calibration_certificate.py`, `certified_bridge.py`, `certified_segments.py`, `certified_runtime.py`, `certified_chart_worker.py`, `certified_window_worker.py`, `certified_viewer.html`, `verify_certified.py`.

Nächste Phase: eigener Vertrag für rauschende Messungen, wiederholte Prüfaufnahmen und Unsicherheitsgebiete der Transformation. Die Nullgrenze wird dafür nicht stillschweigend gelockert.

Die WFB-Prüfung bleibt in `WFB_Eignungspruefung.md`; die Quellenkopie und die bisherigen Gegenbeispiele bleiben Bestandteil des Pakets. Diese Phase beansprucht keine zusätzliche WFB-Theoremübernahme.

---

## Historischer Stand 0.9.0

# GRFPS — 2nd-Layer Synthetic Perception OS, 0.9.0

Versionierte Modellreferenz und kontrollierter Drift: Eine frische Offsetmessung erlaubt die bisherigen Kartenprüfungen. Eine Grenzverletzung widerruft die aktuelle Version dauerhaft. Die Rückkehr eines Messwerts repariert den Widerruf nicht. Eine explizite neue Referenz verlangt neue Belege.

## Start

Python 3.10+, Standardbibliothek. Im entpackten Projektordner:

```sh
python calibrated_runtime.py --out mein_raum --open
python calibrated_runtime.py --out mein_raum --resume --open
python run_calibrated_demo.py --out neuer_driftlauf
python validate.py
```

Der neue Ordner darf noch nicht existieren. Standardlaufzeit 15 Sekunden, anpassbar mit `--duration`. Der lokale Server bietet Messsteuerung und **Aktuellen Referenzwert übernehmen**. Die Aktion wartet einen laufenden Auftrag ab, fordert einen frischen Referenzsample und erzeugt eine neue Version. Die Fehlergrenze bleibt unverändert. Keine neue Referenz wird allein durch Drift automatisch übernommen.

**GRFPS_Second_Layer_Demo.html** zeigt den aufgezeichneten Driftversuch. `calibration.json` im neuen Lauf enthält den diagnostischen Modelloffset. `journal` hält alle Segmente; `replay.html` wird beim Ende exportiert. `uncertain_demo.html` und die älteren Profile bleiben erhalten.

## WFB-Verwertung

Die vollständige Prüfung steht in **WFB_Eignungspruefung.md**. Verwertet wurden der verankerte Vergleich, getrennte Detektorausgaben und die Kontrolle von Projektionsverlust. `wfb_audit.py` bestätigt das endliche Q8-Projektionsbeispiel und prüft drei Gegenbeispiele zur angegebenen Allgemeinheit einzelner WFB-Sätze. Es reproduziert nicht die fehlenden Original-Experimentskripte. Die bereitgestellte PDF liegt unverändert unter `sources`.

Der Monitor realisiert keine Quantenholonomie und keinen spektralen Fluss. Er besteht aus Widerrufsflag, aktueller Residuumsklasse und der Zahl widerrufener Kalibrierungsversionen. Diese drei Größen dürfen nicht zusammengelegt werden.

## Kalibrierungsvertrag

- Offsetvektor: zwei ganze Zahlen von -32 bis 32, Einheit Modellgitterschritt.
- Default: Referenz [0,0], Fehlergrenze 1, Maximumsnorm, Refresh 200 ms, TTL 800 ms.
- Neue normale Messaufträge benötigen gültige Kalibrierung; ein laufender Auftrag wird nicht präemptiert.
- Sample innerhalb oder auf der Grenze: WITHIN. Oberhalb: DRIFT. Ohne frischen Beleg: UNKNOWN.
- Der erste akzeptierte DRIFT widerruft die Version. Wiederholte Grenzverletzungen derselben Version erhöhen den Zähler nicht erneut.
- Neue Referenz nur als explizites `recalibrate` mit frischem Sample, voriger Referenz und neuer Revision. Maximal 128 Versionen.
- Referenzübernahme setzt einen neuen Frame und entzieht alte operative Belege. Die historischen Records behalten ihre ursprünglichen Referenzen.
- Kosten und Widerrufe bleiben bei Segmentwechsel und Neustart erhalten. Replay prüft weiterhin die gesamte Historie.

Eine Referenzübernahme ist ein **Modellbezugwechsel**, keine nachgewiesene Sensorreparatur. Das neue Organ ist ein synthetischer diagnostischer Sensor. Es korrigiert keine Kameramatrix und authentifiziert keine Hardware. Die nächste Phase benötigt eine echte Kalibrierungsprozedur mit eigenen Prüfdaten.

## Nachweis

100 Transitionen, 7 Segmente, 20 Messaufträge, 24 Kosteneinheiten, 49 HTTP-Projektionsvergleiche. Geprüfte Folge: Known → Grenzkontakt → Widerruf → Rückkehr ohne Reparatur → neue Version → neue Belege/Known → zweiter Widerruf. Wiederaufnahme bewahrt 24 verbrauchte Einheiten und beide Widerrufe.

Jede erfolgreiche Sensorantwort wird aus ihrer archivierten Fixture nachgerechnet. **230 Python-Tests und 94 JavaScript-Prüfungen bestanden**, einschließlich der Vorprofile und einer separaten CLI-Wiederaufnahme. Keine visuelle Browserprüfung. Neue Läufe dürfen andere Zeitstempel und Tickzahlen erzeugen.

Neue Module: `calibrated_bridge.py`, `calibrated_segments.py`, `calibrated_runtime.py`, `calibration_worker.py`, `calibrated_viewer.html`, `verify_calibrated.py`, `wfb_audit.py`.

Nächste Phase: Kalibrierungsnachweis mit mehreren Referenzpunkten, geschätzter Transformation und getrennten Falsifikationspunkten.

---

## Erhaltene Hypothesenbank 0.8.0


Mehrere räumliche Zuordnungen bleiben explizite Kandidaten. Eine Kartenantwort wird freigegeben, wenn alle zulässigen Kandidaten gültige und übereinstimmende Feldantworten besitzen. Unterschiedliche Antworten bleiben Ambiguous; fehlende Belege oder eine leere Kandidatenmenge bleiben Unknown.

## Start

Python 3.10+, Standardbibliothek. Im entpackten Projektordner:

```sh
python uncertain_runtime.py --out mein_raum --open
python uncertain_runtime.py --out mein_raum --resume --open
python validate.py
python run_uncertain_demo.py --out neuer_hypothesenlauf
```

Neue Ausgabeordner dürfen noch nicht existieren. Standardlaufzeit 15 Sekunden, anpassbar über `--duration`. Der Server ist lokal. `replay.html` wird am Ende exportiert; `journal` enthält die verketteten Segmente. **uncertain_demo.html** ist das Offline-Replay der Ostauflösung. Die übrigen Fälle liegen unter `uncertain_evidence_run`.

## Neuer Vertrag

- Bis zu vier verschiedene Sektorkandidaten je Registrierung, maximal 16 Registrierungen.
- Ganzzahliger Fehlerbetrag für den gerichteten Landmarken-Differenzvektor, L-infinity-Norm in Modellgitterschritten. Keine geschätzte Positionskovarianz.
- Default: Reichweite 2, Fehlerbetrag 2, deklarierte Kandidaten Ost und Nord. Der Kandidatenraum ist ausdrücklich vorgegeben; er ist nicht zwangsläufig vollständig für die Außenwelt.
- `registration_status` beschreibt die Eindeutigkeit der Zuordnung. `epistemic` beschreibt die Antwort. Eine mehrdeutige Zuordnung kann Known true oder Known false tragen.
- `ADMITTED` gilt im Profil 0.8 erst bei vollständigem Antwortkonsens. Die abweichende Gatebedeutung von 0.7 bleibt in dessen eigenem Profil erhalten.
- Widersprüchliche gültige Antworten lösen einen gezielten `registration_probe` aus, sofern Budget und Wiederholungsfrist es erlauben. Kosten werden bei Auftrag verbraucht, auch bei Fehlern.
- Der Probe liest eine separate synthetische Orientierungsdatei. Seine Antwort ist an Auftrag, Geometriestützung, Frame und Zeit gebunden. Quelle und Toleranz sind Modellvorgaben; keine empirische Kalibrierung oder Authentifizierung.
- Neue Patchfassungen, Ablauf und Framewechsel entziehen alte Einschränkungen. Eine leere Schnittmenge bedeutet Gegenbeleg, niemals Known durch leere Allquantifikation.
- Pro Registrierung bleibt die letzte akzeptierte Probeantwort resident. Alle früheren Antworten stehen im vollständigen Journal; sie sind kein neuer Typ im Patch-/Boolean-Archiv.

## Nachweise

| Fall | Übergänge | Aufträge | Kosten | Probes | HTTP-Vergleiche |
|---|---:|---:|---:|---:|---:|
| Ost → Known true | 28 | 6 | 8 | 1 | 14 |
| Nord → Known false | 26 | 6 | 8 | 1 | 12 |
| Konsens bei mehrdeutiger Lage | 22 | 5 | 6 | 0 | 10 |
| Gegenbeleg außerhalb der Kandidaten | 29 | 6 | 8 | 1 | 15 |

Alle Fälle nutzen den normalen asynchronen Service und echte Worker. Die 51 HTTP-Antworten entsprechen dem Zustandsbesitzer. Jede erfolgreiche Messung wird gegen ihre archivierte Quelldatei nachgerechnet. Zeitstempel und Tickzahlen neuer Läufe können abweichen. **203 Python-Tests und 82 JavaScript-Prüfungen** einschließlich der erhaltenen Profile. Eine visuelle Browserprüfung ist nicht enthalten.

Die Segmentgrenzen bewahren globale Kosten, IDs, offene Aufträge und vollständige Checkpoints. Recovery prüft weiterhin die gesamte Historie. Keine allgemeine Tailreparatur, Mehrschreiberkoordination oder konstante Startzeit. Die Auswahlheuristik garantiert keinen optimalen Informationsgewinn und keine allgemeine Fairness.

Neue Module: `uncertain_bridge.py`, `uncertain_segments.py`, `uncertain_runtime.py`, `orientation_worker.py`, `uncertain_viewer.html`, `verify_uncertain.py`.

Nächste Phase: versionierte Kalibrierungsevidenz und kontrollierter Drift mit nachgewiesenem Gateentzug. Externe reale Sensorik benötigt einen eigenen empirischen Adaptervertrag.

---

## Erhaltenes registriertes Profil 0.7.0


Feldbeobachtungen können jetzt über einen expliziten Registrierungswitness für eine Landmarkenstrecke relevant werden. Ein gültiger Strahlbeleg erzeugt ein eigenes Prädikat über freie Sicht; er wird nicht als Graphkante ausgegeben. Gegenbelege, Ablauf und Framewechsel sperren die Zuordnung.

## Start

Python 3.10+, keine Zusatzpakete. Im entpackten Ordner:

~~~sh
python registered_runtime.py --out mein_raum --open
python registered_runtime.py --out mein_raum --resume --open
python validate.py
python run_registered_demo.py --out neuer_registrierungslauf
~~~

Neue Ausgabeordner dürfen noch nicht existieren. Die Runtime erzeugt eigene synthetische Weltdateien; die Sitzung läuft standardmäßig 15 Sekunden. `--duration` verändert die Laufzeit. `replay.html` wird beim Ende exportiert, die Segmente liegen unter `journal`.

**registered_demo.html** ist der mitgelieferte Offline-Replay. Die bisherige Bankdemo bleibt als `bank_demo.html` verfügbar.

## Registrierungsvertrag

- Vier Feldrichtungen, im Standard zwei Zellen Reichweite und zwei Gittereinheiten zwischen A und B.
- Der feste Worker prüft Feldtiefe und Sektorzahl. Nicht passende Reichweite erzeugt ERROR.
- Fenster-ID, tatsächliche Patchherkunft, gerichteter Vektor, Scopehash und Frame müssen passen.
- Gemeinsamer Ursprung und Gittereinheit sind Voraussetzungen des synthetischen Modellvertrags. Sie werden nicht empirisch geschätzt oder authentisiert.
- ADMITTED bezeichnet eine gültige Zuordnung. HOLD sperrt die Verwendung der Feldantwort für die Kartenfrage.
- Known false bleibt eine bekannte negative Strahlaussage. Geometrische Gegenbelege sperren dagegen die Zuordnung selbst.

## Segmentfortsetzung

Jeder Segmentheader enthält einen vollständigen materialisierten Checkpoint und den Vorgängerhead. Das Replay berechnet die gesamte Historie neu und vergleicht auch den Checkpoint bytegenau. Ein neu gehashter falscher Checkpoint wird zurückgewiesen.

Rollover setzt nur lokale Verwaltungszähler zurück. Globale Sequenz, Kosten, Mess-IDs, Frame, offene Aufträge, Archivkopf und Evidenz bleiben erhalten. Standard: 32 Records × 128 Segmente = maximal 4096 Records. Die Session bleibt endlich. Ein vollständiger letzter Header ohne ersten Record ist fortsetzbar; allgemeine Tailreparatur und Mehrschreiberkoordination fehlen weiterhin.

Die gespeicherten Checkpoints überspringen noch keine Historie. Der Wiederanlauf ist vollständig verifiziert, jedoch nicht unabhängig von der Historienlänge schnell.

## Nachweise

- Live: 124 Übergänge, acht Segmente, 27 Aufträge, 36 Kosteneinheiten und 57 tatsächliche HTTP-Projektionsvergleiche.
- Zustände: registriert wahr → registriert falsch → HOLD bei geometrischem Gegenbeleg → Scopefehler → neue Framebindung und erneute Freigabe → Pause.
- Fortsetzung: 2131 Übergänge in 67 Segmenten, einschließlich Wiederanlauf mit erhaltenen vier Kosteneinheiten und Archivkopf.
- Der Fortsetzungslauf verwendet nach drei realen Sensorprozessen 2050 explizite Millisekundentakte. Er ist kein Echtzeitbenchmark.
- **182 Python-Tests und 64 JavaScript-Prüfungen bestanden.** Erfolgreiche neue Messantworten werden gegen ihre archivierten Fixturefassungen geprüft.
- Eine visuelle Browserprüfung war nicht verfügbar; die Ansichtslogik wurde mit minimalem DOM getestet.

Neue Module: `domain_bridge.py`, `registered_segments.py`, `registered_runtime.py`, `scoped_field_worker.py`, `registered_viewer.html`. Nachweise und Fixturefassungen: `registered_evidence_run`.

Nächste Phase: mehrere zulässige Registrierungen mit expliziten Toleranzen und gezielten Unterscheidungsmessungen. Empirische Sensorkalibrierung und externe Quellen bleiben eigene Verträge.

## Erhaltenes Organbankprofil 0.6.0

Eine gemeinsame Organbank steuert jetzt Kartenfenster, freie Sicht und Beacon-Präsenz. Fenster liefern Patches; die beiden Feldorgane liefern typisierte boolesche Evidenz. Alle Aufträge teilen ein Budget. Inaktive Belege werden aus dem operativen Speicher gelöst und bleiben über das vollständig geprüfte Journal adressierbar.

## Start

Python 3.10+, keine Zusatzpakete. ZIP entpacken und im Ordner starten:

~~~sh
python bank_runtime.py --out meine_bank --open
python bank_runtime.py --out meine_bank --resume --open
python validate.py
python run_bank_demo.py --out neuer_bankversuch
~~~

Ein neuer Lauf benötigt einen neuen Ausgabeordner und erzeugt eigene synthetische Weltdateien. Standardlaufzeit: 15 Sekunden; anpassbar mit `--duration`. Nach Stop liegt `replay.html` im Laufordner. Resume erhält IDs, Kosten und Archivkopf und bindet einen neuen Frame.

**bank_demo.html** zeigt den mitgelieferten Archivversuch offline. Für eine archivierte Inhaltsreferenz:

~~~sh
python bank_journal.py meine_bank/bank.jsonl --resolve HASH64
~~~

HASH64 durch eine tatsächliche archivierte Referenz ersetzen. Die Auflösung führt ein vollständiges semantisches Replay aus; sie ist kein kurzer Inklusionsbeweis.

## Neue Verträge

| Organ | Antwort | Kosten pro Auftrag |
|---|---|---:|
| window | Patch | 2 |
| ray_clear | BooleanEvidence | 1 |
| beacon_present | BooleanEvidence, gegebenenfalls verdeckt | 1 |

Nur ein Auftrag ist gleichzeitig offen. Der älteste bezahlbare Organvorschlag erhält Vorrang. Kosten entstehen bei Annahme und werden bei Fehlern nicht erstattet. Antworten müssen zu Organ, Auftrag, Exposition und Frame passen. Eine boolesche Antwort erzeugt keine Kartenkante.

Der Feldadapter und die Feldoperatoren aus 0.3.0 werden tatsächlich wiederverwendet. Ihre komplette alte Lifecycleverwaltung wird durch den eigenen gemeinsamen Bankvertrag ersetzt; das separate alte Profil bleibt ausführbar.

Archivierung entfernt ausschließlich inaktive Patches beziehungsweise abgelaufene oder ersetzte Feldbelege. Der vollständige Inhalt wird als Ausgabe des geprüften Journalübergangs gesichert. Residentzustand, Zähler und Archivkopf werden erst nach fsync veröffentlicht. Patch- und Auftragszähler bleiben monoton.

## Reproduzierbare Ergebnisse

- Live: 54 Übergänge, 13 Aufträge, 17 Kosteneinheiten und 25 tatsächliche HTTP-Projektionsvergleiche.
- Archiv: 120 echte Sensorprozesse, davon 40 Fenster und 80 Feldabfragen, über zehn Runden.
- Höchstens vier residente Patches bei 40 integrierten Fensteraufnahmen.
- 108 archivierte Belege: 36 Patches und 72 boolesche Belege; eine alte Patchreferenz wurde exakt aufgelöst.
- Wiederaufnahme nach Runde fünf erhält 80 verbrauchte Einheiten; Endverbrauch 160.
- **160 Python-Tests und 54 JavaScript-Prüfungen bestanden.** Alle neuen Messantworten werden gegen die archivierten Fixtures neu berechnet.

Der Archivharness rückt die Uhr zwischen den Runden explizit vor. Er testet Gültigkeit und Fortsetzung, nicht Durchsatz oder reale Wartezeiten. Die JavaScript-Prüfung verwendet ein minimales DOM; eine visuelle Browserprüfung war nicht verfügbar.

## Reichweite

Standardbudget 128, höchstens 32 residente Patches und 2000 äußere Ereignisse. Innere Ereignisbudgets können früher greifen; die Runtime schließt vor der zuerst erreichten Grenze geordnet ab. Die Verdichtung reduziert den operativen Belegbestand; Journalgröße und Replayarbeit wachsen weiterhin. Der HTML-Export sammelt die Historie bewusst vollständig. Tailreparatur und Mehrschreiberkoordination sind nicht implementiert.

Die zwei Weltdateien sind synthetisch. Eine gemeinsame Steuerung begründet weder Quellenunabhängigkeit noch eine inhaltliche Verbindung zwischen Feldsektoren und Landmarken. Solche Domänenkorrespondenzen und geprüfte Segmentfortsetzung bilden die nächste Phase.

Neue Dateien: `organ_bank.py`, `bank_journal.py`, `bank_runtime.py`, `bank_viewer.html`, `run_bank_demo.py`, `test_bank.py`, `test_bank_viewer.cjs`. `bank_evidence_run` enthält beide Versuche und ihre Fixtures.

## Erhaltenes aktives Atlasprofil 0.5.0

Die Kartenaufnahme läuft jetzt autonom: Ein typisiertes Fensterorgan wählt Folgefenster anhand aktueller Randlandmarken, reserviert Budget und integriert ihre Antworten. Die lokale Live-Ansicht zeigt neue Kartenanschlüsse unmittelbar.

## Start

Python 3.10+, keine Zusatzpakete. Im entpackten Ordner:

~~~sh
python active_runtime.py --out mein_aktiver_lauf --open
python active_runtime.py --out mein_aktiver_lauf --resume --open
python validate.py
~~~

Der erste Start erzeugt eine eigene synthetische Welt und verlangt einen neuen Ausgabeordner. Standardlaufzeit: 15 Sekunden; anpassbar mit `--duration`. Die angezeigte Loopback-Adresse öffnet das Cockpit. Nach Sitzungsende liegt `replay.html` im Laufordner. Wiederaufnahme erhält den bisherigen Weltpfad und das verbrauchte Budget.

**active_demo.html** ist die mitgelieferte Offlineaufzeichnung. Sie benötigt weder Python noch einen Server. Die Kontrollen sind dort deaktiviert.

## Was diese Phase realisiert

- Evidenzgebundene Fensterwahl: ein Bootstrap, danach Abfragen über mindestens zwei bekannte Einstiegslandmarken und einen beobachteten Rand.
- Ein fester nebenläufiger Sensorprozess; Pause und TTL bleiben auch während einer offenen Messung wirksam.
- Ein einziges Aufnahmeorgan mit READY, WAITING, QUIESCENT und STOPPED. Die booleschen Organe bleiben im kompatiblen Profil 0.3.0; eine gemeinsame gemischte Organbank folgt später.
- Kosten bei Dispatch, kein Erstatten fehlgeschlagener Aufträge. Wiederanlauf erhält Kosten und IDs und invalidiert die alte Framebindung.
- Loopback-HTTP mit vollständigen Kartenprojektionen, Pause, Freigabe, Framewechsel und geordnetem Stop.
- Katalogdaten liefern bekannte Abfrage-Einstiege, keine Weltkoordinaten oder Erfolgsgarantie. Dies ist gebundenes Vorwissen, keine universelle Exploration.

## Geprüfter Lauf

129 Übergänge, zwölf Sensoraufträge, 92 tatsächliche HTTP-Projektionsvergleiche. Vier Fenster wurden automatisch erschlossen und durch drei Anschlüsse verbunden. Pause hielt den Verbrauch bei vier; erneute Aufnahme erhöhte ihn auf acht. Wiederanlauf erhielt diese acht Einheiten und beendete den Lauf beim Budget von zwölf.

**138 Python-Tests und 44 JavaScript-Prüfungen bestanden.** Darunter realer Prozesstimeout, Pause bei blockiertem Worker, Gegenbelege, veraltete Vorschläge, Schreibfehler und semantische Replaymanipulation. Eine visuelle Browserprüfung war nicht verfügbar; die JavaScript-Prüfung verwendet ein minimales DOM.

Der Betrieb bleibt endlich: Standardbudget 16, 32 archivierte Patches, 1024 äußere Ereignisse. Es gibt keine Tailreparatur und keine Mehrschreiberkoordination. Pause invalidiert konservativ den ganzen Frame. Ein Stop bewahrt bereits integrierte Evidenz bis zu deren Ablauf. Vollständige Snapshots werden alle 250 ms abgefragt; inkrementelle Kartendeltas sind noch nicht implementiert.

Die neue Implementierung liegt in `active_atlas.py`, `active_runtime.py`, `active_worker.py` und `active_viewer.html`. `active_evidence_run` enthält den aufgezeichneten Nachweis. Das PDF und die eigenständig kompilierbare LaTeX-Datei enthalten den vollständigen Systemvertrag.


## Erhaltenes Atlasprofil 0.4.0

Version 0.4.0 ergänzt bezeugte lokale Kartenstücke. Zwei Messfenster werden nur bei mindestens zwei gemeinsamen Landmarken und einer eindeutigen kompatiblen Transformation verbunden. Rücknahme, Ablauf und Framewechsel entziehen abhängigen Anschlüssen ihre Gültigkeit. Gegenbelege bleiben sichtbar.

## Kartenphase starten

**map_demo.html** direkt öffnen: 23 Zustände eines vollständig geprüften Laufs, ohne Server. Der Zeitschieber zeigt Anschlüsse, Konflikte, getrennte Komponenten und offene Randpunkte.

Für neue echte Messprozesse: Python 3.10+; keine Zusatzpakete. Im entpackten Verzeichnis:

~~~sh
python run_map_demo.py --out mein_kartenlauf
python map_runtime.py mein_kartenlauf/map.jsonl --html mein_atlas.html
python validate.py
~~~

Der Ausgabeordner darf noch nicht existieren. Der Harness verwendet eine eigene synthetische Welt, führt acht feste Sensorprozesse aus und archiviert alle tatsächlich benutzten Weltfassungen. Die Zeitachse ist logisch und kein Latenzbenchmark. Der Mapper selbst erhält lokale Punkte und Beziehungen, keine verborgenen Weltposen.

## Vertrag der Kartenstufe

- Ganzzahlige 2D-Punkte, Vierteldrehungen und Translationen; Landmarken-IDs werden vom Sensor vorgegeben.
- Auftragsgebundene Patches mit Quelle, Frame, Abtastzeit, TTL, Beziehungen und offenen Rändern.
- Mindestens zwei gemeinsame Punkte; alle gemeinsamen Punkte müssen exakt passen. Keine Spiegelung, kein numerisches Fitting.
- Gemeinsame Beziehungen dürfen nicht widersprechen. Konflikte können nicht über andere Patches umgangen werden; inkonsistente Komponenten werden konservativ getrennt.
- Fehlende Beobachtung ist kein false. Gleichzeitige gegensätzliche Aussagen ergeben Ambiguous.
- Ein offener Auftrag; Kosten bei Annahme. Standard: 16 Aufträge, 512 Ereignisse, 32 archivierte Patches; kein unbegrenzter Dauerbetrieb.
- Append-first Journal mit fsync, semantischem Vollreplay und Schreibfehlersperre. Das Atlasprofil repariert keine unvollständigen Journale und unterstützt noch keinen Wiederanlauf.

Der neue Fensteradapter ist ein getrenntes typisiertes Aufnahmeprofil. Er ist noch nicht an den Scheduler der Organruntime angeschlossen. Die Kartenansicht ist ein Offline-Replay; `start.py` startet weiterhin das kompatible Organ-Cockpit.

## Nachweis dieser Phase

22 Übergänge, acht tatsächliche Messprozesse. Zwei kompatible Fenster verbinden sich; ein drittes bleibt getrennt. Rücknahme entfernt den Anschluss, ein Gegenbeleg verhindert ihn, konsistenter Ersatz stellt ihn wieder her. TTL und Framewechsel entfernen ihn erneut. Eine Antwort aus dem alten Frame wird unterdrückt.

Nach drei Messungen: vier richtige positive Beziehungen, keine falsche positive Beziehung, keine fehlende positive Beziehung in der kleinen Fixture. Der absichtlich fehlerhafte deklarierte Kontrollgraph hat zwei zusätzliche falsche Kanten. Dies ist ein Konformitätsbeispiel, kein allgemeiner Mapping-Leistungsvergleich.

Prüfumfang: **119 Python-Tests und 36 JavaScript-Prüfungen**. Dazu vollständige Replays, archivierte Sample-Provenienz, Neuberechnung der Kontrollmetriken und die erhaltenen 36 Organversuche. JavaScript wurde mit minimalem DOM getestet; eine visuelle Browserprüfung war nicht verfügbar.

| Datei | Zweck |
|---|---|
| mapping.py | Patchvertrag, Zustandsmaschine, Overlap, Konsistenz, Atlas |
| map_worker.py | Fester lesender Fenster-Sensorprozess |
| map_runtime.py | Adapter, Journal, Replay und HTML-Export |
| run_map_demo.py | Reproduzierbarer Versuch mit eigenen Fixtures |
| mapping_run/ | Protokoll, Journal, Report, archivierte Samples |
| test_mapping.py / test_map_viewer.cjs | Neue Vertrags- und Ansichtsprüfungen |
| GRFPS_2nd_Layer_OS.tex / .pdf | Vollständiger Monolith einschließlich dieser Phase |


## Erhaltene Organruntime 0.3.0

Voraussetzung: Python 3.10 oder neuer; getestet mit Python 3.12 unter Linux. Keine zusätzlichen Python-Pakete. Für die Live-Ansicht einen aktuellen Browser mit Fetch und AbortSignal.timeout verwenden.

ZIP entpacken, Terminal im entpackten Ordner öffnen:

~~~sh
python start.py
~~~

Das Programm erstellt ein eigenes Testfeld, startet die Organruntime und öffnet das lokale Cockpit. Unter Windows kann „py“ anstelle von „python“ verwendet werden. Falls das automatische Browseröffnen scheitert, die im Terminal ausgegebene Adresse öffnen.

Die Standardlaufzeit beträgt höchstens 30 Sekunden. Danach schließt die lokale Runtime und erzeugt eine Offlineansicht im jeweiligen Unterordner von organ_runs. Ohne automatisches Browseröffnen:

~~~sh
python start.py --duration 30 --no-browser
~~~

**organ_demo.html** lässt sich direkt öffnen. Diese mitgelieferte Aufzeichnung benötigt weder Python noch einen Server. Der Zeitschieber wählt einzelne Übergänge; ein Sektorknoten zeigt Aussage, Gültigkeit, Exposition und Quellenbeleg.

## Was die zwei Organe messen

| Organ | Frage | Beobachtungsgrenze |
|---|---|---|
| Freie Sicht / ray_clear | Enthält der endliche radiale Sektor irgendein Hindernis? | Ein Hindernis belegt false; vollständig freier Sektor belegt true. |
| Signalpräsenz / beacon_present | Existiert ein Beacon irgendwo im endlichen Sektor? | Die Messung reicht bis einschließlich des ersten Hindernisses. Ein verdeckter Rest kann Unknown erzeugen. |

Die Standardwelt besitzt acht Sektoren mit je vier Zellen. Jede Zelle trägt die booleschen Merkmale solid und beacon. Ein Beacon auf einer Hinderniszelle gilt als sichtbar. Ein Beacon dahinter bleibt verborgen. Wenn der sichtbare Präfix keinen Beacon enthält und ein Rest verdeckt ist, wird keine negative Gesamtaussage erfunden.

Jede Kombination aus Organ und Sektor ist ein eigener Fact. Der Richtungswechsel ändert die abgefragte Frage; er benennt keine vorhandene Evidenz um. Der fortlaufende Schrittzähler verfolgt positive zyklische Richtungswechsel. Das ist ein diskretes Instrumentenmodell, keine physische Rotation oder 720-Grad-Spinorimplementierung.

## Lebenszyklus und Messautomat

Der Lebenszyklus entspricht der Rollenfolge aus Anhang H.2 der Ausgangsschrift:

TEMPLATE → INSTANTIATED → CALIBRATED → ACTIVE → QUIESCENT → RETIRED

Die implementierte Kalibrierung prüft den Vertrag des idealen Feldmodells: Operatorversion, Sektorzahl, Apertur, Frame und Zeiteinheit. Sie ersetzt keine empirische Sensorkalibrierung. Pause und Trackingverlust bewahren die Organidentität in QUIESCENT. Geordneter Stop erzeugt RETIRED.

Innerhalb der aktiven Bindung gibt es getrennte Messphasen:

| Übergang | Wirkung |
|---|---|
| READY → EXPOSING | Gewählten Sektor und Expositionswitness binden. |
| EXPOSING → WAITING | Request ausstellen und Kosten genau einmal verbrauchen. |
| WAITING → INTEGRATING | Passende Antwort aufnehmen; noch keine neue operative Evidenz. |
| INTEGRATING → COOLDOWN | Verwertbares oder überholtes Ergebnis verarbeiten. |
| INTEGRATING → FAULT | Fehler oder Timeout explizit verarbeiten. |
| COOLDOWN / FAULT → READY | Nach Wartefrist ausdrücklich freigeben beziehungsweise reaktivieren. |

Ein Receipt bindet Request-ID und Expositionsdigest. Ziel- und Frameepochen werden bei Integration erneut geprüft. Ein inzwischen überholtes Ergebnis bleibt als SUPERSEDED im Journal, erzeugt aber keine neue Beobachtung.

## Laufsteuerung und Budget

~~~sh
python organ_runtime.py watch --world field.json --out run_journal --budget 32 --duration 30 --open
python organ_runtime.py replay run_journal --html replay.html
python organ_runtime.py watch --out run_journal --resume --budget 64 --duration 30
~~~

Das Testfeldformat zeigt organ_evidence_run/field.json. Ein neuer Journalordner darf noch nicht existieren. Die Adresse bindet ausschließlich an 127.0.0.1; mit --port kann ein bestimmter lokaler Port gewählt werden.

**--budget gibt das absolute Gesamtlimit an.** Resume setzt den Verbrauch nicht zurück. Ein Limit unter bereits verbrauchten Kosten wird abgewiesen. Auch Timeout und SUPERSEDED behalten ihre verbrauchten Kosten. Eine bereits angenommene Messung wird durch eine zulässige Budgetänderung nicht nachträglich ungebunden.

Im Cockpit kann das Limit um 16 Einheiten erhöht werden. Eine HTTP-Bestätigung bedeutet zunächst Einreihung; erst der Commit ändert das Budget. Bei ausgeschöpftem Budget laufen Ticks und Evidenzverfall weiter. Das Messbudget enthält abstrakte Einheiten, keine gemessene CPU-Zeit oder physische Energie.

Resume prüft die komplette Segmentfolge, lässt bisherige Evidenz konservativ verfallen, gibt offene Requests auf und kalibriert die bestehenden Organidentitäten erneut. Der ursprünglich gebundene Weltpfad bleibt bestehen; Pfade oder neue Konfigurationen können nicht gleichzeitig ersetzt werden. Für einen unabhängigen neuen Lauf einen neuen Journalordner verwenden.

## Defaults und Grenzen

| Größe | Standard |
|---|---|
| Organe / Sektoren | 2 / 8 |
| Messpolitik | coverage |
| Messkosten / Anfangsbudget | 1 / 32 |
| TTL / Timeout / Cooldown | 2000 / 500 / 50 ms |
| Nominelle Zykluspause | 40 ms, zuzüglich Bearbeitungszeit |
| Aktive Messfolgen | höchstens 1 |
| Steuerqueue / Delta-Ring | 16 / 64 |
| Segmentgröße | 64 Übergänge |
| Obergrenzen | 1024 Segmente und 10000 Sessionübergänge |
| Standardlaufzeit | höchstens 30 Sekunden |

Die zuerst erreichte Laufgrenze löst einen geordneten Stop aus. Ein laufender Messprozess verzögert Steuerung bis zur Antwort oder zum Timeout. Es gibt keine harte Echtzeitgarantie. Der Worker ist zeitlich überwacht, aber nicht durch eine OS-Sandbox isoliert.

Der Dienst führt ausschließlich die zwei fest gebundenen Messoperatoren aus. HTTP kann keine Programme, Weltwerte oder Beobachtungen einschleusen. Host- und Origin-Prüfungen begrenzen fremde Browseraufrufe; der lokale Dienst ist kein authentisierter Mehrbenutzerdienst. Pro Journalordner ist genau ein Writer vorgesehen.

Pfade und Kennungen unterliegen weiterhin dem ASCII-Kanonisierungsprofil. Die Ring- und Querbeziehungen der Modellkarte sind vorgegeben. Kartographische Rekonstruktion, dynamisches Laden weiterer Organe, kontinuierliche Rotorfaser, räumliche Kalibrierung, Multiskaligkeit und XR sind weitere Stufen.

## Segmentiertes Gedächtnis

Jeder neue Segmentheader bindet globale Sequenz, Zustand, Konfiguration und Vorgängerkopf. Rotation erhält Evidenz, Organidentität und Budget. Sie erzeugt keinen semantischen Neustart.

Ein Übergang wird berechnet, geschrieben, geflusht und mit fsync bestätigt, bevor der Kandidat als aktueller Zustand veröffentlicht wird. Replay prüft Header, vollständige Records, Hashverkettung und die erneute Ausführung aller Übergänge. Ein vollständig korrupter Record wird abgewiesen.

Beim expliziten Resume wird ein unvollständiges letztes Fragment unverändert als .torn gesichert. Auch ein abgerissener Header eines neuen Segments kann so vom geprüften Vorgänger aus wiederhergestellt werden. Vorhandene Fragmentdateien werden nicht überschrieben. Normales Replay repariert keine Fragmente.

Der OrganKernel archiviert nicht zusätzlich jeden historischen inneren Renderzustand. Ein Vergleich über 120 Ereignisse bestätigt dieselben Zustände und Tracedigests wie beim vollständigen Interpreter. Beobachtungen und Traces wachsen weiterhin; Rotation erzeugt weder konstanten Speicherverbrauch noch konstante Replaykosten. Checkpoints werden durch vollständiges Replay überprüft und sind noch kein vertrauenswürdiger Schnellstart.

## Vergleich unter gleichem Budget

Vorab festgelegt: zwölf statische Testwelten, drei Politiken, je 16 Messungen zu je einer Einheit; insgesamt 36 Läufe und 576 Messungen.

| Politik | Verschiedene angefragte Fragen, Mittel von 16 | Bestimmte Fragen, Mittel von 16 | Falsche Known / Known gesamt |
|---|---:|---:|---:|
| fixed: stets Sektor 0 | 2,00 | 1,83 | 0 / 22 |
| uniform: gleichverteilte Pseudozufallswahl | 10,00 | 8,67 | 0 / 104 |
| coverage: ältester beziehungsweise unbesuchter Sektor | 16,00 | 13,67 | 0 / 164 |

Alle Läufe sind replaybar. Die Zahlen unterscheiden ausdrücklich zwischen angefragten und bestimmten Fragen: Eine verdeckte Frage bleibt Unknown.

Die feste Richtung ist eine Ablation der Expositionswahl; uniform ist eine einfache Vergleichspolitik. Systematische Abdeckung ist in dieser statischen endlichen Aufgabe erwartbar effizient. Der Versuch belegt diesen konkreten Unterschied, keine allgemeine Überlegenheit gegenüber aktiver Inferenz oder optimierten Sensorsystemen. Messfunktion und Evaluator gehören demselben idealen Modell an. Ein unabhängiger Realweltbenchmark und eine Laufzeitmessung sind nicht enthalten.

Protokoll, alle Welten, Journale und Einzelfallergebnisse liegen in benchmark_run. Einen neuen Versuch erzeugen:

~~~sh
python benchmark_organs.py --out new_benchmark
~~~

## Integrationsnachweis

Der aufgezeichnete Lauf umfasst 55 reale Messprozessaufrufe, 474 Übergänge, 15 Journalabschnitte und 354 über HTTP verglichene Projektionen. Das Umfeld dieser Prozesse bleibt synthetisch.

Er enthält Feldänderung und Wiederherstellung, eine verdeckte Beaconfrage, Pause bis zum Evidenzverfall, Wiedererfassung, Epochenwechsel während eines offenen Requests, einen absichtlich blockierten Prozess, Recovery, Budgetstopp und Budgeterweiterung.

Das Harness verändert ausschließlich sein eigenes Testfeld. Die normale Runtime liest es. Die Zeitwerte des Berichts sind Laufzeitpunkte dieser Ausführung; Mutationszeitpunkte und Publikationslatenzen wurden nicht separat als Latenzbenchmark erfasst.

~~~sh
python run_organ_demo.py --out new_integration
~~~

Beide Versuchsskripte verlangen bisher nicht vorhandene Ausgabeordner. Für aktive Journale einen lokalen Ordner verwenden, dessen Dateien kein zweiter Prozess überschreibt. Die mitgelieferten absoluten Pfade dokumentieren die ursprüngliche Bindung; Replay liest diese Weltpfade nicht erneut. Neue Ausführungen besitzen andere Messzeiten und Digests.

## Verifikation

~~~sh
python validate.py
~~~

Die Releaseprüfung führt 119 Python-Tests aus: 34 Kern-, 27 Dateisession-, 36 Organ- und 22 Kartenprüfungen. Sie prüft die beiden Integrationsjournale, alle 36 Vergleichsläufe samt Messwerten sowie einen tatsächlichen CLI-Start mit Stop, Resume und Replay.

Bei vorhandenem Node.js werden außerdem 36 Prüfungen der vier Ansichtslogiken ausgeführt; andernfalls wird das ausdrücklich als übersprungen ausgewiesen. validation.json und validation.log enthalten die Ergebnisse. Die JavaScript-Prüfungen verwenden eine minimale DOM-Umgebung. Eine visuelle Prüfung in einem echten Browser war hier nicht verfügbar.

## Frühere Dateiwahrnehmung

~~~sh
python start_files.py
python start_files.py "/PFAD/datei_a.txt" "/PFAD/datei_b.txt"
python live.py watch --journal file_run.jsonl --duration 60 "/PFAD/datei.txt"
python live.py replay file_run.jsonl --html file_replay.html
~~~

Dieses Profil fragt reale lokale Dateimetadaten ab. Ohne Pfadargument benötigt start_files.py eine verfügbare Tk-Dateiauswahl. closed_loop_demo.html zeigt seinen aufgezeichneten Integrationslauf. legacy_demo.html enthält die ursprüngliche konstruierte Mehrquellenwelt.

## Erhaltene Quelldateien

| Datei | Rolle |
|---|---|
| organs.py | Organlebenszyklus, Messautomat, Exposition und Budget |
| field_world.py | endliches Weltmodell, Generator, Messung und Evaluator |
| field_worker.py / field_adapter.py | feste Prozessmessung und Überwachung |
| segments.py | segmentierte Lineage, Recovery, Checkpointprüfung |
| organ_runtime.py / organ_viewer.html | Dienst, HTTP, CLI und Second Layer |
| run_organ_demo.py / benchmark_organs.py | Integration und Expositionsvergleich |
| grfps_l2.py / session.py / journal.py / live.py | kompatible frühere Kern- und Dateiprofile |
| test_*.py / test_*.cjs / validate.py | Vertragstests und Releaseprüfung |
| GRFPS_2nd_Layer_OS.pdf / .tex | vollständiger Systemvertrag und eigenständige LaTeX-Quelle |

