"""Minimal observation port inspired by OPERATORIUM, not full conformance.
No effect executor. A reported input event is never a reconciled effect.
"""
from grfps_l2 import canon
from carrier_contract import seal
PROFILE='grfps-observation-port/1'
def project(state):
    c=state['carrier'];a=state['geometry_answer'];last=c['latest'];ref=state['source_state_ref']
    objects=[dict(id='geometry_answer',referent=ref,projection='universal_query/1',value=a['value'],epistemic=a['epistemic'],facticity='Simulated',scope=state['reference'],evidence=a['binding']),
             dict(id='carrier_pose',referent=c['head'],projection='reported_pose/1',value=last['pose'] if last else None,epistemic='Unknown' if not last or last['pose'] is None else 'Reported',facticity=c['facticity'],scope=c['reference_space'],evidence=c['head'])]
    port=dict(profile=PROFILE,source_ref=ref,sequence=state['sequence'],host_time=state['at'],view_epoch=state['frame'],objects=objects,
              joining=dict(spatial='Unknown',clock='Unknown'),affordances=[dict(id='inspect',effect='local_view'),dict(id='replay',effect='local_view')],external_effects=[],loss=['raw_view_matrices_in_trace','no_physical_accuracy_claim','no_cross_frame_world_join'])
    port['digest']=seal('WorldSnapshot',port);canon(port);return port
