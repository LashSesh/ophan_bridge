"""Carrier records enter the existing owner/journal through a typed port."""
import copy
from grfps_l2 import require,fields,canon,uint
from source_bank import SourceBank,PROFILE as SOURCE_PROFILE,config as source_config
from noisy_bridge import checkpoint as base_checkpoint
from carrier_contract import CarrierState,PROFILE as CARRIER_PROFILE,seal as port_seal,sha
from operator_port import project
PROFILE='grfps-carrier-bank/0.15.0'
def seal(kind,value):return port_seal(kind,dict(profile=PROFILE,value=value))
def config(base,carrier):return dict(copy.deepcopy(base),profile=PROFILE,carrier=copy.deepcopy(carrier))
def checkpoint(m):
    x=base_checkpoint(m);x['bank']['carrier_state']=copy.deepcopy(m.carrier_state.__dict__);return x

class CarrierBank(SourceBank):
    def __init__(self,c):
        require(c.get('profile')==PROFILE and 'carrier' in c,'carrier_bank_profile');cc=c['carrier'];fields(cc,'profile manifest raw_sha256 record_refs record_count')
        require(cc['profile']==CARRIER_PROFILE and type(cc['record_refs']) is list and type(cc['record_count']) is int and 1<=cc['record_count']<=512 and cc['record_count']==len(cc['record_refs']),'carrier_contract')
        require(all(type(h) is str and len(h)==64 and all(x in '0123456789abcdef' for x in h) for h in [cc['raw_sha256'],*cc['record_refs']]),'carrier_hash')
        base=copy.deepcopy(c);base.pop('carrier');base['profile']=SOURCE_PROFILE;super().__init__(base);self.contract=copy.deepcopy(c);self.carrier_state=CarrierState(cc['manifest']);self.carrier_ingested_at=None
    def snapshot(self):
        s=super().snapshot();s['source_state_ref']=s['state_digest'];s['profile']=PROFILE;s['carrier']=self.carrier_state.snapshot();s['carrier']['ingested_at']=self.carrier_ingested_at
        s['observation_port']=project(s);s['contract_ref']=seal('Contract',self.contract);s['state_digest']=seal('State',{k:v for k,v in s.items() if k!='state_digest'});return s
    def _registered(self,e):
        if e.get('kind')=='carrier_record':
            fields(e,'kind at index raw');cc=self.contract['carrier'];idx=self.carrier_state.cursor
            require(self.phase=='RUNNING' and not self.active.paused and type(e['index']) is int and e['index']==idx and idx<cc['record_count'],'carrier_cursor')
            require(type(e['raw']) is str and sha(e['raw'].encode('ascii'))==cc['record_refs'][idx],'carrier_raw_binding')
            self._active(dict(kind='tick',at=e['at']));self.carrier_state.apply(e['raw']);self.carrier_ingested_at=e['at'];self.last=dict(kind='carrier_record',index=idx,head=self.carrier_state.head)
        else:super()._registered(e)
