import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from geometry_bank import GeometryBank,config,seal
from geometry_sensor import fixture,capture,validate_source
from geometry_segments import SegmentJournal,replay
from noisy_certificate import fixture as calibration_fixture
from test_noisy import answer as calibration_answer
from trace_geometry import solve,verify_witness


def machine(limit=4096,budget=65536,case='refinement'):
    c=config('/tmp/world','/tmp/field','/tmp/orientation','/tmp/calibration','/tmp/sensor')
    c['geometry'].update(windows=sorted(fixture(case)['windows']),node_limit=limit,node_budget=budget)
    return GeometryBank(c)
def event(m,source=None):
    r=m.pending
    if r['organ']=='calibration_probe':return calibration_answer(m,calibration_fixture([0,0,0]))
    p=r['payload'];at=m.mapper.at+1
    if r['organ']=='geometry_window':data=capture(fixture() if source is None else source,r)
    else:
        i=p['inputs'];data=solve(i['windows'],i['candidates'],i['query'],p['node_limit'],i['pose_bound'])
    return dict(kind='geometry_result',at=at,request=r['id'],exposure=r['exposure'],calibration_ref=p['calibration_ref'],outcome='OK',data=data,sampled_at=at,sample_ref=seal('WorkerSample',dict(exposure=r['exposure'],data=data,sampled_at=at)))
def dispatch(m):return m.reduce(dict(kind='dispatch',at=m.mapper.at,proposal=m.plan()))[0]
def tick(m,at):return m.reduce(dict(kind='tick',at=at))[0]
def advance(m,source=None):
    p=m.recalibration_proposal()
    if p and m.calibration['revision']==0:return m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=p))[0]
    if m.plan() is None:return tick(m,m.mapper.at+100)
    m=dispatch(m);return m.reduce(event(m,source))[0]
def until(m,predicate,source=None,n=100):
    for _ in range(n):
        if predicate(m):return m
        m=advance(m,source)
    raise AssertionError(str(m.snapshot()['geometry_answer']))
def ready(**kw):return until(machine(**kw),lambda m:m.answer()['epistemic']=='Ambiguous')
def solver_pending(m=None):
    m=until(machine() if m is None else m,lambda m:bool(m.plan()) and m.plan()['organ']=='geometry_solver');return dispatch(m)


class GeometryLiveTests(unittest.TestCase):
    def test_active_refinement_reaches_known(self):
        m=ready();initial=m.spent
        m=until(m,lambda m:m.answer()['epistemic']=='Known')
        self.assertIs(m.answer()['value'],True);self.assertIn('fine',m.precision.values());self.assertGreater(m.spent,initial)
    def test_every_emitted_witness_satisfies_original_boxes(self):
        m=ready();i=m.inputs()
        for w in m.solution['result']['witnesses'].values():self.assertTrue(verify_witness(i['windows'],i['candidates'],i['query'],w))
    def test_snapshot_and_plan_never_run_solver(self):
        m=ready()
        with patch('geometry_bank.solve',side_effect=AssertionError('hidden_search')):m.snapshot();m.plan();m.answer()
    def test_fixed_anchor_is_not_replaced(self):
        m=ready();m.box_windows.pop('left')
        self.assertEqual(m.answer()['anchor'],'left');self.assertEqual(m.answer()['reason'],'fixed_anchor_missing');self.assertEqual(m.answer()['epistemic'],'Unknown')
    def test_all_required_windows_must_be_present(self):
        m=ready();m.box_windows.pop('right');self.assertEqual(m.answer()['reason'],'required_window_missing')
    def test_search_nodes_reserved_before_dispatch(self):
        m=solver_pending();self.assertEqual(m.nodes_reserved,4096);self.assertEqual(m.nodes_spent,0)
    def test_verified_work_releases_unused_reservation(self):
        m=solver_pending();e=event(m);m=m.reduce(e)[0]
        self.assertEqual(m.nodes_reserved,0);self.assertEqual(m.nodes_spent,e['data']['nodes']);self.assertLess(m.nodes_spent,4096)
    def test_solver_error_charges_full_grant(self):
        m=solver_pending();r=m.pending;e=dict(kind='geometry_result',at=m.mapper.at+1,request=r['id'],exposure=r['exposure'],calibration_ref=r['payload']['calibration_ref'],outcome='ERROR',data=None,sampled_at=None,sample_ref=None)
        m=m.reduce(e)[0];self.assertEqual(m.nodes_spent,4096);self.assertIsNone(m.solution)
    def test_partial_solution_cannot_admit(self):
        m=until(machine(limit=1,budget=3),lambda m:m.solution is not None)
        self.assertEqual(m.solution['result']['status'],'LIMIT');self.assertEqual(m.answer()['epistemic'],'Unknown')
    def test_compute_budget_is_never_exceeded(self):
        m=machine(limit=1,budget=2)
        for _ in range(100):m=advance(m)
        self.assertLessEqual(m.nodes_spent+m.nodes_reserved,2);self.assertEqual(m.nodes_spent,2);self.assertIsNone(m.ordinary_plan())
    def test_geometry_changes_invalidate_solver_evidence(self):
        m=ready();m=until(m,lambda m:bool(m.plan()) and m.plan()['organ']=='geometry_window')
        m=dispatch(m);m=m.reduce(event(m))[0];self.assertEqual(m.answer()['epistemic'],'Unknown');self.assertIsNone(m.snapshot()['geometry_solution'])
    def test_solver_completion_after_expiry_is_not_admitted(self):
        c=machine().contract;c['geometry'].update(ttl=100,refresh=80,retry=20)
        m=solver_pending(GeometryBank(c));e=event(m);e['at']=m.mapper.at+200
        m=m.reduce(e)[0];self.assertEqual(m.last['status'],'STALE_INPUTS');self.assertIsNone(m.solution)
    def test_wrong_exposure_rejected(self):
        m=solver_pending();e=event(m);e['exposure']='0'*64
        with self.assertRaisesRegex(ValueError,'binding'):m.reduce(e)
    def test_wrong_calibration_rejected(self):
        m=solver_pending();e=event(m);e['calibration_ref']='0'*64
        with self.assertRaisesRegex(ValueError,'binding'):m.reduce(e)
    def test_rehashed_forged_solver_result_rejected(self):
        m=solver_pending();e=event(m);e['data']['values']=[True]
        e['sample_ref']=seal('WorkerSample',dict(exposure=e['exposure'],data=e['data'],sampled_at=e['sampled_at']))
        with self.assertRaisesRegex(ValueError,'solver_semantics'):m.reduce(e)
    def test_old_frame_result_is_superseded(self):
        m=solver_pending();e=event(m);m=m.reduce(dict(kind='frame',at=m.mapper.at))[0];m=m.reduce(e)[0]
        self.assertEqual(m.last['status'],'SUPERSEDED');self.assertIsNone(m.solution);self.assertEqual(m.nodes_reserved,0)
    def test_pause_blocks_dispatch_but_ages_evidence(self):
        m=ready();m=m.reduce(dict(kind='pause',at=m.mapper.at,paused=True))[0];self.assertIsNone(m.plan())
        m=tick(m,m.mapper.at+6000);self.assertEqual(m.answer()['epistemic'],'Unknown')
    def test_clock_and_measurement_budget_survive_restart(self):
        m=ready();spent=m.spent;nodes=m.nodes_spent;cert=m.calibration
        m=m.reduce(dict(kind='stop',at=m.mapper.at,reason='user'))[0]
        m=m.reduce(dict(kind='resume',at=m.mapper.at+6000))[0]
        self.assertEqual((m.spent,m.nodes_spent,m.calibration),(spent,nodes,cert));self.assertEqual(m.answer()['epistemic'],'Unknown')
    def test_no_unrequested_results(self):
        m=solver_pending();e=event(m);done=m.reduce(e)[0]
        with self.assertRaises(ValueError):done.reduce(e)
    def test_wrong_sensor_channel_rejected(self):
        m=until(machine(),lambda m:bool(m.plan()) and m.plan()['organ']=='geometry_window');m=dispatch(m);e=event(m);e['data']['mode']='fine'
        e['sample_ref']=seal('WorkerSample',dict(exposure=e['exposure'],data=e['data'],sampled_at=e['sampled_at']))
        with self.assertRaisesRegex(ValueError,'channel'):m.reduce(e)
    def test_occlusion_removes_window_evidence(self):
        m=ready();m=until(m,lambda m:bool(m.plan()) and m.plan()['organ']=='geometry_window');m=dispatch(m);src=fixture();p=m.pending['payload'];src['windows'][p['window']][p['mode']]=dict(outcome='OCCLUDED',points=None)
        m=m.reduce(event(m,src))[0];self.assertNotIn(p['window'],m.live_windows());self.assertEqual(m.answer()['epistemic'],'Unknown')
    def test_cycle_conflict_is_live_unknown(self):
        m=until(machine(case='cycle'),lambda m:m.solution is not None,fixture('cycle'))
        self.assertEqual(m.solution['result']['status'],'CONFLICT');self.assertEqual(m.answer()['epistemic'],'Unknown')
    def test_invalid_anchor_contract(self):
        m=machine();c=copy.deepcopy(m.contract);c['geometry']['anchor']='right'
        with self.assertRaisesRegex(ValueError,'anchor'):GeometryBank(c)
    def test_invalid_sensor_radius(self):
        src=fixture();src['windows']['left']['coarse']['points']['A']['radius']=2
        with self.assertRaisesRegex(ValueError,'radius'):validate_source(src)
    def test_legacy_exact_geometry_cannot_bypass_new_gate(self):
        with self.assertRaises(ValueError):machine().reduce(dict(kind='noisy_result',at=0))
    def test_pending_solver_crosses_segment_and_replays(self):
        with tempfile.TemporaryDirectory(dir='/tmp') as tmp:
            c=machine().contract;c['segment_records']=16;j=SegmentJournal(Path(tmp)/'journal',c)
            for _ in range(100):
                m=j.machine;p=m.recalibration_proposal()
                if p and m.calibration['revision']==0:e=dict(kind='recalibrate',at=m.mapper.at,proposal=p)
                elif m.pending:
                    if m.pending['organ']=='geometry_solver':break
                    e=event(m)
                elif m.plan():e=dict(kind='dispatch',at=m.mapper.at,proposal=m.plan())
                else:e=dict(kind='tick',at=m.mapper.at+100)
                j.commit(e)
            self.assertEqual(j.machine.pending['organ'],'geometry_solver')
            while j.count<16:j.commit(dict(kind='tick',at=j.machine.mapper.at))
            j.commit(event(j.machine));expected=j.machine.snapshot();j.close()
            self.assertEqual(replay(Path(tmp)/'journal')['machine'].snapshot(),expected)

if __name__=='__main__':unittest.main()
