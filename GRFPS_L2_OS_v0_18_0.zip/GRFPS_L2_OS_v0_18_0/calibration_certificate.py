"""Exact finite C4 calibration: fit-only estimation, disjoint held-out validation.
A certificate proves these finite correspondences, not a physical error bound.
"""
import copy
from grfps_l2 import fields,require,ident,canon
from mapping import hashof,rot,transform,inverse,validate_patch
PROFILE='grfps-calibration-certificate/1'
PROTOCOL=dict(algorithm='c4-anchor-fit/1',raw_frame='sensor_local',reference_frame='window_local',units='model_grid_step',coordinate_limit=64,fit_limit=0,check_limit=0,min_fit=3,min_check=2,max_points=16)
def seal(kind,x):return hashof(kind,dict(profile=PROFILE,value=x))
def point(p):return type(p) is list and len(p)==2 and all(type(v) is int and abs(v)<=64 for v in p)
def pose(t):return type(t) is list and len(t)==3 and type(t[0]) is int and 0<=t[0]<4 and all(type(v) is int and abs(v)<=128 for v in t[1:])
def chart_fixture(t=None):
    t=[1,3,-2] if t is None else t;require(pose(t),'pose')
    ref=[[0,0],[4,0],[0,4],[3,2],[-2,3]]
    return dict(profile='grfps-calibration-chart/1',protocol=copy.deepcopy(PROTOCOL),points=[dict(id=('fit' if i<3 else 'check')+str(i),role='fit' if i<3 else 'check',raw=list(transform(p,inverse(t))),reference=p) for i,p in enumerate(ref)])
def validate_chart(w):
    fields(w,'profile protocol points');require(w['profile']=='grfps-calibration-chart/1' and canon(w['protocol'])==canon(PROTOCOL),'chart_protocol')
    points=w['points'];require(type(points) is list and 5<=len(points)<=16,'chart_size')
    for p in points:
        fields(p,'id role raw reference');require(ident(p['id']) and p['role'] in ['fit','check'] and point(p['raw']) and point(p['reference']),'chart_point')
    for key in ['id','raw','reference']:
        values=[p[key] if key=='id' else tuple(p[key]) for p in points];require(len(values)==len(set(values)),'chart_partition_overlap')
    fit=[p for p in points if p['role']=='fit'];check=[p for p in points if p['role']=='check'];require(len(fit)>=3 and len(check)>=2,'chart_partition')
    a=fit[0]['raw'];require(any((b['raw'][0]-a[0])*(c['raw'][1]-a[1])!=(b['raw'][1]-a[1])*(c['raw'][0]-a[0]) for b in fit[1:] for c in fit[1:]),'degenerate_fit')
    return w

def residuals(points,t):
    return [dict(id=p['id'],role=p['role'],residual=max(abs(a-b) for a,b in zip(transform(p['raw'],t),p['reference']))) for p in points]
def evaluate(w):
    validate_chart(w);fit=sorted((p for p in w['points'] if p['role']=='fit'),key=lambda p:p['id']);a=fit[0];solutions=[]
    # Held-out points never participate in this loop or candidate selection.
    for q in range(4):
        x,y=rot(a['raw'],q);t=[q,a['reference'][0]-x,a['reference'][1]-y]
        if pose(t) and all(p['residual']==0 for p in residuals(fit,t)):solutions.append(t)
    report=dict(status='FIT_REJECTED',fit_candidates=len(solutions),chart_ref=seal('Chart',w),protocol_ref=seal('Protocol',PROTOCOL),transform=None,residuals=[],certificate=None)
    if len(solutions)!=1:return report
    t=solutions[0];rs=residuals(sorted(w['points'],key=lambda p:p['id']),t);report.update(transform=t,residuals=rs,status='CHECK_REJECTED')
    if any(p['residual']>0 for p in rs):return report
    cert=dict(profile=PROFILE,protocol=copy.deepcopy(PROTOCOL),chart_ref=report['chart_ref'],fit_ids=sorted(p['id'] for p in w['points'] if p['role']=='fit'),check_ids=sorted(p['id'] for p in w['points'] if p['role']=='check'),transform=t,residuals=rs)
    report.update(status='PASS',certificate=cert);return report

def validate_certificate(cert,w):
    expected=evaluate(w)['certificate'];require(expected is not None and canon(expected)==canon(cert),'certificate_mismatch');return cert

def corrected_patch(raw,cert,calibration_ref):
    validate_patch(raw);require(all(point(p) for p in raw['points'].values()),'raw_domain')
    out=copy.deepcopy(raw);out['points']={k:list(transform(p,cert['transform'])) for k,p in raw['points'].items()}
    out['sample_ref']=seal('CorrectedSample',dict(raw_sample_ref=raw['sample_ref'],raw_patch_ref=hashof('Patch',raw),calibration_ref=calibration_ref,certificate_ref=seal('Certificate',cert)))
    validate_patch(out);return out

def raw_sample(world,request,at):
    from map_worker import sample
    require(pose(world.get('sensor_transform')),'sensor_transform');out=sample(world,request,at)
    out['points']={k:list(transform(p,inverse(world['sensor_transform']))) for k,p in out['points'].items()}
    validate_patch(out);return out
