import json
from pathlib import Path
from carrier_contract import preflight,CarrierState
from registration3d import compile_certificate,projection,rotate_point
from registration3d_fixtures import CASES
from registered3d_runtime import html,export
from registered3d_segments import replay

def verify(root,export_views=True):
    root=Path(root);out={};gallery=[]
    for name in CASES:
        d=root/name;r=replay(d/'journal',collect=True);m=r['machine'];expected=json.loads((d/'report.json').read_text());b=json.loads((d/'registration3d.json').read_text());mf=json.loads((d/'carrier_manifest.json').read_text());cc,lines,_=preflight((d/'carrier.jsonl').read_bytes(),mf);assert cc==m.contract['carrier'] and b==m.contract['registration3d'];cert=compile_certificate(b,cc);cs=CarrierState(mf);last=None;seen=[];records=0;witnesses=0
        for before,e,after in zip(r['views'],r['events'],r['views'][1:]):
            if e['kind']=='registration3d_result':assert e['certificate']==cert
            if e['kind']=='carrier_record':
                assert e['index']==cs.cursor and e['raw']==lines[cs.cursor];cs.apply(e['raw']);records+=1
                if json.loads(e['raw'])['record_kind']=='frame':last=e['raw']
            g=projection(b,after['registration_certificate'],cs.snapshot(),last);assert g==after['registered3d'];assert g['physical_validation']=='Unknown' and g['facticity']=='Simulated';assert after['observation_port']['joining']==dict(spatial='Unknown',clock='Unknown') and not after['observation_port']['external_effects']
            if e['kind']=='carrier_record':seen.append(g['status'])
            for w in g['witnesses'].values():
                local=[[x[0]-err,x[1]+err] for x,err in zip(cs.latest['pose']['position_um'],b['sensor_error_um'])];assert all(a[0]<=v<=a[1] for a,v in zip(local,w['local_um']))
                row=next(x for x in cert['spatial_candidates'] if x['rotation_id']==w['rotation_id']);assert all(x[0]<=y<=x[1] for x,y in zip(row['translation_um'],w['translation_um']));assert [x+y for x,y in zip(rotate_point(w['local_um'],row['rotation']),w['translation_um'])]==w['reference_um'];assert (w['reference_um'][b['query']['axis']]>b['query']['threshold_um'])==w['value'];witnesses+=1
            if e['kind']=='resume':assert before['registered3d']==after['registered3d'] and before['registration_certificate']==after['registration_certificate']
        assert records==len(lines)
        if name in ['spatial_rejection','clock_rejection','partial_holdout']:assert set(seen)=={'Unknown'}
        if name=='ambiguous_registration':assert set(seen)=={'Ambiguous'} and len(cert['spatial_candidates'])==24
        if name=='baseline':assert seen[:4]==['Known','Known','Ambiguous','Known']
        if name in ['reference_reset','horizon']:assert seen[-1]=='Unknown' and 'Known' in seen
        if name=='tracking_loss':assert seen[5:8]==['Unknown']*3 and seen[-1]=='Known'
        for k,v in [('transitions',m.seq),('head',r['head']),('state_digest',m.snapshot()['state_digest']),('spent',m.spent),('nodes_spent',m.nodes_spent),('requests',m.request_count)]:assert expected[k]==v
        out[name]=dict(transitions=m.seq,segments=r['index']+1,requests=m.request_count,spent=m.spent,nodes_spent=m.nodes_spent,http_checks=expected['http_checks'],source_records=records,certificate_status=cert['status'],spatial_candidates=len(cert['spatial_candidates']),clock_candidates=len(cert['clock_candidates']),verified_witnesses=witnesses,head=r['head'],state_digest=m.snapshot()['state_digest']);gallery.append(dict(name=name,views=r['views'],events=r['events'],head=r['head']))
        if export_views:export(d/'journal',d/'replay.html')
    if export_views:(root.parent/'finite3d_demo.html').write_text(html(dict(mode='replay',cases=gallery)))
    return dict(cases=out,transitions=sum(x['transitions'] for x in out.values()),http_checks=sum(x['http_checks'] for x in out.values()),source_records=sum(x['source_records'] for x in out.values()),requests=sum(x['requests'] for x in out.values()),spent=sum(x['spent'] for x in out.values()),nodes_spent=sum(x['nodes_spent'] for x in out.values()),full_semantic_replay=True,physical_measurements=False)
if __name__=='__main__':print(json.dumps(verify(Path(__file__).parent/'registered3d_evidence_run'),indent=2))
