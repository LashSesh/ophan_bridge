"""Synthetic raw-coordinate sensor; no access to an adopted certificate."""
import sys,time
from pathlib import Path
from grfps_l2 import loads,canon,require
from calibration_certificate import raw_sample
try:
    with Path(sys.argv[1]).open('rb') as f:raw=f.read(1048577)
    require(len(raw)<=1048576,'world_size');q=loads(sys.stdin.buffer.read(8193));at=q['offset']+(time.monotonic_ns()-q['start_ns'])//1000000
    sys.stdout.buffer.write(canon(raw_sample(loads(raw),q['request'],at)))
except Exception:sys.exit(2)
