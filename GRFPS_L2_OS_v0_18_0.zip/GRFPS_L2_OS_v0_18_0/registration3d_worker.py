"""Finite compiler worker; parent independently checks the returned certificate."""
import sys
from grfps_l2 import loads,canon,fields
from registration3d import compile_certificate
if __name__=='__main__':
    data=loads(sys.stdin.buffer.read(262145));fields(data,'bundle carrier');sys.stdout.buffer.write(canon(compile_certificate(data['bundle'],data['carrier']))+b'\n')
