import copy,itertools,json,tempfile,unittest
from pathlib import Path
from fractions import Fraction as F
from unittest.mock import patch
import continuous3d as c
from continuous3d_fixtures import dataset,BASE,U,T
from continuous3d_bank import Continuous3DBank,config
from continuous3d_segments import SegmentJournal,replay
from continuous3d_runtime import worker_certificate
from carrier_contract import preflight,CarrierState
from carrier_bank import config as carrier_config
from test_sources import machine

def inputs(case='baseline'):
    raw,m,b=dataset(case);cc,ls,_=preflight(raw,m);return cc,ls,b
def state(case='baseline',index=3):
    cc,ls,b=inputs(case);cert=c.compile_certificate(b,cc);s=CarrierState(cc['manifest']);last=None
    for row in ls[:index+1]:
        s.apply(row)
        if json.loads(row)['record_kind']=='frame':last=row
    return b,cert,s.snapshot(),last
def bank(case='baseline'):
    cc,ls,b=inputs(case);m=Continuous3DBank(config(carrier_config(machine().contract,cc),b));return m,ls,b
def qmul(a,b):
    w,x,y,z=a;v,r,s,t=b
    return [w*v-x*r-y*s-z*t,w*r+x*v+y*t-z*s,w*s-x*t+y*v+z*r,w*t+x*s-y*r+z*v]
def independent_rotate(u,p):
    q=[F(1),*u];out=qmul(qmul(q,[F(0),*p]),[q[0],-q[1],-q[2],-q[3]]);norm=sum(x*x for x in q);return [x/norm for x in out[1:]]

class IntervalAlgebra(unittest.TestCase):
    def test_cross_zero_square_has_zero_lower_bound(self):self.assertEqual(c.square([F(-2),F(3)]),[0,9])
    def test_signed_products_enclose_grid(self):
        for a,b in itertools.product([[-2,3],[-4,-1],[0,0],[1,2]],repeat=2):
            lo,hi=c.mul(a,b)
            for x,y in itertools.product(range(a[0],a[1]+1),range(b[0],b[1]+1)):self.assertLessEqual(lo,x*y);self.assertGreaterEqual(hi,x*y)
    def test_denominator_must_be_positive(self):
        with self.assertRaisesRegex(ValueError,'positive_interval'):c.divide_positive([1,2],[0,3])
    def test_exact_matrix_matches_independent_quaternion_product(self):
        for u in itertools.product([F(-1),F(-1,3),F(0),F(1,5),F(1)],repeat=3):
            m=c.exact_matrix(u,BASE)
            for p in [[1,0,0],[0,1,0],[0,0,1],[2,-3,5]]:self.assertEqual(c.exact_transform(m,p),independent_rotate(u,p))
    def test_matrices_are_exactly_orthogonal_and_proper(self):
        for u in [U,[F(1),F(-1,2),F(2,3)],[F(-1),F(1),F(1)]]:
            m=c.exact_matrix(u,BASE)
            for i,j in itertools.product(range(3),repeat=2):self.assertEqual(sum(m[k][i]*m[k][j] for k in range(3)),int(i==j))
            a,b,d=m;self.assertEqual(a[0]*(b[1]*d[2]-b[2]*d[1])-a[1]*(b[0]*d[2]-b[2]*d[0])+a[2]*(b[0]*d[1]-b[1]*d[0]),1)
    def test_interval_matrix_contains_interior_quaternion_rotations(self):
        domain=[[F(-1,3),F(1,2)],[F(-1,5),F(2,3)],[F(1,7),F(3,4)]];m=c.matrix(domain,BASE)
        for u in itertools.product(*[[a+(z-a)*F(k,4) for k in range(5)] for a,z in domain]):
            for j in range(3):
                p=[int(k==j) for k in range(3)];v=independent_rotate(u,p)
                for i in range(3):self.assertTrue(m[i][j][0]<=v[i]<=m[i][j][1])
    def test_all_24_bases_preserve_interval_inclusion(self):
        domain=[[x-F(1,100),x+F(1,100)] for x in U]
        for base in c.old.ROTATIONS:
            m=c.matrix(domain,base);p=[F(2),F(-3),F(5)];v=c.old.rotate_point(independent_rotate(U,p),base);box=c.transform(m,[c.scalar(x) for x in p]);self.assertTrue(all(a<=x<=z for x,(a,z) in zip(v,box)))
    def test_four_charts_cover_rational_quaternion_samples(self):
        bases=[[1,2,3],[1,-2,-3],[-1,2,-3],[-1,-2,3]]
        for q in itertools.product([-2,-1,0,1,2],repeat=4):
            if not any(q):continue
            j=max(range(4),key=lambda k:abs(q[k]));baseq=[int(k==j) for k in range(4)];conj=[baseq[0],-baseq[1],-baseq[2],-baseq[3]];local=qmul(conj,list(q));u=[F(x,local[0]) for x in local[1:]];self.assertTrue(all(abs(x)<=1 for x in u))
            p=[2,-1,3];out=qmul(qmul(list(q),[0,*p]),[q[0],-q[1],-q[2],-q[3]]);expected=[F(x,sum(v*v for v in q)) for x in out[1:]];self.assertEqual(c.exact_transform(c.exact_matrix(u,bases[j]),p),expected)

class Contract(unittest.TestCase):
    def test_noncanonical_parameters_rejected(self):
        for v in [['2','2'],['-0','1'],['1','0'],['01','2'],['1','-2'],['1','1000000001'],[0,1],['2','1']]:
            cc,ls,b=inputs();b['charts'][0]['u'][0][0]=v
            with self.subTest(v=v),self.assertRaises(ValueError):c.compile_certificate(b,cc)
    def test_nonpoint_local_fit_is_rejected(self):
        cc,ls,b=inputs();b['spatial_fit'][0]['local_um'][0]=[-1,1]
        with self.assertRaisesRegex(ValueError,'exact_local'):c.compile_certificate(b,cc)
    def test_reflection_chart_rejected(self):
        cc,ls,b=inputs();b['charts'][0]['base']=[-1,2,3]
        with self.assertRaisesRegex(ValueError,'proper_chart'):c.compile_certificate(b,cc)
    def test_search_bounds_are_exact_and_bounded(self):
        for key,value in [('max_cells',128),('max_cells',0),('max_depth',9),('min_depth',4),('min_depth',True)]:
            cc,ls,b=inputs();b['search'][key]=value
            with self.subTest(key=key,value=value),self.assertRaisesRegex(ValueError,'search_bound'):c.compile_certificate(b,cc)
    def test_source_and_query_bind_entire_certificate(self):
        b,cert,s,r=state()
        for key in ['charts','search','query']:
            changed=copy.deepcopy(b)
            if key=='charts':changed[key][0]['u'][0][0]=['0','1']
            elif key=='search':changed[key]['max_cells']-=1
            else:changed[key]['threshold_um']+=1
            with self.subTest(key=key),self.assertRaisesRegex(ValueError,'projection_bundle_binding'):c.projection(changed,cert,s,r)
    def test_duplicate_chart_id_rejected(self):
        cc,ls,b=inputs();b['charts']*=2
        with self.assertRaisesRegex(ValueError,'chart_identity'):c.compile_certificate(b,cc)
    def test_oversize_bundle_is_bounded_before_parse(self):
        cc,ls,b=inputs()
        with tempfile.TemporaryDirectory(dir='/tmp') as d:
            p=Path(d)/'b.json';p.write_bytes(b' '*(c.MAX_BYTES+1))
            with self.assertRaisesRegex(ValueError,'bundle_size'):c.load_bundle(p,cc)

class ContinuousCertificate(unittest.TestCase):
    def test_rotation_is_not_an_axis_permutation(self):
        m=c.exact_matrix(U,BASE);self.assertEqual(m[0][0],F(12,13));self.assertEqual(m[1][0],F(5,13));cc,ls,b=inputs();self.assertEqual(c.compile_certificate(b,cc)['status'],'PASS')
    def test_subdivision_preserves_boundary_existence_witness(self):
        cc,ls,b=inputs('refinement');cert=c.compile_certificate(b,cc);self.assertEqual(cert['status'],'PASS');self.assertGreater(cert['work']['splits'],0);self.assertGreater(cert['work']['discarded_cells'],0)
        for row in cert['spatial_candidates']:self.assertIsNotNone(row['fit_witness']);self.assertEqual([c.unfrac(v) for v in row['fit_witness']['u']],U)
    def test_leaf_partition_covers_every_root_without_holes(self):
        for name in ['baseline','refinement','search_limit','control_unproven']:
            cc,ls,b=inputs(name);cert=c.compile_certificate(b,cc);paths=[x['path'] for x in cert['spatial_candidates']+cert['discarded_cells']];self.assertEqual(sum(F(1,2**len(x)) for x in paths),1)
            for a,z in itertools.combinations(paths,2):self.assertFalse(a.startswith(z) or z.startswith(a))
            self.assertLessEqual(cert['work']['cell_evaluations'],b['search']['max_cells'])
    def test_sampled_feasible_states_survive_interval_pruning(self):
        cc,ls,b=inputs('refinement');cert=c.compile_certificate(b,cc)
        for k in range(257):
            u=[F(0),F(0),F(19,100)+F(k,12800)];t=c.concrete_fit(b,u,BASE)
            if not c.nonempty(t):continue
            covering=[x for x in cert['spatial_candidates'] if all(a<=v<=z for v,(a,z) in zip(u,c.decode_box(x['u'])))];self.assertTrue(covering)
            self.assertTrue(any(c.inside(t,c.decode_box(x['translation_um'])) for x in covering))
    def test_budget_exhaustion_never_reports_false_fit_empty(self):
        cc,ls,b=inputs('search_limit');cert=c.compile_certificate(b,cc);self.assertEqual(cert['status'],'SEARCH_LIMIT');self.assertEqual(len(cert['spatial_candidates']),1);self.assertTrue(cert['fit_existence_witnessed'])
    def test_control_failure_retains_all_fit_cells(self):
        cc,ls,b=inputs('control_unproven');cert=c.compile_certificate(b,cc);self.assertEqual(cert['status'],'CONTROL_UNPROVEN');self.assertTrue(cert['fit_existence_witnessed']);self.assertTrue(cert['spatial_candidates'])
    def test_partial_control_cannot_select_a_passing_chart(self):
        cc,ls,b=inputs('enclosure_overlap');b['charts']=[dict(id='identity',base=BASE,u=c.encode([[F(0),F(0)]]*3)),dict(id='quarter',base=[-2,1,3],u=c.encode([[F(0),F(0)]]*3))]
        for row in b['spatial_check']:row['local_um']=[[1000,1000],[0,0],[0,0]];row['reference_um']=[[T[0]+1000,T[0]+1000],[T[1],T[1]],[T[2],T[2]]]
        cert=c.compile_certificate(b,cc);self.assertEqual(cert['status'],'CONTROL_UNPROVEN');self.assertEqual(len(cert['spatial_candidates']),2);self.assertEqual(sum(x['passed'] for x in cert['spatial_candidates']),1)
    def test_empty_outer_fit_is_not_vacuous_pass(self):
        cc,ls,b=inputs('fit_empty');cert=c.compile_certificate(b,cc);self.assertEqual(cert['status'],'SPATIAL_FIT_EMPTY');self.assertFalse(cert['fit_existence_witnessed'])
    def test_feasibility_without_a_found_witness_remains_unknown(self):
        cc,ls,b=inputs('refinement');b['search']=dict(min_depth=0,max_depth=0,max_cells=1);u=[F(0),F(0),F(201,1000)];m=c.exact_matrix(u,BASE)
        for row in b['spatial_fit']:row['reference_um']=[[int(x+z)-1,int(x+z)+1] for x,z in zip(c.exact_transform(m,[a for a,z in row['local_um']]),T)]
        for row in b['spatial_check']:row['reference_um']=[[-10000000,10000000]]*3
        cert=c.compile_certificate(b,cc);self.assertEqual(cert['status'],'FIT_EXISTENCE_UNPROVEN');self.assertTrue(cert['spatial_candidates'])
    def test_clock_model_matches_prior_exact_profile(self):
        cc,ls,b=inputs();old=copy.deepcopy(b);old.pop('charts');old.pop('search');old['profile']=c.old.PROFILE;self.assertEqual(c.clock_candidates(b),c.old.compile_certificate(old,cc)['clock_candidates'])
    def test_actual_compiler_subprocess_matches_parent(self):
        cc,ls,b=inputs('refinement');self.assertEqual(worker_certificate(b,cc),c.compile_certificate(b,cc))

class ContinuousProjection(unittest.TestCase):
    def test_negative_ambiguous_positive_sequence(self):
        for i,status,value in [(0,'Known',False),(2,'Ambiguous',None),(3,'Known',True)]:
            b,cert,s,r=state(index=i);g=c.projection(b,cert,s,r);self.assertEqual((g['status'],g['value']),(status,value))
    def test_two_rotation_witnesses_establish_ambiguity(self):
        b,cert,s,r=state('two_witnesses');g=c.projection(b,cert,s,r);self.assertEqual(g['status'],'Ambiguous');self.assertEqual(set(g['witnesses']),{'true','false'});self.assertNotEqual(g['witnesses']['true']['u'],g['witnesses']['false']['u'])
    def test_enclosing_overlap_without_two_witnesses_is_unknown(self):
        b,cert,s,r=state('enclosure_overlap');g=c.projection(b,cert,s,r);self.assertEqual(g['enclosure_values'],[False,True]);self.assertEqual(len(g['values']),1);self.assertEqual((g['status'],g['reason']),('Unknown','enclosure_overlap'));self.assertIsNone(g['value'])
    def test_all_witnesses_satisfy_original_fit_constraints(self):
        for case in ['baseline','refinement','two_witnesses','enclosure_overlap']:
            b,cert,s,r=state(case);g=c.projection(b,cert,s,r);local=[[F(a-e),F(z+e)] for (a,z),e in zip(s['latest']['pose']['position_um'],b['sensor_error_um'])]
            for w in g['witnesses'].values():self.assertTrue(c.verify_witness(b,w,local))
    def test_forged_witness_fails_direct_constraint_check(self):
        b,cert,s,r=state();g=c.projection(b,cert,s,r);w=copy.deepcopy(next(iter(g['witnesses'].values())));w['translation_um'][0]=['0','1'];local=[[F(a-e),F(z+e)] for (a,z),e in zip(s['latest']['pose']['position_um'],b['sensor_error_um'])]
        with self.assertRaises(AssertionError):c.verify_witness(b,w,local)
    def test_rational_positions_are_not_rounded_to_integers(self):
        b,cert,s,r=state();g=c.projection(b,cert,s,r);self.assertTrue(any(int(x[1])!=1 for row in g['position_um'] for x in row));c.canon(g)
    def test_existing_scope_expiration_and_tracking_guards(self):
        for case,i,reason in [('reference_reset',5,'reference_scope_changed'),('horizon',5,'source_horizon'),('tracking_loss',5,'pose_unavailable')]:
            b,cert,s,r=state(case,i);g=c.projection(b,cert,s,r);self.assertEqual(g['reason'],reason);self.assertIsNone(g['position_um'])
    def test_reference_horizon_covers_every_clock_candidate(self):
        cc,ls,b=inputs();_,cert,s,r=state();g=c.projection(b,cert,s,r);lo=c.unfrac(g['reference_time_ns'][0]);b['valid_reference_ns'][0]=str(lo.numerator//lo.denominator+1);cert=c.compile_certificate(b,cc);self.assertEqual(c.projection(b,cert,s,r)['reason'],'reference_horizon')
    def test_origin_and_orientation_are_not_promoted(self):
        b,cert,s,r=state();g=c.projection(b,cert,s,r);self.assertEqual((g['facticity'],g['physical_validation'],g['orientation']),('Simulated','Unknown','Unknown'))
    def test_strict_outer_overestimate_does_not_invent_ambiguity(self):
        cc,ls,b=inputs('enclosure_overlap');b['query'].update(axis=1,threshold_um=200000);b['sensor_error_um']=[0,0,0];cert=c.compile_certificate(b,cc);_,_,s,r=state('enclosure_overlap');s['latest']['pose']['position_um']=[[1000,1000],[1000,1000],[0,0]];g=c.projection(b,cert,s,r)
        # Actual y/T = 1000*(1+2z-z^2)/(1+z^2) >= 1000 on [0,1],
        # since numerator - denominator = 2z(1-z) >= 0.
        # Independent interval entries still include zero at the lower bound.
        self.assertEqual(g['status'],'Unknown');self.assertEqual(g['reason'],'enclosure_overlap');self.assertEqual(g['values'],[True]);self.assertEqual(g['enclosure_values'],[False,True])
    def test_boolean_raw_epoch_cannot_satisfy_explicit_generation(self):
        b,cert,s,r=state();raw=json.loads(r);raw['source_epoch']=False;self.assertEqual(c.projection(b,cert,s,json.dumps(raw))['reason'],'explicit_scope_missing')

class ContinuousBank(unittest.TestCase):
    def test_rehashed_pruned_cover_is_rejected_atomically(self):
        m,ls,b=bank('refinement');cert=c.compile_certificate(b,m.contract['carrier']);cert['spatial_candidates'].pop();cert['digest']=c.seal('Certificate',{k:v for k,v in cert.items() if k!='digest'});before=m.snapshot()
        with self.assertRaisesRegex(ValueError,'registration_semantics'):m.reduce(dict(kind='registration3d_result',at=0,certificate=cert))
        self.assertEqual(m.snapshot(),before)
    def test_reads_do_not_run_hidden_search(self):
        m,ls,b=bank()
        with patch('continuous3d_bank.compile_certificate',side_effect=AssertionError('hidden_search')):m.snapshot();m.plan()
    def test_new_port_has_no_implicit_room_grid_join(self):
        m,ls,b=bank();p=m.snapshot()['observation_port'];self.assertEqual(p['profile'],'grfps-observation-port/3');self.assertEqual(p['joining'],dict(spatial='Unknown',clock='Unknown'));self.assertEqual(p['external_effects'],[])
    def test_certificate_is_single_and_pre_import(self):
        m,ls,b=bank();event=dict(kind='registration3d_result',at=0,certificate=c.compile_certificate(b,m.contract['carrier']));n=m.reduce(event)[0]
        with self.assertRaisesRegex(ValueError,'registration_lifecycle'):n.reduce(event)
        n=m.reduce(dict(kind='carrier_record',at=0,index=0,raw=ls[0]))[0]
        with self.assertRaisesRegex(ValueError,'registration_lifecycle'):n.reduce(event)
    def test_segment_replay_and_resume_preserve_cover_and_work(self):
        m,ls,b=bank('reference_reset');contract=m.contract;contract['segment_records']=16
        with tempfile.TemporaryDirectory(dir='/tmp') as d:
            j=SegmentJournal(Path(d)/'j',contract);j.commit(dict(kind='registration3d_result',at=0,certificate=c.compile_certificate(b,contract['carrier'])))
            for i,row in enumerate(ls):j.commit(dict(kind='carrier_record',at=i,index=i,raw=row));j.commit(dict(kind='tick',at=i))
            j.commit(dict(kind='stop',at=j.machine.mapper.at,reason='user'));old=j.machine.snapshot();j.close();j=SegmentJournal.reopen(Path(d)/'j');j.commit(dict(kind='resume',at=j.machine.mapper.at+6000));now=j.machine.snapshot()
            for key in ['registered3d','registration_certificate','registration_work','spent']:self.assertEqual(now[key],old[key])
            j.close();r=replay(Path(d)/'j');self.assertEqual(r['machine'].snapshot(),now);self.assertGreater(r['index'],0)
if __name__=='__main__':unittest.main()
