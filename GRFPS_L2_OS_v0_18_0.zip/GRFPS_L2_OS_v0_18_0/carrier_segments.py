"""Linked full-state boundaries. Recovery verifies all history, never trusts a hash alone."""
import os
from pathlib import Path
from grfps_l2 import canon,loads,require
from carrier_bank import CarrierBank as RegisteredBank,PROFILE,seal,checkpoint

MAX_LINE=2*1024*1024

def header(m,index,previous):
    h=dict(profile=PROFILE,index=index,previous=previous,sequence=m.seq,contract=m.contract,state_digest=m.snapshot()['state_digest'],checkpoint=checkpoint(m))
    return dict(h,digest=seal('SegmentHeader',h))
def record(m,e,parent):
    n,out=m.reduce(e);r=dict(profile=PROFILE,sequence=m.seq,parent=parent,event=e,pre=m.snapshot()['state_digest'],post=n.snapshot()['state_digest'],output=out)
    return n,dict(r,digest=seal('Transition',r))
def replay(directory,collect=False):
    paths=sorted(Path(directory).glob('segment-*.jsonl'));require(paths,'missing_segments');m=None;head=None;views=[];events=[];count=0
    for index,path in enumerate(paths):
        require(path.name==f'segment-{index:06d}.jsonl','segment_gap')
        with path.open('rb') as f:
            def line():
                b=f.readline(MAX_LINE+1);require(len(b)<=MAX_LINE and (not b or b.endswith(b'\n')),'segment_line');return loads(b) if b else None
            h=line();require(type(h) is dict and 'contract' in h,'segment_header')
            if m is None:
                m=RegisteredBank(h['contract'])
                if collect:views.append(m.snapshot())
            require(index<m.contract['max_segments'],'segment_limit');require(canon(h)==canon(header(m,index,head)),'checkpoint_or_link')
            head=h['digest'];count=0
            while (r:=line()) is not None:
                require(count<m.contract['segment_records'],'segment_capacity')
                if index and count==0:require(r['event'].get('kind')=='rollover','missing_rollover')
                n,expected=record(m,r['event'],head);require(canon(r)==canon(expected),'record_semantics');m=n;head=r['digest'];count+=1
                if collect:views.append(m.snapshot());events.append(r['event'])
        require(index==len(paths)-1 or count==m.contract['segment_records'],'premature_boundary')
    return dict(machine=m,head=head,index=len(paths)-1,count=count,views=views,events=events)

class SegmentJournal:
    def __init__(self,directory,c):
        self.directory=Path(directory);self.machine=RegisteredBank(c);self.index=0;self.count=0;self.head=None;self.failed=False
        self.directory.mkdir(parents=True,exist_ok=False);self._open_segment()
    def _write(self,obj):
        data=canon(obj)+b'\n';require(len(data)<=MAX_LINE,'line_capacity');st=self.path.stat();fd=os.fstat(self.stream.fileno())
        require((st.st_dev,st.st_ino)==(fd.st_dev,fd.st_ino) and self.stream.tell()==fd.st_size,'writer_identity_or_size')
        self.stream.write(data);self.stream.flush();os.fsync(self.stream.fileno())
    def _open_segment(self):
        self.path=self.directory/f'segment-{self.index:06d}.jsonl';self.stream=self.path.open('xb')
        h=header(self.machine,self.index,self.head)
        try:self._write(h)
        except BaseException:self.failed=True;self.stream.close();raise
        self.head=h['digest'];self.count=0
    def _commit(self,e):
        n,r=record(self.machine,e,self.head)
        try:self._write(r)
        except BaseException:self.failed=True;raise
        self.machine=n;self.head=r['digest'];self.count+=1
    def commit(self,e):
        require(not self.failed,'writer_failed');require(e.get('kind')!='rollover','rotation_owned_by_journal')
        # Validate against the prospective boundary state before writing anything.
        preview=self.machine
        if self.count==self.machine.contract['segment_records']:
            require(self.index+1<self.machine.contract['max_segments'],'total_capacity')
            rotation=dict(kind='rollover',at=self.machine.mapper.at,epoch=self.index+1)
            preview=preview.reduce(rotation)[0]
        elif self.index and self.count==0:
            preview=preview.reduce(dict(kind='rollover',at=self.machine.mapper.at,epoch=self.index))[0]
        preview.reduce(e)
        if self.count==self.machine.contract['segment_records']:
            self.stream.close();self.index+=1;self._open_segment();self._commit(rotation)
        elif self.index and self.count==0:
            # A fully written header with no first record is a recoverable boundary.
            self._commit(dict(kind='rollover',at=self.machine.mapper.at,epoch=self.index))
        self._commit(e);return self.machine.snapshot()
    def close(self):self.stream.close()
    @classmethod
    def reopen(cls,directory):
        r=replay(directory);j=cls.__new__(cls);j.directory=Path(directory);j.machine=r['machine'];j.head=r['head'];j.index=r['index'];j.count=r['count'];j.failed=False
        j.path=j.directory/f'segment-{j.index:06d}.jsonl';j.stream=j.path.open('ab');return j
