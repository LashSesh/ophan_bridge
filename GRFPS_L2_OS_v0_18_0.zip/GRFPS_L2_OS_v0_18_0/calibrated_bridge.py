"""Versioned model references, sampled drift and latched gate revocation.
The detector is an engineering adaptation, not spectral flow or quantum holonomy.
"""
import copy
from pathlib import Path
from grfps_l2 import canon,fields,uint,require
from uncertain_bridge import UncertainBank,config as uncertain_config,checkpoint
from mapping import hashof
PROFILE='grfps-calibrated-bank/0.9.0'
def seal(kind,x):return hashof(kind,dict(profile=PROFILE,value=x))
def vector(v):return type(v) is list and len(v)==2 and all(type(x) is int and -32<=x<=32 for x in v)
def config(world,field,orientation,calibration):
    c=uncertain_config(world,field,orientation);c.update(profile=PROFILE,calibration_world=str(Path(calibration).resolve()),calibration_cost=1,calibration_refresh=200,calibration_ttl=800,calibration_limit=1)
    return c
def calibration_fixture(offset=None):return dict(profile='grfps-reference-fixture/1',units='model_grid_step',offset=offset or [0,0])
def validate_fixture(w):
    fields(w,'profile units offset');require(w['profile']=='grfps-reference-fixture/1' and w['units']=='model_grid_step' and vector(w['offset']),'calibration_fixture');return w

class CalibratedBank(UncertainBank):
    def __init__(self,c):
        extra=['calibration_world','calibration_cost','calibration_refresh','calibration_ttl','calibration_limit'];fields(c,'profile bank segment_records max_segments scope_cells registrations probe_world probe_cost '+' '.join(extra));canon(c)
        require(c['profile']==PROFILE and type(c['calibration_world']) is str and 0<len(c['calibration_world'])<=1024,'calibration_path')
        require(uint(c['calibration_cost']) and 1<=c['calibration_cost']<=16 and uint(c['calibration_limit']) and c['calibration_limit']<=16,'calibration_bounds')
        require(uint(c['calibration_refresh']) and uint(c['calibration_ttl']) and 10<=c['calibration_refresh']<c['calibration_ttl']<=1000000,'calibration_time')
        base={k:v for k,v in c.items() if k not in extra};base['profile']='grfps-uncertain-bank/0.8.0';super().__init__(base);self.contract=copy.deepcopy(c)
        self.calibration=dict(revision=1,reference=[0,0],activated_at=0,units='model_grid_step',limit=c['calibration_limit'])
        self.calibration_sample=None;self.calibration_attempt=-c['calibration_refresh'];self.revoked=False;self.breaches=0;self.pending_calibration=None
    def calibration_ref(self):return seal('Calibration',self.calibration)
    def monitor(self):
        e=self.calibration_sample;fresh=e is not None and e['calibration_ref']==self.calibration_ref() and e['frame']==self.mapper.frame and self.mapper.at<e['sampled_at']+self.contract['calibration_ttl']
        residual=max(abs(e['offset'][i]-self.calibration['reference'][i]) for i in range(2)) if fresh else None
        cls='UNKNOWN' if not fresh else 'WITHIN' if residual<=self.calibration['limit'] else 'DRIFT'
        status='REVOKED' if self.revoked else 'VALID' if cls=='WITHIN' else 'UNKNOWN'
        return dict(status=status,flag=True if self.revoked else False if status=='VALID' else None,sample_class=cls,breach_count=self.breaches,residual=residual,calibration_ref=self.calibration_ref(),revision=self.calibration['revision'],reference=copy.deepcopy(self.calibration['reference']),limit=self.calibration['limit'],sample=copy.deepcopy(e) if fresh else None)
    def recalibration_proposal(self):
        m=self.monitor()
        if self.phase!='RUNNING' or self.pending or not m['sample'] or self.calibration['revision']>=128:return None
        return dict(previous=self.calibration_ref(),revision=self.calibration['revision']+1,reference=m['sample']['offset'],sample_ref=seal('CalibrationSample',m['sample']))
    def projections(self):
        out=super().projections();m=self.monitor()
        for b in out:
            b['calibration_ref']=self.calibration_ref();b['calibration_status']=m['status']
            if m['status']!='VALID':b.update(gate='HOLD',epistemic='Unknown',value=None,reason='calibration_'+m['status'].lower())
        return out
    def plan(self):
        if self.phase!='RUNNING' or self.active.paused or self.pending:return None
        if self.mapper.at-self.calibration_attempt>=self.contract['calibration_refresh'] and self.spent+self.contract['calibration_cost']<=self.config['budget']:
            return dict(organ='calibration_probe',cost=self.contract['calibration_cost'],frame=self.mapper.frame,payload=dict(calibration_ref=self.calibration_ref()))
        return super().plan() if self.monitor()['status']=='VALID' else None
    def snapshot(self):
        s=super().snapshot();s.update(profile=PROFILE,calibration=copy.deepcopy(self.calibration),drift=self.monitor(),pending_calibration=self.pending_calibration,recalibration_proposal=self.recalibration_proposal(),contract_ref=seal('Contract',self.contract))
        s['bank'].append(dict(id='calibration_probe',type='ReferenceOffset',cost=self.contract['calibration_cost'],last_dispatch=None));s['state_digest']=seal('State',{k:v for k,v in s.items() if k!='state_digest'});return s
    def _registered(self,e):
        k=e.get('kind')
        if k=='dispatch' and e.get('proposal',{}).get('organ')=='calibration_probe':
            fields(e,'kind at proposal');require(self.phase=='RUNNING','stopped');self._active(dict(kind='tick',at=e['at']));p=self.plan();require(p is not None and canon(p)==canon(e['proposal']),'proposal_binding')
            self.spent+=p['cost'];self.request_count+=1;r=dict(id='bank'+str(self.request_count),organ=p['organ'],cost=p['cost'],frame=self.mapper.frame,issued_at=e['at'],deadline=e['at']+self.config['timeout'],payload=p['payload']);r['exposure']=seal('CalibrationExposure',r);self.pending=r;self.calibration_attempt=e['at'];self.last=dict(kind=k,request=r)
        elif k=='calibration_result':
            fields(e,'kind at request exposure outcome offset sampled_at sample_ref');r=self.pending
            require(self.phase=='RUNNING' and r and r['organ']=='calibration_probe' and e['request']==r['id'] and e['exposure']==r['exposure'],'calibration_binding')
            require(e['outcome'] in ['OK','ERROR','TIMEOUT'],'calibration_outcome');require(e['outcome']!='TIMEOUT' or e['at']>=r['deadline'],'early_timeout')
            if e['outcome']=='OK':
                require(vector(e['offset']) and uint(e['sampled_at']) and r['issued_at']<=e['sampled_at']<=e['at'],'calibration_sample')
                require(type(e['sample_ref']) is str and len(e['sample_ref'])==64 and all(c in '0123456789abcdef' for c in e['sample_ref']),'sample_ref')
            else:require(e['offset'] is None and e['sampled_at'] is None and e['sample_ref'] is None,'failure_payload')
            self._active(dict(kind='tick',at=e['at']));status='SUPERSEDED' if r['frame']!=self.mapper.frame or r['payload']['calibration_ref']!=self.calibration_ref() else 'TIMEOUT' if e['at']>r['deadline'] else e['outcome']
            if status=='OK':
                self.calibration_sample=dict(offset=e['offset'],sampled_at=e['sampled_at'],sample_ref=e['sample_ref'],frame=r['frame'],calibration_ref=r['payload']['calibration_ref'],request=r['id'])
                if self.monitor()['sample_class']=='DRIFT' and not self.revoked:self.breaches+=1;self.revoked=True
            self.pending=None;self.last=dict(kind=k,status=status,drift=self.monitor())
        elif k=='recalibrate':
            fields(e,'kind at proposal');require(self.phase=='RUNNING','stopped');self._active(dict(kind='tick',at=e['at']));p=self.recalibration_proposal();require(p is not None and canon(p)==canon(e['proposal']),'recalibration_witness')
            previous=copy.deepcopy(self.calibration);self.calibration=dict(revision=p['revision'],reference=p['reference'],activated_at=e['at'],units=previous['units'],limit=previous['limit'])
            self.revoked=False;self.calibration_sample=None;self.calibration_attempt=-self.contract['calibration_refresh'];self._active(dict(kind='frame',at=e['at']));self.last=dict(kind=k,previous=previous,calibration=copy.deepcopy(self.calibration),witness=p)
        elif k=='calibrated_result':
            fields(e,'kind at calibration_ref event');require(self.pending is not None and e['calibration_ref']==self.pending_calibration and e['calibration_ref']==self.calibration_ref(),'result_calibration')
            inner=e['event'];require(type(inner) is dict and inner.get('kind') in ['window_result','scoped_boolean','probe_result'] and inner.get('at')==e['at'],'calibrated_type');super()._registered(inner);self.pending_calibration=None;self.last=dict(kind=k,calibration_ref=e['calibration_ref'],result=self.last)
        elif k in ['window_result','scoped_boolean','probe_result']:raise ValueError('uncalibrated_result_forbidden')
        else:
            super()._registered(e)
            if k=='dispatch':self.pending_calibration=self.calibration_ref()
            if k=='resume':self.pending_calibration=None
