"""Historical XR plus a finite registered 3-D target, with existing live geometry."""
import argparse,json,subprocess,sys,threading,time,webbrowser
from pathlib import Path
from grfps_l2 import canon,loads,require
from carrier_contract import preflight,load as load_trace
from carrier_bank import config as carrier_config
from carrier_runtime import CarrierService,sources
from registration3d import compile_certificate,load_bundle
from registration3d_fixtures import dataset,CASES
from registered3d_bank import config
from registered3d_segments import SegmentJournal,replay
from adapters import MonotonicClock
from live import server_for

def worker_certificate(bundle,carrier):
    data=canon(dict(bundle=bundle,carrier=carrier));r=subprocess.run([sys.executable,str(Path(__file__).with_name('registration3d_worker.py'))],input=data,capture_output=True,timeout=10,check=True);c=loads(r.stdout);require(c==compile_certificate(bundle,carrier),'worker_certificate');return c

def html(data):return Path(__file__).with_name('registered3d_viewer.html').read_text().replace('__REGISTERED3D_DATA__',json.dumps(data,ensure_ascii=True).replace('<','\u003c'))
def export(directory,target):
    r=replay(directory,collect=True);Path(target).write_text(html(dict(mode='replay',views=r['views'],events=r['events'],head=r['head'])));m=r['machine'];return dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,requests=m.request_count,nodes_spent=m.nodes_spent,head=r['head'],state_digest=m.snapshot()['state_digest'])
def initialize(d,raw,mf,bundle):
    cc,lines,_=preflight(raw,mf);cert=worker_certificate(bundle,cc)
    d.mkdir(parents=True,exist_ok=False);(d/'carrier.jsonl').write_bytes(raw);(d/'carrier_manifest.json').write_bytes(canon(mf));(d/'registration3d.json').write_bytes(canon(bundle));base=carrier_config(sources(d),cc);base.update(segment_records=32,calibration_refresh=500);j=SegmentJournal(d/'journal',config(base,bundle));j.commit(dict(kind='registration3d_result',at=0,certificate=cert));return j,lines

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',default='registered3d_run');p.add_argument('--case',choices=CASES,default='baseline');p.add_argument('--trace');p.add_argument('--manifest');p.add_argument('--registration');p.add_argument('--resume',action='store_true');p.add_argument('--duration',type=float,default=3);p.add_argument('--open',action='store_true');a=p.parse_args();require(0<a.duration<=3600,'duration');d=Path(a.out).resolve()
    if a.resume:
        r=replay(d/'journal');cc,lines,_=load_trace(d/'carrier.jsonl',r['machine'].contract['carrier']['manifest']);require(cc==r['machine'].contract['carrier'],'carrier_source_changed');bundle=load_bundle(d/'registration3d.json',cc);require(bundle==r['machine'].contract['registration3d'],'registration_source_changed');j=SegmentJournal.reopen(d/'journal');offset=j.machine.mapper.at+6000;j.commit(dict(kind='resume',at=offset));clock=MonotonicClock(offset)
    else:
        if a.trace or a.manifest or a.registration:
            require(a.trace and a.manifest and a.registration,'three_inputs_required');mf=loads(Path(a.manifest).read_bytes());cc,lines,_=load_trace(a.trace,mf);raw=''.join(lines).encode('ascii');bundle=load_bundle(a.registration,cc)
        else:raw,mf,bundle=dataset(a.case)
        j,lines=initialize(d,raw,mf,bundle);clock=MonotonicClock()
    s=CarrierService(j,clock,lines=lines);server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));th=threading.Thread(target=server.serve_forever,daemon=True);th.start();url=f'http://127.0.0.1:{server.server_port}/';print(url,flush=True)
    if a.open:webbrowser.open(url)
    end=time.monotonic()+a.duration
    try:
        while True:
            if time.monotonic()>=end:s.stop_reason='duration'
            if not s.cycle():break
            time.sleep(.025)
    except KeyboardInterrupt:
        s.stop_reason='user'
        while s.cycle():time.sleep(.025)
    finally:server.shutdown();server.server_close();th.join();s.close()
    print(json.dumps(export(d/'journal',d/'replay.html'),indent=2))
if __name__=='__main__':main()
