"""Live uncertain windows and budgeted joint geometry on the retained organ bank.
Snapshots never run the solver. Only a bound, verified solver result can admit.
"""
import copy
from pathlib import Path
from grfps_l2 import canon,fields,ident,uint,require
from noisy_bridge import NoisyBank,config as noisy_config,seal as noisy_seal,checkpoint
from noisy_certificate import PROTOCOL,evaluate,seal as certificate_seal
from mapping import hashof
from source_registration import validate_capture,clock_certificate,spatial_certificate,TARGETS
from source_geometry import solve

PROFILE='grfps-multisource-bank/0.14.0'
def seal(kind,x):return hashof(kind,dict(profile=PROFILE,value=x))
def config(world,field,orientation,calibration,sensor):
    c=noisy_config(world,field,orientation,calibration)
    c.update(profile=PROFILE,geometry=dict(source=str(Path(sensor).resolve()),windows=['left','right'],anchor='left',
        query=dict(kind='x_greater',a='A',b='B'),ttl=5000,refresh=2000,retry=200,
        costs=dict(coarse=2,fine=3),node_limit=4096,node_budget=65536,pose_bound=8))
    c['geometry'].update(sources={n:dict(id='camera_'+n,path=str(Path(sensor).with_name(n+'.json').resolve())) for n in ['left','right']},reference='room_grid',max_skew=1000)
    c['bank'].update(budget=128,timeout=3000);c.update(calibration_refresh=400,calibration_ttl=5000)
    return c


class SourceBank(NoisyBank):
    def __init__(self,c):
        require(type(c) is dict and c.get('profile')==PROFILE and 'geometry' in c,'geometry_profile')
        g=c['geometry'];fields(g,'source windows anchor query ttl refresh retry costs node_limit node_budget pose_bound sources reference max_skew')
        require(type(g['source']) is str and 1<=len(g['source'])<=1024,'source_path')
        require(type(g['windows']) is list and 1<=len(g['windows'])<=4 and all(ident(n) for n in g['windows']) and g['windows']==sorted(set(g['windows'])),'window_contract')
        require(g['anchor']==g['windows'][0],'fixed_anchor')
        require(type(g['sources']) is dict and set(g['sources'])==set(g['windows']) and g['reference']=='room_grid' and uint(g['max_skew']) and 10<=g['max_skew']<=g['ttl'],'source_contract')
        for spec in g['sources'].values():
            fields(spec,'id path');require(ident(spec['id']) and type(spec['path']) is str and 1<=len(spec['path'])<=1024,'source_spec')
        require(len({s['id'] for s in g['sources'].values()})==len(g['sources']) and len({s['path'] for s in g['sources'].values()})==len(g['sources']),'separate_sources')
        fields(g['query'],'kind a b');require(g['query']['kind']=='x_greater' and ident(g['query']['a']) and ident(g['query']['b']) and g['query']['a']!=g['query']['b'],'query')
        require(all(uint(g[k]) for k in ['ttl','refresh','retry','node_limit','node_budget','pose_bound']),'geometry_integers')
        require(10<=g['retry']<=g['refresh']<g['ttl']<=1000000 and 1<=g['node_limit']<=100000 and g['node_limit']<=g['node_budget']<=1000000 and g['pose_bound']==8,'geometry_bounds')
        fields(g['costs'],'coarse fine');require(all(uint(v) and 1<=v<=16 for v in g['costs'].values()),'geometry_costs')
        base=copy.deepcopy(c);base.pop('geometry');base['profile']='grfps-noisy-bank/0.11.0';super().__init__(base)
        self.contract=copy.deepcopy(c);self.box_windows={};self.window_attempts={};self.precision={}
        self.solution=None;self.solve_attempt=None;self.nodes_spent=0;self.nodes_reserved=0;self.geometry_last=None;self.source_epochs={n:0 for n in g['windows']}

    def bind_proposal(self):return None
    def projections(self):return []
    def compactable(self):return []
    @property
    def geometry_contract(self):return self.contract['geometry']

    def live_windows(self):
        return {n:v for n,v in self.box_windows.items() if v['frame']==self.mapper.frame and v['calibration_ref']==self.calibration_ref() and v['observation']['epoch']==self.source_epochs[n] and self.mapper.at<v['clock_registration']['interval'][0]+self.geometry_contract['ttl']}

    def temporal_status(self):
        live=self.live_windows()
        if len(live)!=len(self.geometry_contract['windows']):return 'required_source_missing'
        intervals=[v['clock_registration']['interval'] for v in live.values()]
        return 'PASS' if max(x[1] for x in intervals)-min(x[0] for x in intervals)<=self.geometry_contract['max_skew'] else 'temporal_scope_gap'

    def inputs(self):
        live=self.live_windows();g=self.geometry_contract;cert=self.calibration['certificate']
        if cert is None or self.temporal_status()!='PASS':return None
        return dict(windows={n:v['observation']['points'] for n,v in sorted(live.items())},candidates=cert['candidates'],query=g['query'],pose_bound=g['pose_bound'],
                    anchor=g['anchor'],reference=g['reference'],calibration_ref=self.calibration_ref(),frame=self.mapper.frame,
                    spatial={n:v['spatial_registration'] for n,v in sorted(live.items())},
                    evidence={n:seal('AcceptedWindow',v) for n,v in sorted(live.items())})

    def binding(self):
        i=self.inputs();return seal('GeometryInputs',i) if i else None

    def answer(self):
        g=self.geometry_contract;live=self.live_windows();binding=self.binding();s=self.solution
        result=s['result'] if s and s['binding']==binding and binding else None
        reason=self.temporal_status() if self.temporal_status()!='PASS' else 'awaiting_geometry'
        status='Unknown';value=None
        if self.nodes_spent+self.nodes_reserved>=g['node_budget'] and result is None:reason='compute_budget_exhausted'
        if result:
            reason=result['reason']
            if result['status']=='FEASIBLE':
                status='Known' if len(result['values'])==1 else 'Ambiguous'
                if status=='Known':value=result['values'][0]
        monitor=self.monitor()['status']
        if monitor!='VALID':status='Unknown';value=None;reason='calibration_'+monitor.lower()
        if self.phase!='RUNNING':status='Unknown';value=None;reason='stopped'
        return dict(epistemic=status,value=value,reason=reason,anchor=g['anchor'],query=g['query'],frame=self.mapper.frame,
                    registration_ref=seal('QueryFrame',dict(reference=g['reference'],targets=TARGETS,windows=g['windows'],query=g['query'])),reference=g['reference'],binding=binding)

    def ordinary_plan(self):
        g=self.geometry_contract;live=self.live_windows();at=self.mapper.at
        if self.nodes_spent>=g['node_budget']:return None
        def request(n,mode,reason):
            cost=g['costs'][mode]
            if self.spent+cost>self.config['budget']:return None
            return dict(organ='geometry_window',cost=cost,frame=self.mapper.frame,payload=dict(window=n,mode=mode,reason=reason,calibration_ref=self.calibration_ref(),source_id=g['sources'][n]['id'],source_epoch=self.source_epochs[n]))
        missing=[n for n in g['windows'] if n not in live and at-self.window_attempts.get(n,-g['retry'])>=g['retry']]
        if missing:
            n=min(missing,key=lambda n:(self.window_attempts.get(n,-1),n))
            return request(n,self.precision.get(n,'coarse'),'missing_or_expired')
        if self.temporal_status()=='temporal_scope_gap':
            return request(min(live,key=lambda n:live[n]['clock_registration']['interval'][0]),self.precision.get(min(live,key=lambda n:live[n]['clock_registration']['interval'][0]),'coarse'),'temporal_refresh')
        binding=self.binding()
        if binding and (self.solution is None or self.solution['binding']!=binding) and self.solve_attempt!=binding:
            return dict(organ='geometry_solver',cost=0,frame=self.mapper.frame,payload=dict(binding=binding,inputs=self.inputs(),node_limit=min(g['node_limit'],g['node_budget']-self.nodes_spent),calibration_ref=self.calibration_ref()))
        result=self.solution['result'] if self.solution and self.solution['binding']==binding else None
        if result and (result['status']!='FEASIBLE' or len(result['values'])>1):
            refine=[n for n,v in live.items() if self.precision.get(n)=='coarse' and any(p['radius'] for p in v['observation']['points'].values()) and at-self.window_attempts.get(n,0)>=g['retry']]
            if refine:return request(min(refine,key=lambda n:(self.window_attempts[n],n)),'fine','geometry_challenge')
        due=[n for n in g['windows'] if at-self.window_attempts.get(n,-g['refresh'])>=g['refresh']]
        if due:return request(min(due,key=lambda n:(self.window_attempts.get(n,-1),n)),self.precision.get(min(due,key=lambda n:(self.window_attempts.get(n,-1),n)),'coarse'),'refresh')
        return None

    def plan(self):
        if self.phase!='RUNNING' or self.active.paused or self.pending:return None
        ordinary=self.ordinary_plan() if self.monitor()['status']=='VALID' else None
        if self.calibration_yield and ordinary:return ordinary
        if evaluate(self.fresh_campaign())['status']=='PASS' and self.monitor()['status']!='VALID':return None
        if self.mapper.at-self.calibration_attempt>=self.contract['calibration_refresh'] and self.spent+self.contract['calibration_cost']<=self.config['budget']:
            stage=self.next_stage();campaign=self.fresh_campaign()
            return dict(organ='calibration_probe',cost=self.contract['calibration_cost'],frame=self.mapper.frame,payload=dict(calibration_ref=self.calibration_ref(),protocol_ref=certificate_seal('Protocol',PROTOCOL),stage=stage,fit_ref=noisy_seal('AcceptedFit',campaign['fit']) if stage!='fit' else None,series_ref=campaign['fit']['observation']['series_ref'] if stage!='fit' else None))
        return ordinary

    def snapshot(self):
        s=super().snapshot();g=self.geometry_contract;binding=self.binding()
        s.update(profile=PROFILE,geometry_answer=self.answer(),box_windows=copy.deepcopy(self.live_windows()),geometry_solution=copy.deepcopy(self.solution) if self.solution and self.solution['binding']==binding else None,
                 geometry_last=copy.deepcopy(self.geometry_last),search_budget=dict(spent=self.nodes_spent,reserved=self.nodes_reserved,total=g['node_budget'],per_request=g['node_limit']),
                 contract_ref=seal('Contract',self.contract),source_epochs=copy.deepcopy(self.source_epochs),temporal_status=self.temporal_status(),reference=g['reference'])
        s['bank']=[dict(id='calibration_probe',type='BoundedCalibration',cost=self.contract['calibration_cost']),dict(id='geometry_window',type='UncertainWindow',cost=g['costs']),dict(id='geometry_solver',type='JointGeometry',cost_unit='search_nodes')]
        s['state_digest']=seal('State',{k:v for k,v in s.items() if k!='state_digest'});return s

    def _registered(self,e):
        k=e.get('kind')
        if k=='dispatch' and e.get('proposal',{}).get('organ') in ['geometry_window','geometry_solver']:
            fields(e,'kind at proposal');self._active(dict(kind='tick',at=e['at']));p=self.plan()
            require(p is not None and canon(p)==canon(e['proposal']),'proposal_binding')
            self.spent+=p['cost'];self.request_count+=1
            r=dict(id='bank'+str(self.request_count),organ=p['organ'],cost=p['cost'],frame=self.mapper.frame,issued_at=e['at'],deadline=e['at']+self.config['timeout'],payload=copy.deepcopy(p['payload']))
            r['exposure']=seal('Exposure',r);self.pending=r;self.pending_calibration=self.calibration_ref();self.calibration_yield=False
            if p['organ']=='geometry_window':self.window_attempts[p['payload']['window']]=e['at']
            else:self.nodes_reserved=p['payload']['node_limit'];self.solve_attempt=p['payload']['binding']
            self.last=dict(kind=k,request=r)
        elif k=='geometry_result':
            fields(e,'kind at request exposure calibration_ref outcome data sampled_at sample_ref');r=self.pending
            require(self.phase=='RUNNING' and r and r['organ'] in ['geometry_window','geometry_solver'] and r['id']==e['request'] and r['exposure']==e['exposure'] and r['payload']['calibration_ref']==e['calibration_ref'],'geometry_binding')
            require(e['outcome'] in ['OK','ERROR','TIMEOUT'],'geometry_outcome');require(e['outcome']!='TIMEOUT' or e['at']>=r['deadline'],'early_timeout')
            nodes=r['payload']['node_limit'] if r['organ']=='geometry_solver' else 0
            if e['outcome']=='OK':
                require(uint(e['sampled_at']) and r['issued_at']<=e['sampled_at']<=e['at'],'sample_time')
                require(e['sample_ref']==seal('WorkerSample',dict(exposure=r['exposure'],data=e['data'],sampled_at=e['sampled_at'])),'sample_hash')
                if r['organ']=='geometry_window':
                    validate_capture(e['data'],r)
                    clock=clock_certificate(e['data']['clock'],r['issued_at'],e['sampled_at'],self.geometry_contract['ttl'])
                    spatial=spatial_certificate(e['data']['beacons'],self.calibration['certificate']['candidates'] if self.calibration['certificate'] else [])
                else:
                    i=r['payload']['inputs'];expected=solve(i,r['payload']['node_limit'])
                    require(canon(e['data'])==canon(expected),'solver_semantics');nodes=expected['nodes']
            else:require(e['data'] is None and e['sampled_at'] is None and e['sample_ref'] is None,'failure_payload')
            self._active(dict(kind='tick',at=e['at']))
            status='SUPERSEDED' if r['frame']!=self.mapper.frame or e['calibration_ref']!=self.calibration_ref() else 'TIMEOUT' if e['at']>r['deadline'] else e['outcome']
            if r['organ']=='geometry_window' and r['payload']['source_epoch']!=self.source_epochs[r['payload']['window']]:status='SUPERSEDED'
            if r['organ']=='geometry_solver':
                self.nodes_spent+=nodes;self.nodes_reserved=0
                if status=='OK' and r['payload']['binding']!=self.binding():status='STALE_INPUTS'
                if status=='OK':self.solution=dict(binding=r['payload']['binding'],result=copy.deepcopy(e['data']),request=r['id'],sample_ref=e['sample_ref'])
            elif status=='OK':
                o=e['data'];name=o['window']
                if clock['status']!='PASS' or spatial['status']!='PASS':
                    status='CLOCK_'+clock['status'] if clock['status']!='PASS' else 'SPATIAL_REJECTED';self.box_windows.pop(name,None)
                elif self.mapper.at>=clock['interval'][0]+self.geometry_contract['ttl']:status='EXPIRED'
                else:
                    status=o['outcome']
                    if status=='OK':
                        accepted=dict(observation=copy.deepcopy(o),sampled_at=e['sampled_at'],frame=r['frame'],calibration_ref=e['calibration_ref'],request=r['id'],exposure=r['exposure'],sample_ref=e['sample_ref'],clock_registration=clock,spatial_registration=spatial)
                        all_ids=set(o['points'])
                        for n,v in self.live_windows().items():
                            if n!=name:all_ids.update(v['observation']['points'])
                        require(len(all_ids)<=8,'active_landmark_limit')
                        self.box_windows[name]=accepted;self.precision[name]=o['mode']
                    else:self.box_windows.pop(name,None)
            elif r['organ']=='geometry_window' and status in ['ERROR','TIMEOUT']:
                self.box_windows.pop(r['payload']['window'],None)
            self.pending=None;self.pending_calibration=None;self.geometry_last=dict(status=status,organ=r['organ'],request=r['id'],nodes=nodes)
            self.last=dict(kind=k,**self.geometry_last)
        elif k=='source_reset':
            fields(e,'kind at window previous epoch');n=e['window']
            require(self.phase=='RUNNING' and n in self.source_epochs and uint(e['previous']) and uint(e['epoch']) and e['previous']==self.source_epochs[n] and e['epoch']==e['previous']+1 and e['epoch']<=128,'source_epoch_transition')
            self._active(dict(kind='tick',at=e['at']));self.source_epochs[n]=e['epoch'];self.box_windows.pop(n,None);self.window_attempts.pop(n,None);self.precision.pop(n,None);self.solution=None;self.solve_attempt=None
            self.last=dict(kind=k,window=n,epoch=e['epoch'])
        elif k in ['noisy_result','window_result','scoped_boolean','probe_result']:raise ValueError('legacy_geometry_input_forbidden')
        else:
            super()._registered(e)
            if k in ['resume','frame','recalibrate']:
                if k=='resume':self.nodes_spent+=self.nodes_reserved;self.nodes_reserved=0
                self.box_windows={};self.window_attempts={};self.precision={};self.solution=None;self.solve_attempt=None

