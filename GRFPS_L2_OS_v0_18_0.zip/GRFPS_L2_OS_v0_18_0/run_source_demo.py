"""Six actual worker/HTTP experiments; immutable full-history evidence."""
import argparse,copy,json,shutil,tempfile,threading,time,urllib.request
from pathlib import Path
from source_runtime import SourceService,sources,html,export
from source_segments import SegmentJournal,replay
from source_registration import fixture,seal as source_seal
from noisy_certificate import fixture as chart_fixture,seal as chart_seal
from live import server_for
CASES=['moving_sources','clock_rejection','spatial_rejection','temporal_gap','registered_conflict','registered_limit']

def run_case(d,case):
    d.mkdir();c=sources(d);samples=d/'samples';samples.mkdir()
    def write(name,w):
        ref=chart_seal('Series',w) if name=='calibration' else source_seal('Source',w);raw=json.dumps(w).encode();(samples/(ref+'.json')).write_bytes(raw)
        p=d/(name+'.next');p.write_bytes(raw);p.replace(d/(name+'.json'))
    sensors={n:fixture(n) for n in ['left','right']};write('calibration',chart_fixture([0,0,0]))
    if case=='clock_rejection':sensors['left']['clock_check_shift']=1
    if case=='spatial_rejection':sensors['left']['beacons']['H0'][0]+=1
    if case=='registered_conflict':
        for v in sensors['right']['channels'].values():v['points']['A']['center']=[8,0]
    for n,w in sensors.items():write(n,w)
    c.update(segment_records=16,calibration_refresh=200,calibration_ttl=5000);c['bank'].update(budget=256,timeout=3000);c['geometry'].update(ttl=4000,refresh=1400,retry=100,max_skew=2000)
    if case=='temporal_gap':c['geometry']['max_skew']=10
    if case=='registered_limit':c['geometry'].update(node_limit=1,node_budget=2)
    j=SegmentJournal(d/'journal',c);s=SourceService(j);stages=[];checks=0;step=0
    def stage(label):
        st=s.current;stages.append(dict(stage=label,sequence=st['sequence'],answer=st['geometry_answer'],epochs=st['source_epochs'],last=st['geometry_last']))
    server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])));th=threading.Thread(target=server.serve_forever,daemon=True);th.start();url=f'http://127.0.0.1:{server.server_port}'
    def control(kind,**extra):
        req=urllib.request.Request(url+'/api/control',data=json.dumps(dict(kind=kind,**extra)).encode(),headers={'Content-Type':'application/json','Origin':url},method='POST')
        with urllib.request.urlopen(req) as response:assert response.status==202
    end=time.monotonic()+35
    try:
        while time.monotonic()<end:
            assert s.cycle();st=s.current;a=st['geometry_answer'];last=st['geometry_last'];sol=st['geometry_solution']
            with urllib.request.urlopen(url+'/api/updates') as response:v=json.load(response)
            assert v['snapshot']['state_digest']==st['state_digest'];checks+=1
            if case=='clock_rejection' and last and last['status']=='CLOCK_CHECK_REJECTED':stage('clock_check_rejected');break
            if case=='spatial_rejection' and last and last['status']=='SPATIAL_REJECTED':stage('spatial_check_rejected');break
            if case=='temporal_gap' and st['temporal_status']=='temporal_scope_gap':stage('temporal_scope_gap');break
            if case=='registered_conflict' and sol and sol['result']['status']=='CONFLICT':stage('registered_conflict');break
            if case=='registered_limit' and st['search_budget']['spent']==2:stage('compute_budget_exhausted');break
            if case=='moving_sources':
                if step==0 and a['epistemic']=='Ambiguous':stage('coarse_ambiguous');step=1
                elif step==1 and a['epistemic']=='Known':
                    assert a['value'] is True;stage('fine_known');sensors['left']=fixture('left',1,[2,3,-2]);write('left',sensors['left']);control('source_reset',window='left',previous=0,epoch=1);step=2
                elif step==2 and st['source_epochs']['left']==1:
                    assert a['epistemic']=='Unknown';stage('motion_revokes_old_proof');step=3
                elif step==3 and a['epistemic']=='Known':
                    assert a['value'] is True;stage('rotated_window_fixed_answer');sensors['right']=fixture('right',1,offset=900);write('right',sensors['right']);control('source_reset',window='right',previous=0,epoch=1);step=4
                elif step==4 and st['source_epochs']['right']==1:
                    assert a['epistemic']=='Unknown';stage('clock_epoch_revokes_old_proof');step=5
                elif step==5 and a['epistemic']=='Known':
                    assert a['value'] is True and st['box_windows']['right']['clock_registration']['offsets']==[899,900,901];stage('new_clock_registered_known')
                    # A repeated lifecycle notification must be rejected without crashing.
                    control('source_reset',window='right',previous=0,epoch=1);step=6
                elif step==6 and any(x['status']=='STALE_SOURCE_EPOCH' for x in s.command_results):stage('duplicate_reset_rejected');break
            time.sleep(.02)
        else:raise AssertionError(json.dumps(dict(case=case,step=step,snapshot=s.current)))
        s.stop_reason='user'
        while s.cycle():time.sleep(.02)
    finally:server.shutdown();server.server_close();th.join();s.close()
    old=replay(d/'journal')['machine'];j=SegmentJournal.reopen(d/'journal');j.commit(dict(kind='resume',at=old.mapper.at+6000));ss=j.machine.snapshot()
    assert ss['spent']==old.spent and ss['search_budget']['spent']==old.nodes_spent and ss['source_epochs']==old.source_epochs and ss['geometry_answer']['epistemic']=='Unknown'
    j.commit(dict(kind='stop',at=j.machine.mapper.at,reason='user'));j.close()
    report=export(d/'journal',d/'replay.html');report.update(case=case,http_checks=checks,stages=stages,command_results=list(s.command_results),restart_preserved_epochs=old.source_epochs)
    (d/'report.json').write_text(json.dumps(report,indent=2));return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='source_evidence_run');a=p.parse_args();target=Path(a.out).resolve();assert not target.exists()
    with tempfile.TemporaryDirectory(prefix='grfps014_',dir='/tmp') as tmp:
        work=Path(tmp)/'proof';work.mkdir()
        for name in CASES:
            r=run_case(work/name,name);print(json.dumps({name:{k:r[k] for k in ['transitions','spent','requests','nodes_spent','http_checks']}}),flush=True)
        from verify_sources import verify
        verified=verify(work,export_views=False);(work/'integration_report.json').write_text(json.dumps(verified,indent=2));shutil.copytree(work,target)
if __name__=='__main__':main()
