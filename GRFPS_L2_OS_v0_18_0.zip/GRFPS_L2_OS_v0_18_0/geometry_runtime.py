"""Live joint geometry: existing calibration, worker scheduling, journal and HTTP."""
import argparse,json,subprocess,sys,threading,time,webbrowser
from pathlib import Path
from grfps_l2 import canon,loads,fields,require
from noisy_runtime import NoisyService
from geometry_bank import config
from geometry_segments import SegmentJournal,replay
from geometry_sensor import fixture as sensor_fixture
from noisy_certificate import fixture as chart_fixture
from bank_runtime import fixture as atlas_fixture
from field_world import generate_world
from adapters import MonotonicClock
from live import server_for


class GeometryService(NoisyService):
    def failure(self,r,outcome):
        if r['organ'] not in ['geometry_window','geometry_solver']:return super().failure(r,outcome)
        at=max(self.now(),r['deadline']+1) if outcome=='TIMEOUT' else self.now()
        return dict(kind='geometry_result',at=at,request=r['id'],exposure=r['exposure'],calibration_ref=r['payload']['calibration_ref'],outcome=outcome,data=None,sampled_at=None,sample_ref=None)

    def measure(self,r):
        if r['organ'] not in ['geometry_window','geometry_solver']:return super().measure(r)
        try:
            p=subprocess.run([sys.executable,str(Path(__file__).with_name('geometry_worker.py')),self.engine.machine.geometry_contract['source']],
                input=canon(dict(request=r,start_ns=self.clock.start_ns,offset=self.clock.offset)),capture_output=True,timeout=max(.001,(r['deadline']-self.now())/1000))
            require(p.returncode==0 and len(p.stdout)<=262144,'geometry_worker_protocol');v=loads(p.stdout)
            fields(v,'data sampled_at exposure sample_ref');require(v['exposure']==r['exposure'],'worker_exposure')
            return dict(kind='geometry_result',at=self.now(),request=r['id'],exposure=r['exposure'],calibration_ref=r['payload']['calibration_ref'],outcome='OK',data=v['data'],sampled_at=v['sampled_at'],sample_ref=v['sample_ref'])
        except subprocess.TimeoutExpired:return self.failure(r,'TIMEOUT')
        except (OSError,ValueError):return self.failure(r,'ERROR')


def html(data):return Path(__file__).with_name('geometry_viewer.html').read_text().replace('__GEOMETRY_DATA__',json.dumps(data,ensure_ascii=True).replace('<','\\u003c'))


def export(directory,target):
    r=replay(directory,collect=True);Path(target).write_text(html(dict(mode='replay',views=r['views'],events=r['events'],head=r['head'])))
    m=r['machine'];return dict(transitions=m.seq,segments=r['index']+1,spent=m.spent,requests=m.request_count,nodes_spent=m.nodes_spent,head=r['head'],state_digest=m.snapshot()['state_digest'],revision=m.calibration['revision'],breaches=m.breaches)


def sources(d,case='refinement'):
    values=dict(world=atlas_fixture(),field=generate_world(23,sectors=4,depth=2),orientation=dict(profile='grfps-orientation-fixture/1',registrations=dict(AB_ray=[0,1,2,3])),calibration=chart_fixture([0,0,0]),sensor=sensor_fixture(case))
    for k,v in values.items():(d/(k+'.json')).write_text(json.dumps(v,indent=2))
    c=config(*(d/(n+'.json') for n in ['world','field','orientation','calibration','sensor']))
    c['geometry']['windows']=sorted(values['sensor']['windows']);return c


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',default='geometry_run');p.add_argument('--resume',action='store_true');p.add_argument('--duration',type=float,default=15);p.add_argument('--open',action='store_true');a=p.parse_args()
    require(0<a.duration<=3600,'duration');d=Path(a.out).resolve()
    if a.resume:
        j=SegmentJournal.reopen(d/'journal');offset=j.machine.mapper.at+max(j.machine.geometry_contract['ttl'],j.machine.contract['calibration_ttl'])+1
        j.commit(dict(kind='resume',at=offset));clock=MonotonicClock(offset)
    else:d.mkdir(parents=True,exist_ok=False);j=SegmentJournal(d/'journal',sources(d));clock=MonotonicClock()
    s=GeometryService(j,clock);server=server_for(s,html_factory=lambda _:html(dict(mode='live',views=[s.current],events=[])))
    t=threading.Thread(target=server.serve_forever,daemon=True);t.start();url=f'http://127.0.0.1:{server.server_port}/';print(url,flush=True)
    if a.open:webbrowser.open(url)
    end=time.monotonic()+a.duration
    try:
        while True:
            if time.monotonic()>=end:s.stop_reason='duration'
            if not s.cycle():break
            time.sleep(.03)
    except KeyboardInterrupt:
        s.stop_reason='user'
        while s.cycle():time.sleep(.03)
    finally:server.shutdown();server.server_close();t.join();s.close()
    print(json.dumps(export(d/'journal',d/'replay.html'),indent=2))

if __name__=='__main__':main()
