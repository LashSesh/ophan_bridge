"""Reproduce boundary failures in the unchanged uploaded physical evaluator.
The two audited modules are loaded in an isolated package; no third-party deps.
"""
import copy,hashlib,importlib.util,json,sys,tempfile,types,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ZIP_SHA='92e8099645eabd4e2938bee436cd1bfdb921796940d0719fd4d3a9880b7063b4'
def report():
    archive=ROOT/'sources/Physical_Carrier_Integration_v0_6_0.zip';assert hashlib.sha256(archive.read_bytes()).hexdigest()==ZIP_SHA
    with tempfile.TemporaryDirectory(dir='/tmp') as tmp:
        tmp=Path(tmp);package='_grfps015_audited';pkg=types.ModuleType(package);pkg.__path__=[str(tmp)];sys.modules[package]=pkg
        with zipfile.ZipFile(archive) as z:
            for name in ['canon','physical']:
                path=tmp/(name+'.py');path.write_bytes(z.read('python/grfps_refkernel/'+name+'.py'));spec=importlib.util.spec_from_file_location(package+'.'+name,path);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
            reference=json.loads(z.read('conformance/capability-envelope.simulated.json'));rows=[json.loads(x) for x in z.read('examples/openxr-telemetry.rehearsal.jsonl').splitlines()]
        P=m.PhysicalCarrierSession;E=m.PhysicalCarrierEvaluator;Policy=m.PhysicalCarrierPolicy
        session=P('s','c','r','LOCAL')
        for r in rows:
            if r['record_kind']=='frame':session.append_frame(r)
            else:session.append_event(r)
        baseline=session.seal();w=E.evaluate(baseline);cap=E.capability_envelope(witness=w,simulated_reference=reference)
        checks={}
        checks['synthetic_promoted_to_device_measured']=all(f['source_api']=='DRY_RUN' for f in baseline['frames']) and cap['status']=='DEVICE_MEASURED'
        s=copy.deepcopy(baseline)
        for f in s['frames']:f.pop('tracking_state')
        checks['missing_tracking_counts_as_fully_tracked']=E.evaluate(s)['metrics']['tracking_fraction']==1
        s=copy.deepcopy(baseline)
        for f in s['frames']:f['tracking_state']='POSITION_VALID'
        checks['partial_validity_counts_as_fully_tracked']=E.evaluate(s)['metrics']['tracking_fraction']==1
        s=copy.deepcopy(baseline);s['frames'][0]['head_pose']['position_m']=[999,999,999]
        checks['tampered_unrehashed_session_still_passes']=E.evaluate(s)['status']=='MEASURED_PASS'
        f=copy.deepcopy(rows[0]);f['session_id']='intruder';checks['frame_can_override_session_identity']=P('owner','c','r','LOCAL').append_frame(f)['session_id']=='intruder'
        f=copy.deepcopy(rows[0]);f['head_pose']['position_m']=[True];checks['boolean_and_wrong_pose_dimension_accepted']=len(P('s','c','r','LOCAL').append_frame(f)['head_pose']['position_m'])==1
        s=copy.deepcopy(baseline);s['events']=[];checks['no_interactions_still_passes_interaction_check']=E.evaluate(s)['checks']['interaction']
        s=copy.deepcopy(baseline);s['external_measurements']['DisplayLatency_ms']={};checks['empty_external_object_satisfies_required_display_check']=E.evaluate(s,Policy(require_external_display_latency=True))['checks']['display_latency']
        s=copy.deepcopy(baseline)
        for f in s['frames']:f.pop('registration_error_m')
        negative_control=E.evaluate(s)['metrics']['registration_error_m']['p95'] is None and not E.evaluate(s)['checks']['registration']
        assert all(checks.values()) and negative_control
        return dict(archive_sha256=ZIP_SHA,baseline_frames=len(baseline['frames']),baseline_events=len(baseline['events']),baseline_status=w['status'],baseline_capability_status=cap['status'],reproduced_boundary_failures=checks,negative_control_missing_registration_is_unknown=negative_control,meaning='Observed behavior of supplied evaluator; not hardware evidence.')
if __name__=='__main__':print(json.dumps(report(),indent=2))
