import copy,tempfile,unittest
from pathlib import Path
from calibration_certificate import chart_fixture,evaluate,validate_chart,validate_certificate,corrected_patch,seal
from mapping import transform,inverse
from certified_bridge import CertifiedBank,config
from certified_segments import SegmentJournal,replay
from test_uncertain import answer as uncertain_answer

def machine():return CertifiedBank(config('/tmp/w','/tmp/f','/tmp/o','/tmp/c'))
def dispatch(m):return m.reduce(dict(kind='dispatch',at=m.mapper.at,proposal=m.plan()))[0]
def answer(m,chart=None):
    if m.pending['organ']=='calibration_probe':
        r=m.pending;w=chart_fixture() if chart is None else chart;return dict(kind='calibration_result',at=m.mapper.at+1,request=r['id'],exposure=r['exposure'],outcome='OK',chart=w,sampled_at=m.mapper.at+1,sample_ref=seal('Chart',w))
    e=uncertain_answer(m)
    if e['kind']=='window_result' and e['event']['kind']=='patch':
        p=e['event']['patch'];t=m.calibration['certificate']['transform'];p['points']={k:list(transform(v,inverse(t))) for k,v in p['points'].items()}
    return dict(kind='certified_result',at=e['at'],calibration_ref=m.pending_calibration,event=e)
def sampled(chart=None):
    m=dispatch(machine());return m.reduce(answer(m,chart))[0]
def adopt(m):return m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=m.recalibration_proposal()))[0]
def calibrated():
    m=dispatch(adopt(sampled()));return m.reduce(answer(m))[0]
def known():
    m=calibrated()
    for _ in range(16):
        if m.projections()[0]['epistemic']=='Known':return m
        m=dispatch(m);m=m.reduce(answer(m))[0]
    raise AssertionError('not known')
def refresh(m,chart=None):
    m=m.reduce(dict(kind='tick',at=m.mapper.at+m.contract['calibration_refresh']))[0];m=dispatch(m);return m.reduce(answer(m,chart))[0]
def window_pending():
    m=calibrated()
    for _ in range(16):
        m=dispatch(m)
        if m.pending['organ']=='window':return m
        m=m.reduce(answer(m))[0]
    raise AssertionError('window absent')
def bad_check():
    w=chart_fixture();w['points'][-1]['reference'][0]+=1;return w

class CertificateTests(unittest.TestCase):
    def test_all_rotations_and_translations(self):
        for q in range(4):
            for t in [[q,0,0],[q,3,-2],[q,-6,5]]:self.assertEqual(evaluate(chart_fixture(t))['certificate']['transform'],t)
    def test_bad_fit(self):
        w=chart_fixture();w['points'][1]['reference'][0]+=1;self.assertEqual(evaluate(w)['status'],'FIT_REJECTED')
    def test_check_failure_cannot_change_fit(self):
        good=evaluate(chart_fixture());bad=evaluate(bad_check());self.assertEqual(bad['status'],'CHECK_REJECTED');self.assertEqual(bad['transform'],good['transform']);self.assertIsNone(bad['certificate'])
    def test_tampered_certificate(self):
        w=chart_fixture();c=evaluate(w)['certificate'];c['transform'][1]+=1
        with self.assertRaises(ValueError):validate_certificate(c,w)
    def test_degenerate_fit(self):
        w=chart_fixture()
        for i in range(3):w['points'][i]['raw']=[i,i]
        with self.assertRaises(ValueError):validate_chart(w)
    def test_duplicate_partition_point(self):
        for key in ['id','raw','reference']:
            w=chart_fixture();w['points'][-1][key]=w['points'][0][key]
            with self.assertRaises(ValueError):validate_chart(w)
    def test_missing_check(self):
        w=chart_fixture();w['points'][-1]['role']='fit'
        with self.assertRaises(ValueError):validate_chart(w)
    def test_boolean_and_outside_domain(self):
        for v in [True,65,1.1]:
            w=chart_fixture();w['points'][0]['raw'][0]=v
            with self.assertRaises(ValueError):validate_chart(w)
    def test_threshold_change_forbidden(self):
        w=chart_fixture();w['protocol']['check_limit']=1
        with self.assertRaises(ValueError):evaluate(w)
    def test_order_does_not_change_transform(self):
        w=chart_fixture();w['points'].reverse();self.assertEqual(evaluate(w)['transform'],[1,3,-2])

class CertifiedTests(unittest.TestCase):
    def test_initial_unknown_even_with_pass(self):
        m=sampled();self.assertEqual(m.monitor()['candidate']['status'],'PASS');self.assertEqual(m.monitor()['status'],'UNKNOWN');self.assertIsNone(m.plan())
    def test_failed_check_cannot_adopt(self):
        m=sampled(bad_check());self.assertIsNone(m.recalibration_proposal())
        with self.assertRaises(ValueError):adopt(m)
    def test_adoption_invalidates_geometry_and_monitor(self):
        m=adopt(sampled());self.assertEqual(m.calibration['revision'],1);self.assertEqual(m.mapper.frame,1);self.assertEqual(m.monitor()['status'],'UNKNOWN');self.assertIsNone(m.projections()[0]['value'])
    def test_corrected_geometry_known(self):
        m=known();self.assertIs(m.projections()[0]['value'],True)
        p=next(p for p in m.mapper.patches.values() if 'A' in p['points']);self.assertEqual([p['points']['B'][i]-p['points']['A'][i] for i in range(2)],[2,0])
    def test_raw_patch_and_derived_ref(self):
        m=window_pending();e=answer(m);raw=e['event']['event']['patch'];expected=corrected_patch(raw,m.calibration['certificate'],m.calibration_ref());m=m.reduce(e)[0]
        self.assertEqual(m.mapper.patches[raw['id']],expected);self.assertNotEqual(raw['points'],expected['points']);self.assertNotEqual(raw['sample_ref'],expected['sample_ref'])
    def test_drift_latched_even_after_return(self):
        m=refresh(known(),chart_fixture([2,1,0]));self.assertTrue(m.revoked);m=refresh(m);self.assertEqual(m.monitor()['sample_class'],'WITHIN');self.assertEqual(m.monitor()['status'],'REVOKED');self.assertEqual(m.breaches,1)
    def test_new_transform_requires_new_evidence(self):
        m=refresh(known(),chart_fixture([2,1,0]));spent=m.spent;m=adopt(m);self.assertEqual(m.calibration['certificate']['transform'],[2,1,0]);self.assertEqual(m.spent,spent);self.assertEqual(m.monitor()['status'],'UNKNOWN');self.assertIsNone(m.projections()[0]['value'])
    def test_repeat_drift_single_breach(self):
        m=refresh(calibrated(),bad_check());m=refresh(m,bad_check());self.assertEqual(m.breaches,1)
    def test_expired_proposal(self):
        m=sampled();p=m.recalibration_proposal()
        with self.assertRaises(ValueError):m.reduce(dict(kind='recalibrate',at=801,proposal=p))
    def test_pending_adoption(self):
        m=calibrated();p=m.recalibration_proposal();m=dispatch(m)
        with self.assertRaises(ValueError):m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=p))
    def test_tampered_proposal(self):
        m=sampled();p=m.recalibration_proposal();p['certificate']['transform'][0]=0
        with self.assertRaises(ValueError):m.reduce(dict(kind='recalibrate',at=m.mapper.at,proposal=p))
    def test_binding_and_chart_hash(self):
        m=dispatch(machine())
        for key in ['exposure','sample_ref']:
            e=answer(m);e[key]='0'*64
            with self.assertRaises(ValueError):m.reduce(e)
    def test_old_frame_result(self):
        m=dispatch(machine());e=answer(m);m=m.reduce(dict(kind='frame',at=0))[0];m=m.reduce(e)[0];self.assertEqual(m.last['status'],'SUPERSEDED')
    def test_late_chart(self):
        m=dispatch(machine());e=answer(m);e['at']=m.pending['deadline']+1;m=m.reduce(e)[0];self.assertEqual(m.last['status'],'TIMEOUT');self.assertIsNone(m.recalibration_proposal())
    def test_error_keeps_cost(self):
        m=dispatch(machine());e=answer(m);e.update(outcome='ERROR',chart=None,sampled_at=None,sample_ref=None);m=m.reduce(e)[0];self.assertEqual(m.spent,1);self.assertIsNone(m.recalibration_proposal())
    def test_unwrapped_and_wrong_version(self):
        m=dispatch(calibrated());e=answer(m)
        with self.assertRaises(ValueError):m.reduce(e['event'])
        e['calibration_ref']='0'*64
        with self.assertRaises(ValueError):m.reduce(e)
    def test_raw_outside_domain_rejected(self):
        m=window_pending();e=answer(m);e['event']['event']['patch']['points']['A']=[65,0]
        with self.assertRaises(ValueError):m.reduce(e)
    def test_paused_no_adoption(self):
        m=sampled();m=m.reduce(dict(kind='pause',at=m.mapper.at,paused=True))[0];self.assertIsNone(m.recalibration_proposal())
    def test_replay_pending_across_segment(self):
        with tempfile.TemporaryDirectory(dir='/tmp') as t:
            c=config('/tmp/w','/tmp/f','/tmp/o','/tmp/c');c['segment_records']=16;j=SegmentJournal(Path(t)/'j',c)
            for _ in range(15):j.commit(dict(kind='tick',at=0))
            j.commit(dict(kind='dispatch',at=0,proposal=j.machine.plan()));j.commit(answer(j.machine));s=j.machine.snapshot();j.close();self.assertEqual(replay(Path(t)/'j')['machine'].snapshot(),s)
    def test_restart_preserves_certificate_and_cost(self):
        m=refresh(known(),bad_check());old=copy.deepcopy(m.calibration);spent=m.spent;m=m.reduce(dict(kind='stop',at=m.mapper.at,reason='user'))[0];m=m.reduce(dict(kind='resume',at=2000))[0]
        self.assertEqual(m.calibration,old);self.assertEqual(m.spent,spent);self.assertTrue(m.revoked);self.assertEqual(m.monitor()['status'],'REVOKED')
if __name__=='__main__':unittest.main()
