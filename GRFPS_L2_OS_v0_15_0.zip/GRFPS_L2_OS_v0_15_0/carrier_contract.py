"""Bounded XR file adapter. Exact decimal input; no physical promotion.
Raw bytes are retained. Micrometre intervals enclose representation only.
"""
import copy,hashlib,json
from decimal import Decimal,ROUND_FLOOR,ROUND_CEILING,localcontext
from pathlib import Path
from grfps_l2 import require,fields,ident,uint,canon
PROFILE='grfps-carrier-port/0.15.0'
MAX_BYTES=2097152;MAX_LINE=32768;MAX_RECORDS=512

def sha(raw):return hashlib.sha256(raw).hexdigest()
def seal(kind,value):return sha(canon(dict(profile=PROFILE,kind=kind,value=value)))
def read_line(raw):
    require(type(raw) is str and len(raw.encode('ascii'))<=MAX_LINE,'ascii_line_limit')
    def pairs(items):
        d={}
        for k,v in items:require(k not in d,'duplicate_key');d[k]=v
        return d
    def bad(x):raise ValueError('nonfinite_number')
    o=json.loads(raw,parse_float=Decimal,parse_constant=bad,object_pairs_hook=pairs)
    require(type(o) is dict,'record_object');return o

def number(x,bound=10000):
    require(type(x) in [int,Decimal] and (type(x) is int or x.is_finite()),'finite_number')
    d=Decimal(x);require(abs(d)<=bound and (-48<=d.as_tuple().exponent<=6) and len(d.as_tuple().digits)<=64,'numeric_bounds');return d

def interval(x,scale=1000000,bound=10000):
    with localcontext() as ctx:
        ctx.prec=128;d=number(x,bound)*scale
        return [int(d.to_integral_value(rounding=ROUND_FLOOR)),int(d.to_integral_value(rounding=ROUND_CEILING))]
def decimal_text(x):
    d=number(x,2);s=format(d,'f');return s.rstrip('0').rstrip('.') if '.' in s else s

def timestamp(x):
    require(type(x) is int and 0<=x<=2**63-1,'timestamp');return str(x)
def label(x):require(ident(x),'identifier');return x

def pose(x):
    fields(x,'position_m orientation_xyzw');p=x['position_m'];q=x['orientation_xyzw']
    require(type(p) is list and len(p)==3 and type(q) is list and len(q)==4,'pose_dimensions')
    coords=[interval(v) for v in p];qs=[number(v,2) for v in q]
    with localcontext() as ctx:
        ctx.prec=128;require(Decimal('.98')<=sum(v*v for v in qs)<=Decimal('1.02'),'quaternion_norm')
    return dict(position_um=coords,orientation_xyzw=[decimal_text(v) for v in q],error_kind='decimal_representation_only')

def manifest(origin='synthetic',api='DRY_RUN',reference='LOCAL'):
    return dict(profile=PROFILE,origin=origin,source_api=api,session_id='carrier_session',carrier_id='carrier_instance',runtime='declared_runtime',reference_space=reference,timebase='performance_ns' if api=='WebXR' else 'runtime_ns' if api=='OpenXR' else 'synthetic_ns')
def validate_manifest(m):
    fields(m,'profile origin source_api session_id carrier_id runtime reference_space timebase');require(m['profile']==PROFILE and m['origin'] in ['synthetic','recorded'],'manifest')
    require(m['source_api'] in ['DRY_RUN','OpenXR','WebXR'] and (m['source_api']!='DRY_RUN' or m['origin']=='synthetic'),'origin_promotion')
    require(m['timebase']==('performance_ns' if m['source_api']=='WebXR' else 'runtime_ns' if m['source_api']=='OpenXR' else 'synthetic_ns'),'timebase')
    for k in ['session_id','carrier_id','runtime','reference_space']:label(m[k])
    return m

class CarrierState:
    def __init__(self,m):
        self.manifest=copy.deepcopy(validate_manifest(m));self.cursor=0;self.frame_count=0;self.event_count=0;self.epoch=0;self.reference=m['reference_space'];self.last_time=None;self.last_frame_time=None;self.latest=None;self.last_event=None;self.head=None
        self.counts=dict(tracked=0,partial=0,unavailable=0,registration_present=0,application_present=0,provenance_present=0);self.application_upper_us=[];self.registration_upper_um=[]
    def apply(self,raw):
        r=read_line(raw);kind=r.get('record_kind');t=timestamp(r.get('monotonic_time_ns'))
        require(self.last_time is None or int(t)>=int(self.last_time),'source_time_regression')
        for k in ['session_id','carrier_id','runtime']:
            if k in r:require(r[k]==self.manifest[k],'source_identity_override')
        if kind=='frame':
            required=set('record_kind frame_index monotonic_time_ns predicted_display_time_ns predicted_display_period_ns session_state should_render head_pose views'.split())
            optional=set('tracking_state registration_error_m application_frame_ms provenance_ref source_api reference_space source_epoch session_id carrier_id runtime capture_status view_state_flags head_location_flags callback_time_ns callback_interval_ns emulated_position'.split())
            require(required<=set(r)<=required|optional,'frame_fields')
            require(type(r['frame_index']) is int and r['frame_index']==self.frame_count,'frame_sequence')
            require(self.last_frame_time is None or int(t)>int(self.last_frame_time),'frame_time_regression')
            require(r.get('source_api')==self.manifest['source_api'],'source_api_binding')
            require(r.get('reference_space',self.reference)==self.reference and type(r.get('source_epoch',self.epoch)) is int and r.get('source_epoch',self.epoch)==self.epoch,'reference_epoch_binding')
            require(type(r['should_render']) is bool,'render_flag');label(r['session_state'])
            predicted=None if r['predicted_display_time_ns'] is None else timestamp(r['predicted_display_time_ns'])
            period=None if r['predicted_display_period_ns'] is None else timestamp(r['predicted_display_period_ns'])
            require(period is None or int(period)>0,'display_period')
            tracking=r.get('tracking_state','UNAVAILABLE');require(tracking in ['TRACKED','PARTIAL','UNAVAILABLE','POSITION_VALID','ORIENTATION_VALID'],'tracking_state')
            hp=None if r['head_pose'] is None else pose(r['head_pose'])
            require(tracking not in ['TRACKED','PARTIAL','POSITION_VALID','ORIENTATION_VALID'] or hp is not None,'tracked_pose_missing')
            emulated=r.get('emulated_position');require(emulated is None or type(emulated) is bool,'emulation_flag')
            if emulated is True and tracking=='TRACKED':tracking='PARTIAL'
            if 'head_location_flags' in r:
                flags=r['head_location_flags'];require(type(flags) is int and 0<=flags<=15,'head_flags')
                if not flags&3:tracking='UNAVAILABLE'
                elif flags!=15 and tracking=='TRACKED':tracking='PARTIAL'
            if 'capture_status' in r:
                cs=r['capture_status'];fields(cs,'xrLocateSpace xrLocateViews');require(all(type(v) is int for v in cs.values()),'capture_status')
                if cs['xrLocateSpace']<0:tracking='UNAVAILABLE'
            for k in ['callback_time_ns','callback_interval_ns']:
                if r.get(k) is not None:timestamp(r[k])
            require(type(r['views']) is list and len(r['views'])<=4,'views')
            views=[];ids=set()
            for v in r['views']:
                require(type(v) is dict and set(v)<=set('index eye pose transform fov projection_matrix'.split()),'view_fields')
                key=v.get('eye',v.get('index'));require((type(key) is int and 0<=key<4 or type(key) is str and key in ['left','right','none']) and str(key) not in ids,'view_identity');ids.add(str(key))
                vp=v.get('pose',v.get('transform'));require(vp is not None,'view_pose')
                views.append(dict(id=str(key),pose=pose(vp)))
                if 'projection_matrix' in v:require(type(v['projection_matrix']) is list and len(v['projection_matrix'])==16 and all(abs(number(x,1000000))<=1000000 for x in v['projection_matrix']),'projection_matrix')
                if 'fov' in v:
                    fields(v['fov'],'angle_left angle_right angle_up angle_down');require(all(abs(number(x,4))<=4 for x in v['fov'].values()),'fov')
            if 'view_state_flags' in r:
                f=r['view_state_flags'];require(type(f) is int and 0<=f<=15,'view_flags')
                if f&3!=3:views=[]
            if 'capture_status' in r and r['capture_status']['xrLocateViews']<0:views=[]
            reg=r.get('registration_error_m');app=r.get('application_frame_ms')
            for v in [reg,app]:
                if v is not None:require(number(v)>=0,'negative_measurement')
            ri=None if reg is None else interval(reg);ai=None if app is None else interval(app,1000)
            provenance=r.get('provenance_ref');require(provenance is None or (type(provenance) is str and provenance.isascii() and len(provenance)<=256),'provenance')
            if ri is not None:self.counts['registration_present']+=1;self.registration_upper_um.append(ri[1])
            if ai is not None:self.counts['application_present']+=1;self.application_upper_us.append(ai[1])
            if provenance:self.counts['provenance_present']+=1
            self.counts['tracked' if tracking=='TRACKED' else 'unavailable' if tracking=='UNAVAILABLE' else 'partial']+=1
            self.latest=dict(frame_index=self.frame_count,source_time_ns=t,display_time_ns=predicted,display_period_ns=period,reference_space=self.reference,epoch=self.epoch,tracking=tracking,pose=hp if tracking=='TRACKED' and r['should_render'] else None,views=views,registration_um=ri,application_us=ai,provenance_ref=provenance,should_render=r['should_render'])
            self.last_frame_time=t;self.frame_count+=1
        elif kind=='event':
            k=r.get('kind')
            require(k in ['interaction','visibility','reference_reset'],'event_kind')
            if k=='reference_reset':
                fields(r,'record_kind kind monotonic_time_ns previous epoch reference_space');require(type(r['previous']) is int and type(r['epoch']) is int and r['previous']==self.epoch and r['epoch']==self.epoch+1 and r['epoch']<=128,'reference_reset')
                self.epoch=r['epoch'];self.reference=label(r['reference_space']);self.latest=None
            elif k=='visibility':
                fields(r,'record_kind kind monotonic_time_ns visibility_state');label(r['visibility_state'])
                if r['visibility_state']=='hidden':self.latest=None
            else:
                require(set('record_kind kind action monotonic_time_ns'.split())<=set(r)<=set('record_kind kind action roundtrip_ok monotonic_time_ns input_source'.split()),'interaction_fields');label(r['action'])
                if 'input_source' in r:label(r['input_source'])
                if 'roundtrip_ok' in r:require(type(r['roundtrip_ok']) is bool,'roundtrip_type')
            self.last_event=dict(kind=k,source_time_ns=t,action=r.get('action'),effect_status='Unknown',receipt=None);self.event_count+=1
        else:raise ValueError('record_kind')
        self.last_time=t;self.head=seal('CarrierRecord',dict(parent=self.head,index=self.cursor,raw_ref=sha(raw.encode('ascii'))));self.cursor+=1
        return self.snapshot()
    def snapshot(self):
        def metric(xs):return dict(count=len(xs),missing=self.frame_count-len(xs),max=max(xs) if xs else None)
        return dict(profile=PROFILE,origin=self.manifest['origin'],facticity='Simulated' if self.manifest['origin']=='synthetic' else 'Recorded',physical_validation='Unknown',temporal_scope='historical_file',timebase=self.manifest['timebase'],reference_space=self.reference,epoch=self.epoch,cursor=self.cursor,frames=self.frame_count,events=self.event_count,head=self.head,latest=copy.deepcopy(self.latest),last_event=copy.deepcopy(self.last_event),counts=copy.deepcopy(self.counts),application_us=metric(self.application_upper_us),registration_um=metric(self.registration_upper_um),world_registration='Unknown',display_latency='Unknown',interaction_reconciliation='Unknown')

def preflight(raw,m):
    require(type(raw) is bytes and 0<len(raw)<=MAX_BYTES,'trace_bytes');raw.decode('ascii');lines=raw.decode('ascii').splitlines(keepends=True)
    require(1<=len(lines)<=MAX_RECORDS and all(x.strip() for x in lines),'trace_records');state=CarrierState(m)
    for line in lines:state.apply(line)
    require(state.frame_count>0,'no_frames')
    c=dict(profile=PROFILE,manifest=copy.deepcopy(m),raw_sha256=sha(raw),record_refs=[sha(x.encode('ascii')) for x in lines],record_count=len(lines))
    return c,lines,state.snapshot()

def load(path,m):
    with Path(path).open('rb') as f:raw=f.read(MAX_BYTES+1)
    return preflight(raw,m)
